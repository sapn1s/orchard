/**
 * Claude Station — the real UI.
 *
 * Everything on screen comes from the live server: the registry, the
 * session-history index of ~/.claude/projects, and the typed StationEvent
 * stream over the WebSocket. There is no canned data in this file.
 *
 * Scale note: the session store holds ~676 files. Sessions are fetched per
 * project on first expand and rendered in pages of 40, so the sidebar never
 * builds more DOM than the user has actually opened. Search loads every
 * project's index once, then filters in memory.
 */
import { $, el, clear, svg, mmss, kilo, bytes, when, shortPath, toolArg, prose, inlineInto, setText, setHidden, setAttr } from './lib/dom.js';
import * as api from './lib/api.js';
import { createDrawer } from './lib/drawer.js';
import { createSlidePanel } from './lib/slide-panel.js';
import { createGitView } from './lib/git-view.js';
import { parseQuestions, parsePlan, createQuestionCard, createPlanCard, markUnanswered } from './lib/question.js';
import { createDecideCard } from './lib/decide.js';
import { ticketView, NOT_RECORDED, WORK_STATE_LABEL, HUMAN_ACTION_LABEL, outstandingBroken, INVISIBLE_CLAIM } from './lib/ticket-record.js';
import { renderAssistantText } from './lib/digest.js';
import { renderRequestsInto } from './lib/requests-view.js';
import { parseHash, formatHash, sameRoute, parseTicketsHash, formatTicketsHash, parseGuideHash, formatGuideHash, parseGitHash, formatGitHash } from './lib/route.js';

/*
 * Sessions shown per project before the "N more" affordance.
 *
 * Deliberately small. The sidebar's job is to get you to a project first and a
 * session second; with ~28 rows one expanded project buried the other five
 * entirely. Six is roughly one screen-third, so every project stays on screen
 * at once and depth is one click away rather than a scroll away.
 */
/**
 * The settings fields the server accepts as per-session overrides. Anything
 * else (isolation, mounts, container.*) is rejected with a fatal error by
 * design — honouring it would mean rebuilding the container and leaking the
 * change into every other session on the project.
 */
/*
 * FEAT-045: 'provider' has been in the SERVER's SESSION_OVERRIDE_FIELDS since
 * FEAT-037 P3, but this client-side mirror lacked it — so an armed session-
 * scope provider (drawer or the launch control) silently never rode `start`.
 */
/*
 * THIS IS A HAND-MAINTAINED MIRROR of `SESSION_OVERRIDE_FIELDS` in
 * `src/server/validate.ts` (that constant names this one back). A field missing
 * HERE is armable in the UI and then silently never put on the `start` frame —
 * which is exactly what happened to 'provider' above. The two lists are asserted
 * SET-EQUAL mechanically by `scripts/verify-feat-145-session-override.mjs`; run
 * it after touching either side.
 *
 * FEAT-145: 'claudeAccount' — which Claude subscription this one session bills
 * to. The server accepts it for `direct` projects and refuses it fatally for
 * container ones (the credential is a container bind mount, not an env var).
 */
const SESSION_OVERRIDABLE = ['provider', 'model', 'effort', 'claudeAccount', 'permissionMode', 'maxBudgetUsd', 'allowedTools', 'disallowedTools'];

const PAGE = 6;
/** How many more a click of "N more" reveals — a screenful, not a trickle. */
const PAGE_MORE = 20;
/*
 * Recorded agents shown per session before "N more". A real overnight run in
 * this store has 113 of them; dropping all 113 hairlines at the end of the
 * transcript is the same wall the sidebar had, so the same restraint applies.
 */
const RAN_PAGE = 8;
const RAN_MORE = 25;

const state = {
  projects: [],
  sessions: new Map(), // projectId -> { loading, error, list, shown }
  expanded: new Set(),
  /*
   * FEAT-070 — how the project list is ordered: 'recency' (lastActivityAt desc,
   * the default) or 'alpha' (by name). `projOrder` is the STABLE captured id
   * order the tree actually renders — recomputed only on an explicit refresh or
   * a sort flip, never on every render, so a background activity bump cannot
   * reshuffle the sidebar under the user mid-session (the reorder-churn the
   * app.js:177 rationale warned about). See resortProjects().
   */
  projSort: 'recency',
  projOrder: [],
  current: { projectId: null, encodedDir: null, sessionId: null, title: null, os: null },
  /*
   * session-list-recency — the client's optimistic "the human just submitted
   * here" stamps, keyed by sessionId → ISO time. stampUserSubmit writes this on a
   * composer send; recencyKey reads MAX(server lastUserMessageAt, this stamp) so
   * the reorder-to-top SURVIVES the wholesale s.list replacement in loadSessions.
   * Without it, any refetch that re-derives an OLDER server value — a large
   * SAMPLED transcript whose true last user message sits beyond the tail window,
   * or a refetch that races the transcript write — silently reverted the reorder,
   * so the session only rose to the top on a full reload (the reported bug). An
   * entry is dropped in loadSessions once the server value catches up (>=), so a
   * stamp can never PIN a session past the truth; only stampUserSubmit (a real
   * human send) ever writes here, so agent activity still never reorders.
   */
  userSubmitAt: new Map(),
  /*
   * BUG-106 — the project that OWNS the session currently open in the transcript
   * dock (its running strip, permission hairline, driving socket, running poll).
   * Distinct from current.projectId, which follows the SIDEBAR selection:
   * selectProject (a bare "look at another project" header click) moves
   * current.projectId but must NOT move this. Keeping the two apart is what lets
   * the dock's session-bound surfaces be gated on "is the open session foreign to
   * the project I am now looking at?" (dockIsForeign) — so one project's live work
   * is never attributed to another — WITHOUT discarding the open session the user
   * may switch back to. Set when a session opens (openSession) or a new one is
   * started (startNew); untouched by selectProject.
   */
  openProjectId: null,
  overrides: {}, // session-scope settings overrides (drawer owns the semantics)
  ws: null,
  live: false,
  busy: false,
  turnStartedAt: 0,
  /*
   * BUG-033 — TRUE when this tab knows a turn is running but NOT when it
   * started (an old server that does not report `turnStartedAt`, reattaching to
   * a bridge whose turn began before this tab existed). The old code stamped
   * `Date.now()` in that case and counted up from it, so the "1:08" on screen
   * was how long the TAB had believed it, not the age of the turn. An honest
   * unknown ("—") is worth more than a fabricated stopwatch.
   */
  turnStartUnknown: false,
  agents: new Map(), // agentId -> { agent, t0, settled }
  /*
   * ARCH-001 phase 2 / BUG-034 — THE SERVER'S ANSWER to "what is running right
   * now" for the open session: `{v, at, turn:{running,since,…}, running:[…],
   * ended:[…]}`. This, and only this, decides what the live strip shows.
   * `null` = the server has not answered yet (or is too old to have the route),
   * which is an honest "we do not know", NOT an excuse to fall back to guessing
   * from accumulated events — see the block above renderStrip().
   */
  snap: null,
  snapPollTimer: null,
  /*
   * BUG-083 — a monotonic token stamped on every session boundary
   * (resetTranscript). A running-set poll captures it before its await and
   * drops its answer if the token has moved on: the poll it fired belonged to
   * the session we have since LEFT, and letting it land would paint the old
   * session's agents under the new one's name (ARCH-001 dishonesty).
   */
  snapScope: 0,
  /*
   * BUG-087 — a SIBLING of snapScope for the TRANSCRIPT (message) pane. Bumped on
   * every session boundary (resetTranscript). openSession captures it after the
   * reset and before its transcript fetch await; a fetch that lands after the
   * user has switched away (its scope has moved on) is DROPPED, so the previous
   * session's transcript can never paint under the newly-opened session's header
   * (the content-pane analogue of the running-strip race BUG-083 fixed).
   */
  txScope: 0,
  /*
   * BUG-034 / §C — TRUE when the last answer can no longer be checked: the
   * socket dropped or the poll cannot reach the server. The rows are NOT
   * deleted (the work may well still be running server-side — BUG-018/020) and
   * NOT presented as current either (nothing can vouch for them). They freeze,
   * lose their ◐, and say so. Claiming and denying are both lies here.
   */
  snapStale: false,
  snapStaleAt: 0,
  /** FEAT-057 — undismissed agent deaths the server recorded (rail items). */
  outcomes: [],
  /* ARCH-017 — lane results Orchard is holding. `null` until the first poll
   * answers, so the rail can tell "not asked yet" from "nothing waiting". */
  pending: null,
  pendingProblem: null,
  /* ARCH-017 round 2 (§7) — the last FAILED drain/dismiss, shown at the user.
   * A verifier reproduced a non-writer server answering 200 with `lanes:[]`,
   * the client ignoring `skipped`, and the row silently reappearing with
   * nothing said. Silence is the worst available behaviour here. */
  pendingActionProblem: null,
  /* ARCH-017 round 2 (§4) — the 12-row cap hid 5 of 17 items with no indicator. */
  showAllPending: false,
  /* ARCH-017 round 2 (§5) — the collected bundle, so it has a DOM surface. */
  lastDrain: null,
  requests: [],      // FEAT-126 — declared user-request bindings for the open session (no status)
  /** BUG-070 — false = recent/undismissed only; true = "show all" (old + dismissed). */
  showAllOutcomes: false,
  agentText: new Map(), // agentId -> accumulated text
  asks: new Map(),
  threads: new Map(), // 'main' | agentId -> thread (own .pane, own render cursor)
  viewing: 'main',
  caps: { subagents: null, live: null, running: null, outcomes: null, requests: null, pending: null }, // null = unprobed, false = route absent on this server
  effective: null,         // EffectiveConfig — what the session really runs with
  /* FEAT-051 — the LIVE session's own tool list (session-init.tools), the
     ground truth for which MCP servers actually attached: an attached server
     shows up as `mcp__<server>__…` tool names in the CLI's init report.
     Null until a session speaks; cleared with the socket. */
  liveTools: null,
  /* Per-session snapshot protection reported in the `start` ack:
     null = unreported, {protected:true} = has a restore point,
     {protected:false} = none (off, or the start snapshot failed). */
  startSnapshot: null,
  dropped: false,          // socket died mid-session; refuse to send until resolved
  budgetLocked: false,     // maxBudgetUsd hit — session refuses all further sends (BUG-013)
  budgetLockReason: '',    // the server's budget-stop message, shown in the lock banner
  liveElsewhere: '',       // BUG-149: the server's live-in-another-tab refusal, shown in a banner (not the console)
  pendingSend: null,       // { el, text } for the optimistic youBubble of an in-flight submit(),
                           // rolled back if the server rejects it (BUG-013) — cleared on any settle
  resumeOnNextSend: null,  // sdk session id to resume once the user writes again
  pendingStart: null,      // text of a `start`/resume awaiting its `ack`; non-null == turn not yet begun
  pendingStartResume: null,// the sdk session id that pending `start` was resuming (null for a fresh start)
  pendingStartEl: null,    // BUG-149: the exact optimistic bubble that `start` painted — set with pendingStart, in the same tick
  drainWaitTimer: null,    // BUG-045: slow self-retry interval while a drain-wait row is queued
  drainWaitAttempt: null,  // BUG-045: the queue row whose self-retry `start` is in flight (exactly-once guard)
  drainWaitLastTry: 0,     // BUG-045: throttle so poll + liveness-transition triggers cannot hammer the gate
  queueSettling: null,     // BUG-217: openSession's txScope while it is still deciding how this tab reaches the session (driveQueue waits)
  deliveryRelay: null,     // FEAT-065: the open ws is ONLY the approval relay for a turn delivered into the drain-held survivor (sdk id, or true)
  closingOnPurpose: false, // distinguishes our own close() from a real drop
  pendingAnswers: new Map(), // requestId -> answer awaiting the server's ack
  decisionsByRequest: new Map(), // requestId -> question/plan card still awaiting the user (BUG-166: the OWNER of "the model stopped, waiting on you"; pruned the moment a card settles — see awaitingUserDecision())
  busyWatchdog: null,
  sdkSessionId: null,
  // FEAT-022: the STATION session id (from the `start` ack) — the key the
  // /api/sessions/:id/autonomous routes are addressed by. Null until a session
  // is actually driven from this tab.
  stationSessionId: null,
  // FEAT-022: autonomous mode mirror of the server's AutonomousState. Default
  // interactive; a session is NEVER shown autonomous unless the server says so.
  autonomous: { autonomous: false, maxTurns: null, turnsDone: 0, remaining: null, stopReason: null },
  watchWs: null,          // passive listener — see the "auto-follow" section
  watchTries: 0,
  liveIds: new Map(),  // `${dir} ${sessionId}` -> live record, for sessions being written
  // FEAT-154 — sdkSessionIds whose bridge has an OUTSTANDING pending
  // question/permission ("waiting on you"), published by the server on
  // /api/sessions (`awaitingUser`) and refreshed on the live poll. The nav reads
  // THIS for the amber waiting marker; it is never re-derived client-side.
  awaitingIds: new Set(),
  following: false,    // is the server watching the open session file for us?
  liveTimer: null,
  forkFrom: null, // session id being branched from, set by the Windows fork bar
  forkEncodedDir: null, // BUG-090: the SOURCE store dir a needs-fork branch must stage from (server-supplied)
  pendingFork: null, // BUG-090: {resumeSessionId, resumeEncodedDir, cause} — a resume the server said needs a fork
  queue: [], // messages typed mid-turn: {text, el} — delivered at turn boundaries
  /*
   * BUG-129 (option A): the batch flushQueue/deliverForced has HANDED to the
   * socket but whose turn this tab has not yet seen start. It is spliced out of
   * state.queue at that moment, so without this it exists nowhere for the whole
   * send→turn-end window and a reload in that window destroys it. Cleared at
   * turn-end — the point at which the server has certainly written the prompt to
   * the transcript, i.e. the point at which it is durable somewhere else.
   * {texts: string[], at: number}
   */
  outbox: null,
  sendAttempts: new Map(), // BUG-191: sendId -> { texts, el, at, resume } — per-attempt ownership of an in-flight `send`
  forceSend: null, // {text, composedAt} pulled out of queue, awaiting the interrupt it triggered to land at turn-end (FEAT-031 Part A)
  /*
   * BUG-083 — unsent composer text, keyed to the project/session it was typed
   * in. A switch SAVES the outgoing draft under its key and RESTORES the target
   * session's own draft (empty if none), so a draft never rides into the wrong
   * project. Survives within the tab's lifetime; not persisted to storage.
   */
  drafts: new Map(),
  // FEAT-073 — the projectId whose "New session" the user has EXPLICITLY opened
  // and not yet sent. Only this drives the derived pending-new sidebar row, so a
  // project that is merely selected (a project with no session on screen) never
  // sprouts a phantom row. Set by startNew, cleared when a real session opens.
  pendingNew: null,
  searchLoaded: false,
  contentSearch: null, // { q, scope, showTools, loading, error, result } — tier-2 search
  git: new Map(), // projectId -> { status, at, loading } — crown chip cache
  followingLive: false, // opened a session still running server-side (e.g. after reload)
  followingExternal: false, // opened a session written live by ANOTHER process (a terminal) — no bridge to drive it; a toggle only arms the takeover
  seen: new Map(), // `${dir} ${sessionId}` -> ISO of when the user last had it open
  readMarks: new Map(), // FEAT-118 — seenKey -> last-read absolute message index (auto "you were here")
  bookmarks: new Map(), // FEAT-118 — seenKey -> manually-bookmarked absolute message index
  procSummary: null, // projectId -> {count, ports, hasSelf} — ambient "running here"
  board: null,       // {hasBoard, needsYou, queued, inflight, doneToday} for the current project
  boardProjectId: null, // which project state.board belongs to
  boardBusy: false,  // a refresh is in flight
  openAnswerId: null, // FEAT-153 — the one needs-you ticket whose answer flow is mounted in #railNeeds
  // FEAT-040 — session-status affordance ground truth. `sessPhase` only means
  // something while `busy` is true ('thinking' until the first text-delta,
  // then 'streaming'); the others are independent flags so more than one true
  // condition can exist at once — computeSessState() below picks the single
  // most-honest label by priority.
  sessPhase: 'thinking',
  sessReconnecting: false, // a resume's connect() is in flight — transport down, work status unknown
  // BUG-153: there is no `sessDetached` flag. "Running server-side without THIS
  // tab driving it" is DERIVED — see isDriving() and computeSessState().
  sessError: null,         // last fatal/budget-stop message; cleared when a new turn starts
  // BUG-031 — the last TERMINAL provider-error event of the current turn
  // (kind/provider/detail/retryable…), so turn-end can label the ending with
  // the provider's own words instead of the SDK's misleading subtype (an API
  // error turn's subtype is literally 'success'). Cleared when a turn starts.
  provError: null,
  lastTurnPrompt: null,    // last user prompt actually sent — the retry affordance re-sends it
  // FEAT-048 — lazily-fetched /api/health survival ground truth for the
  // CURRENT session, cached briefly so repeated hovers don't re-fetch.
  // { key, entry, at } — key identifies which session `entry` describes.
  sessSurvival: { key: null, entry: null, at: 0 },
};

/** BUG-191 — the note a send whose delivery was never confirmed carries (read by the dock to say "not confirmed", not "not delivered"). */
// BUG-217 round 4: also the answer for a row the server can no longer vouch for either way — so "may", not "was".
const UNCONFIRMED_NOTE = 'it may already have been sent, and Orchard cannot confirm either way — check the transcript before sending it again';

/* ------------------------------------------------- sidebar attention state */
/*
 * The user works ~3 projects at once. Two things must survive a reload so the
 * sidebar answers "what still needs me" without re-expanding everything:
 *  - WHICH projects are expanded (their choice, not a heuristic — auto-expand
 *    by recency was tried on paper and rejected: 4 active projects would
 *    rebuild the wall-of-sessions the cap exists to prevent);
 *  - which sessions they have SEEN, so a collapsed header can badge "2 new"
 *    for activity that happened since they last looked.
 */

const EXPANDED_KEY = 'cs-expanded';
const SEEN_KEY = 'cs-seen';
// FEAT-118 — within-session marks, persisted per session so they survive a
// reload AND a switch away and back. `cs-readmark` is the AUTOMATIC "you were
// here" boundary (the highest absolute message index the user has actually
// read); `cs-bookmark` is the MANUAL bookmark the user dropped deliberately.
// Both are keyed by seenKey(dir, sessionId) and hold an absolute message index.
const READMARK_KEY = 'cs-readmark';
const BOOKMARK_KEY = 'cs-bookmark';

function saveExpanded() {
  try { localStorage.setItem(EXPANDED_KEY, JSON.stringify([...state.expanded])); } catch { /* private mode — volatile is fine */ }
}
function loadExpanded() {
  try { for (const id of JSON.parse(localStorage.getItem(EXPANDED_KEY) ?? '[]')) state.expanded.add(id); } catch { /* garbage — start fresh */ }
}
function loadSeen() {
  try {
    for (const [k, v] of Object.entries(JSON.parse(localStorage.getItem(SEEN_KEY) ?? '{}'))) state.seen.set(k, v);
  } catch { /* garbage — start fresh */ }
}
let seenSaveTimer = null;
function saveSeenSoon() {
  clearTimeout(seenSaveTimer);
  seenSaveTimer = setTimeout(() => {
    try { localStorage.setItem(SEEN_KEY, JSON.stringify(Object.fromEntries(state.seen))); } catch { /* full/private */ }
  }, 400);
}
const seenKey = (dir, sessionId) => `${dir ?? ''} ${sessionId}`;

/* FEAT-118 — load/save the per-session read-mark and manual-bookmark maps. Same
   shape and debounce as the seen map: an index per seenKey, JSON in one key. A
   garbage or private-mode store is simply an empty map, never an error. */
function loadMarks() {
  const into = (key, map) => {
    try {
      for (const [k, v] of Object.entries(JSON.parse(localStorage.getItem(key) ?? '{}'))) {
        if (Number.isInteger(v)) map.set(k, v);
      }
    } catch { /* garbage — start fresh */ }
  };
  into(READMARK_KEY, state.readMarks);
  into(BOOKMARK_KEY, state.bookmarks);
}
let marksSaveTimer = null;
function saveMarksSoon() {
  clearTimeout(marksSaveTimer);
  marksSaveTimer = setTimeout(() => {
    try {
      localStorage.setItem(READMARK_KEY, JSON.stringify(Object.fromEntries(state.readMarks)));
      localStorage.setItem(BOOKMARK_KEY, JSON.stringify(Object.fromEntries(state.bookmarks)));
    } catch { /* full/private */ }
  }, 300);
}

/** Stamp the open session as seen NOW — the user is literally looking at it. */
function stampSeenCurrent() {
  const { encodedDir, sessionId } = state.current;
  if (!sessionId) return;
  state.seen.set(seenKey(encodedDir, sessionId), new Date().toISOString());
  saveSeenSoon();
}

/**
 * Sessions in this project with activity the user has not looked at since.
 * Never-seen sessions only count within a 24h baseline — without it, every
 * old session would scream "new" on the feature's first day.
 */
function unseenCount(s) {
  if (!s?.loaded) return 0;
  const dayAgo = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const cur = seenKey(state.current.encodedDir, state.current.sessionId ?? '');
  let n = 0;
  for (const x of s.list) {
    if (foldsFromList(x)) continue; // hidden from the list ⇒ never badged "new"
    const k = seenKey(x.encodedDir, x.sessionId);
    if (k === cur) continue; // on screen right now
    const seen = state.seen.get(k) ?? dayAgo;
    if (String(x.lastActivityAt ?? '') > seen) n++;
  }
  return n;
}

/* Ambient "something is running here": one server-side /proc sweep for all
   projects, polled slowly. The header shows the listening port — the most
   recognizable fingerprint of a forgotten dev server. */
const PROC_POLL_MS = 15_000;

async function refreshProcSummary() {
  try {
    const s = await api.processSummary();
    if (s === null) return; // route not on this server yet — show nothing
    const before = JSON.stringify(state.procSummary);
    state.procSummary = s;
    if (JSON.stringify(s) !== before) { renderTree(); paintCrown(); }
  } catch { /* transient — keep the last honest answer */ }
}

function startProcPolling() {
  void refreshProcSummary();
  setInterval(() => void refreshProcSummary(), PROC_POLL_MS);
}

/* FEAT-116 — provider rate-limit window usage: "how much of each provider's
   window have I burned, and when does it reset?", so the answer to "dispatch
   this lane now, or park a ticket until the window resets?" is on-screen instead
   of guessed. Sourced server-side from each provider's OWN interface (never our
   token accounting); polled slowly, and the server read is cached + non-blocking
   so a slow/hung provider can never delay this poll or the UI. */
const USAGE_POLL_MS = 30_000;
state.usage = state.usage ?? null; // [{provider, available, asOf, windows, plan, note}] | null

async function refreshUsage() {
  try {
    const list = await api.usage();
    if (list === null) return; // route not on this server yet — show nothing
    state.usage = list;
    paintCrown();
  } catch { /* transient — keep the last honest answer, with its own as-of */ }
}
function startUsagePolling() {
  void refreshUsage();
  setInterval(() => { if (!document.hidden) void refreshUsage(); }, USAGE_POLL_MS);
}

/** Short relative countdown to a reset (unix seconds): "now" | "40m" | "4h" | "5d". */
function usageResetShort(sec) {
  if (sec == null) return '';
  const mins = Math.round((sec * 1000 - Date.now()) / 60000);
  if (mins <= 0) return 'now';
  if (mins < 60) return `${mins}m`;
  const hrs = mins / 60;
  if (hrs < 48) return `${Math.round(hrs)}h`;
  return `${Math.round(hrs / 24)}d`;
}
/** Absolute reset time for the tooltip. */
function usageResetAbs(sec) {
  if (sec == null) return 'unknown';
  return new Date(sec * 1000).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function usageAsOf(asOf) {
  if (asOf == null) return 'never read';
  return new Date(asOf).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
/**
 * FEAT-145 — which Claude ACCOUNT this project's next lane would run on. Same
 * resolution shape as providerView(): an armed per-launch override wins, then
 * the project setting, then the implicit default account. Reads defensively so
 * this is correct both before and after the account setting exists.
 */
function claudeAccountView() {
  const o = state.overrides ?? {};
  const v = ('claudeAccount' in o ? o.claudeAccount : null) ?? currentProject()?.settings?.claudeAccount ?? null;
  return typeof v === 'string' && v ? v : 'default';
}
/** A snapshot's display name: 'OpenAI', 'Claude', or 'Claude (<account label>)'. */
function usageSnapName(s) {
  if (s.provider === 'openai') return 'OpenAI';
  // The default account is just "Claude" — a single-account user sees no change.
  if (!s.accountId || s.accountId === 'default' || !s.accountLabel) return 'Claude';
  return `Claude (${s.accountLabel})`;
}
/**
 * The full detail — the decision surface lives in the tooltip. One block per
 * snapshot in SERVER order (FEAT-145: every Claude account, default first, then
 * openai), so two subscriptions show two independent 5-hour windows and the
 * "which one do I switch to" answer is actually on screen.
 */
function usageTitle() {
  const list = state.usage ?? [];
  const lines = [];
  for (const s of list) {
    if (s.provider !== 'anthropic' && s.provider !== 'openai') continue;
    const name = usageSnapName(s);
    if (!s.available) {
      lines.push(`${name} — not available${s.note ? ` (${s.note})` : ''}${s.asOf ? ` · last read ${usageAsOf(s.asOf)}` : ''}`);
      continue;
    }
    lines.push(`${name}${s.plan ? ` (${s.plan})` : ''} — as of ${usageAsOf(s.asOf)}`);
    for (const w of s.windows) {
      lines.push(`  ${w.label}: ${w.usedPercent}%${w.binding ? ' (binding)' : ''} · resets ${usageResetAbs(w.resetsAt)}`);
    }
  }
  lines.push('Rate-limit windows — decide whether a lane fits before dispatching.');
  return lines.join('\n');
}

/**
 * FEAT-139 r3 — draw the window-burn as a FILLED RING inside #usageRing. The arc
 * length IS the reading (a near-full ring reads near-full at any hue → the state
 * is not colour-alone); `pct === null` renders a track-only "no reading" ring.
 * Colour is applied via the button's warn/danger class in CSS, not here.
 */
function paintUsageRing(pct) {
  const R = 5.2, C = 2 * Math.PI * R;
  const frac = pct == null ? 0 : Math.max(0, Math.min(100, pct)) / 100;
  const off = C * (1 - frac);
  node.usageRing.innerHTML =
    `<svg width="14" height="14" viewBox="0 0 14 14" fill="none">` +
    `<circle class="track" cx="7" cy="7" r="${R}" stroke-width="2.2"/>` +
    (pct == null
      ? ''
      : `<circle class="fill" cx="7" cy="7" r="${R}" stroke-width="2.2" ` +
        `stroke-dasharray="${C.toFixed(2)}" stroke-dashoffset="${off.toFixed(2)}" ` +
        `stroke-linecap="round" transform="rotate(-90 7 7)"/>`) +
    `</svg>`;
}

function paintUsageChip() {
  const btn = node.usageBtn;
  if (!btn || !node.usageRing) return; // markup not present (older shell)
  const p = currentProject();
  if (!p) { btn.hidden = true; return; }
  const provider = providerView(); // the engine THIS project's next lane would use
  // FEAT-145: the badge answers "can I dispatch RIGHT NOW", so it must show the
  // window binding the account this session will ACTUALLY run on — not whichever
  // account happens to be listed first. Falls back to the first snapshot for the
  // provider (the default account) when the selected one is not in the list, so
  // a single-account user's badge is byte-identical to pre-145.
  const list = state.usage ?? [];
  const snap =
    provider === 'anthropic'
      ? (list.find((s) => s.provider === 'anthropic' && (s.accountId ?? 'default') === claudeAccountView())
        ?? list.find((s) => s.provider === 'anthropic'))
      : list.find((s) => s.provider === provider);
  btn.classList.remove('warn', 'danger', 'unknown');
  if (!snap || !snap.available) {
    paintUsageRing(null);
    btn.classList.add('unknown');
    btn.title = usageTitle() || 'Provider usage — not available';
    btn.setAttribute('aria-label', 'Provider usage — not available');
    btn.hidden = false;
    return;
  }
  // The binding window is the one that will actually stop the next lane.
  const b = snap.windows.find((w) => w.binding) ?? snap.windows[0];
  const short = /weekly/i.test(b.label) ? 'weekly' : b.label;
  const reset = usageResetShort(b.resetsAt);
  paintUsageRing(b.usedPercent);
  if (b.usedPercent >= 90) btn.classList.add('danger');
  else if (b.usedPercent >= 75) btn.classList.add('warn');
  btn.title = usageTitle();
  // The percent + window + reset that left the FACE survive on hover (title
  // above, full detail) and here for screen readers — nothing dropped.
  btn.setAttribute('aria-label', `Usage — ${b.usedPercent}% of the ${short} window used${reset ? `, resets in ${reset}` : ''}`);
  btn.hidden = false;
}

/** The station's own port — always shown first in the proc popover. */
const STATION_PORT = 4317;

/**
 * BUG-082: a STABLE port order so the capped inline preview never jitters
 * between polls — :4317 (the station) always first, then the ephemeral scratch
 * ports ascending. Deduped and numeric-sorted, so re-renders are deterministic.
 */
function orderedPorts(ports) {
  const nums = [...new Set((ports ?? []).map(Number))].filter((x) => Number.isFinite(x)).sort((a, b) => a - b);
  const station = nums.filter((x) => x === STATION_PORT);
  const rest = nums.filter((x) => x !== STATION_PORT);
  return [...station, ...rest];
}

/** Compact header chip text for a project's process summary, or null. */
function procChipText(p) {
  const s = state.procSummary?.[p.id];
  if (!s || !s.count) return null;
  const ports = orderedPorts(s.ports);
  if (ports.length) return `:${ports[0]}${ports.length > 1 ? ` +${ports.length - 1}` : ''}`;
  return `${s.count} proc${s.count === 1 ? '' : 's'}`;
}

function procChipTitle(p) {
  const s = state.procSummary?.[p.id];
  if (!s) return '';
  return `${s.count} process${s.count === 1 ? '' : 'es'} running from this directory`
    + `${s.ports.length ? ` · listening ${orderedPorts(s.ports).map((x) => `:${x}`).join(' ')}` : ''}`
    + `${s.hasSelf ? ' (includes this dashboard)' : ''}\nOpen project settings › Running here`;
}

/** Any session of this project being written right now (any process). */
function projectHasLive(p, s) {
  if (!state.liveIds.size) return false;
  const dirs = new Set(s?.dirs ?? []);
  for (const rec of state.liveIds.values()) {
    if (rec.dir && dirs.has(rec.dir)) return true;
    // dir-less live records: fall back to matching a listed session id
    if (!rec.dir && s?.list?.some((x) => x.sessionId === rec.sessionId)) return true;
  }
  return false;
}

const node = {
  win: $('#win'),
  tree: $('#tree'),
  projSort: $('#projSort'), // FEAT-070 — the recency/alpha sort toggle

  where: $('#where'),
  title: $('#title'),
  seal: $('#seal'),
  sessStatus: $('#sessStatus'),
  sessStatusLbl: $('#sessStatusLbl'),
  provSel: $('#provSel'),   // this-feat — header provider selector (opens #provPop)
  provSelG: $('#provSelG'),
  provSelN: $('#provSelN'),
  sealBreak: $('#sealBreak'), // this-feat — the tier divider; mounts insert before it
  fold: $('#fold'),
  settingsBtn: $('#settingsBtn'), // BUG-158 — labelled seal-strip opener for the settings drawer

  insBtn: $('#insBtn'),
  insN: $('#insN'),
  insPlus: $('#insPlus'),
  gitBtn: $('#gitBtn'),
  gitN: $('#gitN'),
  gitDot: $('#gitDot'),       // FEAT-139 r3 — shape-coded git state dot
  procBtn: $('#procBtn'),
  procN: $('#procN'),
  procPop: $('#procPop'),
  usageBtn: $('#usageBtn'),   // FEAT-116 — provider rate-limit window readout
  usageRing: $('#usageRing'), // FEAT-139 r3 — filled window-burn ring (no % text)
  procPorts: $('#procPorts'),
  sealSep: $('#sealSep'),
  rowMenu: $('#rowMenu'),
  picker: $('#picker'),
  pickList: $('#pickList'),
  pickFilter: $('#pickFilter'),
  pickPath: $('#pickPath'),
  pickApplyMethod: $('#pickApplyMethod'),
  main: document.querySelector('.main'),
  scroll: $('#scroll'),
  jump: $('#jump'),
  panes: $('#panes'),
  asks: $('#asks'),
  strip: $('#strip'),
  stripRows: $('#stripRows'),
  stripSum: $('#stripSum'),
  stripClk: $('#stripClk'),
  box: $('#box'),
  prompt: $('#prompt'),
  go: $('#go'),
  skipBtn: $('#skipBtn'),
  planBtn: $('#planBtn'),
  modelBtn: $('#modelBtn'),
  provBtn: $('#provBtn'),
  provPop: $('#provPop'),
  provOpts: $('#provOpts'),
  modelChip: $('#modelChip'),
  modelChipName: $('#modelChipName'),
  modelPop: $('#modelPop'),
  modelOpts: $('#modelOpts'),
  effortOpts: $('#effortOpts'),
  permLine: $('#permLine'),
  frozen: $('#frozen'),
  dropped: $('#dropped'),
  droppedText: $('#droppedText'),
  historyBar: $('#history'),
  historyLatestBtn: $('#historyLatestBtn'),
  agentDone: $('#agentDone'),
  agentDoneText: $('#agentDoneText'),
  fine: $('#fine'),
  finder: $('#finder'),
  findInput: $('#findInput'),
  rail: $('#rail'),
  railBadge: $('#railBadge'),
  railBadgeN: $('#railBadgeN'),
  railCount: $('#railCount'),
  railBoardLink: $('#railBoardLink'), // FEAT-066 — in-context entry to the board
  boardBtn: $('#boardBtn'),           // FEAT-066 — persistent topbar board entry
  boardBtnN: $('#boardBtnN'),
  railSummary: $('#railSummary'), // FEAT-067 — server-derived top-of-rail status index
  railBoardGrid: $('#railBoardGrid'), // FEAT-153 — the primary ticket-board grid
  railRequests: $('#railRequests'), // FEAT-126 — "Your requests" persistent status surface
  railNeeds: $('#railNeeds'),
  railObservations: $('#railObservations'), // FEAT-079 — read-only findings lane
  railStopped: $('#railStopped'), // FEAT-057 — agents that stopped, and why
  railPending: $('#railPending'), // ARCH-017 — lane results Orchard is holding
  railQueued: $('#railQueued'),   // FEAT-053 — the todo backlog, read-only
  railInflight: $('#railInflight'),
  railDone: $('#railDone'),
  integStrip: $('#integStrip'),   // FEAT-051 — attached-capability chips
  ticketModal: $('#ticketModal'),         // FEAT-053 — rail ticket modal
  ticketModalBody: $('#ticketModalBody'),
};

/*
 * BUG-013: a budget-stopped session must lock the composer, not just show a
 * transient toast — the toast scrolls away, the composer does not lie about
 * being usable again. Built here (not in index.html) so the fix stays inside
 * app.js: reuses the existing `.frozen` banner styling (see #dropped/#frozen
 * in index.html) rather than inventing new CSS. Inserted right after the
 * "connection dropped" banner, in the same composer-replacement stack.
 */
node.budgetLockedText = el('span');
node.budgetLocked = el('div', { class: 'frozen', id: 'budgetLocked', hidden: true }, node.budgetLockedText);
node.dropped.insertAdjacentElement('afterend', node.budgetLocked);

/*
 * BUG-149: the server refuses a send when another tab is already driving the
 * session, and it says exactly why in a sentence a person can act on. That
 * sentence used to reach `console.log` and nothing else, so the message simply
 * looked sent and no reply ever came. It gets a banner of its own, built the
 * same way as the budget lock above (same `.frozen` styling, no new CSS).
 *
 * Unlike the budget lock this one does NOT replace the composer: the session is
 * alive and this tab may take it over the moment the other one lets go, so
 * typing must stay possible. It stays until the next send attempt settles it.
 *
 * Placement is load-bearing and was got wrong first: mounted next to the
 * composer-replacement banners it rendered BELOW the composer, off the bottom
 * of the viewport — a screenshot caught what the DOM assertions could not (the
 * element was present, visible and correct, and the user still could not read
 * it). It belongs directly above the dock, so the three things read in the
 * order they happened: what the server said, the words it refused, the box to
 * try again from.
 */
node.liveElsewhereText = el('span');
node.liveElsewhereDismiss = el('button', { class: 'pill', text: 'Dismiss' });
node.liveElsewhere = el('div', { class: 'frozen', id: 'liveElsewhere', hidden: true },
  node.liveElsewhereText, node.liveElsewhereDismiss);
$('#queueBox').insertAdjacentElement('beforebegin', node.liveElsewhere);
node.liveElsewhereDismiss.addEventListener('click', () => {
  state.liveElsewhere = '';
  node.liveElsewhere.hidden = true;
});

/* ------------------------------------------------------------------ chrome */

/*
 * BUG-100 — the composer footer (#fine) is a PERSISTENT status affordance, not a
 * log. Two rules keep it honest:
 *
 *   1. A hard length cap. No single status item may ever overflow the strip,
 *      whatever the server sends. A caller can hand `say()` a multi-hundred-char
 *      shell command (a dispatched agent's task notification carries exactly
 *      that); it is truncated on a word/segment boundary with an ellipsis, and
 *      the FULL text rides the title so nothing is lost to a hover.
 *   2. The stable isolation/access label is the RESTING content — never
 *      permanently displaced by activity text. `restLabel()` re-asserts it once
 *      a turn settles; the raw command text lives in the running rail + title,
 *      never as the footer's resting line.
 */
const MAX_FINE = 88;

function truncFine(text) {
  const t = String(text ?? '');
  if (t.length <= MAX_FINE) return t;
  const cut = t.slice(0, MAX_FINE - 1);
  // Prefer the last word/segment boundary (space, · separator, or path slash)
  // in the back third of the budget, so we never chop mid-word.
  const b = Math.max(cut.lastIndexOf(' '), cut.lastIndexOf('·'), cut.lastIndexOf('/'));
  const head = (b > MAX_FINE * 0.6 ? cut.slice(0, b) : cut).replace(/[\s·/]+$/, '');
  return `${head}…`;
}

function say(text, isErr = false, full = null) {
  const raw = text ?? '';
  const shown = truncFine(raw);
  node.fine.textContent = shown;
  // Keep the untruncated text (or an explicit `full`, e.g. a raw command) on the
  // title so the strip is never the only place it exists.
  node.fine.title = full != null ? String(full) : (shown !== String(raw) ? String(raw) : '');
  node.fine.classList.toggle('err', !!isErr);
  node.fine.hidden = !shown;
  if (isErr) console.warn('[station]', raw);
}

/**
 * BUG-101 — the footer's two kinds of fact set apart. The isolation/access label
 * is a PERMANENT session property; the "N agents running" count is TRANSIENT
 * activity. Rendered as one flat run-on with an identical `·` they read as a
 * single string. Here the label is the stable primary content and the count
 * rides a `.fine-run` span in a quieter tone, introduced by the moss "alive" dot
 * (the app reserves moss for a running agent) instead of another `·` — structure
 * matching meaning. Cap + truncation order are preserved: the transient count is
 * dropped FIRST when the strip is tight; the label always survives (truncated on
 * its own boundary only if it alone exceeds the cap). `full` (the raw command)
 * still rides the title so nothing is lost.
 */
function sayIso(label, activity, full = null) {
  const f = node.fine;
  f.classList.remove('err');
  f.textContent = '';
  f.title = full != null ? String(full) : '';
  const lbl = String(label ?? '');
  const act = String(activity ?? '');
  // The moss-dot separator is drawn by CSS (::before), so it costs no textContent
  // budget; a single space keeps the label and count from concatenating in copy.
  const runCost = act ? act.length + 1 : 0;
  if (act && lbl.length + runCost <= MAX_FINE) {
    if (lbl) appendLabel(f, lbl);
    const run = el('span', { class: 'fine-run' }, document.createTextNode(` ${act}`));
    f.append(run);
  } else {
    // No activity, or no room for it: the stable label alone, count sacrificed.
    appendLabel(f, truncFine(lbl || act));
  }
  f.hidden = !f.textContent;
}

/**
 * BUG-101 fix2 — the label's own `·` separators are a MINOR break (inside one
 * label: `Direct · full access to this machine`), while the moss dot marks the
 * MAJOR break between two different facts. Rendered as plain text the minor
 * break inherited full label weight and out-shouted the accent — the ranking
 * read backwards. Each `·` rides a `.fine-sep` span so CSS can rank it below
 * the words it parts. textContent is byte-identical, so the BUG-100 length cap
 * and truncation contract are untouched.
 */
function appendLabel(host, text) {
  const parts = String(text ?? '').split('·');
  parts.forEach((part, i) => {
    if (i > 0) host.append(el('span', { class: 'fine-sep', text: '·' }));
    if (part) host.append(document.createTextNode(part));
  });
}

/**
 * BUG-100 — the stable isolation/access label as one string. The SINGLE source
 * for both the resting footer line (paintSeal) and its re-assertion (restLabel),
 * so the two can never disagree.
 */
function isoLabel(p) {
  if (!p) return '';
  const mounts = p.settings?.mounts ?? [];
  const n = mounts.length;
  return p.isolation === 'container'
    ? `Container · ${n} mount${n === 1 ? '' : 's'} · everything stays on this machine`
    : p.isolation === 'sandbox'
      ? 'Sandbox · writes confined to the project'
      : 'Direct · full access to this machine';
}

/** Re-assert the stable isolation label as the footer's resting content. Called
 *  whenever a turn/agent activity settles so transient text can never stick. */
function restLabel() {
  const p = currentProject();
  // sayIso with no activity = the stable label alone, rendered with its `·`
  // breaks ranked below the words (BUG-101 fix2). Same text, same cap.
  if (p && !state.busy) sayIso(isoLabel(p), '');
}

/** How many SUBAGENTS the server's running snapshot reports in flight (never the
 *  main row). Used to render a bounded "N agents running" indicator. */
function runningAgentCount() {
  const snap = state.snap;
  if (snap && Array.isArray(snap.running)) return snap.running.filter((r) => r.row !== 'main').length;
  return 0;
}

/* ------------------------------------------- per-session override memory */
/*
 * Session-scope overrides (skip-perms, plan, model, effort) are deliberate
 * per-SESSION acts: a NEW session must never inherit them. But the SAME
 * session losing its armed state on a page reload is not hygiene, it is
 * amnesia — the toggle said "enabled" and a reload silently un-said it.
 * So overrides persist keyed by the exact session, restored only when THAT
 * session is reopened. startNew still starts clean, always.
 */
const OVR_KEY = 'cs-overrides';

function ovrStore() {
  try { return JSON.parse(localStorage.getItem(OVR_KEY) ?? '{}'); } catch { return {}; }
}

/*
 * BUG-196 round 3 — THE ENGINE A SESSION IS PINNED TO, keyed by SESSION ID.
 *
 * A session id is meaningful only to the engine that minted it (a Codex thread
 * id continues only on Codex, a Claude file only on Claude), so "which engine
 * does session X resume on" is a fact about X — it does not change when the
 * sidebar selection moves, a pending-new view is shown, or the dock is foreign.
 * Rounds 1 and 2 stored it on transient VIEW state (state.current.lockedProvider)
 * and gated its readers on view predicates (pendingNew, dockIsForeign), and each
 * new UI state made the lock vanish. Here it is written ONLY from the server's
 * declarations (the transcript route's `lockedProvider` — resumeProviderOf — and
 * the `session-init` frame's), and every reader asks by the id of the session it
 * is acting on (lockedProviderOf). Nothing else writes it; nothing re-derives it.
 */
const lockedProviders = new Map(); // sessionId → 'anthropic' | 'openai'

function lockedProviderOf(sessionId) {
  return sessionId ? (lockedProviders.get(sessionId) ?? null) : null;
}

/**
 * Record a server-declared pin, and heal what a pinned session can never honour:
 * a per-session `provider` override persisted for it (the round-2 foreign-dock
 * path wrote exactly that under the LOCKED session's own key, and restoreOverrides
 * re-armed it on every reopen). Other armed fields on that entry are kept.
 */
function declareLockedProvider(sessionId, provider) {
  if (!sessionId || (provider !== 'anthropic' && provider !== 'openai')) return;
  lockedProviders.set(sessionId, provider);
  const all = ovrStore();
  let dirty = false;
  for (const [k, v] of Object.entries(all)) {
    if (!k.endsWith(` ${sessionId}`) || !v || typeof v !== 'object' || !('provider' in v)) continue;
    delete v.provider;
    if (!Object.keys(v).length) delete all[k];
    dirty = true;
  }
  if (dirty) { try { localStorage.setItem(OVR_KEY, JSON.stringify(all)); } catch { /* volatile is fine */ } }
  if (state.current?.sessionId === sessionId) delete state.overrides.provider;
  paintProvSurfaces();
}

/*
 * BUG-198 — WHOSE overrides the in-memory bag holds, declared when the bag is
 * (re)loaded, never re-derived from the view. `state.overrides` is ONE bag shared
 * by reference (the drawer holds it), and it belongs to exactly one session: the
 * one restoreOverrides() loaded it for. The old writer re-derived its storage key
 * from `state.current` at write time, and selectProject() emptied the bag on any
 * sidebar project change while the dock's session stayed A — so the next persist
 * wrote an empty bag under A's key and erased A's saved permissionMode/model/effort.
 * Now: the bag's owner key is set ONLY by resetOverrides() at the transitions that
 * change which session the bag is for (openSession → restoreOverrides, startNew,
 * fork staging, a dead-link route) and adopted once at session-init by a bag
 * that was pending (a not-yet-born session). persistOverrides() writes under that
 * owner and nothing else; a pending bag (owner null) persists nothing. Navigation
 * (selectProject) and repaints no longer touch the bag at all.
 */
/*
 * BUG-198 round 2 — the owner is a TAGGED value, not a nullable key. Round 1 used
 * null for two different intents — "a NEW session, not yet born" and "no session
 * at all" (a dead link) — so a late session-init for an ABANDONED "+" attempt
 * adopted a bag armed later on a dead-link view and wrote it under the stale id.
 *   { kind: 'session', key }  — a born session's bag; the ONLY kind that persists.
 *   { kind: 'pending', token } — a not-yet-born session's bag. The token is minted
 *       client-side at the act that begins it ("+", a fork staged) and is unique,
 *       so two pending attempts can never be confused for each other.
 *   { kind: 'none' }          — no session (dead link): persists nothing and is
 *       never adopted by any session-init.
 * A session-init adopts ONLY a pending bag whose token is the one the `start`
 * frame carrying that bag was sent under, on the socket the init arrived over
 * (ovrStart, stamped in startTurn). Any other init — late, stray, from a
 * closed or different socket — adopts nothing.
 */
const OVR_NONE = Object.freeze({ kind: 'none' });
let ovrPendingSeq = 0;
const ovrSession = (key) => (key ? { kind: 'session', key } : OVR_NONE);
const ovrPending = () => ({ kind: 'pending', token: `pending-${++ovrPendingSeq}-${Date.now().toString(36)}` });
let overridesOwner = OVR_NONE; // BUG-198 round 2 — see the tagged kinds above
/** BUG-198 round 2 — {token, ws}: the pending bag the in-flight `start` carried, and its socket. */
let ovrStart = null;
const ovrKeyOf = (encodedDir, sessionId) => (sessionId ? `${encodedDir ?? ''} ${sessionId}` : null);

/** BUG-198 round 2 — empty the bag and declare who it now belongs to (a tagged owner). */
function resetOverrides(owner) {
  for (const k of Object.keys(state.overrides)) delete state.overrides[k];
  overridesOwner = owner?.kind ? owner : OVR_NONE;
}

/**
 * BUG-198 round 2 — the bag a `start` for a NOT-YET-BORN session carries belongs
 * to that session: declared here, at the one moment it is known (startTurn, the
 * same tick the frame is sent). A bag that is not already pending — a dead-link
 * view, or a fresh start from a view whose bag was another session's — is
 * re-owned to a fresh token WITHOUT touching storage; the in-memory contents are
 * exactly what the frame carries.
 */
function stampPendingStart(ws, bornFresh) {
  if (!bornFresh) { ovrStart = null; return; }
  if (overridesOwner.kind !== 'pending') overridesOwner = ovrPending();
  ovrStart = { token: overridesOwner.token, ws };
}

/** BUG-198 round 2 — a pending bag now belongs to the id ITS OWN session-init named (token + socket bound). */
function adoptPendingOverrides(encodedDir, sessionId, fromWs) {
  const st = ovrStart;
  // A frame that did not arrive over the start's own socket (stray, injected, a
  // different socket) neither adopts nor consumes the binding.
  if (!st || !fromWs || st.ws !== fromWs) return;
  ovrStart = null;
  if (overridesOwner.kind === 'pending' && st.token === overridesOwner.token && sessionId) {
    overridesOwner = ovrSession(ovrKeyOf(encodedDir, sessionId));
  }
}

function persistOverrides() {
  const k = overridesOwner.kind === 'session' ? overridesOwner.key : null; // BUG-198 round 2 — only a born session's bag is written
  if (!k) return; // BUG-198 — pending (pre-start) arming persists once session-init names the id
  const all = ovrStore();
  // BUG-196 round 3 — never persist a provider for a session its transcript pins:
  // the one write path, so no UI state (foreign dock, drawer, a future surface)
  // can store a switch the resume would ignore.
  // BUG-196 round 4 — every entry here is keyed by a session ID, and a session
  // with an id already has (or is writing) a transcript that pins its engine; the
  // server alone decides a resume's engine. So a provider is never persisted for
  // ANY id — not only once the pin has landed (the pre-pin window was round 3's gap).
  const keep = { ...state.overrides };
  delete keep.provider;
  if (Object.keys(keep).length) all[k] = keep;
  else delete all[k];
  try { localStorage.setItem(OVR_KEY, JSON.stringify(all)); } catch { /* volatile is fine */ }
}

/** Replace the in-memory overrides with what THIS session had armed, if anything. */
function restoreOverrides(encodedDir, sessionId) {
  resetOverrides(ovrSession(ovrKeyOf(encodedDir, sessionId))); // BUG-198 round 2 — the bag is now THIS session's (tagged owner)
  const saved = ovrStore()[`${encodedDir ?? ''} ${sessionId}`];
  // BUG-196 round 4 — never re-arm a persisted provider for an existing session id,
  // pinned yet or not: restore runs at openSession ENTRY, before the transcript
  // fetch declares the pin, and a send in that window used to carry the stale
  // value. The server decides a resume's engine; the next persist drops the stale
  // field from storage too (and declareLockedProvider heals it when the pin lands).
  // BUG-196 round 5 — stripped BEFORE the assign, so this is not even a transient
  // provider writer: pickProvider is the only one.
  if (saved && typeof saved === 'object') {
    const { provider: _stale, ...rest } = saved;
    Object.assign(state.overrides, rest);
    // BUG-196 round 6 — and heal STORAGE here too, not only when a pin lands: the
    // matrix found a stale provider left on disk whenever the pin never arrived
    // (transcript read failed and the turn died before session-init). Inert (never
    // re-armed), but storage must not hold what no id may carry.
    // Written under THIS key directly: restore runs before openSession reassigns
    // state.current, so persistOverrides() would write under the OUTGOING session.
    if ('provider' in saved) {
      const all = ovrStore();
      const k = `${encodedDir ?? ''} ${sessionId}`;
      if (Object.keys(rest).length) all[k] = rest;
      else delete all[k];
      try { localStorage.setItem(OVR_KEY, JSON.stringify(all)); } catch { /* volatile is fine */ }
    }
  }
}

/** Outstanding live permission-mode change: {requestId, next, timer}. */
let permModePending = null;

/**
 * Outstanding live MODEL change: {requestId, value, timer}. BUG-026 — picking a
 * model on a RUNNING session must go through the server's live `setModel` (the
 * SDK's `Query.setModel`), exactly like permission mode: the old code only ever
 * armed a client-side override that `effectiveModel()` correctly ignores while
 * live, so the picker reverted on reopen and the session never switched.
 */
let modelPending = null;

/*
 * FEAT-042 — the always-visible model chip's two sources of truth:
 *
 *   liveWireModel     — the wire id the RUNNING session last reported for its
 *                       main thread (`session-init.model`, then every
 *                       `model-observed` per-turn report). The most live value
 *                       there is; null until the session speaks (and reset when
 *                       a confirmed live switch makes the old report stale).
 *   expectedLiveModel — what the USER chose or launched with (session-init's
 *                       pick, updated by a server-CONFIRMED /model switch).
 *                       A live report that does not match this is, by
 *                       definition, a change the user did not initiate — the
 *                       silent provider switch the chip exists to catch.
 */
let liveWireModel = null;
let expectedLiveModel = null;

const currentProject = () => state.projects.find((p) => p.id === state.current.projectId) ?? null;

/*
 * FEAT-083: the digest-aware assistant-text renderer. A project may DISABLE the
 * structured response digest via `settings.responseDigest.enabled === false`, in
 * which case the envelope is never parsed and the message renders as plain prose
 * (the fence just shows as a normal code block). Default is enabled. Reading the
 * flag per-render (not caching) means a project settings change takes effect on
 * the next transcript render with no server restart.
 */
const digestEnabled = () => currentProject()?.settings?.responseDigest?.enabled !== false;
const assistantProse = (text) => renderAssistantText(text, {
  enabled: digestEnabled(),
  projectId: state.current.projectId ?? null,
});

let gitView;
const drawer = createDrawer({
  getProject: currentProject,
  overrides: state.overrides,
  getEffective: () => state.effective,
  // BUG-135 — the drawer needs the running session's OWN attach report to say
  // "enabled here, not in this session". Routed through the same dockLiveTools
  // gate as every other live surface so a foreign selection reads null (BUG-106)
  // rather than borrowing another project's attach.
  getLiveTools: () => dockLiveTools(),
  getStartSnapshot: () => state.startSnapshot,
  // FEAT-139 — the Appearance control under Settings → Machine reads and writes
  // the app theme through these; applyTheme owns the localStorage + <html> write.
  themes: () => THEMES,
  getTheme: () => theme,
  setTheme: (t) => setThemePersist(t),
  /*
   * FEAT-146 — the Claude ACCOUNT list has ONE owner, and it is this file
   * (ARCH-010). The settings modal used to keep a second list of its own
   * (`d.claudeAccounts`, its own `api.getClaudeAccounts()` call) and a second
   * copy of the plan-description helper, so two surfaces could disagree about
   * which subscription a session would spend. It reads these now and stores
   * nothing. `pickSessionAccount` is pickAccount itself, so a per-launch
   * override still has exactly one writer — the one that persists it, tells the
   * user, and repaints the launch pill and the usage badge.
   */
  accounts: () => ACCOUNTS,            // undefined = unfetched, null = no route, [] = default only
  refreshAccounts: (opts) => refreshAccounts(opts ?? {}),
  acctPlanDesc: (a) => acctPlanDesc(a),
  acctUsageDesc: (id) => acctUsageDesc(id),
  accountLockedReason: () => accountLockedReason(),
  // BUG-196 round 6 — the drawer's SESSION-scope provider control reads the ONE
  // engine state (engine shown, refusal, unknown) the composer-tray button and
  // popover read, instead of its own lockedProvider + refusal pair.
  sessionEngine: () => sessionEngine(),
  // BUG-196 round 6 — the session-scope model cycle follows the same engine state.
  // FEAT-159 — the same list WITH its labels, for the settings Model dropdown.
  sessionModelOpts: () => activeModelOpts().map((o) => ({ value: o.v ?? null, label: o.n })),
  // BUG-196 round 5 — the drawer's SESSION-scope provider control writes ONLY
  // through pickProvider (the one guarded writer, same pattern as
  // pickSessionAccount/pickAccount), and disables itself on the same guard.
  pickSessionProvider: (next) => pickProvider(next),
  pickSessionAccount: (next) => pickAccount(next),
  notify: say,
  openGit: () => void gitView?.open(),
  async refreshProject() {
    const p = await api.getProject(state.current.projectId);
    const i = state.projects.findIndex((x) => x.id === p.id);
    if (i >= 0) state.projects[i] = p;
    paintCrown();
  },
  onStackChanged: paintCrown,
  /*
   * BUG-138 — a repoint changes two things the sidebar is showing: whether the
   * project is flagged "dir missing", and which sessions list under it (the
   * old path's history is carried, so the list must be re-read, not kept).
   * Refreshing only the drawer would leave the sidebar asserting a state the
   * user just fixed.
   */
  async onPathChanged(id) {
    await loadProjects();
    await loadSessions(id, { force: true });
    paintCrown();
  },
});

gitView = createGitView({
  getProject: (id) => id ? (state.projects.find((p) => p.id === id) ?? null) : currentProject(),
  getProjects: () => state.projects,
  navigate: (id, options) => navGit(id, options),
  notify: say,
  onStatusChanged(status, projectId) {
    const p = state.projects.find((candidate) => candidate.id === projectId) ?? null;
    if (!p || !status) return;
    state.git.set(p.id, { status, at: Date.now(), loading: false });
    paintGitChip();
  },
});

/* ------------------------------------------------------------------- theme */

// FEAT-139 — theme is a real, server-persisted machine setting surfaced in
// Settings → Machine (Appearance), not a sidebar-foot cycle button. The SERVER
// is the source of truth: it persists the value (global-settings.ts) and injects
// it onto <html data-theme> for a flash-free first paint. localStorage stays a
// FAST client cache (and offline fallback), NOT the only record. On load we
// reconcile against the server; on change we write THROUGH to the server.
const THEMES = ['system', 'light', 'dark'];
function cachedTheme() { try { return localStorage.getItem('cs.theme'); } catch { return null; } }
// First-paint value: prefer the server-injected <html data-theme> (authoritative,
// present even with a cold cache), then the localStorage cache, then 'system'.
let theme = (() => {
  const injected = document.documentElement.dataset.theme;
  if (injected && THEMES.includes(injected)) return injected;
  const cached = cachedTheme();
  return cached && THEMES.includes(cached) ? cached : 'system';
})();
// Apply locally + refresh the cache. Does NOT touch the server (used for first
// paint and for reconciling a server value we just read back).
function applyTheme(t) {
  if (!THEMES.includes(t)) t = 'system';
  theme = t;
  if (t === 'system') delete document.documentElement.dataset.theme;
  else document.documentElement.dataset.theme = t;
  try { localStorage.setItem('cs.theme', t); } catch { /* private mode */ }
}
applyTheme(theme);
// Reconcile against the server (source of truth) once, after first paint. The
// injected attribute already made first paint correct; this repairs a stale
// cache and covers a static serve that did not inject. No write-back.
(async () => {
  try {
    const s = await api.getSettings();
    const t = s && typeof s.theme === 'string' ? s.theme : null;
    if (t && THEMES.includes(t) && t !== theme) applyTheme(t);
  } catch { /* offline — the cache/injection stand */ }
})();
// The Appearance control writes THROUGH: local (cache + <html>) then the server
// record. If the PATCH fails (offline) the cache holds and the next reconcile
// re-syncs; the server, when reachable, is the authority.
function setThemePersist(t) {
  applyTheme(t);
  api.patchSettings({ theme: t }).catch(() => { /* offline; cache holds */ });
}

/* ----------------------------------------------------------------- sidebar */

async function loadProjects() {
  state.projects = await api.listProjects();
  resortProjects(); // FEAT-070 — an explicit refresh is a sanctioned re-sort point
  renderTree();
}

function sessionState(id) {
  if (!state.sessions.has(id)) state.sessions.set(id, { loading: false, error: null, list: [], shown: PAGE, loaded: false });
  return state.sessions.get(id);
}

async function loadSessions(id, { force = false } = {}) {
  const s = sessionState(id);
  if (s.loaded && !force) return s;
  // AWAIT an in-flight load instead of returning the still-empty state.
  // Returning early here made applyRoute() see zero sessions whenever the
  // boot preload had started the same fetch first — and a session named in
  // the URL was then declared missing and silently dropped to the project.
  if (s.loading) return s.inflight ?? s;
  s.loading = true;
  s.error = null;
  renderTree();
  s.inflight = (async () => {
    try {
      const r = await api.projectSessions(id);
      s.list = (r.sessions ?? []).slice().sort((a, b) => recencyKey(b).localeCompare(recencyKey(a)));
      // session-list-recency — retire an optimistic user-submit stamp once the
      // server's derived value has reached it (the transcript write settled and
      // the scan saw it). Retiring keeps a stamp from PINNING a session past the
      // truth; keeping it while the server still lags is exactly what holds the
      // just-submitted session at the top across this refetch.
      for (const row of s.list) {
        const stamp = state.userSubmitAt.get(row.sessionId);
        if (stamp && String(row.lastUserMessageAt ?? '') >= stamp) state.userSubmitAt.delete(row.sessionId);
      }
      s.encodedDir = r.encodedDir ?? null;
      s.dirs = r.dirs ?? [];
      s.loaded = true;
    } catch (err) {
      s.error = err.message;
    } finally {
      s.loading = false;
      s.inflight = null;
      renderTree();
    }
    return s;
  })();
  return s.inflight;
}

function projectDot(p) {
  const s = state.sessions.get(p.id);
  // BUG-106 — the live open session belongs to state.openProjectId (its OWNER),
  // not to whatever the sidebar currently has selected. Keying the run dot to the
  // selection lit up a FOREIGN project's dot (B shows 'run' while A is the live
  // session). The owner gets the live dot; every other project falls to the
  // server-truth projectHasLive() path below. Identical when not foreign.
  if (state.live && state.openProjectId === p.id) return 'run';
  // Alive is alive wherever it happens: a collapsed project whose session is
  // being written RIGHT NOW (any process) gets the same moss dot — that is
  // "Claude is still working in here" at a glance.
  if (projectHasLive(p, s)) return 'run';
  if (s?.loaded && listedCount(s) === 0) return 'none';
  return '';
}

/* ═══════════════════════════ FEAT-070 — project ordering ══════════════════
 * Default: most-recently-worked at the top (lastActivityAt desc). The prior
 * decision recorded at app.js:177 rejected auto-EXPAND by recency (it rebuilt
 * the wall-of-sessions the cap exists to prevent) — a different concern from
 * ORDERING, but it names the real risk of recency here too: churn/jitter as an
 * active project shuffles to the top under the user. Reconciled per the user's
 * request: recency is the default, an explicit alpha toggle is always one click
 * away, and the order is CAPTURED and held stable within a session — only an
 * explicit refresh (loadProjects) or a sort flip re-sorts. So the sidebar does
 * not reorder itself while you work; it re-sorts when you ask it to.
 */
const PROJ_SORT_KEY = 'cs.projSort';
function loadProjSort() {
  try { return localStorage.getItem(PROJ_SORT_KEY) === 'alpha' ? 'alpha' : 'recency'; } catch { return 'recency'; }
}
const projRecency = (p) => { const t = Date.parse(p.lastActivityAt ?? ''); return Number.isFinite(t) ? t : 0; };
const projName = (p) => (p.name || '').toLowerCase();
function projLess(a, b) {
  return state.projSort === 'alpha'
    ? projName(a).localeCompare(projName(b))
    : (projRecency(b) - projRecency(a)) || projName(a).localeCompare(projName(b));
}
/** Recompute the stable display order — called ONLY on refresh or a sort flip. */
function resortProjects() {
  state.projOrder = state.projects.slice().sort(projLess).map((p) => p.id);
}
/**
 * Projects in display order. The captured `projOrder` holds within a session;
 * a project that appeared SINCE the last resort (not in the capture) floats to
 * the front by the live sort, so a brand-new project is never lost at the end.
 */
function orderedProjects() {
  const idx = new Map(state.projOrder.map((id, i) => [id, i]));
  return state.projects.slice().sort((a, b) => {
    const ia = idx.has(a.id) ? idx.get(a.id) : -1;
    const ib = idx.has(b.id) ? idx.get(b.id) : -1;
    if (ia >= 0 && ib >= 0) return ia - ib;      // both captured — hold the stable order
    if (ia < 0 && ib < 0) return projLess(a, b); // both new — live sort
    return ia < 0 ? -1 : 1;                       // a new project floats above captured ones
  });
}
/** Flip recency <-> alpha: persist, re-sort (an explicit act), repaint. */
function toggleProjSort() {
  state.projSort = state.projSort === 'alpha' ? 'recency' : 'alpha';
  try { localStorage.setItem(PROJ_SORT_KEY, state.projSort); } catch { /* private mode */ }
  resortProjects();
  paintProjSort();
  renderTree();
}
function paintProjSort() {
  if (!node.projSort) return;
  const alpha = state.projSort === 'alpha';
  node.projSort.textContent = alpha ? 'A–Z' : 'Recent';
  node.projSort.title = alpha
    ? 'Projects sorted A–Z — click for most-recent first'
    : 'Projects sorted most-recent first — click for A–Z';
  node.projSort.setAttribute('aria-label', node.projSort.title);
}

function renderTree() {
  const q = node.findInput.value.trim().toLowerCase();
  stampSeenCurrent(); // whatever is on screen is, by definition, seen
  clear(node.tree);

  if (!state.projects.length) {
    node.tree.append(el('div', { class: 'hint-row' },
      el('b', { text: 'No projects yet.' }),
      document.createTextNode(' Use '),
      el('b', { text: '+ Add project' }),
      document.createTextNode(' at the bottom to pick one of your directories — any Claude history it already has shows up straight away.')));
    return;
  }

  if (q) return renderSearch(q);

  /*
   * Recency split, not a manual archive: projects quiet for 2+ weeks fold
   * into one expandable row at the bottom. Derived state only — nothing to
   * mark, and a project un-archives itself the moment it sees activity.
   * The current project and the expanded working set always stay visible,
   * however old: "my open project vanished" is not a feature.
   */
  const ordered = orderedProjects();
  const active = ordered.filter(isActiveProject);
  const inactive = ordered.filter((p) => !isActiveProject(p));
  for (const p of active) renderProjectGroup(p);
  if (inactive.length) {
    const t = el('button', { class: 'inactive-l', 'aria-expanded': String(!!state.showInactive) },
      el('span', { class: 'tw', text: state.showInactive ? '▾' : '▸' }),
      document.createTextNode(`${inactive.length} inactive project${inactive.length === 1 ? '' : 's'}`),
      el('span', { class: 'qk', text: `quiet ${INACTIVE_AFTER_DAYS}d+` }));
    t.addEventListener('click', () => { state.showInactive = !state.showInactive; renderTree(); });
    node.tree.append(t);
    if (state.showInactive) for (const p of inactive) renderProjectGroup(p);
  }
}

const INACTIVE_AFTER_DAYS = 14;

function isActiveProject(p) {
  if (state.current.projectId === p.id) return true;
  if (state.expanded.has(p.id)) return true;
  const t = Date.parse(p.lastActivityAt ?? '');
  return Number.isFinite(t) && Date.now() - t < INACTIVE_AFTER_DAYS * 24 * 3600 * 1000;
}

function renderProjectGroup(p) {
  {
    const open = state.expanded.has(p.id);
    const s = state.sessions.get(p.id);
    const head = el('button', {
      class: 'proj',
      'aria-expanded': String(open),
      title: p.hostPath,
    });
    head.append(el('span', { class: 'tw', text: '▼' }));
    head.append(el('span', { class: `dot ${projectDot(p)}`.trim() }));
    head.append(el('span', { class: 'nm', text: p.name }));
    /*
     * BUG-138 — a project whose directory is gone says so HERE, before the user
     * spends a message finding out. The reported failure was a session that
     * showed the bare word "Error" because the directory had been renamed; the
     * server now reports `pathMissing` on the list every boot already fetches,
     * so the sidebar can name it. Clicking lands on the Directory block that
     * fixes it.
     */
    if (p.pathMissing) {
      const gone = el('span', {
        class: 'pgone', role: 'button', tabindex: '0', text: 'dir missing',
        title: `${p.hostPath} no longer exists — sessions can\u2019t start here.\nClick to point this project at its new directory (its sessions come with it).`,
      });
      gone.addEventListener('click', (e) => { e.stopPropagation(); selectProject(p.id); void drawer.open('settings'); });
      head.append(gone);
    }
    // Recency on the HEADER, so "which did I work on recently" reads at a
    // glance with nothing expanded (expansion stays a deliberate click).
    if (p.lastActivityAt) head.append(el('span', { class: 'ago', text: when(p.lastActivityAt), title: `last activity ${new Date(p.lastActivityAt).toLocaleString()}` }));
    // Ambient "running here" — visible with nothing expanded, no submenu.
    const pc = procChipText(p);
    if (pc) {
      const chip = el('span', { class: 'procn', role: 'button', tabindex: '0', text: pc, title: procChipTitle(p) });
      chip.addEventListener('click', (e) => { e.stopPropagation(); selectProject(p.id); void drawer.open('settings'); });
      head.append(chip);
    }
    // "What still needs me": sessions with activity since the user last had
    // them open. THE attention signal, so it wears the one accent colour.
    // Number only — the moss pill IS the word "new"; the tooltip spells it out.
    const fresh = unseenCount(s);
    if (fresh) head.append(el('span', { class: 'unseen', text: String(fresh), title: `${fresh} session${fresh === 1 ? '' : 's'} with activity since you last opened ${fresh === 1 ? 'it' : 'them'}` }));
    head.append(el('span', { class: 'n', text: s?.loaded ? String(listedCount(s)) : '' }));

    const plus = el('span', { class: 'plus', role: 'button', tabindex: '0', title: 'New session', 'aria-label': `New session in ${p.name}` });
    plus.append(iconPlus());
    plus.addEventListener('click', (e) => { e.stopPropagation(); startNew(p.id); });
    head.append(plus);

    const cog = el('span', { class: 'cog', role: 'button', tabindex: '0', title: 'Project settings', 'aria-label': `Settings for ${p.name}` });
    cog.append(iconCog());
    cog.addEventListener('click', (e) => {
      e.stopPropagation();
      selectProject(p.id);
      void drawer.open('settings');
    });
    head.append(cog);

    // FEAT-038: right-click a project → a small overflow with the one-click
    // "Onboard to Orchard" action (an occasional, per-project act, so it lives
    // in an overflow rather than adding a third always-on icon to every row).
    head.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openProjectMenu(p, e.clientX, e.clientY);
    });

    head.addEventListener('click', () => {
      if (state.expanded.has(p.id)) {
        state.expanded.delete(p.id);
        // Re-expanding should start compact again, not re-dump the whole list
        // the user just paged through — reset the reveal to the first page and
        // re-arm the FEAT-070 recency window.
        const s = state.sessions.get(p.id);
        if (s) { s.shown = PAGE; s.windowed = true; }
      } else { state.expanded.add(p.id); void loadSessions(p.id); }
      saveExpanded(); // expansion is the user's working set — it survives reloads
      selectProject(p.id, { quiet: true });
      renderTree();
    });
    // Header + sessions share a group: sticky is scoped to the group box, so
    // headers cannot pile up on each other once their project scrolls away.
    const group = el('div', { class: 'pgroup' });
    group.dataset.pid = String(p.id); // FEAT-147 — anchor so a project search-hit can scroll here
    group.append(head);
    node.tree.append(group);

    const kids = el('div', { class: 'kids' });
    kids.hidden = !open;
    if (open) {
      // FEAT-073: the not-yet-sent "New session" rides at the very TOP of its
      // project, above pinned and history alike — it is where you are right now.
      const pend = pendingNewFor(p.id);
      if (pend) kids.append(sessionRow(p, pend));
      if (s?.loading) kids.append(el('div', { class: 'hint-row', text: 'reading history…' }));
      else if (s?.error) kids.append(el('div', { class: 'hint-row', text: `history unavailable: ${s.error}` }));
      // A pending row already fills the group; the "no history" note would then
      // read as a contradiction under a visible session, so suppress it there.
      // All-hidden counts as empty: every row folds out of the default view, so
      // the list presents nothing — show an empty state, not a bare "N more" over
      // invisible clutter (BUG-193 round 1 finding 3). A project that genuinely
      // has NO session files gets the diagnostic note; one whose only sessions are
      // folded (dispatch lanes / external scripts) gets an honest "all hidden"
      // note instead of the false "no .jsonl files" text. Folded rows stay
      // reachable via search and their URL.
      else if (s?.loaded && !listedCount(s)) {
        if (!pend) kids.append(s.list.length ? allHiddenNote(s) : emptyProjectNote(p, s));
      }
      else if (s?.loaded) {
        const v = visibleSessions(s);
        v.rows.forEach((sess, i) => {
          const row = sessionRow(p, sess);
          // A hairline under the last pinned row. The pinned block needs an
          // edge, or it just reads as "the top of the list" and the pin does
          // no work at a glance.
          if (v.pinnedCount && i === v.pinnedCount - 1 && v.rows.length > v.pinnedCount) row.classList.add('pin-last');
          kids.append(row);
        });
        if (v.hidden > 0) {
          const more = el('button', { class: 'more', text: `${v.hidden} more` });
          // FEAT-070: the first "N more" lifts the recency window (reveals older
          // sessions); it and each further click grow the reveal by a screenful.
          more.addEventListener('click', () => { s.windowed = false; s.shown += PAGE_MORE; renderTree(); });
          kids.append(more);
        }
        // BUG-085: collapse-back. Once the user has paged past the default
        // capped view (window lifted or the reveal grown), offer an in-place
        // return to the ≤6 cap — no page reload (expansion used to be one-way
        // until refresh).
        if (s.windowed === false || (s.shown ?? PAGE) > PAGE) {
          const less = el('button', { class: 'more less', text: '▴ Show less' });
          less.addEventListener('click', () => { s.windowed = true; s.shown = PAGE; renderTree(); });
          kids.append(less);
        }
      }
    }
    group.append(kids);
  }
}

/**
 * A project with no sessions is ambiguous: never used, or used under a
 * different path (a container cwd, a Windows checkout) that the logical-key
 * merge — which keys on the directory basename — could not match. Say which.
 */
/**
 * The empty state for a project whose ONLY sessions are folded out of the nav
 * list (dispatch lanes, external `claude -p`/SDK scripts). Distinct from
 * emptyProjectNote so it never claims the store holds no session files — it
 * holds plenty; they are just hidden by design. Honest about the count and about
 * how to still reach them.
 */
function allHiddenNote(s) {
  const n = (s?.list ?? []).length;
  const note = el('div', { class: 'hint-row' });
  note.append(el('b', { text: 'No interactive sessions here.' }));
  note.append(document.createTextNode(
    ` ${n} background/scripted session${n === 1 ? '' : 's'} (agent lanes or external ‑p runs) ${n === 1 ? 'is' : 'are'} hidden from this list. Search or open one by URL to reach it.`));
  return note;
}

function emptyProjectNote(p, s) {
  const note = el('div', { class: 'hint-row' });
  if (s.dirs && s.dirs.length) {
    const win = s.dirs.filter((d) => /^[A-Za-z]--/.test(d));
    note.append(el('b', { text: 'No session logs for this project.' }));
    note.append(document.createTextNode(
      ` Claude has ${s.dirs.length === 1 ? 'a history folder that merges' : 'history folders that merge'} with this path (${s.dirs.join(', ')}), but ${s.dirs.length === 1 ? 'it holds' : 'they hold'} no .jsonl session files`
      + (win.length === s.dirs.length
        ? ` — ${win.length === 1 ? 'it was' : 'they were'} written on the Windows side, and only non-session data (project memory) came across.`
        : '.')));
    return note;
  }
  note.append(el('b', { text: 'No Claude history found for this path.' }));
  note.append(document.createTextNode(
    ` Nothing under ~/.claude/projects matches ${shortPath(p.hostPath)} (looked for ${s.encodedDir ?? 'its encoded form'}).`
    + ' Sessions this project ran under a different path — inside a container, or on the Windows side — are indexed under that path instead,'
    + ' because history is merged on the last path segment.'));
  return note;
}

/**
 * The title this session is LISTED under. `customTitle` wins when the server
 * carries a rename in its own field rather than folding it into `displayTitle`,
 * so the sidebar, the search filter, the crown and the rename verification all
 * read the same string — a rename that only some of them saw would be exactly
 * the kind of half-applied change this app refuses to show.
 */
const rowTitle = (s) =>
  (typeof s?.customTitle === 'string' && s.customTitle ? s.customTitle : (s?.displayTitle ?? ''));

/*
 * FEAT-073 — the pending "New session" row.
 *
 * Selecting "New session" opens a not-yet-sent session (state.current with a
 * projectId but no encodedDir/sessionId). There is no on-disk session yet, so
 * renderTree — which lists server-known sessions — had nothing to show and the
 * new session was invisible in the sidebar. This synthesises a single derived
 * row for it: pinned to the TOP of its project, marked current/open. It is
 * PURELY derived from state.current, so it disappears the moment the user
 * navigates away (state.current changes → the next renderTree drops it) with no
 * orphan to clean up, and it never touches the BUG-083 draft map. Once the first
 * message sends the session becomes real: state.stationSessionId (then the
 * encodedDir/sessionId) is set, this returns null, and the real row from the
 * server list renders in its place — no duplicate, because the sentinel is never
 * added to any session list.
 */
const PENDING_NEW_ID = '__pending_new__';
function pendingNewFor(pid) {
  const c = state.current;
  // Only an EXPLICITLY-opened New session (startNew) shows the row — not every
  // project that happens to have no session on screen.
  if (state.pendingNew !== pid || !c || c.projectId !== pid) return null;
  // A real session (opened from disk, or this one once its first turn started)
  // carries a sessionId/encodedDir, or at least a live station bridge.
  if (c.sessionId != null || c.encodedDir != null || state.stationSessionId) return null;
  return {
    sessionId: PENDING_NEW_ID,
    encodedDir: null,
    displayTitle: c.title || 'New session',
    os: c.os || 'linux',
    lastActivityAt: new Date().toISOString(),
    pending: true,
  };
}

/**
 * A project's rows in display order: pinned first, then the rest, each block
 * newest-first. Ordering here rather than in loadSessions() means a pin the
 * server has just confirmed re-sorts on the next render.
 */
/*
 * The recency key is the last time the USER submitted a message, NOT transcript
 * mtime (`lastActivityAt`). A session an agent has been grinding in for hours —
 * live, streaming frames — must NOT keep climbing to the top: only a human
 * submit reorders. mtime moved on every agent write, which reshuffled the list
 * under the reader (the exact "it keeps reordering perma" the user reported).
 * `lastUserMessageAt` is server-derived from the transcript (so it survives
 * reload and is right for pre-existing sessions), stamped optimistically on a
 * local send (recencyKey / stampUserSubmit) so the reorder is instant. It falls
 * back to lastActivityAt for rows without a detected human prompt (codex, or a
 * transcript whose user turn fell outside the sampled window). FOLDING stays
 * keyed on LIVENESS, not this — a live agent session is never folded even
 * though the human has not typed in it (see hasLiveWork / visibleSessions).
 */
const recencyKey = (x) => {
  // MAX(server-derived last-user-submit, client optimistic stamp). ISO strings
  // compare chronologically, so `>` picks the later of the two. The stamp keeps
  // a just-submitted session at the top across a refetch whose re-derived server
  // value has not caught up (or, for a large sampled transcript, never will);
  // it is cleared in loadSessions the moment the server value reaches it.
  const stamp = state.userSubmitAt.get(x?.sessionId);
  const server = x?.lastUserMessageAt ?? null;
  const submit = stamp && (!server || stamp > server) ? stamp : server;
  return String(submit ?? x?.lastActivityAt ?? '');
};
function orderedSessions(s) {
  // The session the user is CURRENTLY in leads its own group's recency tail, so
  // opening or switching to a session makes it the top row and it is never
  // something to re-hunt for on the next switch (the reported "keep refinding
  // when switching until i page reload"). This is a TRANSIENT ordering tier, not
  // a durable recency stamp: it follows state.current, so switching away lets the
  // previous session fall straight back to its true last-user-submit recency (no
  // accumulation), and an AGENT frame — which never changes state.current — can
  // never move the list, preserving the "only my own action reorders" property.
  // It sits BELOW an explicit pin (a pin is a stronger, durable "keep at top"
  // choice) and is reload-consistent because the open session is restored from
  // the URL before this runs.
  const isOpen = (x) => state.current.sessionId != null
    && x?.sessionId === state.current.sessionId
    && x?.encodedDir === state.current.encodedDir;
  const rank = (x) => (api.pinnedOf(x) ? 0 : (isOpen(x) ? 1 : 2));
  return (s.list ?? []).slice().sort((a, b) => rank(a) - rank(b)
    || recencyKey(b).localeCompare(recencyKey(a)));
}

/*
 * A human just submitted into `sessionId` (composer send / resume / fork).
 * Stamp its row's user-submit recency to now so the sidebar reorders it to the
 * top IMMEDIATELY, before the transcript round-trips to disk and the next list
 * fetch carries the server-derived value. Agent frames never call this — that is
 * the client half of "only my submitted message reorders". A no-op for a
 * not-yet-real session (no sessionId), whose row is the pinned pending-new row
 * already at the top.
 */
function stampUserSubmit(sessionId, encodedDir) {
  if (!sessionId) return;
  const iso = new Date().toISOString();
  // The DURABLE half: recencyKey reads this map, so the reorder survives the
  // wholesale s.list replacement a turn-end/live-poll refetch performs (which
  // re-derives an older server lastUserMessageAt and, without this, reverted the
  // session back down — the reported "only reorders after a reload"). Cleared in
  // loadSessions once the server value catches up.
  state.userSubmitAt.set(sessionId, iso);
  for (const [, s] of state.sessions) {
    const row = (s.list ?? []).find((x) => x.sessionId === sessionId
      && (encodedDir == null || x.encodedDir == null || x.encodedDir === encodedDir));
    // Mutating the on-hand row too keeps the immediate render correct even before
    // the next sort reads the map; both agree because both take the max.
    if (row) { row.lastUserMessageAt = iso; break; }
  }
  renderTree();
}

/*
 * FEAT-070 / session-list-recency — the default per-project view is a RECENCY
 * WINDOW, not a flat 6. But recency alone is a poor filter: the real store is
 * mostly BRIEF throwaway sessions (median 3 renderable messages, p25=1), and a
 * flat one-week window kept every one of them — clutter that took the same
 * vertical space as the session being worked in right now.
 *
 * So the window is SUBSTANCE-SCALED: how long a session stays in the default
 * view depends on how much work it holds.
 *   - A SUBSTANTIAL session (>= SUBSTANTIAL_MSGS renderable messages — a real
 *     back-and-forth you may be mid-way through) stays visible for days.
 *   - A BRIEF session (a one-shot question, an abandoned start) drops out of the
 *     default view within hours: a one-message session from an hour ago is
 *     clutter, not the working set.
 * Both fold under the SAME "N more" affordance (clicking it lifts the window and
 * reveals everything — see renderProjectGroup). The open session and any session
 * with LIVE work never fold, whatever their age (visibleSessions).
 */
const SUBSTANTIAL_MSGS = 6;          // >= this many renderable messages = a real session, not a one-shot
const BRIEF_WINDOW_H = 2;            // a brief session leaves the default view this fast
const SUBSTANTIAL_WINDOW_H = 72;     // a substantial one you may be mid-way through lingers ~3 days
const hoursSince = (iso) => {
  const t = Date.parse(iso ?? '');
  return Number.isFinite(t) ? (Date.now() - t) / 3600000 : Infinity;
};
const isBriefSession = (sess) => (Number(sess?.messageCount) || 0) < SUBSTANTIAL_MSGS;
const withinRecentWindow = (sess) =>
  hoursSince(sess?.lastActivityAt) < (isBriefSession(sess) ? BRIEF_WINDOW_H : SUBSTANTIAL_WINDOW_H);
/*
 * "Attention" = activity the user has not seen since they last had the session
 * open (the same signal `unseenCount`/the row `fresh` badge use). BUG-085: this
 * NO LONGER bypasses the ≤6 cap — a day working across a dozen sessions used to
 * make every one "attention" and explode the list past the cap. Attention now
 * only wins PRIORITY within the cap (ranked first among the visible seats) and
 * stays exempt from the recency WINDOW (an old-but-active session still competes
 * for a seat rather than being folded outright). Never-seen OLD sessions are NOT
 * attention — the 24h baseline (mirroring unseenCount) keeps them out.
 */
function isAttentionSession(sess) {
  if (!sess) return false;
  if (sess.sessionId === state.current.sessionId) return false; // the open session is always-in on its own
  const k = seenKey(sess.encodedDir, sess.sessionId);
  const base = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  return String(sess.lastActivityAt ?? '') > (state.seen.get(k) ?? base);
}
/*
 * The only session that bypasses the hard cap outright is the one open on
 * screen ("my open session vanished" is not a feature). Pins are handled
 * separately in their own always-on block (an explicit user act may exceed the
 * cap). Everything else — attention included — earns a capped seat.
 */
const isAlwaysVisible = (sess) => sess?.sessionId === state.current.sessionId;
/*
 * A session with LIVE or background work in flight is NEVER folded, whatever its
 * age or length — hiding a running session behind "N more" is the same class of
 * defect as a status chip that cannot tell working from dead. `liveInfo` is the
 * same alive signal the row's moss dot uses (this dashboard driving it, or
 * another writer), so what the fold hides can never contradict what a visible
 * row would claim is running.
 */
const hasLiveWork = (sess) => liveInfo(sess) != null;

/*
 * An AGENT-started session (an orchestrator's dispatched worker lane), declared
 * at creation by the server (`startedBy`, from session-provenance). These bury
 * the human's own conversations in a project agents actually work in — a busy
 * project accretes far more dispatched rows than human ones, all titled with
 * ticket ids. So they FOLD out of the default view like an out-of-window row:
 * revealed by the SAME "N more" affordance, always reachable by URL/search, and
 * NEVER folded while live or open (those bypass the pool via alwaysIds below —
 * hiding running work is a defect class this app has hit before). A row with no
 * declared provenance defaults to 'user' server-side, so pre-existing human
 * sessions stay visible.
 */
const isAgentStarted = (sess) => sess?.startedBy === 'agent';

/*
 * Whether a row FOLDS out of the default nav view. The server owns this decision
 * (`foldByDefault`, from session-provenance.foldsFromDefaultList) so the client
 * never re-derives it — ARCH-010. It covers TWO kinds of clutter the human never
 * opened: an orchestrator's dispatched worker lanes (startedBy 'agent') AND
 * external programmatic sessions Orchard never launched (an `sdk-cli`/`sdk-ts`
 * transcript with no Orchard provenance record — e.g. a `claude -p` script). It
 * is presentation-only: the row is still reachable via "N more", search and its
 * URL, and a live/open row bypasses the fold via alwaysIds. The `?? isAgentStarted`
 * fallback keeps the pre-existing lane fold working against an older server that
 * has not yet learned to send the field.
 */
const foldsFromList = (sess) =>
  (typeof sess?.foldByDefault === 'boolean' ? sess.foldByDefault : isAgentStarted(sess));

/*
 * The sessions a project's nav list actually PRESENTS — everything except the
 * rows folded out of the default view (dispatch lanes, external programmatic
 * sessions). This is the set every COUNT and BADGE that describes the list must
 * measure: the header session count, the empty-state, the unseen badge and the
 * "N sessions of history listed" toast. A folded row is still reachable via
 * "N more"/search/URL, but it does not COUNT toward "this project has N
 * sessions" — otherwise an all-hidden project reads "1" while showing nothing
 * (BUG-193 round 1 finding 3). Reads the server's `foldByDefault` via
 * `foldsFromList`; the client never recomputes the fold.
 */
const listedSessions = (s) => (s?.list ?? []).filter((x) => !foldsFromList(x));
const listedCount = (s) => listedSessions(s).length;

/*
 * ── FEAT-118 — the picker's per-row LIFECYCLE state, read from GROUND TRUTH ──
 *
 * Five states the user asked to tell apart, resolved WITHOUT inventing a sixth
 * notion of "is this alive": running comes from the liveness authority (the same
 * /api/sessions/live signal the moss dot already uses), a death comes from the
 * server-recorded agent-outcomes ledger (outcomes.ts — the "what died and why"
 * store), unread/visited come from the seen map. `sessionLifecycle` returns the
 * single leading-rail marker (mutually exclusive, priority order); unread and
 * recently-visited are ORTHOGONAL emphases layered on top by sessionRow.
 *
 *   'running'  — liveInfo(sess) != null. The authority vouches for it now.
 *   'stopped'  — NOT live, and an UNDISMISSED still-recent agent-outcome (a
 *                server-recorded DEATH, kind ≠ completed) names this session.
 *                THIS is "it was working in the background and died without
 *                answering", surfaced in the list where it was invisible before.
 *                Same isRecentOutcome view the death rail renders, so the row
 *                marker and the rail can never disagree about what died.
 *   'finished' — NOT live, NO death on record, but written to within
 *                FINISHED_WINDOW_MS: almost certainly running moments ago, just
 *                gone quiet. Claimed ONLY when activity is genuinely that recent
 *                — a session whose fate is UNKNOWN carries a death record and
 *                reads 'stopped', so an unknown fate is NEVER dressed up as a
 *                clean finish (WA §C: never claim a state you cannot know).
 *   null       — an ordinary idle/older row: no rail marker.
 */
const FINISHED_WINDOW_MS = 8 * 60 * 1000;   // "just went quiet" ⇒ recently-finished
const VISITED_WINDOW_MS = 2 * 3600 * 1000;  // opened within this ⇒ recently-visited

/** The undismissed, still-recent DEATH record for this session, or null. Reads
 *  the same state.outcomes the death rail renders (scoped to the current project
 *  — see refreshOutcomes), matched on either id the ledger keys deaths by. */
function endedUnanswered(sess) {
  const id = sess?.sessionId;
  if (!id || !Array.isArray(state.outcomes)) return null;
  for (const o of state.outcomes) {
    if (!isRecentOutcome(o)) continue;
    // FEAT-154 (round 3, bug B): the "ended without answering" marker is a fact
    // about the SESSION — its own main turn ended without producing an answer.
    // A `row:'tool'` death (a failed/killed local_bash lane) or a `row:'agent'`
    // death (a subagent that died) is NOT the session dying: the main turn kept
    // going and answered. The owner (outcomes.ts, `row`) already distinguishes
    // them; read that field rather than treating every lane death as a session
    // death. Without this, a LIVE orchestrator session whose only outcomes were
    // failed background bash lanes rendered the red "ended without answering"
    // triangle whenever it was momentarily not-running.
    if (o.row !== 'main') continue;
    if (o.sdkSessionId === id || o.stationSessionId === id) return o;
  }
  return null;
}

/** Is a TURN actually in flight for this row? Reads the liveness authority's own
 *  `running` field (ARCH-010: the owner declares it, the reader never re-derives
 *  it). `hasLiveWork` — mere PRESENCE in the live list — is the wrong signal for
 *  this: an alive-but-idle DETACHED bridge is present in the list with
 *  `liveness.running===false`, which is exactly FEAT-154 bug A (a day-idle
 *  session rendered light-blue "running"). A live-list entry that carries no
 *  `liveness` block is there only because its transcript mtime is fresh (<30s),
 *  which itself IS active writing — so that counts as running; likewise the
 *  degraded no-route fallback (liveInfo's `sess.live` branch) keeps the
 *  historical "the row's own live flag ⇒ running" answer. */
function isSessionRunning(sess) {
  const info = liveInfo(sess);
  if (!info) return false;
  // The liveness authority's own verdict, carried through by api.liveSessions()
  // (ARCH-010). `working` (FEAT-154 round 5) is the user's notion of running — a
  // MAIN turn in flight OR a live subagent/background lane — so a session whose
  // main turn ended while its subagents keep working reads as running; prefer it.
  // Fall back to `running` (main turn only) on an older server that omits it.
  // `null`/absent for both = a transcript-mtime-only entry (actively being
  // written) OR the degraded no-route fallback (liveInfo's `sess.live` branch) —
  // both keep the historical "present ⇒ running" answer; only a boolean `false`
  // (an alive-but-idle bridge with no live work) is not running (round 3).
  if (typeof info.working === 'boolean') return info.working;
  if (typeof info.running === 'boolean') return info.running;
  return true;
}

function sessionLifecycle(sess) {
  if (isSessionRunning(sess)) return 'running';
  if (endedUnanswered(sess)) return 'stopped';
  if (hoursSince(sess?.lastActivityAt) * 3600000 <= FINISHED_WINDOW_MS) return 'finished';
  return null;
}

/** The user OPENED this row within the recent-visit window (the quietest tier —
 *  a persistent muted timestamp, no glyph, no colour). */
function recentlyVisited(sess) {
  if (!sess || sess.sessionId === state.current.sessionId) return false;
  const t = Date.parse(state.seen.get(seenKey(sess.encodedDir, sess.sessionId)) ?? '');
  return Number.isFinite(t) && (Date.now() - t) <= VISITED_WINDOW_MS;
}

/** A short, honest tooltip for a died-without-answering row, from the ledger's
 *  own words — never a fabricated cause. */
function stoppedTip(o) {
  if (!o) return 'Ended without answering';
  const why = o.kind === 'provider-error' && o.providerError
    ? `${o.providerError.kind} (${o.providerError.provider})`
    : (o.kind === 'unknown' ? 'reason unknown' : o.kind);
  return `Ended without answering — ${why} · ${datedTime(o.at)}`;
}

/*
 * The default seat budget ADAPTS to how many sessions are genuinely recent,
 * rather than a fixed slice. When a burst of recent work fills the window the
 * budget opens up to the ceiling and the older tail folds ("show current
 * sessions less"); on a quiet project it stays near the floor so the sidebar
 * doesn't reserve dead space. Live/open/pinned bypass the budget entirely (see
 * visibleSessions), so this only governs the ordinary recency tail.
 *   MAX_SEATS holds the historical ≤6 ceiling (BUG-085's invariant that a day of
 *   many "attention" sessions can never explode the list, and the one-screen-
 *   third rationale that keeps every project on screen at once).
 */
const MIN_SEATS = 4;
const MAX_SEATS = 6;
const RECENT_SEAT_H = 24;            // "genuinely recent" for the purpose of sizing the budget

/**
 * What the row cap actually shows. A pin hidden behind "N more" is a pin that
 * does nothing, so pinned rows are always present and the cap applies to the
 * unpinned remainder only.
 *
 * The default view is bounded by an ADAPTIVE budget (MIN..MAX_SEATS), sized by
 * how many pool sessions are genuinely recent — not a fixed count. Bypasses that
 * are never folded: the OPEN session (on screen) and any session with LIVE work
 * (whatever its age). 24h "attention" only reorders WITHIN the budget (priority
 * for a seat), it never buys extra seats (BUG-085). Sessions outside the
 * substance-scaled recency window fold under "N more" unless attention keeps
 * them competing. `hidden` is the true number of unpinned rows off screen.
 */
function visibleSessions(s) {
  const ordered = orderedSessions(s);
  const pinned = ordered.filter((x) => api.pinnedOf(x));
  const rest = ordered.filter((x) => !api.pinnedOf(x)); // recency-ordered
  const windowed = s.windowed !== false;                // "N more" sets this false
  // Never folded, whatever the budget: the open session (on screen) and any
  // session with live/background work in flight — BUT NEVER a FOLDED row.
  //   BUG-193 (user decision, round 5): a programmatic row (a dispatch/verify
  //   lane, an external `claude -p`/codex-exec run) is not meant for the user to
  //   interact with, so it must NOT appear in the nav list — running or not,
  //   open or not. The two former bypasses both leaked it in: `isAlwaysVisible`
  //   (a folded lane the user only deep-linked into) and `hasLiveWork` (a folded
  //   lane surfaced simply because it was mid-turn — the actual cause of the
  //   round-5 sighting: `01a0e93a`, an openai verify lane, was live when seen).
  //   Both now yield to the fold. The row's contract is unchanged: it still
  //   OPENS on a direct deep link and the transcript pane renders it; it stays
  //   reachable via "N more"/URL/search; and running lanes remain observable via
  //   the project proc chip + the orchestrator's own lane views — only the nav
  //   row is withheld. A NON-folded live/open session (dashboard/interactive)
  //   still always shows, so real work never vanishes.
  const alwaysIds = new Set(rest.filter((x) =>
    !foldsFromList(x) && (isAlwaysVisible(x) || hasLiveWork(x))).map((x) => x.sessionId));
  // The pool competing for the budget: everything not already always-in, kept if
  // it is within the (substance-scaled) recency window OR carries unseen
  // attention (so an old-but-active session still competes rather than being
  // folded outright). When the window is lifted by "N more", everything qualifies.
  // Programmatic rows fold out of the DEFAULT view (a dispatched worker lane, or
  // an external `claude -p`/SDK session Orchard never launched — clutter the human
  // never opened); "N more" (windowed === false) reveals them like any other
  // folded row, and a live/open one already bypassed the pool via alwaysIds above,
  // so running work is never hidden. `foldsFromList` is the server-owned decision.
  const pool = rest.filter((x) => !alwaysIds.has(x.sessionId)
    && (!windowed || (!foldsFromList(x) && (withinRecentWindow(x) || isAttentionSession(x)))));
  // Adaptive seat budget: sized by how many pool sessions are genuinely recent,
  // clamped to [MIN_SEATS, MAX_SEATS]. Lifting the window ("N more") hands the
  // budget to s.shown — the progressive reveal.
  const recentInPool = pool.filter((x) => hoursSince(x.lastActivityAt) < RECENT_SEAT_H).length;
  const seats = windowed
    ? Math.min(MAX_SEATS, Math.max(MIN_SEATS, recentInPool))
    : Math.max(0, s.shown);
  // Rank for the scarce seats: SUBSTANTIAL sessions first, then unseen
  // attention, then recency (a stable sort preserves recency order among
  // equals). Substance leads because a long session from yesterday you are
  // mid-way through must outrank a one-message throwaway from an hour ago — the
  // reverse (pure recency/attention) would fold the work and keep the clutter.
  const briefRank = (x) => (isBriefSession(x) ? 1 : 0);
  const ranked = pool.slice().sort((a, b) =>
    briefRank(a) - briefRank(b)
    || (isAttentionSession(b) ? 1 : 0) - (isAttentionSession(a) ? 1 : 0));
  const capped = ranked.slice(0, seats);
  const keep = new Set([...alwaysIds, ...capped.map((x) => x.sessionId)]);
  // Display in recency order — attention priority decides WHICH make the cut,
  // never the order the user reads the rows in.
  const shown = rest.filter((x) => keep.has(x.sessionId));
  return { rows: [...pinned, ...shown], pinnedCount: pinned.length, hidden: rest.length - shown.length };
}

/** Multi-line tooltip. Only states what an explicit server field says is true. */
function rowTooltip(sess, pinned, renamed) {
  const bits = [rowTitle(sess)];
  if (pinned) bits.push('Pinned — held at the top of this project');
  if (renamed) {
    const auto = api.autoTitleOf(sess);
    bits.push(auto ? `Renamed by you — was “${auto}”` : 'Renamed by you');
  }
  return bits.join('\n');
}

function sessionRow(p, sess) {
  const isWin = sess.os === 'windows';
  const pendingRow = sess.pending === true; // FEAT-073 — the not-yet-sent new session
  const active = pendingRow || state.current.sessionId === sess.sessionId;
  const pinned = !pendingRow && api.pinnedOf(sess);
  const renamed = !pendingRow && api.renamedOf(sess);
  const k = seenKey(sess.encodedDir, sess.sessionId);
  const fresh = !active
    && String(sess.lastActivityAt ?? '') > (state.seen.get(k) ?? new Date(Date.now() - 24 * 3600 * 1000).toISOString());
  // FEAT-118 — the leading-rail lifecycle marker (ground truth) plus the two
  // quiet orthogonal cues. Row-level classes carry the persistent-timestamp
  // treatments (amber "when" for a death, muted "when" for a recent visit).
  const life = pendingRow ? null : sessionLifecycle(sess);
  const visited = !pendingRow && recentlyVisited(sess);
  // FEAT-154 (round 2) — WAITING ON YOU: the model paused on a question/permission
  // and needs an answer. Read from the SERVER-published set (`state.awaitingIds`,
  // sourced from the bridge's own `#approvals` via /api/sessions `awaitingUser` —
  // BUG-166's owner, ARCH-010), keyed by sdkSessionId. This covers EVERY row, not
  // just the open one, and the client never re-derives it from busy flags. It
  // out-ranks every lifecycle marker because a turn paused for input still reads
  // `live` (would otherwise show as running/blue).
  const awaiting = !pendingRow && state.awaitingIds.has(sess.sessionId);
  // Unread is silent while running (content is arriving) — so the class that
  // carries the unread type-lift is withheld there too, not just the tick.
  const showUnread = fresh && life !== 'running';
  const b = el('button', {
    class: `row${isWin ? ' win' : ''}${pendingRow ? ' pending' : ''}${pinned ? ' pinned' : ''}${renamed ? ' named' : ''}${showUnread ? ' fresh' : ''}`
      + `${awaiting ? ' awaiting' : ''}${life === 'stopped' ? ' died' : ''}${visited ? ' visited' : ''}`,
    'aria-current': String(active),
    title: pendingRow ? 'New session — not sent yet' : rowTooltip(sess, pinned, renamed),
  });
  b.append(el('span', { class: 'when', text: when(sess.lastActivityAt) }));
  // BUG-086: pinned rows carry an explicit pin GLYPH (reads as "pinned"), not a
  // leading-edge bar (which reads as selection/active). Only aria-current keeps
  // the active highlight; a pinned-not-open row stays clearly un-selected. A
  // pinned-AND-open row shows the active highlight AND this marker.
  if (pinned) {
    b.append(el('span', { class: 'pin-mark', title: 'Pinned', 'aria-hidden': 'true' }, svg(MENU_ICON.pin, 11)));
  }
  b.append(document.createTextNode(rowTitle(sess)));
  // FEAT-037 P2b: an Orchard-owned (non-Claude) session names its engine — the
  // same quiet `codex` voice as the crown chip. Anthropic rows render
  // byte-identical to before (no tag, no dataset).
  if (sess.provider && sess.provider !== 'anthropic') {
    b.dataset.provider = sess.provider;
    b.append(el('span', {
      class: 'prov-tag',
      text: sess.provider === 'openai' ? 'codex' : sess.provider,
      title: 'recorded by the OpenAI Codex engine — reopening resumes the same thread',
    }));
  }
  /*
   * FEAT-118 — ONE leading-rail marker, chosen by lifecycle (ground truth). The
   * five states resolve into three salience tiers so a dense list reads as a
   * hierarchy, not five competing colours:
   *   ALARM  — a death (amber filled triangle: a distinct SHAPE, not just a hue,
   *            so it survives colour-blindness and a fast scan). The one bold
   *            thing; boldness is spent here because a silently-died session is
   *            what loses work.
   *   ACTIVE — running (the existing moss breathing dot) and recently-finished
   *            (the same moss, a STILL hollow ring). One family, differentiated
   *            by motion, so the eye groups "alive / just-alive" apart from the
   *            amber alarm.
   *   QUIET  — unread (a moss tick on the TRAILING edge + title lift, off the
   *            leading rail so it never doubles up with a lifecycle dot) and
   *            recently-visited (a persistent muted timestamp, no glyph at all).
   */
  // Precedence (single leading marker): waiting-on-you > running > error(died) >
  // finished > idle. `stateSr` is the plain-words state for screen readers — the
  // glyphs are colour/shape only (aria-hidden), so a non-visual reader still hears
  // the state (FEAT-154; colour is never the only cue).
  let stateSr = null;
  if (awaiting) {
    b.append(el('span', { class: 'waiting', 'aria-hidden': 'true', title: 'Waiting on your answer' }));
    b.dataset.awaiting = '1';
    stateSr = 'waiting on you';
  } else if (life === 'running') {
    const alive = liveInfo(sess);
    b.append(el('span', {
      class: `alive${alive?.drivenByDashboard ? ' here' : ''}`, 'aria-hidden': 'true',
      title: alive?.drivenByDashboard
        ? 'running now — this dashboard is driving it'
        : 'running now — another process is writing this session',
    }));
    b.dataset.live = alive?.drivenByDashboard ? 'here' : 'true';
    stateSr = alive?.drivenByDashboard ? 'running now — this dashboard is driving it' : 'running now';
  } else if (life === 'stopped') {
    const o = endedUnanswered(sess);
    b.append(el('span', { class: 'stopped', 'aria-hidden': 'true', title: stoppedTip(o) }));
    b.dataset.stopped = '1';
    stateSr = 'ended without answering';
  } else if (showUnread) {
    // FEAT-154 (visual-review): UNREAD lives on the LEADING rail now — a FILLED
    // moss dot ("new / something to read"), the counterpart to the hollow
    // finished ring below. Keeping unread in the primary scan column (not a
    // second trailing dot) is the review's fix for finished-unread vs
    // finished-read being told apart only by a faint timestamp, and it removes
    // the two-different-meanings-for-a-dot ambiguity. Bold title (row.fresh) and
    // the green timestamp still back it.
    b.append(el('span', { class: 'settled new', 'aria-hidden': 'true', title: 'New activity since you last looked' }));
    stateSr = life === 'finished' ? 'just finished, unread' : 'unread — new since you last looked';
  } else if (life === 'finished') {
    // Read + just-finished: a quiet HOLLOW moss ring (no motion, no bold).
    b.append(el('span', { class: 'settled', 'aria-hidden': 'true', title: 'Just finished — no turn is running now' }));
    stateSr = 'just finished';
  }
  // Carry the state to screen readers via aria-label (NOT a text child): the
  // glyphs are colour/shape only, and a text child would pollute the row's
  // textContent (breaking title-suffix matching and adding "3h — running" noise
  // to the accessible name). aria-label names the row as "title — state".
  if (stateSr) b.setAttribute('aria-label', `${rowTitle(sess)} — ${stateSr}`);
  // FEAT-073: the pending-new row IS the open session already — clicking it just
  // returns focus to the composer. It has no on-disk session, so openSession /
  // the rename·pin·delete row menu (which act on a real sessionId) don't apply.
  if (pendingRow) {
    b.addEventListener('click', () => node.prompt?.focus());
    return b;
  }
  b.addEventListener('click', () => void openSession(p, sess));

  /* Our menu, not the browser's. `contextmenu` also fires for the keyboard
     Context-Menu key, which arrives with no useful pointer coordinates — so
     that case is detected and anchored to the row instead of to (0,0). */
  b.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const byKey = e.button === -1 || (e.clientX === 0 && e.clientY === 0);
    const r = b.getBoundingClientRect();
    openRowMenu(p, sess, byKey ? r.left + 26 : e.clientX, byKey ? r.bottom - 2 : e.clientY, b);
  });
  b.addEventListener('keydown', (e) => {
    // Shift+F10 is the other standard way in, and Chrome does NOT synthesise a
    // contextmenu event for it, so it needs its own handler.
    if (!(e.shiftKey && e.key === 'F10')) return;
    e.preventDefault();
    const r = b.getBoundingClientRect();
    openRowMenu(p, sess, r.left + 26, r.bottom - 2, b);
  });
  return b;
}

/*
 * Finder query grammar. Plain text filters session titles everywhere.
 * A leading "#" scopes discord-style: while the project name is being typed
 * ("#ext"), project-name suggestions render — Enter or click completes; once
 * completed ("#external-project-J ..."), everything after searches INSIDE that
 * project only. Inactive (folded) projects are findable the same way.
 */
function parseFinderQuery(raw) {
  // Left-trim only — a TRAILING space is load-bearing here: it is how
  // completeProjectScope() signals "the project name is complete, now show
  // its whole session list" (mode 'scoped' with an empty text) rather than
  // "still typing the project name" (mode 'pickProject'). A full trim()
  // would erase that signal and make the scoped-empty view unreachable
  // (BUG-009).
  const m = /^#(\S*)(?:\s(.*))?$/.exec(raw.replace(/^\s+/, ''));
  if (!m) return { mode: 'plain', text: raw.trim().toLowerCase() };
  const name = m[1].toLowerCase();
  if (m[2] === undefined) return { mode: 'pickProject', name };
  const project = state.projects.find((x) => x.name.toLowerCase() === name)
    ?? state.projects.find((x) => x.name.toLowerCase().startsWith(name));
  return { mode: 'scoped', project: project ?? null, name, text: (m[2] ?? '').trim().toLowerCase() };
}

/** Complete "#partial" to the first matching project. Returns true if it did. */
function completeProjectScope() {
  const pq = parseFinderQuery(node.findInput.value);
  if (pq.mode !== 'pickProject') return false;
  const match = state.projects.find((x) => x.name.toLowerCase().includes(pq.name));
  if (!match) return false;
  node.findInput.value = `#${match.name} `;
  renderTree();
  return true;
}

function renderSearch(raw) {
  // Parse the LIVE input value, not the fully-trimmed `raw` gate value from
  // renderTree() — a trailing space on `raw` is the scoped-empty sentinel
  // (see parseFinderQuery) and must survive into parseFinderQuery() untouched.
  const pq = parseFinderQuery(node.findInput.value.length ? node.findInput.value : raw);

  if (pq.mode === 'pickProject') {
    const matches = state.projects.filter((x) => x.name.toLowerCase().includes(pq.name));
    node.tree.append(el('div', { class: 'found-l', text: `${matches.length} project${matches.length === 1 ? '' : 's'} — Enter to scope the search` }));
    for (const p of matches) {
      const b = el('button', { class: 'row hit', title: `Search inside ${p.name}` });
      const top = el('span', { class: 'hit-top' });
      top.append(el('span', { class: 'when', text: when(p.lastActivityAt) }));
      top.append(document.createTextNode(`#${p.name}`));
      if (!isActiveProject(p)) top.append(el('span', { class: 'in', text: '  inactive' }));
      b.append(top);
      b.addEventListener('click', () => { node.findInput.value = `#${p.name} `; node.findInput.focus(); renderTree(); });
      node.tree.append(b);
    }
    if (!matches.length) node.tree.append(el('div', { class: 'hint-row', text: 'no project by that name' }));
    return;
  }

  if (pq.mode === 'scoped' && !pq.project) {
    node.tree.append(el('div', { class: 'hint-row', text: `no project named “#${pq.name}” — backspace to see the suggestions` }));
    return;
  }

  const scopeIds = pq.mode === 'scoped' ? new Set([pq.project.id]) : null;
  const text = pq.text;
  if (scopeIds && !state.sessions.get(pq.project.id)?.loaded) void loadSessions(pq.project.id);

  const hits = [];
  for (const p of state.projects) {
    if (scopeIds && !scopeIds.has(p.id)) continue;
    const s = state.sessions.get(p.id);
    if (!s?.loaded) continue;
    for (const sess of s.list) {
      // An empty scoped query ("#proj ") lists the whole project.
      if (!text || rowTitle(sess).toLowerCase().includes(text)) hits.push({ p, sess });
      if (hits.length >= 300) break;
    }
  }
  // FEAT-147 — plain-text search also surfaces PROJECTS, above the session
  // hits. The reported need: reach a project (e.g. to start a new session in
  // it) by typing part of its name, without knowing the "#" scope grammar or
  // scrolling the whole session list. A direct project-name match must not sit
  // below session-title hits, so this section renders first.
  if (pq.mode === 'plain' && text) {
    const projHits = state.projects
      .filter((p) => p.name.toLowerCase().includes(text))
      .sort((a, b) =>
        projMatchRank(a.name.toLowerCase(), text) - projMatchRank(b.name.toLowerCase(), text)
        || (b.lastActivityAt ?? 0) - (a.lastActivityAt ?? 0));
    if (projHits.length) {
      node.tree.append(el('div', { class: 'search-section', text: 'Projects' }));
      node.tree.append(el('div', { class: 'found-l', text:
        `${projHits.length} project${projHits.length === 1 ? '' : 's'} — open, or + to start a session` }));
      for (const p of projHits) node.tree.append(projectHitRow(p));
    }
  }

  const total = [...state.sessions.values()].filter((s) => s.loaded).reduce((n, s) => n + s.list.length, 0);
  node.tree.append(el('div', { class: 'search-section', text: 'Sessions' }));
  node.tree.append(el('div', { class: 'found-l', text:
    `${hits.length} ${scopeIds ? `in #${pq.project.name}` : `of ${total} sessions`}` }));
  if (!state.searchLoaded && !scopeIds) node.tree.append(el('div', { class: 'hint-row', text: 'indexing the rest…' }));
  for (const { p, sess } of hits) {
    const row = sessionRow(p, sess); // already carries its own .when
    if (!scopeIds) row.append(el('span', { class: 'in', text: `  ${p.name}` }));
    node.tree.append(row);
  }
  if (!hits.length && (state.searchLoaded || scopeIds)) node.tree.append(el('div', { class: 'hint-row', text: 'no titles match' }));
  renderContentSearch(node.findInput.value.trim());
}

/* FEAT-147 — rank a project-name match: exact 0, prefix 1, substring 2. */
function projMatchRank(nameLc, text) {
  if (nameLc === text) return 0;
  if (nameLc.startsWith(text)) return 1;
  return 2;
}

/* FEAT-147 — dismiss the finder overlay and clear its query. Mirrors the
   findBtn toggle's own reset so a search-hit that navigates away lands on the
   normal tree rather than back inside the search view. */
function closeFinder() {
  node.finder.classList.remove('on');
  node.findInput.value = '';
}

/* FEAT-147 — scroll a project's group into view after a search-hit reveals it. */
function revealProject(id) {
  node.tree.querySelector(`.pgroup[data-pid="${id}"]`)?.scrollIntoView({ block: 'nearest' });
}

/*
 * FEAT-147 — a PROJECT result in plain-text search. Mirrors the sidebar project
 * header's affordances so the visual/interaction idiom is identical: clicking
 * the row opens (expands + selects) the project; the "+" starts a new session
 * in it directly. Both close the finder first.
 */
function projectHitRow(p) {
  const b = el('button', { class: 'row hit', title: `Open ${p.name}` });
  const top = el('span', { class: 'hit-top' });
  top.append(el('span', { class: 'when', text: when(p.lastActivityAt) }));
  top.append(el('span', { class: `dot ${projectDot(p)}`.trim() }));
  top.append(document.createTextNode(`#${p.name}`));
  if (!isActiveProject(p)) top.append(el('span', { class: 'in', text: '  inactive' }));

  const plus = el('span', { class: 'plus', role: 'button', tabindex: '0',
    title: `New session in ${p.name}`, 'aria-label': `New session in ${p.name}` });
  plus.append(iconPlus());
  plus.addEventListener('click', (e) => { e.stopPropagation(); closeFinder(); startNew(p.id); });
  top.append(plus);
  b.append(top);

  b.addEventListener('click', () => {
    closeFinder();
    // BUG-194 / ARCH-010 — selecting a project must land the view FULLY in it.
    // A bare selectProject() only moved the sidebar header to p while the FOREIGN
    // session (from another project) stayed open in the dock: the header said p
    // but the transcript — and the composer's send target (state.current's
    // encodedDir/sessionId) — still belonged to the other project. startNew() is
    // the ONE project-open transition (the same path as the sidebar "+"/pending-
    // new row): it closes the foreign session, sets openProjectId to p, and opens
    // a fresh new-session composer for p. No agent launches until the user sends,
    // so "which project is this view showing" has one answer, not two.
    startNew(p.id);
    revealProject(p.id);
  });
  return b;
}

/* ---------------------- content search (tier 2: rg, debounced as you type) */
/*
 * Titles filter immediately (tier 1, in memory). CONTENTS follow after a short
 * debounce; Enter skips that wait. The previous fetch is aborted before its
 * replacement starts, which also causes the server to terminate its rg child.
 * the server runs ripgrep over every registered project's store (measured
 * fast enough that there is no index to go stale). Prose hits rank above
 * tool/thinking hits; a hit deep-links to the exact message via locate().
 */

const CONTENT_SEARCH_DEBOUNCE_MS = 225;
const CONTENT_SEARCH_MIN = 3;
let contentSearchTimer = null;
let contentSearchAbort = null;

function scheduleContentSearch() {
  clearTimeout(contentSearchTimer);
  contentSearchTimer = null;
  contentSearchAbort?.abort();
  contentSearchAbort = null;
  const raw = node.findInput.value.trim();
  const pq = parseFinderQuery(raw);
  if (pq.mode === 'pickProject' || (pq.mode === 'scoped' && !pq.project) || pq.text.length < CONTENT_SEARCH_MIN) {
    state.contentSearch = null;
    return;
  }
  contentSearchTimer = setTimeout(() => void runContentSearch(), CONTENT_SEARCH_DEBOUNCE_MS);
}

async function runContentSearch() {
  clearTimeout(contentSearchTimer);
  contentSearchTimer = null;
  contentSearchAbort?.abort();
  const raw = node.findInput.value.trim();
  const pq = parseFinderQuery(raw);
  if (pq.mode === 'pickProject') return; // Enter completes the scope instead — see keydown
  if (pq.mode === 'scoped' && !pq.project) return say(`no project named “#${pq.name}”`, true);
  const text = pq.mode === 'scoped' ? pq.text : pq.text;
  if (text.length < CONTENT_SEARCH_MIN) return say(`type at least ${CONTENT_SEARCH_MIN} characters to search message contents`, true);
  const controller = new AbortController();
  contentSearchAbort = controller;
  const cs = { q: raw, scope: 'all', showTools: true, loading: true, error: null, result: null,
    scopedProject: pq.mode === 'scoped' ? pq.project : null, visibleGroups: 10, visibleHits: new Map() };
  state.contentSearch = cs;
  renderTree();
  try {
    cs.result = await api.searchContent(text, cs.scopedProject?.id, controller.signal);
  } catch (err) {
    if (controller.signal.aborted) return;
    cs.error = err.message;
  }
  if (controller.signal.aborted) return;
  cs.loading = false;
  if (contentSearchAbort === controller) contentSearchAbort = null;
  if (state.contentSearch === cs) renderTree();
}

function renderContentSearch(q) {
  const cs = state.contentSearch;
  if (!q) return;
  if (parseFinderQuery(q).mode === 'pickProject') return; // suggestions own the pane
  if (!cs || cs.q !== q) {
    const text = parseFinderQuery(q).text;
    node.tree.append(el('div', { class: 'search-section', text: 'Messages' }));
    node.tree.append(el('div', { class: 'hint-row cs-hint', text: text.length < CONTENT_SEARCH_MIN
      ? `Type ${CONTENT_SEARCH_MIN} characters to search messages in registered projects.`
      : 'Waiting to search messages…' }));
    return;
  }
  node.tree.append(el('div', { class: 'search-section', text: 'Messages' }));
  if (cs.loading) {
    node.tree.append(el('div', { class: 'found-l', text: 'searching message contents…' }));
    return;
  }
  if (cs.error) {
    node.tree.append(el('div', { class: 'hint-row', text: `content search failed: ${cs.error}` }));
    return;
  }
  const r = cs.result;
  const shown = r.hits
    .filter((h) => cs.showTools || h.kind === 'prose')
    .filter((h) => cs.scopedProject ? true : (cs.scope === 'all' || h.projectId === state.current.projectId));
  node.tree.append(el('div', { class: 'found-l', text:
    `${shown.length} in ${cs.scopedProject ? `#${cs.scopedProject.name} contents` : 'message contents'} · ${r.tookMs} ms${r.truncated ? ' · more exist — refine the query' : ''}` }));
  const ctl = el('div', { class: 'cs-ctl' });
  if (!cs.scopedProject) {
    const scope = el('button', { class: 'cs-pill', text: cs.scope === 'all' ? 'all projects' : `only ${currentProject()?.name ?? 'current project'}` });
    scope.addEventListener('click', () => { cs.scope = cs.scope === 'all' ? 'project' : 'all'; renderTree(); });
    ctl.append(scope);
  }
  const tools = el('button', { class: 'cs-pill', text: cs.showTools ? 'tool output shown' : 'tool output hidden' });
  tools.addEventListener('click', () => { cs.showTools = !cs.showTools; renderTree(); });
  ctl.append(tools);
  node.tree.append(ctl);
  const groups = [];
  const bySession = new Map();
  for (const h of shown) {
    const key = `${h.projectId}\0${h.encodedDir}\0${h.sessionId}`;
    let g = bySession.get(key);
    if (!g) { g = { key, hits: [] }; bySession.set(key, g); groups.push(g); }
    g.hits.push(h);
  }
  for (const g of groups.slice(0, cs.visibleGroups)) node.tree.append(searchHitGroup(g, cs));
  if (groups.length > cs.visibleGroups) {
    const more = el('button', { class: 'cs-more', text: `Show ${groups.length - cs.visibleGroups} more session${groups.length - cs.visibleGroups === 1 ? '' : 's'}` });
    more.addEventListener('click', () => { cs.visibleGroups = groups.length; renderTree(); });
    node.tree.append(more);
  }
  if (r.truncated) node.tree.append(el('div', { class: 'hint-row cs-truncated', text: 'More message matches exist than the search returned — refine the query to see them.' }));
  if (!shown.length) node.tree.append(el('div', { class: 'hint-row', text: cs.showTools ? 'nothing in message contents' : 'nothing outside tool output — try showing it' }));
}

function searchHitTitle(h) {
  const s = state.sessions.get(h.projectId);
  const row = s?.list?.find((x) => x.sessionId === h.sessionId && x.encodedDir === h.encodedDir);
  return row ? rowTitle(row) : h.sessionId.slice(0, 8);
}

function searchHitGroup(g, cs) {
  const first = g.hits[0];
  const p = state.projects.find((x) => x.id === first.projectId);
  const box = el('section', { class: 'cs-group' });
  const head = el('div', { class: 'cs-group-head' });
  head.append(el('span', { class: 'cs-group-title', text: searchHitTitle(first) }));
  head.append(el('span', { class: 'in', text: p?.name ?? first.encodedDir }));
  head.append(el('span', { class: 'when', text: when(first.timestamp) }));
  head.append(el('span', { class: 'cs-count', text: `${g.hits.length} result${g.hits.length === 1 ? '' : 's'}` }));
  box.append(head);
  const cap = cs.visibleHits.get(g.key) ?? 5;
  for (const h of g.hits.slice(0, cap)) box.append(searchHitRow(h));
  if (g.hits.length > cap) {
    const more = el('button', { class: 'cs-more nested', text: `Show ${g.hits.length - cap} more` });
    more.addEventListener('click', () => { cs.visibleHits.set(g.key, g.hits.length); renderTree(); });
    box.append(more);
  }
  return box;
}

function searchHitRow(h) {
  const b = el('button', { class: `row hit cs-hit${h.os === 'windows' ? ' win' : ''}`, title: 'Open this session at the matched message' });
  const sn = el('span', { class: 'snip' });
  /*
   * The row is one clamped line, so a long lead-in silently pushes the match
   * itself out of sight — a hit that shows no highlight reads as a wrong
   * result. Keep at most a short run-up; the match always stays visible.
   */
  const LEAD = 12; // a sidebar line holds ~38 characters: any longer a run-up clips the match
  const before = h.snippet.slice(0, h.matchStart);
  let lead = before;
  if (before.length > LEAD) {
    const tail = before.slice(-LEAD);
    lead = `…${tail.includes(' ') ? tail.replace(/^\S*\s+/, '') : tail}`; // never start on half a word
  }
  sn.append(document.createTextNode(lead));
  sn.append(el('mark', { text: h.snippet.slice(h.matchStart, h.matchEnd) }));
  sn.append(document.createTextNode(h.snippet.slice(h.matchEnd)));
  if (h.kind === 'tool') sn.append(el('span', { class: 'hit-tool', text: 'tool' }));
  b.append(sn);
  b.addEventListener('click', () => void openSearchHit(h));
  return b;
}

async function openSearchHit(h) {
  const p = state.projects.find((x) => x.id === h.projectId);
  if (!p) return say(`this hit belongs to no registered project (${h.encodedDir})`, true);
  say('locating the matched message…');
  let at = null;
  let exact = true; // declared out here: the open call below needs it after the try
  try {
    const loc = await api.searchLocate(h.encodedDir, h.sessionId, h.line);
    at = loc.index;
    exact = loc.exact !== false;
    if (!exact) say('that line is not a rendered message — opening at the nearest one before it');
  } catch (err) {
    // Includes the honest 410 when the file changed since the search ran.
    return say(`could not locate the match: ${err.message}`, true);
  }
  const s = await loadSessions(p.id);
  const sess = s.list?.find((x) => x.sessionId === h.sessionId && x.encodedDir === h.encodedDir)
    ?? { sessionId: h.sessionId, encodedDir: h.encodedDir, os: h.os, displayTitle: h.sessionId.slice(0, 8) };
  await openSession(p, sess, { at, highlightAt: exact ? at : null });
}

async function loadAllSessions() {
  if (state.searchLoaded) return;
  // BUG-158: fetch every project's session list in PARALLEL, not one strictly
  // after another. Each request keys on its own sessionState(id) and guards
  // with s.loading, so concurrent loads never race; renderTree() is idempotent.
  // The old serial `for … await` chained 13 round-trips end to end (~4 s of the
  // measured 7.5 s boot); once the server-side scans are memoised each request
  // is cheap, and firing them together collapses the chain to a single wave.
  await Promise.all(state.projects.map((p) => loadSessions(p.id)));
  state.searchLoaded = true;
  renderTree();
}

/* ------------------------------------------- session row context menu */
/*
 * Right-click (or Context-Menu / Shift+F10) on a sidebar session row.
 *
 * The whole point of this menu is finding a discussion again next week, so the
 * two rules it is built around are about TRUST, not convenience:
 *
 *  1. NOTHING is shown as renamed, pinned or deleted until the server has been
 *     re-read and the change is actually there. Every action here writes, then
 *     re-fetches the project's session list, then checks. A 200 with an
 *     unrecognised body is not proof; neither is a hopeful local mutation.
 *  2. Every label says what the action really does. "Fork" makes a COPY with a
 *     new id and leaves the original alone, and the panel says exactly that,
 *     including the part where nothing is copied until you send a message —
 *     because that is how this app's fork actually works.
 */

const menu = {
  view: 'root',      // root | rename | fork | delete
  p: null,           // project the row was rendered under
  sess: null,        // the row's session (re-resolved from state before every write)
  origin: null,      // element to hand focus back to
  busy: null,        // label of the in-flight write, or null
  err: null,         // the last refusal, in the server's own words where possible
  note: null,        // a non-error result that belongs in the panel
  typed: '',
  force: null,       // a 409 the server offers an override for, awaiting a second click
  pinDead: false,    // this server has no working pin route: stop offering it
  delDead: false,
};

/** The freshest copy of the row's session, after any forced list reload. */
function menuSession() {
  const st = state.sessions.get(menu.p?.id);
  const fresh = st?.list?.find((x) => x.sessionId === menu.sess?.sessionId && x.encodedDir === menu.sess?.encodedDir);
  return fresh ?? menu.sess;
}

/** Re-read the project's list from the server and return this row, or null. */
async function reread(projectId, sess) {
  await loadSessions(projectId, { force: true });
  const st = state.sessions.get(projectId);
  return st?.list?.find((x) => x.sessionId === sess.sessionId && x.encodedDir === sess.encodedDir) ?? null;
}

function openRowMenu(p, sess, x, y, origin) {
  closePops();
  menu.view = 'root';
  menu.p = p;
  menu.sess = sess;
  menu.origin = origin ?? null;
  menu.busy = null;
  menu.err = null;
  menu.note = null;
  menu.force = null;
  menu.typed = '';
  paintRowMenu();
  node.rowMenu.classList.add('open');
  placeAt(node.rowMenu, x, y);
  focusInMenu();
}

function closeRowMenu() {
  if (!node.rowMenu.classList.contains('open')) return;
  const inside = node.rowMenu.contains(document.activeElement);
  node.rowMenu.classList.remove('open');
  if (inside && menu.origin?.isConnected) menu.origin.focus();
  menu.origin = null;
}

/** First interactive thing in the panel — an item in the root menu, the field elsewhere. */
function focusInMenu() {
  const first = node.rowMenu.querySelector('input, [role="menuitem"]:not([disabled]), button:not([disabled])');
  if (first) queueMicrotask(() => first.focus());
}

/**
 * Point-anchored placement that keeps the WHOLE panel on screen. Measured after
 * the panel is displayed: a `display:none` element has zero height, and
 * clamping against zero would drop the bottom edge off the viewport for any
 * right-click near the foot of the window.
 */
function placeAt(popEl, x, y) {
  const pad = 8;
  popEl.style.bottom = '';
  popEl.style.left = '-9999px';
  popEl.style.top = '0px';
  const r = popEl.getBoundingClientRect();
  const left = Math.max(pad, Math.min(x, window.innerWidth - r.width - pad));
  let top = y;
  if (top + r.height + pad > window.innerHeight) top = y - r.height; // flip above the point
  top = Math.max(pad, Math.min(top, Math.max(pad, window.innerHeight - r.height - pad)));
  popEl.style.left = `${left}px`;
  popEl.style.top = `${top}px`;
}

/*
 * Stroke icons rather than text glyphs. The obvious characters for these
 * actions (⑂ for fork, ⌫ for delete) are exactly the sort that fall back to a
 * tofu box on a machine with different fonts, and a menu whose items are
 * unreadable is worse than one with no icons at all.
 */
const MENU_ICON = {
  rename: 'M10.4 2.9 13.1 5.6 5.5 13.2 2.2 13.8l.6-3.3z',
  pin: 'M4.6 2.6h6.8v10.8L8 10.7l-3.4 2.7z',
  fork: 'M4.4 13V3.2M4.4 6.3h4.3c1.3 0 2.4 1 2.4 2.4V13',
  copy: 'M6 6h6.6v6.6H6zM3.4 10V3.4H10',
  del: 'M3.2 4.6h9.6M6.2 4.6V3.1h3.6v1.5M4.7 4.6l.6 8.3h5.4l.6-8.3',
};

function mitem(label, icon, onPick, { hint, disabled, danger } = {}) {
  const b = el('button', {
    class: `mi${danger ? ' danger' : ''}`, role: 'menuitem', type: 'button', disabled: disabled ? true : null,
  });
  b.append(el('span', { class: 'g' }, svg(MENU_ICON[icon], 12)));
  b.append(el('span', { class: 'l', text: label }));
  if (hint) b.append(el('span', { class: 'k', text: hint }));
  if (!disabled) b.addEventListener('click', (e) => { e.stopPropagation(); onPick(); });
  return b;
}

function paintRowMenu() {
  const host = clear(node.rowMenu);
  const sess = menuSession();
  if (!sess) return closeRowMenu();
  node.rowMenu.dataset.view = menu.view;
  node.rowMenu.setAttribute('role', menu.view === 'root' ? 'menu' : 'dialog');

  const head = el('div', { class: 'mhead' });
  head.append(el('div', { class: 't', text: rowTitle(sess) }));
  head.append(el('div', { class: 's', text: `${sess.sessionId.slice(0, 8)} · ${menu.p.name}${sess.os === 'windows' ? ' · windows' : ''}` }));
  host.append(head);

  if (menu.view === 'root') paintMenuRoot(host, sess);
  else if (menu.view === 'rename') paintMenuRename(host, sess);
  else if (menu.view === 'fork') paintMenuFork(host, sess);
  else if (menu.view === 'delete') paintMenuDelete(host, sess);

  if (menu.force) host.append(forceBlock());
  if (menu.note) host.append(el('div', { class: 'mnote', text: menu.note }));
  if (menu.err) host.append(el('div', { class: 'mnote err', text: menu.err }));
}

/**
 * The server refuses a rename or a pin on a session that is being written right
 * now, and offers an override. Passing its message through and stopping would
 * hand the user a query-string flag they cannot type — so the override becomes
 * a second, deliberate click, the same arm-then-confirm the docker socket uses.
 */
function forceBlock() {
  const f = menu.force;
  const box = el('div', { class: 'mnote arm' });
  box.append(el('div', { class: 'w', text: f.message }));
  const acts = el('div', { class: 'cacts' });
  const no = el('button', { class: 'mini', type: 'button', text: 'Leave it alone' });
  no.addEventListener('click', () => { menu.force = null; menu.view = 'root'; paintRowMenu(); focusInMenu(); });
  const yes = el('button', { class: 'mini danger', type: 'button', text: f.label });
  yes.addEventListener('click', () => {
    const go = menu.force;
    menu.force = null;
    if (go.kind === 'rename') void doRename(go.title, { force: true });
    else void doPin(go.pinned, { force: true });
  });
  acts.append(no, yes);
  box.append(acts);
  return box;
}

function paintMenuRoot(host, sess) {
  const pinned = api.pinnedOf(sess);
  const busy = !!menu.busy;

  host.append(mitem('Rename…', 'rename', () => {
    menu.view = 'rename'; menu.err = null; menu.note = null; menu.force = null;
    menu.typed = rowTitle(sess);
    paintRowMenu(); focusInMenu();
  }, { disabled: busy }));

  const pinItem = mitem(
    menu.busy === 'pin' ? (pinned ? 'unpinning…' : 'pinning…') : (pinned ? 'Unpin' : 'Pin to top'),
    'pin',
    () => void doPin(!pinned),
    { disabled: busy || menu.pinDead },
  );
  // Filled bookmark when it IS pinned — the state, next to the action that undoes it.
  if (pinned) pinItem.classList.add('on');
  host.append(pinItem);

  host.append(mitem('Fork to another project…', 'fork', () => { menu.view = 'fork'; menu.err = null; menu.note = null; menu.force = null; paintRowMenu(); focusInMenu(); }, { disabled: busy }));

  host.append(mitem('Copy session id', 'copy', () => void doCopyId(sess), { hint: sess.sessionId.slice(0, 8), disabled: busy }));

  host.append(el('div', { class: 'msep' }));
  host.append(mitem('Delete…', 'del', () => { menu.view = 'delete'; menu.err = null; menu.note = null; menu.force = null; menu.typed = ''; paintRowMenu(); focusInMenu(); }, { disabled: busy || menu.delDead, danger: true }));
}

/* ------------------------------------------------------------------ rename */

function paintMenuRename(host, sess) {
  const box = el('div', { class: 'mview' });
  box.append(el('div', { class: 'mp', text: 'Sets the title this session is listed under, here and in search.' }));

  const field = el('div', { class: 'cfield' });
  const input = el('input', {
    class: 'vin', type: 'text', spellcheck: 'false', autocomplete: 'off',
    'aria-label': 'Session title', maxlength: '200',
  });
  input.value = menu.typed;
  field.append(input);
  box.append(field);

  const acts = el('div', { class: 'cacts' });
  const cancel = el('button', { class: 'mini', type: 'button', text: 'Cancel' });
  cancel.addEventListener('click', () => { menu.view = 'root'; menu.err = null; menu.force = null; paintRowMenu(); focusInMenu(); });
  const save = el('button', { class: 'mini danger', type: 'button', text: menu.busy === 'rename' ? 'renaming…' : 'Rename' });
  const ok = () => input.value.trim().length > 0 && input.value.trim() !== rowTitle(sess);
  save.disabled = !ok() || !!menu.busy;
  input.addEventListener('input', () => { menu.typed = input.value; save.disabled = !ok() || !!menu.busy; });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && ok() && !menu.busy) { e.preventDefault(); void doRename(input.value.trim()); }
  });
  save.addEventListener('click', () => { if (ok()) void doRename(input.value.trim()); });
  acts.append(cancel, save);
  box.append(acts);
  host.append(box);
  queueMicrotask(() => { input.focus(); input.select(); });
}

async function doRename(title, { force = false } = {}) {
  const sess = menuSession();
  const p = menu.p;
  menu.busy = 'rename';
  menu.err = null;
  paintRowMenu();
  try {
    await api.renameSession(sess.sessionId, sess.encodedDir, title, { force });
  } catch (err) {
    menu.busy = null;
    if (err.status === 409 && !force) {
      menu.force = { kind: 'rename', title, label: 'Rename anyway', message: err.message };
      return paintRowMenu();
    }
    menu.err = err.missing
      ? 'not renamed — this server has no session-rename route yet'
      : `not renamed — ${err.message}`;
    return paintRowMenu();
  }
  // The response body is not proof. Ask the list again and read the row back.
  const row = await reread(p.id, sess);
  menu.busy = null;
  if (!row || rowTitle(row) !== title) {
    menu.err = `not renamed — the server accepted the change but still lists this session as “${row ? rowTitle(row) : 'gone from the list'}”`;
    return paintRowMenu();
  }
  closeRowMenu();
  if (state.current.sessionId === sess.sessionId && state.current.encodedDir === sess.encodedDir) {
    state.current.title = title;
    paintCrown();
  }
  renderTree();
  say(`renamed to “${title}” · confirmed by the server`);
}

/* --------------------------------------------------------------------- pin */

async function doPin(next, { force = false } = {}) {
  const sess = menuSession();
  const p = menu.p;
  menu.busy = 'pin';
  menu.err = null;
  paintRowMenu();
  try {
    await api.setPinned(sess.sessionId, sess.encodedDir, next, { force });
  } catch (err) {
    menu.busy = null;
    if (err.status === 409 && !force) {
      menu.force = { kind: 'pin', pinned: next, label: next ? 'Pin anyway' : 'Unpin anyway', message: err.message };
      return paintRowMenu();
    }
    if (err.missing) {
      menu.pinDead = true;
      menu.err = 'nothing was pinned — this server has no pin route yet';
    } else {
      menu.err = `not ${next ? 'pinned' : 'unpinned'} — ${err.message}`;
    }
    return paintRowMenu();
  }
  const row = await reread(p.id, sess);
  menu.busy = null;
  if (!row || api.pinnedOf(row) !== next) {
    menu.pinDead = true;
    menu.err = `not ${next ? 'pinned' : 'unpinned'} — the server accepted the change but still reports this session as ${api.pinnedOf(row) ? 'pinned' : 'not pinned'}`;
    return paintRowMenu();
  }
  closeRowMenu();
  renderTree();
  say(`${next ? 'pinned' : 'unpinned'} · confirmed by the server`);
}

/* ---------------------------------------------------------------- copy id */

async function doCopyId(sess) {
  const id = sess.sessionId;
  let ok = false;
  try {
    await navigator.clipboard.writeText(id);
    ok = true;
  } catch {
    // Clipboard API refused (no permission, no focus). Fall back, and only
    // claim a copy if the fallback reports one.
    try {
      const ta = el('textarea', { style: 'position:fixed;left:-9999px;top:0' });
      ta.value = id;
      document.body.append(ta);
      ta.select();
      ok = document.execCommand('copy');
      ta.remove();
    } catch { ok = false; }
  }
  closeRowMenu();
  say(ok ? `session id copied · ${id}` : `could not reach the clipboard — the id is ${id}`, !ok);
}

/* -------------------------------------------------------------------- fork */

function paintMenuFork(host, sess) {
  const box = el('div', { class: 'mview' });
  box.append(el('div', { class: 'mp' },
    el('b', { text: 'Forking makes a copy.' }),
    document.createTextNode(` The copy gets a new session id and lands in the project you pick. This session stays in ${menu.p.name} exactly as it is — nothing is moved, nothing is deleted.`)));
  box.append(el('div', { class: 'mp dim', text: 'Nothing is copied until you send the first message: picking a project arms the composer, and the fork is created when you send.' }));

  const list = el('div', { class: 'mlist' });
  for (const t of state.projects) {
    const b = el('button', { class: 'prow', type: 'button', title: t.hostPath });
    b.append(el('span', { class: 'mid' },
      el('span', { class: 'nm', text: t.name }),
      el('span', { class: 'ph', text: shortPath(t.hostPath) })));
    if (t.id === menu.p.id) b.append(el('span', { class: 'tag', text: 'same project' }));
    b.addEventListener('click', (e) => { e.stopPropagation(); void armFork(t, sess); });
    list.append(b);
  }
  box.append(list);

  const acts = el('div', { class: 'cacts' });
  const cancel = el('button', { class: 'mini', type: 'button', text: 'Cancel' });
  cancel.addEventListener('click', () => { menu.view = 'root'; menu.force = null; paintRowMenu(); focusInMenu(); });
  acts.append(cancel);
  box.append(acts);
  host.append(box);
}

/**
 * Arms a fork; it does not perform one. This app's fork is a field on the WS
 * `start` command, so the copy comes into being with the first message — which
 * is precisely what the panel and this status line say.
 */
async function armFork(target, sess) {
  const src = menu.p;
  closeRowMenu();
  await openSession(src, sess); // put the history being branched on screen first
  // BUG-198 — the staged fork is a NOT-YET-BORN session: its bag must never persist
  // under the SOURCE's key (state.current still names the source id until
  // session-init). Contents keep the pre-BUG-198 behaviour — a cross-project fork
  // started clean (selectProject used to clear), a same-project fork kept the
  // source's armed values — but the owner is pending in both cases.
  const keepArmed = src.id === target.id ? { ...state.overrides } : {};
  resetOverrides(ovrPending()); // BUG-198 round 2 — a fresh token: the fork-to-be's own bag
  Object.assign(state.overrides, keepArmed);
  selectProject(target.id, { quiet: true });
  state.current.projectId = target.id;
  // The source dir must survive: it is where the transcript to stage lives, and
  // the server copies it into the target project's own store dir.
  state.current.encodedDir = sess.encodedDir;
  state.current.sessionId = sess.sessionId;
  state.current.os = 'linux';
  state.forkFrom = sess.sessionId;
  node.box.hidden = false;
  node.frozen.hidden = true;
  node.agentDone.hidden = true;
  paintCrown();
  renderTree();
  node.prompt.focus();
  say(`Forking into ${target.name} — type the first message and send to create the copy.`
    + ` Nothing has been copied yet, and the original stays in ${src.name} under ${sess.sessionId.slice(0, 8)}.`);
}

/* ------------------------------------------------------------------ delete */

/** Short enough to type deliberately, long enough that it cannot be a slip. */
const delToken = (sess) => sess.sessionId.slice(0, 8);

function paintMenuDelete(host, sess) {
  const box = el('div', { class: 'mview ceremony' });
  box.append(el('div', { class: 'ch' },
    el('b', { text: 'Delete this session?' }),
    document.createTextNode(' Its transcript leaves this dashboard and stops being resumable.')));
  box.append(el('div', { class: 'cpath', text: `${sess.encodedDir}/${sess.sessionId}.jsonl` }));
  box.append(el('div', { class: 'cwhich' },
    el('span', { text: `${sess.messageCount ?? '?'} messages` }),
    el('span', { text: `${bytes(sess.fileBytes ?? 0)}` }),
    el('span', { text: `last ${when(sess.lastActivityAt) || '—'}` })));
  box.append(el('div', { class: 'cundo' },
    el('span', { text: 'The server backs the file up before removing it and reports where. If it comes back without naming a backup, this will say so plainly rather than claiming one.' })));

  const field = el('div', { class: 'cfield' });
  const lbl = el('label', { class: 'cl' });
  lbl.append(document.createTextNode('Type '));
  lbl.append(el('code', { text: delToken(sess) }));
  lbl.append(document.createTextNode(' to confirm'));
  const input = el('input', {
    class: 'vin', type: 'text', spellcheck: 'false', autocomplete: 'off',
    'aria-label': `Type ${delToken(sess)} to confirm the delete`,
  });
  input.value = menu.typed;
  field.append(lbl, input);
  box.append(field);

  const acts = el('div', { class: 'cacts' });
  const cancel = el('button', { class: 'mini', type: 'button', text: 'Cancel' });
  cancel.addEventListener('click', () => { menu.view = 'root'; menu.typed = ''; menu.err = null; menu.force = null; paintRowMenu(); focusInMenu(); });
  const go = el('button', { class: 'mini danger', type: 'button', text: menu.busy === 'delete' ? 'deleting…' : 'Delete session' });
  const ok = () => input.value.trim() === delToken(sess);
  go.disabled = !ok() || !!menu.busy;
  input.addEventListener('input', () => { menu.typed = input.value; go.disabled = !ok() || !!menu.busy; });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && ok() && !menu.busy) { e.preventDefault(); go.click(); } });
  go.addEventListener('click', () => { if (ok()) void doDelete(); });
  acts.append(cancel, go);
  box.append(acts);
  host.append(box);
}

async function doDelete() {
  const sess = menuSession();
  const p = menu.p;
  menu.busy = 'delete';
  menu.err = null;
  paintRowMenu();

  let r;
  try {
    r = await api.deleteSession(sess.sessionId, sess.encodedDir);
  } catch (err) {
    r = { problem: err.message };
  }
  menu.busy = null;
  if (r === null) {
    menu.delDead = true;
    menu.err = 'nothing was deleted — this server has no session-delete route yet';
    return paintRowMenu();
  }
  if (r.conflict) {
    menu.err = `not deleted — ${r.message}`;
    return paintRowMenu();
  }
  if (r.problem) {
    menu.err = `not deleted — ${r.problem}`;
    return paintRowMenu();
  }
  // Success is the list no longer carrying the row, not a 200.
  const still = await reread(p.id, sess);
  if (still) {
    menu.err = 'not deleted — the server reported success but still lists this session';
    return paintRowMenu();
  }
  const backup = api.backupPathOf(r.result);
  closeRowMenu();
  if (state.current.sessionId === sess.sessionId && state.current.encodedDir === sess.encodedDir) startNew(p.id);
  renderTree();
  say(backup
    ? `deleted “${rowTitle(sess)}” · the original was ${backup.verified ? 'copied and byte-verified' : 'backed up'} to ${backup.path}`
    : `deleted “${rowTitle(sess)}” · the server did not report a backup location`, !backup);
}

/* ------------------------------------------------- menu keyboard + dismiss */

node.rowMenu.addEventListener('keydown', (e) => {
  if (e.key === 'Tab') { // a menu is not part of the page's tab order
    e.preventDefault();
    return;
  }
  const nav = ['ArrowDown', 'ArrowUp', 'Home', 'End'];
  if (!nav.includes(e.key)) return;
  const items = [...node.rowMenu.querySelectorAll('[role="menuitem"]:not([disabled])')];
  if (!items.length) return;
  e.preventDefault();
  const i = items.indexOf(document.activeElement);
  const n = e.key === 'Home' ? 0
    : e.key === 'End' ? items.length - 1
    : e.key === 'ArrowDown' ? (i + 1) % items.length
    : (i - 1 + items.length) % items.length;
  items[n].focus();
});

function iconPlus() {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 12 12'); s.setAttribute('width', '11'); s.setAttribute('height', '11');
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.5');
  s.setAttribute('stroke-linecap', 'round');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', 'M6 2v8M2 6h8'); s.append(p);
  return s;
}
function iconCog() {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 12 12'); s.setAttribute('width', '11'); s.setAttribute('height', '11');
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.4');
  s.setAttribute('stroke-linecap', 'round');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', 'M1.6 3.4h8.8M1.6 8.6h8.8'); s.append(p);
  for (const [cx, cy] of [[4, 3.4], [8, 8.6]]) {
    const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('cx', cx); c.setAttribute('cy', cy); c.setAttribute('r', '1.3');
    c.setAttribute('fill', 'var(--rail)'); s.append(c);
  }
  return s;
}

/* -------------------------------------------------------------- the crown */

function paintCrown() {
  const p = currentProject();
  node.where.textContent = p ? p.name : '';
  // FEAT-071 — the crown name doubles as a discoverable dir tooltip: which host
  // directory this project maps to, full path on hover (the settings drawer
  // shows the shortened form inline).
  node.where.title = p?.hostPath ? `${p.name}\n${p.hostPath}` : '';
  // FEAT-059 — the global + always spawns in the scratch project, regardless
  // of what is currently selected, so its tooltip is fixed rather than
  // following `currentProject()` the way it used to (that was the bug: it
  // read "New session in <whatever's selected>" and meant it literally).
  const newLbl = 'New scratch session — throwaway, not saved under any project (Scratch — throwaway)';
  $('#newBtn').title = newLbl;
  $('#newBtn').setAttribute('aria-label', 'New scratch session');
  paintGitChip();
  paintProcChip();
  paintUsageChip(); // FEAT-116 — provider rate-limit window (dispatch-now vs park)
  paintIntegrations(); // FEAT-051 — the attached-capability strip tracks the project too
  paintCrumbs();

  const has = !!p;
  paintModelChip(); // FEAT-042 — chip visibility tracks project selection
  paintProvSurfaces(); // FEAT-139 header twin stays hidden; BUG-196 round 3 — button + popover repaint together on every selection change
  paintAccountSel(); // FEAT-145 — which Claude subscription the next session bills to
  // FEAT-139 — the CONFIG chips leave the strip entirely and live under the one
  // Settings door (Machine · This project · This session spine). Provider,
  // isolation (connection mode) and the instruction stack (Working Agreement
  // version) are session-CONSTANT settings, not glance-worthy live signal: a
  // control you click to CHANGE something must not sit on the strip beside the
  // readouts you can only look at. They stay in the DOM (their popovers/handlers
  // are untouched) but are never shown on the strip; every one is reachable in
  // one click via Settings ▸ Capabilities / Isolation & environment / Instructions.
  // FEAT-146 round 4 — #isoBtn and its popover are gone entirely (see
  // index.html): a door nothing could open is not a door.
  node.insBtn.hidden = true;
  node.settingsBtn.hidden = !has; // BUG-158 — the ONE config door, visible whenever a project is selected
  node.seal.querySelector('.seal-vdiv').hidden = true; // nothing left to divide — nav sits alone
  node.sealSep.hidden = !has;
  for (const m of [...node.seal.querySelectorAll('.mnt, .addm')]) m.remove();
  if (!has) return;

  const mounts = p.settings.mounts ?? [];
  // BUG-075: mounts are a CONTAINER-only concept — bind-mounting extra host
  // paths INTO the container. A direct/sandbox session already sees the whole
  // filesystem, so neither the mount pills NOR the "+ Add mount" affordance may
  // render there (they are inert-or-confusing). Ground truth is p.isolation —
  // the SAME source the say() line below reads, so the two can never disagree, and the strip
  // re-renders on every session switch (line 1540 clears the old .mnt/.addm).
  if (p.isolation === 'container') {
    for (const m of mounts) {
      const pill = el('span', { class: 'pill mnt', role: 'button', tabindex: '0', title: 'Mounted into the container — click for Access › Mounts' }, document.createTextNode(shortPath(m.hostPath)));
      // FEAT-054: the pill names a mount, so it lands on the Mounts group —
      // not the drawer's default top. The × keeps its own remove action.
      pill.addEventListener('click', (e) => {
        if (e.target.closest('.x')) return;
        void drawer.open('settings', { focus: 'mounts' });
      });
      pill.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); void drawer.open('settings', { focus: 'mounts' }); }
      });
      if (m.readOnly) pill.append(document.createTextNode(' '), el('span', { class: 'ro', text: 'ro' }));
      const x = el('button', { class: 'x', 'aria-label': 'Remove mount', text: '×' });
      x.addEventListener('click', async () => {
        try {
          await api.patchProject(p.id, { mounts: mounts.filter((q) => q.hostPath !== m.hostPath) });
          const fresh = await api.getProject(p.id);
          state.projects[state.projects.findIndex((x2) => x2.id === p.id)] = fresh;
          drawer.repaint();
          paintCrown();
        } catch (err) { say(`could not remove mount: ${err.message}`, true); }
      });
      pill.append(x);
      // Mounts are container config — keep them in the interactive (top) tier,
      // before the tier break, not trailing after the status readouts.
      node.sealBreak.before(pill);
    }
    const add = el('button', { class: 'pill addm', text: '+ Add mount' });
    add.addEventListener('click', () => void drawer.open('settings', { focus: 'mounts' })); // FEAT-054
    node.sealBreak.before(add);
  }

  paintPerm();

  if (!state.busy) sayIso(isoLabel(p), '');
}

/* ─────────────────────────────── FEAT-051 — integrations strip (crown) ───
 *
 * One small chip per attached MCP capability, like browser-extension icons.
 * Two honest states, never conflated:
 *
 *   planned (hollow) — no live session: what WOULD attach on the next launch,
 *     predicted from the same per-project toggles the server's
 *     plannedMcpServers() consults (browser.enabled; tools.serena default ON;
 *     tools.playwright default OFF).
 *   live (filled)    — a session is running and reported its own tool list
 *     (session-init.tools): an attached server is visible as `mcp__<name>__…`
 *     tool names. That is the CLI's OWN report of the real attach — stronger
 *     than the plan. A live session whose init we never saw (reattach) keeps
 *     the planned rendering rather than inventing a live claim.
 *
 * BUG-135 — a third state, because two were not enough to be honest. The live
 * view used to render ONLY what the running session reported, so a tool the
 * user enables MID-SESSION vanished from the strip entirely: the toggle read
 * "On", the crown showed nothing, and there was no surface anywhere saying the
 * attach is fixed at launch. (Real report: Playwright enabled on a project 33
 * minutes AFTER that project's session launched — Serena chip live from the
 * launch-time plan, Playwright nowhere.) The strip renders the UNION of planned and
 * live, so an enabled-but-not-attached tool shows as `pending`: enabled for the
 * project, arriving on the next session. The inverse (attached but no longer
 * planned) stays visible as `live` for the same reason — the running session
 * really does still have it.
 *
 * Codex (provider 'openai') gets the MCP-off honesty chip instead: the bridge
 * hands that runtime no mcpServers map (capabilities.mcpConfig === false).
 * Hidden entirely when nothing is attachable. Click → drawer Integrations.
 */
const INTEG_META = {
  'stealth-browser': { g: '⌘', n: 'Browser', use: 'real profile, stays logged in, survives bot checks' },
  serena: { g: '◆', n: 'Serena', use: 'symbol-level code navigation (LSP)' },
  playwright: { g: '▷', n: 'Playwright', use: 'clean headless browser for repeatable UI tests' },
};

/** The MCP server names a live session's tool list proves attached. */
function liveAttachedServers() {
  const tools = dockLiveTools(); // BUG-106 — a foreign dock's live attach is not the selected project's
  if (!Array.isArray(tools)) return null;
  const found = new Set();
  for (const t of tools) {
    const m = /^mcp__(.+?)__/.exec(String(t));
    if (m) found.add(m[1]);
  }
  return found;
}

/** What plannedMcpServers() would attach for this project (same rules). */
function plannedServers(p) {
  const out = [];
  if (p.settings?.browser?.enabled === true) out.push('stealth-browser');
  const tools = p.settings?.tools ?? {};
  if (tools.serena !== false) out.push('serena'); // default ON (registry defaultToolSettings)
  if (tools.playwright === true) out.push('playwright');
  return out;
}

function paintIntegrations() {
  const strip = node.integStrip;
  if (!strip) return;
  const p = currentProject();
  clear(strip);
  if (!p) { strip.hidden = true; return; }

  const live = liveAttachedServers(); // null = no live report — planned view (also null when foreign, BUG-106)
  const provider = live
    ? (dockEffective()?.provider ?? 'anthropic')
    // BUG-196 — an open, resumable session's engine is pinned by its transcript, so
    // the integrations posture (Codex ⟹ MCP off) must reflect that, not a project
    // setting / override the resume ignores. lockedSessionProvider is null for the
    // launch surface (pending-new / no session), where the project default applies.
    // BUG-196 round 6 — read from the one engine state (null = not known yet, so the
    // posture is not claimed either way), not re-derived here.
    : providerView();
  const mcpOff = live
    ? dockEffective()?.capabilities?.mcpConfig === false
    : provider === 'openai';

  const chips = [];
  if (mcpOff) {
    // Codex honesty: no station-attached MCP tools on this engine (yet).
    chips.push(el('span', {
      class: 'ichip off',
      role: 'button', tabindex: '0',
      'data-integ': 'mcp-off',
      title: 'This engine (OpenAI Codex) gets no station-attached MCP tools yet — browser/Serena/Playwright do not attach. Click for Integrations.',
    }, el('span', { class: 'g', text: '⌬' }), el('span', { class: 'n', text: 'MCP off' })));
  } else {
    // BUG-135 — union, not just the live report, so an enabled-but-unattached
    // tool is visible as pending instead of silently missing.
    const planned = plannedServers(p);
    const names = live
      ? [...new Set([...planned, ...[...live].filter((s2) => INTEG_META[s2])])]
      : planned;
    for (const name of names) {
      const meta = INTEG_META[name];
      if (!meta) continue;
      const attached = live ? live.has(name) : null;
      const pending = live ? !attached : false;
      chips.push(el('span', {
        class: `ichip${attached ? ' live' : ''}${pending ? ' pending' : ''}`,
        role: 'button', tabindex: '0',
        'data-integ': name,
        'data-live': String(!!attached),
        'data-pending': String(pending),
        title: `${meta.n} — ${meta.use}. ${attached
          ? 'Attached to the running session'
          : pending
            ? 'Enabled for this project, but NOT in the running session — MCP tools are fixed when a session launches. Start a new session to use it'
            : 'Attaches on the next launch'} · click for Integrations.`,
      }, el('span', { class: 'g', text: meta.g }), el('span', { class: 'n', text: meta.n })));
    }
  }

  strip.hidden = chips.length === 0;
  for (const c of chips) {
    // FEAT-054: a capability chip lands on the drawer's Integrations group.
    c.addEventListener('click', () => void drawer.open('settings', { focus: 'integrations' }));
    c.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); void drawer.open('settings', { focus: 'integrations' }); }
    });
    strip.append(c);
  }
}

/* ------------------------------------------------ permission mode (skip prompts) */
/*
 * The single source of truth for "does this session ask before running tools?".
 *
 * Once a session is live the SERVER'S effective-config is authoritative — its
 * `permissionModeSource` even tells us WHY bypass is on (a container defaults to
 * it; a direct session only gets it from a deliberate override). Before a
 * session is live we predict from the same rules the server uses, and label it
 * as intent; the live report then confirms or corrects it. The UI never asserts
 * a mode the server did not report once one is running.
 */
function effectivePerm() {
  const eff = dockEffective(); // BUG-106 — foreign dock ⟹ fall back to the selected project's predicted posture
  if (eff?.effective && 'permissionMode' in eff.effective) {
    return {
      mode: eff.effective.permissionMode,
      source: eff.permissionModeSource ?? 'project',
      iso: eff.isolation ?? currentProject()?.isolation ?? 'direct',
      live: true,
      // A live change accepted but not yet in force (a Codex mid-turn toggle): the
      // running turn still uses `mode` above and keeps prompting, so this is the
      // mode the NEXT turn will adopt. Drives the armed-for-next-turn indicator so
      // the toggle never claims skip is on while the in-flight turn asks.
      pendingNextTurn: eff.permissionModePendingNextTurn ?? null,
    };
  }
  const p = currentProject();
  const iso = p?.isolation ?? 'direct';
  if ('permissionMode' in state.overrides) return { mode: state.overrides.permissionMode, source: 'session-override', iso, live: false };
  const stored = p?.settings?.permissionMode;
  if (stored && stored !== 'default') return { mode: stored, source: 'project', iso, live: false };
  // The server defaults a container to bypass; predict that so a container
  // session reads as "skips prompts" before it is even started.
  if (iso === 'container') return { mode: 'bypassPermissions', source: 'container-default', iso, live: false };
  return { mode: 'default', source: 'project', iso, live: false };
}

/**
 * Read the start-of-session snapshot result off the `start` ack.
 *
 * Branch on `startSnapshotStatus`, NEVER on `startSnapshotId === null`. Both
 * `disabled` and `failed` carry a null id, and conflating them produces the
 * worst possible message: a project that has deliberately turned snapshots off
 * gets told its protection FAILED. Those are opposite facts —
 *   disabled → calm, expected, chosen
 *   failed   → the one case worth interrupting someone about
 *
 * `undefined` status on a server that does not report it yet stays silent
 * rather than guessing either way.
 */
function readStartSnapshot(e) {
  const status = typeof e.startSnapshotStatus === 'string'
    ? e.startSnapshotStatus
    : (typeof e.startSnapshotId === 'string' ? 'taken' : null);
  const err = typeof e.startSnapshotError === 'string' ? e.startSnapshotError : null;
  const id = typeof e.startSnapshotId === 'string' ? e.startSnapshotId : null;
  switch (status) {
    case 'taken':
      return { status, id, protected: true, line: `snapshot ${String(id ?? '').slice(0, 12)}` };
    case 'deduped':
      // Still protected — an identical earlier snapshot is the restore point.
      return { status, id, protected: true, line: 'restore point unchanged since the last snapshot' };
    case 'disabled':
      return { status, id: null, protected: false, line: 'snapshots are off for this project' };
    case 'failed':
      return { status, id: null, protected: false, line: `NO restore point — the start snapshot failed${err ? `: ${err}` : ''}`, error: err };
    default:
      return null; // unreported — say nothing
  }
}

/** Paint the tray toggles, the composer hairline, and the seal chip together. */
function paintPerm() {
  const has = !!currentProject();
  const info = has ? effectivePerm() : null;
  const skipping = info?.mode === 'bypassPermissions';
  const planning = info?.mode === 'plan';
  const calm = skipping && info.iso === 'container'; // container is the boundary
  const risky = skipping && !calm;

  // tray toggles. `plan` and `bypassPermissions` are two values of ONE setting,
  // so both buttons are painted from the same effective mode — turning one on
  // necessarily shows the other off, and they can never both look active.
  node.skipBtn.hidden = !has;
  // aria-pressed reflects the CONFIRMED mode only. While a live change is in
  // flight the button shows a pending mark and does NOT move — the whole point
  // is that it must not look switched before the session actually switched.
  node.skipBtn.setAttribute('aria-pressed', String(!!skipping));
  node.skipBtn.dataset.risk = String(!!risky);
  // Pending has TWO honest cases: a live change awaiting the server's ack,
  // and a mode ARMED on a session that is not running right now — it takes
  // effect when the next send resumes the session. (A LIVE session switches
  // in place the moment the server confirms; no restart is ever scheduled.)
  const armedPending = !info?.live && info?.source === 'session-override';
  // A live change ACCEPTED mid-turn on an engine with no mid-turn switch (Codex):
  // the running turn keeps prompting to its end, so the toggle is armed for the
  // NEXT message, not in force now. `mode` above is still the running turn's real
  // mode, so this never lets the toggle claim skip is on while approvals fire.
  const pendingNextTurn = info?.pendingNextTurn ?? null;
  const armedNextSkip = pendingNextTurn === 'bypassPermissions';
  // An EXTERNAL follow (a terminal writes this session; the dashboard has no
  // bridge to it) can only ARM the takeover — it cannot touch the mode the
  // terminal is running under right now. Say exactly that, so the toggle never
  // reads as if it took effect on the live terminal session.
  const external = !!state.followingExternal;
  const armedNote = external
    ? ' — armed; applies ONLY if you take over this session from the dashboard (your terminal session keeps its own mode until then)'
    : ' — armed; takes effect on your next send, when the session resumes';
  // The running Codex turn cannot switch, so a skip armed here applies to your
  // NEXT message — said plainly so "I enabled skip and it still asks" cannot recur.
  const nextTurnNote = ' — armed; the running turn finishes under approval prompts, your next message skips them';
  node.skipBtn.dataset.pending = String(permModePending?.next === 'bypassPermissions' || (armedPending && skipping) || armedNextSkip);
  node.skipBtn.dataset.external = String(external && armedPending);
  node.skipBtn.title = skipping
    ? `Permissions skipped${armedPending ? armedNote : ''} — click to require approvals`
    : armedNextSkip
      ? `Skip permission prompts${nextTurnNote}`
      : external
        ? 'Skip permission prompts — this session is driven by your terminal; toggling here only applies if you take it over from the dashboard'
        : planning
          ? 'Skip permission prompts for this session (replaces plan mode)'
          : 'Skip permission prompts for this session';

  /*
   * FEAT-037 P3 — capabilities-driven degradation, not a provider check: an
   * engine without a plan mode (capabilities.planMode === false; Codex) gets
   * NO plan toggle rather than a button whose press would be refused. Absent
   * capabilities (older server, no session yet) keep the full UI — the
   * degradation only ever applies on the engine's own word.
   */
  const noPlanMode = dockEffective()?.capabilities?.planMode === false;
  node.planBtn.hidden = !has || noPlanMode;
  node.planBtn.setAttribute('aria-pressed', String(!!planning));
  node.planBtn.dataset.pending = String(permModePending?.next === 'plan' || (armedPending && planning));
  node.planBtn.dataset.external = String(external && armedPending);
  node.planBtn.title = planning
    ? `Plan mode on${armedPending ? armedNote : ''} — Claude reads and explores but cannot edit files or run mutating commands. Click to let it act.`
    : external
      ? 'Plan first — this session is driven by your terminal; toggling here only applies if you take it over from the dashboard'
      : 'Plan first — Claude reads and explores but cannot edit files or run mutating commands; it proposes a plan and waits for your approval';

  // seal chip. FEAT-139 review round 2 — the perm pill now lives INSIDE the
  // .seal-readouts wrapper (it inserts before #sealSep, which moved into the
  // wrapper), so this is a subtree query, not a direct-child one.
  node.seal.querySelector('.perm')?.remove();
  if (has) {
    // Three states, not two: "asks first" is not an honest label for plan mode,
    // where Claude cannot act at all until you approve a plan.
    const pendingChip = (armedPending && (skipping || planning)) || armedNextSkip;
    const chipNote = armedNextSkip ? ' · skip from next msg' : pendingChip ? (external ? ' · if you take over' : ' · from next send') : '';
    // FEAT-139 review round 2 — the mode pill is its OWN category, distinct in
    // KIND from the nav buttons (6px, opaque) and the chromeless readouts: a
    // fully-rounded pill carrying an LED-style ringed dot (a live state) and a
    // caret in the .sel idiom (it opens Settings to CHANGE the mode). The dot +
    // ring recolour per posture via CSS; the caret says "flippable".
    const chip = el('span', { class: 'perm', role: 'button', tabindex: '0', 'data-risk': String(!!risky), 'data-skip': String(!!skipping), 'data-pending': String(pendingChip), 'data-external': String(pendingChip && external) },
      el('span', { class: 'dot' }),
      el('span', { text: (skipping ? 'skips prompts' : planning ? 'plans first' : 'asks first') + chipNote }),
      svg('M4 6.5 8 10.5 12 6.5', 8, 'cx'));
    // FEAT-054: the chip names the permission mode — land on Model &
    // behaviour ▸ Permission mode instead of the drawer's default top.
    chip.addEventListener('click', () => void drawer.open('settings', { focus: 'permissionMode' }));
    chip.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); void drawer.open('settings', { focus: 'permissionMode' }); }
    });
    chip.title = armedNextSkip
      ? 'Skip armed — this engine cannot switch mid-turn, so the running turn finishes under approval prompts and your next message runs with them skipped. Nothing running is changed.'
      : info.live
        ? 'Permission mode, confirmed by the running session'
        : pendingChip
          ? (external
              ? 'Armed — this session is driven by your terminal, which the dashboard only follows. It applies ONLY if you take over by sending a message here; nothing running is changed now.'
              : 'Armed for this session — it takes effect when your next message resumes it. Nothing running is interrupted.')
          : 'Permission mode (applies on next launch)';
    node.sealSep.before(chip);
  }

  // composer hairline — only when prompts are being skipped
  const line = node.permLine;
  // BUG-106 — `skipping` now comes from effectivePerm()'s dockEffective(): when the
  // sidebar selection has moved to a different project the OPEN session's live
  // posture is absent and this falls back to the SELECTED project's predicted
  // posture, so a foreign dock never asserts A's "permissions skipped · container
  // is the boundary" under B — while B's OWN predicted skip (a container B) still
  // shows. Restored to A's live posture on switch-back.
  if (!skipping) {
    // Skip accepted mid-turn on a no-mid-turn-switch engine (Codex): the running
    // turn still asks, so say plainly that skip applies from the NEXT message
    // rather than hiding the line and leaving the toggle looking broken.
    if (armedNextSkip) {
      line.hidden = false;
      line.dataset.risk = 'false';
      clear(line);
      line.title = 'Skip armed — this engine cannot switch mid-turn, so the running turn finishes under approval prompts; your next message runs with prompts skipped. Nothing running is changed.';
      line.append(el('span', { class: 'g', text: '◷' }),
        el('b', { text: 'Skip armed' }),
        document.createTextNode(' · the running turn still asks; your next message skips'));
    } else {
      line.hidden = true;
    }
    return;
  }
  line.hidden = false;
  line.dataset.risk = String(!!risky);
  clear(line);
  // One dense line — the FULL sentence rides in the title so it costs no
  // vertical space while nothing is lost. Chrome must not fight the reading area.
  const full = calm
    ? (info.source === 'container-default'
        ? 'Permissions skipped — the container is the boundary here, so tools run without asking. This is the default for a container project.'
        : 'Permissions skipped — the container is the boundary here, so tools run without asking.')
    : (info.live
        ? 'Permissions skipped — this session runs commands on your machine with no approval prompt.'
        : 'Permissions skipped — the next launch runs commands on your machine with no approval prompt.');
  line.title = full;
  line.append(el('span', { class: 'g', text: risky ? '⚠' : '▣' }),
    el('b', { text: 'Permissions skipped' }),
    document.createTextNode(risky ? ' · runs commands with no prompt' : ' · container is the boundary'));
}

// FEAT-054: the composer permission hairline names the permission mode — one
// persistent element, so the deep-link listener is attached once, not per paint.
node.permLine.addEventListener('click', () => void drawer.open('settings', { focus: 'permissionMode' }));

/* ------------------------------------------------- changing permission mode */
/*
 * TWO PATHS, because there are genuinely two situations:
 *
 *   no session running  → the mode rides `overrides` on the `start` payload.
 *   session running     → it must go through the SDK's
 *                         `Query.setPermissionMode()`, which only the server can
 *                         call. The UI asks and waits for an ack.
 *
 * The old code only ever did the first. During a live session it set
 * `state.overrides.permissionMode` — which `effectivePerm()` correctly ignores,
 * because once a session is live the server's effective-config is the truth. So
 * the icon never moved, approvals kept firing, and the toast still announced
 * "permissions skipped". A control that asserts an effect it did not have is
 * the worst version of this bug, so nothing here claims a mode change until the
 * server confirms one.
 */

function setPermissionMode(next, opts = {}) {
  const p = currentProject();
  if (!p) return;
  const { mode: current, iso } = effectivePerm();
  if (next === current && !opts.force) return;

  /* ---- not started yet: overrides are the honest mechanism ---- */
  if (!state.live) {
    if (next === 'default' && iso !== 'container') delete state.overrides.permissionMode;
    else state.overrides.permissionMode = next;
    persistOverrides(); // the armed state survives a reload of the SAME session
    // An external-follow has no bridge and the terminal owns the live mode, so
    // be explicit that this only arms the takeover — it does not touch the
    // running terminal session (the app's cardinal sin is claiming otherwise).
    const scope = state.followingExternal
      ? '— armed; applies only if you take over this session from the dashboard, not to your terminal session now'
      : '— applies when this session starts';
    say(`${describeMode(next, iso)} ${scope}`, next === 'bypassPermissions' && iso !== 'container');
    paintPerm();
    paintModelBtn();
    drawer.repaintLive?.();
    return;
  }

  /* ---- live: ask the server, claim nothing yet ---- */
  if (permModePending) return say('still waiting on the last permission-mode change', true);
  const requestId = `pm-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
  if (!send({ type: 'set-permission-mode', requestId, mode: next })) {
    return say('permission mode unchanged — no live connection, nothing was sent', true);
  }
  permModePending = { requestId, next };
  permModePending.timer = setTimeout(() => finishPermMode(requestId, false,
    'the server never confirmed — this session is still running with the old mode'), 6000);
  say(`asking the running session to switch to ${next}…`);
  paintPerm(); // paints a pending state; aria-pressed stays on the CONFIRMED mode
}

/**
 * Settle a live mode change. `ok` comes from the server's ack — never from the
 * fact that we managed to send something.
 */
function finishPermMode(requestId, ok, why, appliesFrom) {
  if (!permModePending || permModePending.requestId !== requestId) return;
  clearTimeout(permModePending.timer);
  const { next } = permModePending;
  permModePending = null;

  if (!ok) {
    say(`permission mode NOT changed: ${why ?? 'the server refused'}`, true);
    paintPerm();
    return;
  }
  // Mirror into the session's overrides so a reload RESUMES in the accepted mode —
  // done for both immediate and deferred, since the engine has accepted it either way.
  if (next === 'default') delete state.overrides.permissionMode;
  else state.overrides.permissionMode = next;
  persistOverrides();
  const iso = state.effective?.isolation ?? currentProject()?.isolation ?? 'direct';
  /*
   * DEFERRED (Codex mid-turn): the engine accepted the change but the RUNNING turn
   * keeps its old policy to the end. Do NOT flip `effective.permissionMode` — that
   * would make the toggle claim skip is in force while the in-flight turn is still
   * asking (the reported defect). The server's effective-config carries
   * `permissionModePendingNextTurn`, which paintPerm turns into the armed-for-next
   * -turn indicator; here we just tell the user honestly where it applies.
   */
  if (appliesFrom === 'next-turn') {
    say(`${describeMode(next, iso)} · armed — the running turn finishes under approval prompts; your next message runs under the new mode`,
      next === 'bypassPermissions' && iso !== 'container');
    paintPerm();
    paintModelBtn();
    drawer.repaintLive?.();
    return;
  }
  // Immediate: the server confirmed and it governs the running session now. An
  // `effective-config` event may also arrive and will simply agree.
  if (state.effective?.effective) state.effective.effective.permissionMode = next;
  else state.effective = { ...(state.effective ?? {}), effective: { permissionMode: next } };
  say(`${describeMode(next, iso)} · confirmed by the server — in force for this running session`,
    next === 'bypassPermissions' && iso !== 'container');
  paintPerm();
  paintModelBtn();
  drawer.repaintLive?.();
}

/**
 * Ask the RUNNING session to switch model (BUG-026). Claims nothing until the
 * server confirms — a control that asserts an effect it did not have is the
 * worst version of this bug (same rule as setPermissionMode). `value` is the
 * picker option value: a model alias (e.g. 'haiku') or null to inherit.
 */
function setModelLive(value) {
  if (modelPending) return say('still waiting on the last model change', true);
  const requestId = `md-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
  if (!send({ type: 'set-model', requestId, model: value })) {
    return say('model unchanged — no live connection, nothing was sent', true);
  }
  modelPending = { requestId, value };
  modelPending.timer = setTimeout(() => finishModel(requestId, false,
    'the server never confirmed — this session is still running with the old model'), 6000);
  say(`asking the running session to switch to ${value ?? 'the project default'}…`);
  paintModelBtn();
  paintModelPop(); // paints a pending state; the current row stays on the CONFIRMED model
}

/**
 * Settle a live model change. `ok` comes from the server's ack — never from the
 * fact that we managed to send something.
 */
function finishModel(requestId, ok, why) {
  if (!modelPending || modelPending.requestId !== requestId) return;
  clearTimeout(modelPending.timer);
  const { value } = modelPending;
  modelPending = null;

  if (!ok) {
    say(`model NOT changed: ${why ?? 'the server refused'}`, true);
    paintModelBtn();
    paintModelPop();
    return;
  }
  // The server confirmed, so the live effective-config is now this. An
  // `effective-config` event also arrives and will simply agree.
  if (state.effective?.effective) state.effective.effective.model = value;
  else state.effective = { ...(state.effective ?? {}), effective: { model: value } };
  // Mirror into the session's overrides too: after a reload this session
  // RESUMES with `start.overrides`, and it must resume on the model the server
  // just confirmed — not silently fall back to the project default.
  if (value === null) delete state.overrides.model;
  else state.overrides.model = value;
  persistOverrides();
  // FEAT-042: the user CHOSE this, so it becomes the new expectation (a later
  // per-turn report matching it must never flag). The old wire report is now
  // stale — the chip shows the confirmed value until the new model speaks.
  expectedLiveModel = value;
  liveWireModel = null;
  clearModelFlag();
  paintModelChip();
  // FEAT-045: Codex takes the model per turn/start (P2c) — there is no
  // mid-turn switch, so the honest claim is "from the next turn", not "now".
  say(providerView() === 'openai'
    ? `model: ${value ?? 'project default'} · confirmed — Codex switches at turn boundaries, so it applies from the next turn`
    : `model: ${value ?? 'project default'} · confirmed by the server — in force for this running session`);
  paintModelBtn();
  paintModelPop();
  // NB: no paintCrown() here — it re-says the isolation line when idle, which
  // would immediately STOMP the confirmation above (paintPerm/paintModelBtn are
  // enough; the crown/seal shows isolation+mounts, nothing model-related).
  drawer.repaintLive?.();
}

function describeMode(mode, iso) {
  if (mode === 'bypassPermissions') {
    return iso === 'container'
      ? 'permissions skipped — the container is the boundary'
      : 'permissions skipped — this session can run anything on your machine with no approval';
  }
  if (mode === 'plan') return 'plan mode — Claude reads and proposes, but cannot edit or run mutating commands';
  return 'permission prompts restored';
}

/** Flip skip-permissions. Live sessions go through the server. */
function toggleSkip() {
  const { mode, iso } = effectivePerm();
  if (mode === 'bypassPermissions') {
    // Turning prompts back on: a container's default IS bypass, so it needs an
    // explicit 'default' rather than simply dropping the override.
    setPermissionMode('default', { force: iso === 'container' });
  } else {
    setPermissionMode('bypassPermissions');
  }
}

/**
 * Plan mode, as a SESSION override — matching the skip toggle beside it.
 *
 * It used to `patchProject` the registry, so a single click silently changed
 * that project's default for every future session. Two adjacent, visually
 * identical toggles where only one persists is a trap; both are per-session now.
 */
/**
 * Plan mode. Confirmed to share the skip toggle's scope bug: it also only set
 * `state.overrides`, so during a live session it changed nothing and the button
 * did not move. Both toggles now go through one code path.
 */
function togglePlan() {
  const { mode, iso } = effectivePerm();
  if (mode === 'plan') {
    // A container's default is bypass, so leaving plan there needs to be
    // explicit; the skip button will light up to say what you landed on.
    setPermissionMode('default', { force: iso === 'container' });
  } else {
    // Same underlying setting as skip, so this REPLACES it rather than stacking.
    setPermissionMode('plan');
  }
}

/* ------------------------------------------------------------- transcript */
/*
 * Threads. `main` plus one per subagent, each with its own .pane section that
 * stays in the DOM. Switching threads toggles `.on` — main's live stream, open
 * tool chips and scroll position all survive a round trip into an agent.
 */

function newThread(key, meta = {}) {
  const paneEl = el('section', { class: 'pane', 'data-thread': key === 'main' ? 'main' : 'agent' });
  node.panes.append(paneEl);
  const th = {
    key,
    // BUG-171: the SERVER declares whether a lane is a real subagent or a single
    // TOOL call it surfaced as its own task (a `local_bash`) — LiveAgent.kind on
    // the wire. Read that declared fact (via agentKind at the call sites); never
    // hardcode 'agent', which is what made a tool lane read as a phantom subagent
    // stuck "waiting for this agent's first output…" forever (ARCH-010).
    kind: key === 'main' ? 'main' : (meta.kind ?? 'agent'),
    agentId: key === 'main' ? null : key,
    agentType: meta.agentType ?? '',
    description: meta.description ?? '',
    status: meta.status ?? (key === 'main' ? 'running' : 'running'),
    stats: meta.stats ?? null,
    paneEl,
    claudeBody: null,
    stream: null,
    tools: new Map(),
    loaded: key === 'main',
    loading: false,
    /* scroll state — see the "scroll" section. stick=true means "follow the
       end"; it only ever becomes false because the USER scrolled up. */
    stick: true,
    scrollTop: 0,
    unseen: false,
    page: null, // main only: reverse-pagination cursor into the transcript
  };
  state.threads.set(key, th);
  if (th.kind !== 'main') refreshLede(th);
  return th;
}

/**
 * The one-line mono header inside an agent's pane. Rebuilt rather than written
 * once, because agent-started can arrive before we know the type/description.
 */
function refreshLede(th) {
  if (th.kind === 'main') return;
  if (th.kind === 'tool') { refreshToolLede(th); return; }
  refreshWaiting(th);
  let lede = th.paneEl.querySelector(':scope > .lede');
  if (!lede) {
    lede = el('div', { class: 'lede' });
    th.paneEl.prepend(lede);
  }
  clear(lede);
  lede.append(el('b', { text: th.agentType || 'agent' }));
  if (th.description) lede.append(document.createTextNode(` · ${th.description}`));
  if (th.stats) lede.append(document.createTextNode(` · ${th.stats}`));
}

/**
 * BUG-171 — the lede for a TOOL lane (BUG-030: a CLI `local_bash` the engine
 * surfaces as its own task, e.g. the orchestrator's "Idle wait for subagents"
 * Bash call). It is NOT a subagent: it emits no agent output, so the agent lede
 * and the "waiting for this agent's first output…" hint are both false for it —
 * together they read as a phantom subagent stuck forever, which is exactly how
 * the owner reported it. Show what a bash lane actually is: its task type, the
 * description/command the caller passed, and whether it is still running. The
 * server DECLARES this is a tool (LiveAgent.kind); we read that, not re-derive
 * it (ARCH-010). Deliberately no `.waiting` hint — a tool lane has no first
 * output to wait for — so any one left over from a prior kind is removed.
 */
function refreshToolLede(th) {
  th.paneEl.querySelector(':scope > .waiting')?.remove();
  let lede = th.paneEl.querySelector(':scope > .lede');
  if (!lede) {
    lede = el('div', { class: 'lede' });
    th.paneEl.prepend(lede);
  }
  clear(lede);
  lede.append(el('b', { text: th.agentType || 'tool' }));
  if (th.description) lede.append(document.createTextNode(` · ${th.description}`));
  const stateLabel = th.status === 'running' ? 'running' : (th.stats || th.status || 'done');
  lede.append(document.createTextNode(` · ${stateLabel}`));
}

/**
 * An agent thread is empty between `agent-started` and its first output. Say
 * so rather than showing a blank pane that reads like "nothing happened".
 */
function refreshWaiting(th) {
  if (th.kind !== 'agent') return;
  const hasContent = th.paneEl.querySelector('.claude, .you, .hint-row:not(.waiting)');
  let wait = th.paneEl.querySelector(':scope > .waiting');
  if (hasContent || th.status !== 'running') {
    wait?.remove();
    return;
  }
  if (!wait) {
    wait = el('div', { class: 'hint-row waiting', text: 'waiting for this agent’s first output…' });
    th.paneEl.append(wait);
  }
}

const mainThread = () => state.threads.get('main') ?? newThread('main');

/** The thread an event belongs to. Unknown agent ids get a thread on the spot. */
function threadFor(agentId) {
  if (!agentId) return mainThread();
  return state.threads.get(agentId) ?? newThread(agentId, { agentType: 'agent' });
}

const viewedThread = () => state.threads.get(state.viewing) ?? mainThread();

/*
 * BUG-083 — the composer draft belongs to the project/session it was typed in.
 * A real, on-disk session keys on its dir+id; a not-yet-sent "New session" has
 * no id, so it keys on the project (each project keeps one pending-new draft).
 */
function draftKey(cur) {
  if (!cur || cur.projectId == null) return null;
  return cur.sessionId
    ? `s\x00${cur.encodedDir ?? ''}\x00${cur.sessionId}`
    : `p\x00${cur.projectId}`;
}
/** Stash whatever is in the composer under `cur`'s key (empty clears it). */
function saveDraft(cur) {
  const key = draftKey(cur);
  if (!key) return;
  const v = node.prompt.value;
  if (v) state.drafts.set(key, v); else state.drafts.delete(key);
}
/** Put `cur`'s saved draft back into the composer — empty when there is none. */
function restoreDraft(cur) {
  const key = draftKey(cur);
  node.prompt.value = (key && state.drafts.get(key)) || '';
  autosize();
}

function resetTranscript() {
  clear(node.panes);
  /*
   * BUG-129: every session boundary passes through here, and by this point
   * state.current is ALREADY the incoming session — so drop ownership of the
   * stored rows BEFORE emptying the queue. Without this the paintQueue() below
   * would mirror an empty queue over the incoming session's own stored rows and
   * destroy them (the reverse of the bug). The outgoing session's rows stay in
   * storage, untouched, and are restored when it is opened again — this same
   * function re-takes ownership of the INCOMING session's rows at its end (see
   * the BUG-150 note there), so queueKey is null only for the span of this reset.
   */
  queueKey = null;
  state.outbox = null; // the outgoing session's in-flight batch is not ours to retire or resend
  state.queue.length = 0; // a queue belongs to the session being left behind
  state.followingLive = false; // the followed run belongs to the session we left
  state.followingExternal = false; // …and so does any external-follow framing
  paintQueue();
  state.threads.clear();
  state.viewing = 'main';
  state.agents.clear();
  /*
   * BUG-034 — the server's running-set snapshot belongs to the session being
   * left behind. Dropping it to null (rather than keeping the last one) is what
   * stops the outgoing session's rows from being rendered under the incoming
   * session's name for the moment before the new answer lands.
   */
  state.snap = null;
  // BUG-083 — a session boundary: any running-set poll already in flight was
  // fired under the session we are leaving. Moving the scope token makes that
  // poll drop its answer when it lands, so it can never repaint the outgoing
  // session's agents under the incoming session (ARCH-001 honesty). The strip
  // clears immediately below (renderStrip over the now-null snapshot); the
  // guard only stops a late answer from un-clearing it.
  state.snapScope++;
  // BUG-087 — the transcript-pane sibling of the strip's scope bump. Any
  // transcript fetch already in flight was fired under the session being left;
  // moving this token makes openSession drop that fetch when it lands, so a slow
  // prior-session transcript can never paint under the incoming session's header.
  state.txScope++;
  state.agentText.clear();
  clear(node.asks);
  node.asks.hidden = true;
  state.asks.clear();
  state.decisionsByRequest.clear();
  newThread('main');
  showThread('main');
  renderStrip();
  node.jump.hidden = true;
  /*
   * BUG-150 (ARCH-010) — the queue↔session binding is DECLARED here, once.
   * resetTranscript is the single function every session boundary AND every
   * in-place transcript reset (openSession's success and its catch, startNew,
   * the fresh-start re-take, a route that resolves to no session) passes
   * through, and the only place queueKey is dropped to null. So it is also the
   * only place it is re-bound: re-take ownership of THIS session's stored rows
   * before returning, rather than leaving queueKey null for each caller to
   * remember to re-adopt. A caller that must reason before its transcript is on
   * screen never can (round 1 left the catch path un-adopted — a silent-loss
   * regression). The returned outbox descriptor is judged by the caller: after
   * its transcript is painted where there is an await (openSession), or
   * immediately where there is not (adoptQueue).
   */
  return adoptQueueRows();
}

function youBubble(th, text) {
  th.paneEl.querySelector(':scope > .waiting')?.remove();
  const w = el('div', { class: 'you' }, el('p', { text }));
  th.paneEl.append(w);
  th.claudeBody = null;
  th.stream = null;
  return w;
}

/*
 * Per-message timestamp (user request): weightless at rest, revealed to the SIDE
 * on hover so normal reading is never crowded, but a message's real time is one
 * hover away when checking history of timings. Design decisions:
 *   - ABSOLUTE time, dated only when it is not today (datedTime → "14:32",
 *     "yesterday 14:32", "Aug 10 14:32"). The ask is auditing when things
 *     happened, not "3 minutes ago", and a conversation can span days.
 *   - NO layout shift: the <time> is absolutely positioned in the gutter beside
 *     the message (has-ts is position:relative), so revealing it never nudges a
 *     single character of the text.
 *   - Accessible WITHOUT any focus or hover (BUG-106 clean-room defect B): the old
 *     shape relied on :focus-within to "reveal" the stamp for keyboard/AT users,
 *     but nothing in a message is keyboard-focusable, so that rule was dead — the
 *     affordance could never fire. Making every bubble (or every stamp) tabbable
 *     would add one Tab stop PER message: a keyboard user tabbing past hundreds of
 *     timestamps to reach the composer is a worse experience, not a better one.
 *     The correct fix needs NO focus at all: the <time> carries an `aria-label`
 *     with the FULL, unambiguous absolute datetime (the same detail the pointer
 *     `title` tooltip shows), so a screen reader announces it in the normal reading
 *     order as it passes the message — no reveal, no interaction, no extra stop.
 *     The element stays a real <time datetime=…> in the a11y tree (opacity, never
 *     display:none); the terse visible text ("14:32") is for sighted readers and
 *     the pointer hover keeps reading uncrowded. See styles.css — the dead
 *     :focus-within reveal was removed with this change.
 *   - `iso` is the message's recorded time (ISO string) or an epoch-ms number;
 *     anything unparseable yields no stamp rather than a fake "now".
 * Returns `node` for chaining at the call site.
 */
function accessibleTimeLabel(d) {
  // A full, self-describing absolute time — weekday + full date + year + clock —
  // so an AT user hears the unambiguous moment (not the terse "14:32" the sighted
  // gutter shows, and not the machine `title` string). Falls back to the ISO
  // string if the environment has no Intl.
  try {
    return `sent ${d.toLocaleString(undefined, {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })}`;
  } catch { return `sent ${d.toISOString()}`; }
}

function stampTime(node, iso) {
  if (!node) return node;
  const ms = typeof iso === 'number' ? iso : (typeof iso === 'string' ? Date.parse(iso) : NaN);
  if (!Number.isFinite(ms)) return node;
  const d = new Date(ms);
  node.classList.add('has-ts');
  const t = el('time', {
    class: 'msg-ts',
    datetime: d.toISOString(),
    title: d.toString(),
    // BUG-106 defect B — the accessible name AT users hear, no focus/hover needed.
    'aria-label': accessibleTimeLabel(d),
  });
  t.textContent = datedTime(ms);
  node.append(t);
  return node;
}

function claudeBody(th) {
  th.paneEl.querySelector(':scope > .waiting')?.remove();
  if (th.claudeBody) return th.claudeBody;
  const av = el('div', { class: 'av' }, el('i'));
  const body = el('div', { class: 'body' });
  th.paneEl.append(el('div', { class: 'claude' }, av, body));
  th.claudeBody = body;
  return body;
}

function toolsGroup(th) {
  const body = claudeBody(th);
  const last = body.lastElementChild;
  if (last && last.classList.contains('tools')) return last;
  const g = el('div', { class: 'tools' });
  body.append(g);
  return g;
}

function ranStack(th) {
  const body = claudeBody(th);
  const last = body.lastElementChild;
  if (last && last.classList.contains('ran-stack')) return last;
  const s = el('div', { class: 'ran-stack' }, el('div', { class: 'ran-lbl', text: '' }));
  body.append(s);
  return s;
}

/**
 * BUG-100 — a turn's run summary rendered where an OUTCOME belongs: a durable
 * line at the foot of the main transcript, not the one-shot footer ticker that
 * exists to hold the isolation label. The cost carries an explicit "estimate,
 * not billed" title so the ~$ figure can never be mistaken for real spend.
 */
function appendTurnOutcome(summary, costUsd) {
  const th = mainThread();
  if (!th) return;
  const body = claudeBody(th);
  const line = el('div', { class: 'ran-lbl turn-outcome', text: summary });
  if (costUsd) {
    line.title = 'The ~$ figure is an API-equivalent ESTIMATE for this turn — not money billed to you (you run on a fixed plan).';
  }
  body.append(line);
}

function toolChip(th, name, input) {
  const chip = el('details', { class: 'tool running' });
  const res = el('span', { class: 'res', text: 'running…' });
  chip.append(el('summary', {},
    el('span', { class: 'tw', text: '▶' }),
    el('span', { class: 'nm', text: name }),
    el('span', { class: 'arg', text: toolArg(name, input) }),
    res));
  const pre = el('pre', { text: '' });
  const out = el('div', { class: 'out' });
  // Live edits show WHAT changed, same as recorded ones; the pre below still
  // receives the tool's result output as it streams.
  const diff = diffElementFor(name, input);
  if (diff) out.append(diff);
  out.append(pre);
  chip.append(out);
  toolsGroup(th).append(chip);
  if (state.viewing === th.key) scrollDown();
  return { chip, res, pre };
}

/*
 * Live markdown while streaming — the HONEST variant (FEAT-016). Instead of
 * dumping the raw buffer as textContent (so `**bold**`, list markers and ```
 * fences showed as literal syntax until the turn ended), re-parse the
 * ACCUMULATED buffer through the same tolerant prose() each frame. Completed
 * markdown (earlier bold, headings, closed fences) formats live; in-progress
 * syntax stays literal until its token closes — nothing is asserted before it
 * has happened. The reparse is THROTTLED (leading edge + one trailing render)
 * so a fast token stream does not reparse synchronously on every token; prose()
 * is sub-ms on these small buffers but the throttle keeps it off the hot path.
 */
const STREAM_RENDER_MS = 70;

function renderStreamNow(th) {
  const s = th?.stream;
  if (!s) return;
  if (s.timer) { clearTimeout(s.timer); s.timer = 0; }
  s.lastRender = Date.now();
  const fresh = prose(s.text);
  // The caret rides the end of the last rendered block, not a bare line of its
  // own, so it reads as "still typing here".
  (fresh.lastElementChild ?? fresh).append(s.caret);
  s.wrap.replaceWith(fresh);
  s.wrap = fresh;
  if (state.viewing === 'main') scrollDown();
}

function scheduleStreamRender(th) {
  const s = th?.stream;
  if (!s || s.timer) return;
  s.timer = setTimeout(() => { if (th.stream === s) { s.timer = 0; renderStreamNow(th); } }, STREAM_RENDER_MS);
}

function finishStream(th) {
  if (!th?.stream) return;
  if (th.stream.timer) clearTimeout(th.stream.timer);
  const text = th.stream.text;
  // BUG-169: settle the live stream through the DIGEST-AWARE renderer, not raw
  // prose(). When finishStream fires mid-stream (agent-completed / turn-end /
  // tool-call arrives before the block's own 'text' settle event), the old
  // prose() painted the raw orchard-digest JSON, then the trailing 'text' event
  // — finding th.stream null — APPENDED a second, digest-aware render of the same
  // text: the fence showed twice (raw JSON, then the rail). We now (a) render the
  // settled node digest-aware so it already looks right, and (b) remember it as
  // th.settledStream so the trailing 'text' re-renders THIS node in place instead
  // of appending a duplicate (see case 'text').
  const node = assistantProse(text);
  th.stream.wrap.replaceWith(node);
  th.stream = null;
  th.settledStream = { node, text };
}

/* ----------------------------------------------------------------- scroll */
/*
 * A chat opens on its newest message. Three rules, and they interact:
 *
 *  1. STICK is a remembered intent, not a measurement taken at append time.
 *     The old scrollDown() measured "am I within 240px of the bottom?" AFTER
 *     the new content was already in the DOM, so one tall tool chip could push
 *     the distance past the threshold and silently unstick a user who had never
 *     scrolled. Stickiness is now recomputed only when the USER scrolls.
 *  2. Scrolled away means scrolled away: a live turn appends but never moves
 *     the viewport. The `Latest` pill is how you come back.
 *  3. Every thread keeps its own scrollTop, because all panes share one
 *     scroller — walking into a subagent and back must not lose main's place.
 */

const NEAR_BOTTOM_PX = 64;   // within this of the end counts as "at the bottom"
const JUMP_SHOW_PX = 260;    // don't offer "Latest" for a few lines of drift
const OLDER_TRIGGER_PX = 600; // start fetching older messages this far from the top

const atBottom = () => {
  const s = node.scroll;
  return s.scrollHeight - s.scrollTop - s.clientHeight <= NEAR_BOTTOM_PX;
};

/** Jump to the end with no animation and no intermediate frame. */
function scrollToBottom(th = viewedThread()) {
  const s = node.scroll;
  s.scrollTop = s.scrollHeight;
  th.stick = true;
  th.scrollTop = s.scrollTop;
  th.unseen = false;
  paintJump();
}

/** Follow a live append — only if the user has not scrolled away. */
function scrollDown() {
  const th = viewedThread();
  if (th.stick === false) {
    th.unseen = true;
    paintJump();
    // FEAT-118 — new content while scrolled away is unread: the read boundary is
    // frozen, so the "you were here" line grows below it.
    if (th.key === 'main') paintReadLine(th);
    return;
  }
  const s = node.scroll;
  s.scrollTop = s.scrollHeight;
  th.scrollTop = s.scrollTop;
  // At the live bottom: content is read as it arrives ONLY while the user is
  // actually looking (tab visible). While the tab is hidden the autoscroll still
  // runs but the boundary FREEZES — that is the whole point, so returning shows
  // where they left off instead of "all read" (Discord's over-eager clear).
  if (th.key === 'main') {
    if (!document.hidden) advanceReadMark(th);
    else paintReadLine(th);
  }
}

function onScroll() {
  const th = viewedThread();
  const bottom = atBottom();
  th.stick = bottom;
  th.scrollTop = node.scroll.scrollTop;
  if (bottom) th.unseen = false;
  paintJump();
  // FEAT-118 — advance the read boundary as the user reads DOWN, but never while
  // the tab is hidden (autoscroll-while-AFK must not mark content read — that is
  // exactly Discord's over-eager clear) and never during a programmatic scroll
  // (opening / jumping must not clear the mark it was meant to restore).
  if (th.key === 'main' && !document.hidden && Date.now() > suppressAdvanceUntil) advanceReadMark(th);
  void maybeLoadOlder();
  void maybeLoadNewer();
  syncUrlSoon();
}

function paintJump() {
  const s = node.scroll;
  const th = viewedThread();
  const away = s.scrollHeight - s.scrollTop - s.clientHeight;
  // While a forward gap is outstanding, the pill is ALWAYS offered: the bottom
  // of what is rendered is not the bottom of the session, and hiding the pill
  // there would assert "you are at the end" — the exact lie to avoid.
  const gap = th.key === 'main' && !!th.gap;
  const show = away > JUMP_SHOW_PX || gap;
  node.jump.hidden = !show;
  node.jump.classList.toggle('new', show && th.unseen === true);
}

/* ═══════════════════════════════ FEAT-118 — within-session marks ═══════════
 *
 * TWO marks, both persisted per session (survive a reload AND a switch away and
 * back), both reachable in ONE action:
 *
 *   • the AUTOMATIC "you were here" line — the stated pain. The transcript
 *     autoscrolls while the user is away, so returning means losing their place.
 *     We remember the highest message index they have actually READ and draw a
 *     divider before the first unread message. IMPROVEMENT OVER DISCORD: the
 *     boundary FREEZES while the tab is hidden or they have scrolled up, and
 *     clears ONLY when they scroll down THROUGH it — never on mere focus/switch,
 *     which is Discord's over-eager clear.
 *
 *   • the MANUAL bookmark — what the user literally asked for. A spot they drop
 *     deliberately (the message at the top of the viewport), rendered as a solid
 *     ribbon distinct from the dashed read-line, and returned to in one click.
 *
 * The read-mark and bookmark live in localStorage (state.readMarks/bookmarks),
 * keyed by seenKey; in-memory th.readIndex is the working copy for the open
 * thread. Only the MAIN thread carries marks — a subagent view is transient.
 */

// A programmatic scroll (open, jump-to) fires a `scroll` event ASYNCHRONOUSLY,
// so a boolean cleared on the next tick reopens the gate before that event
// arrives — and the restore then reads as the user having read to the bottom,
// wiping the very mark it was meant to reveal. A short timestamp window instead
// covers the queued event however late it lands.
let suppressAdvanceUntil = 0;
function withoutReadAdvance(fn) {
  suppressAdvanceUntil = Date.now() + 300;
  return fn();
}

function currentMarkKey() {
  const { encodedDir, sessionId } = state.current;
  return sessionId ? seenKey(encodedDir, sessionId) : null;
}

/** Highest absolute message index currently rendered in a thread, or null. */
function maxRenderedIndex(th) {
  let max = null;
  for (const m of th.paneEl.querySelectorAll('[data-i]')) {
    const i = Number(m.dataset.i);
    if (Number.isInteger(i) && (max === null || i > max)) max = i;
  }
  return max;
}

/**
 * Seed the working read boundary when a session opens. A persisted mark wins
 * (so unread survives a reload/switch); otherwise everything on screen at open
 * is the baseline — a first visit is not a wall of "unread". Never advanced past
 * what is rendered here, so a deep-history restore cannot mislabel the tail.
 */
function seedReadMark(th) {
  const key = currentMarkKey();
  if (!key || th.key !== 'main') return;
  const saved = state.readMarks.get(key);
  th.readIndex = Number.isInteger(saved) ? saved : (maxRenderedIndex(th) ?? -1);
}

/** Advance the read boundary as the user reads down, and persist it. At the
 *  live bottom everything rendered is read; mid-history the top-visible message
 *  is the frontier. Monotonic — the boundary never retreats. */
function advanceReadMark(th) {
  const key = currentMarkKey();
  if (!key || th.key !== 'main') return;
  const frontier = atBottom() ? maxRenderedIndex(th) : topVisibleIndex(th);
  if (!Number.isInteger(frontier)) return;
  const prev = Number.isInteger(th.readIndex) ? th.readIndex : -1;
  if (frontier > prev) {
    th.readIndex = frontier;
    state.readMarks.set(key, frontier);
    saveMarksSoon();
  }
  paintReadLine(th);
}

/**
 * Draw (or clear) the "you were here" divider. It sits before the first message
 * whose index is beyond the read boundary — i.e. the boundary between read and
 * unread. Absent when nothing rendered is unread. Also drives the "Resume"
 * pill: offered whenever the divider is above the current viewport.
 */
function paintReadLine(th = viewedThread()) {
  if (!node.leftoff) return;
  // `data-i` rides nested assistant nodes (inside .claude .body), not only
  // top-level children, so every mark query here searches the whole pane —
  // never `:scope >`, which would miss them and let dividers accumulate.
  for (const n of th.paneEl.querySelectorAll('.readline')) n.remove();
  if (th.key !== 'main') { node.leftoff.hidden = true; return; }
  const readIndex = Number.isInteger(th.readIndex) ? th.readIndex : -1;
  const maxIdx = maxRenderedIndex(th);
  // Nothing unread on screen, or a forward gap not yet paid: no line.
  if (maxIdx === null || maxIdx <= readIndex) { node.leftoff.hidden = true; return; }
  // First rendered message beyond the boundary.
  let target = null;
  for (const m of th.paneEl.querySelectorAll('[data-i]')) {
    if (Number(m.dataset.i) > readIndex) { target = m; break; }
  }
  if (!target) { node.leftoff.hidden = true; return; }
  const unread = maxIdx - readIndex;
  const line = el('div', { class: 'readline', 'data-readline': '1' },
    el('span', { class: 'rl-label', text: `You left off here${unread > 0 ? ` · ${unread} new below` : ''}` }));
  target.before(line);
  // Offer the one-action jump whenever the line is above the viewport.
  const above = line.getBoundingClientRect().bottom < node.scroll.getBoundingClientRect().top;
  node.leftoff.hidden = !above;
  node.leftoff.querySelector('.g').textContent = unread > 0 ? `${unread} new` : 'resume';
}

/** One-action return to the read boundary. An INSTANT scroll — a smooth
 *  animation fires a stream of scroll events, and any that land after the
 *  suppression window would advance the very mark this jump exists to reveal. */
function jumpToReadLine() {
  const th = viewedThread();
  const readIndex = Number.isInteger(th.readIndex) ? th.readIndex : -1;
  withoutReadAdvance(() => {
    const line = th.paneEl.querySelector('.readline');
    const s = node.scroll;
    if (line) {
      s.scrollTop = Math.max(0, line.getBoundingClientRect().top - s.getBoundingClientRect().top + s.scrollTop - s.clientHeight / 2);
      th.scrollTop = s.scrollTop;
      th.stick = atBottom();
      paintJump();
    } else {
      scrollToIndex(th, readIndex + 1);
    }
  });
  // Recompute the pill: the line is now in view, so the Resume offer retracts.
  paintReadLine(th);
}

/** Is a rendered node currently within the scroller's viewport? */
function isOnScreen(m) {
  if (!m) return false;
  const r = m.getBoundingClientRect();
  const s = node.scroll.getBoundingClientRect();
  return r.bottom > s.top && r.top < s.bottom;
}

/* ── manual bookmark ─────────────────────────────────────────────────────── */

/** Draw (or clear) the bookmark ribbon on its message, and refresh the button. */
function paintBookmark(th = viewedThread()) {
  const old = th.paneEl.querySelector('[data-i].bookmarked');
  if (old) old.classList.remove('bookmarked');
  const key = currentMarkKey();
  const idx = key ? state.bookmarks.get(key) : null;
  if (Number.isInteger(idx)) {
    // Ribbon rides the nearest rendered message at or before the index.
    let best = null;
    for (const m of th.paneEl.querySelectorAll('[data-i]')) {
      if (Number(m.dataset.i) <= idx) best = m; else break;
    }
    if (best) best.classList.add('bookmarked');
  }
  paintBookmarkBtn(th);
}

/** The bookmark control cycles set → jump → clear from one button, mirroring the
 *  pin's "filled when set" language. */
function paintBookmarkBtn(th = viewedThread()) {
  const btn = node.bookmark;
  if (!btn) return;
  if (th.key !== 'main') { btn.hidden = true; return; }
  btn.hidden = false;
  const key = currentMarkKey();
  const idx = key ? state.bookmarks.get(key) : null;
  const set = Number.isInteger(idx);
  // FEAT-118 r2: `marked`, NOT `set` — `.set` is the settings-row rule
  // (styles.css) and collides (full-width bar over the transcript).
  btn.classList.toggle('marked', set);
  const onScreen = set && isOnScreen(th.paneEl.querySelector('[data-i].bookmarked'));
  // One control cycles set → jump → clear; the label names the NEXT action AND
  // says the cycle, so the button explains itself on hover / to a screen reader
  // even though the moss ribbon it drops is usually scrolled off screen.
  if (!set) {
    btn.title = 'Bookmark this spot — drop a marker here you can jump back to (sets → jumps → clears)';
    btn.setAttribute('aria-label', 'Set bookmark at the top of the view');
  } else if (onScreen) {
    btn.title = 'Bookmark is here — click to clear it';
    btn.setAttribute('aria-label', 'Clear bookmark');
  } else {
    btn.title = 'Jump to your bookmark — then click again there to clear it';
    btn.setAttribute('aria-label', 'Jump to bookmark');
  }
  btn.setAttribute('aria-pressed', String(set));
}

/** Click handler: set when none, jump when off-screen, clear when on-screen. */
function toggleBookmark() {
  const th = viewedThread();
  const key = currentMarkKey();
  if (!key || th.key !== 'main') return;
  const idx = state.bookmarks.get(key);
  if (!Number.isInteger(idx)) {
    const here = topVisibleIndex(th);
    if (!Number.isInteger(here)) return;
    state.bookmarks.set(key, here);
    saveMarksSoon();
    paintBookmark(th);
    say('Bookmark set here — the filled bookmark button (top right) jumps you back to it');
    return;
  }
  const mark = th.paneEl.querySelector('[data-i].bookmarked');
  const onScreen = isOnScreen(mark);
  if (onScreen) {
    state.bookmarks.delete(key);
    saveMarksSoon();
    paintBookmark(th);
  } else {
    withoutReadAdvance(() => scrollToIndex(th, idx));
    paintBookmarkBtn(th);
  }
}

/** Repaint both marks — called after render, on scroll settle, and on return. */
function paintMarks(th = viewedThread()) {
  paintReadLine(th);
  paintBookmark(th);
}

/* ------------------------------------------------- reverse pagination */
/*
 * Only the newest TAIL_PAGE messages are fetched to open a session; older ones
 * arrive as the user scrolls up. The delicate part is the scroll anchor:
 * prepending content moves everything the user is reading DOWN by exactly the
 * height that was inserted, so scrollTop must be increased by the growth in
 * scrollHeight — measured across the mutation, in one synchronous block, so no
 * frame is painted in between.
 */

const TAIL_PAGE = 200;   // messages in the first (newest) page
const OLDER_PAGE = 120;  // messages per scroll-up page

function maybeLoadOlder() {
  const th = viewedThread();
  if (!th.page || th.page.done || th.page.loading) return;
  if (node.scroll.scrollTop > OLDER_TRIGGER_PX) return;
  return loadOlder(th);
}

/*
 * Backward paging on ONE coordinate system. `p.fetch(before, beforeBytes)` asks
 * the server for the page ending just before index `before`; `beforeBytes` is
 * the previous page's `cursorBytes`, which is what keeps this flat-cost on a
 * huge file (measured <=3 MiB/page across all 41 pages of the 286 MB session,
 * vs a tail that would re-read from the end every hop). The server's own
 * `offset`/`cursorBytes`/`hasMore` drive the walk; the client does no index
 * arithmetic, because there is nothing left to reconcile.
 */
/**
 * Backward-cursor state seeded from an opening tail response. `fetch(before,
 * beforeBytes)` is the route-specific request; everything else the server
 * reports on the first page. Shared by the main transcript and subagent threads
 * because both routes now answer with the same fields.
 */
function pageCursor(fetch, first) {
  return {
    fetch,
    oldest: first.offset,          // index of the oldest message now rendered
    cursorBytes: Number.isInteger(first.cursorBytes) ? first.cursorBytes : null,
    total: first.total,
    loading: false,
    done: first.hasMore === false || first.offset <= 0,
  };
}

async function loadOlder(th) {
  const p = th.page;
  if (!p || p.done || p.loading) return;
  p.loading = true;
  const note = el('div', { class: 'hint-row older', text: 'reading older messages\u2026' });
  prependNodes(th, [note]);
  try {
    const t = await p.fetch(p.oldest, p.cursorBytes);
    const msgs = t?.messages ?? [];
    // Anchor across BOTH mutations (note removed, page inserted) at once.
    withScrollAnchor(() => {
      note.remove();
      insertRendered(th, msgs, renderOlderInto);
    });
    applyHookBadges(th); // BUG-177 — badge any older turns a failed gate hit
    // The server says where we now are; trust its answer, do not recompute it.
    p.oldest = Number.isInteger(t?.offset) ? t.offset : 0;
    p.cursorBytes = Number.isInteger(t?.cursorBytes) ? t.cursorBytes : null;
    p.done = t?.hasMore === false || p.oldest <= 0 || !msgs.length;
    if (p.done) {
      withScrollAnchor(() => {
        prependNodes(th, [el('div', { class: 'hint-row older', text: 'beginning of this session' })], false);
      });
    }
  } catch (err) {
    withScrollAnchor(() => {
      note.textContent = `could not read older messages: ${err.message}`;
      note.classList.add('bad');
    });
    p.done = true; // stop hammering a route that is failing
  } finally {
    p.loading = false;
    paintJump();
  }
}

/**
 * Run a DOM mutation that changes content ABOVE the viewport and keep the
 * user's reading position pinned. Returns whatever `mutate` returns.
 */
function withScrollAnchor(mutate) {
  const s = node.scroll;
  const before = s.scrollHeight;
  const top = s.scrollTop;
  const out = mutate();
  s.scrollTop = top + (s.scrollHeight - before);
  viewedThread().scrollTop = s.scrollTop;
  return out;
}

/** Put nodes at the top of a pane, after the agent lede / session-config card. */
function prependNodes(th, nodes, anchor = true) {
  const put = () => {
    // FEAT-132 — the session-config card is a persistent header pinned to the
    // very top of the pane; older pages prepend BELOW it, never above. BUG-177 —
    // the hook-failure banner is a sibling header pinned there too; insert after
    // whichever pinned header sits LOWEST so pages never jump above either.
    const headers = th.paneEl.querySelectorAll(':scope > .hookfail, :scope > .sesscfg, :scope > .lede');
    const top = headers.length ? headers[headers.length - 1] : null;
    if (top) top.after(...nodes);
    else th.paneEl.prepend(...nodes);
  };
  if (anchor && th.paneEl.classList.contains('on')) withScrollAnchor(put);
  else put();
}

/**
 * renderMessages() only appends. To prepend a page, render it at the end with
 * the thread's live cursors parked, then move exactly the nodes it produced to
 * the front. Parking `claudeBody`/`stream` matters: without it an older page
 * would be poured into the CURRENT streaming message.
 */
function renderOlderInto(th, messages) {
  const savedBody = th.claudeBody;
  const savedStream = th.stream;
  th.claudeBody = null;
  th.stream = null;
  const mark = el('span', { class: 'mark' });
  th.paneEl.append(mark);
  const shown = renderMessages(th, messages);
  const moved = [];
  for (let n = mark.nextSibling; n; n = n.nextSibling) moved.push(n);
  mark.remove();
  th.claudeBody = savedBody;
  th.stream = savedStream;
  return { moved, shown };
}

function insertRendered(th, messages, render) {
  const { moved, shown } = render(th, messages);
  if (moved.length) prependNodes(th, moved, false);
  return shown;
}

/**
 * If the newest page is shorter than the viewport there is nothing to scroll,
 * so scroll-up can never fire and the rest of the session becomes unreachable.
 * Pull older pages until the scroller actually overflows.
 */
async function fillViewport(th) {
  for (let i = 0; i < 6; i++) {
    if (!th.page || th.page.done || th.page.loading) return;
    if (node.scroll.scrollHeight > node.scroll.clientHeight + OLDER_TRIGGER_PX) return;
    const before = th.page.oldest;
    await loadOlder(th);
    if (th.page.oldest === before) return; // made no progress — don't spin
    if (th.stick !== false && state.viewing === th.key) scrollToBottom(th);
  }
}

/* ------------------------------------------------ scroll <-> message index */
/*
 * Rendered content carries `data-i` markers — the absolute index (the one
 * coordinate system shared by ?tail/?offset/appends) of the stored message
 * that produced it. Two jobs only: naming the message at the top of the
 * viewport so the URL can remember it, and landing back on that message when
 * a URL carries `i`.
 */

/** Index of the message at the top of the viewport, or null when unknowable. */
function topVisibleIndex(th = viewedThread()) {
  const top = node.scroll.getBoundingClientRect().top;
  let last = null;
  for (const m of th.paneEl.querySelectorAll('[data-i]')) {
    if (m.getBoundingClientRect().bottom > top + 4) return Number(m.dataset.i);
    last = m;
  }
  return last ? Number(last.dataset.i) : null;
}

/**
 * Scroll so the message at absolute index `i` — or the nearest rendered one
 * before it — sits at the top of the viewport. Returns the marker landed on.
 */
function scrollToIndex(th, i) {
  let best = null;
  for (const m of th.paneEl.querySelectorAll('[data-i]')) {
    if (Number(m.dataset.i) <= i) best = m; // markers are in index order
    else break;
  }
  if (!best) return null;
  const s = node.scroll;
  s.scrollTop = Math.max(0, best.getBoundingClientRect().top - s.getBoundingClientRect().top + s.scrollTop - 10);
  th.stick = atBottom();
  th.scrollTop = s.scrollTop;
  th.unseen = false;
  paintJump();
  return best;
}

/** Make a search landing unmistakable, then quietly return it to normal. */
function highlightMessageAt(th, i) {
  if (!Number.isInteger(i)) return false;
  const marks = [...th.paneEl.querySelectorAll(`[data-i="${i}"]`)];
  if (!marks.length) return false;
  for (const m of marks) m.classList.add('search-landing');
  marks[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
  setTimeout(() => { for (const m of marks) m.classList.remove('search-landing'); }, 2800);
  return true;
}

/* --------------------------------------------------- forward gap (restore) */
/*
 * A session restored at a deep `i` renders a window AROUND that message, not
 * the end of the file. Everything newer than the window is a debt the view
 * owes the reader — `th.gap = {next, total}` records it, scrolling toward the
 * bottom pays it off page by page, and while any of it is outstanding the
 * composer is replaced by the #history bar and live appends are refused
 * (splicing an append after a window that is not the end would fabricate
 * adjacency). When the debt reaches zero the session hands back to the normal
 * machinery: live follow on, composer back, the pill back to meaning scroll.
 */

const NEWER_TRIGGER_PX = 600; // start fetching newer pages this far from the bottom

function maybeLoadNewer() {
  const th = viewedThread();
  if (th.key !== 'main' || !th.gap || th.gapLoading) return;
  const s = node.scroll;
  if (s.scrollHeight - s.scrollTop - s.clientHeight > NEWER_TRIGGER_PX) return;
  return loadNewer(th);
}

/*
 * Newer pages are fetched through the BACKWARD selector (`tail` ending just
 * before next+page) rather than ?offset: the forward scan stops at a 128 MiB
 * budget on huge files, the backward path reaches everything.
 */
async function loadNewer(th) {
  if (!th.gap || th.gapLoading) return;
  th.gapLoading = true;
  const { encodedDir, sessionId } = state.current;
  const note = el('div', { class: 'hint-row', text: 'reading newer messages…' });
  th.paneEl.append(note);
  try {
    const want = Math.max(1, Math.min(OLDER_PAGE, th.gap.total - th.gap.next));
    const t = await api.transcript(encodedDir, sessionId, { tail: want, before: th.gap.next + want });
    note.remove();
    // The window can overlap what is rendered when `before` was clamped.
    const fresh = (t.messages ?? []).filter((m) => Number.isInteger(m?.index) && m.index >= th.gap.next);
    finishStream(th);
    th.settledStream = null; // gap-fetched history supersedes the live node; no trailing 'text' re-renders it (BUG-169)
    th.claudeBody = null;
    renderMessages(th, fresh);
    const last = fresh[fresh.length - 1];
    if (!fresh.length || !Number.isInteger(last?.index)) {
      th.gap = null; // nothing newer actually exists — the window was the end
    } else {
      th.lastIndex = Math.max(th.lastIndex ?? -1, last.index);
      th.gap.total = Math.max(th.gap.total, Number.isInteger(t.total) ? t.total : 0);
      th.gap.next = last.index + 1;
      if (th.page && Number.isInteger(th.page.total)) th.page.total = th.gap.total;
      if (th.gap.next >= th.gap.total) th.gap = null;
    }
    if (!th.gap) {
      followCurrent();
      if (state.viewing === th.key) paintComposerFor(th);
      if (th.agentsPending) {
        th.agentsPending = false;
        void loadRecordedAgents(th, sessionId); // deferred from the restore — see openSession
      }
      say('caught up to the latest message');
    }
    paintJump();
  } catch (err) {
    note.textContent = `could not read newer messages: ${err.message}`;
    note.classList.add('bad');
    // th.gap stays set — scrolling retries rather than silently pretending
  } finally {
    th.gapLoading = false;
  }
}

/** What the pill promises while parked in history: "Latest" means the real end. */
function reopenAtLatest() {
  const p = currentProject();
  if (!p) return;
  const cur = state.current;
  const s = state.sessions.get(cur.projectId);
  const sess = s?.list?.find((x) => x.sessionId === cur.sessionId
    && (!cur.encodedDir || x.encodedDir === cur.encodedDir))
    // Deep link opened before the sidebar list loaded — rebuild the row from
    // what the open view already knows; openSession needs nothing more.
    ?? { sessionId: cur.sessionId, encodedDir: cur.encodedDir, os: cur.os, displayTitle: cur.title ?? '' };
  void openSession(p, sess);
}

/* --------------------------------------------------------- thread viewing */

function showThread(key) {
  if (!state.threads.has(key)) return;
  const prev = state.threads.get(state.viewing);
  if (prev && prev.key !== key) {
    // Capture where the outgoing thread was BEFORE the panes swap.
    prev.scrollTop = node.scroll.scrollTop;
    prev.stick = atBottom();
  }
  state.viewing = key;
  for (const th of state.threads.values()) th.paneEl.classList.toggle('on', th.key === key);
  const th = state.threads.get(key);
  // BUG-171: a tool lane is a read-only sub-thread like an agent, not the main
  // composer — anything but `main` renders in the sub-thread ('agent') layout.
  node.main.dataset.viewing = th.kind === 'main' ? 'main' : 'agent';
  paintCrumbs();
  paintComposerFor(th);
  renderStrip();
  restoreScroll(th);
  syncUrl('replace'); // thread switches move within one session — never a history entry
}

/**
 * Put a thread back where it was. A thread that has never been scrolled away
 * from the bottom (`stick !== false`) lands at the bottom — which is also the
 * first-open case for both main and a subagent.
 */
function restoreScroll(th) {
  const s = node.scroll;
  if (th.stick === false) {
    s.scrollTop = Math.max(0, Math.min(th.scrollTop ?? 0, s.scrollHeight - s.clientHeight));
  } else {
    s.scrollTop = s.scrollHeight;
    th.scrollTop = s.scrollTop;
  }
  paintJump();
}

/** Enter a subagent thread, fetching its recorded transcript if we have none. */
async function viewAgent(agentId) {
  let th = state.threads.get(agentId);
  if (!th) th = newThread(agentId, { kind: threadKindFor(agentId) });
  showThread(agentId);
  if (th.loaded || th.loading) return;
  // A live agent's messages arrive over the socket; only recorded ones fetch.
  if (!state.current.sessionId) { th.loaded = true; return; }
  th.loading = true;
  const wait = el('div', { class: 'hint-row', text: 'reading this agent’s transcript…' });
  th.paneEl.append(wait);
  const dir = state.current.encodedDir ?? undefined;
  try {
    const r = await api.subagentMessagesTail(state.current.sessionId, agentId, dir, { limit: TAIL_PAGE });
    wait.remove();
    if (r === null) {
      th.paneEl.append(el('div', { class: 'hint-row' },
        el('b', { text: 'Recorded agent transcripts are not available from this server yet.' }),
        document.createTextNode(' The summary above is everything this session stored for the agent.')));
    } else {
      const n = renderMessages(th, r.messages ?? []);
      if (!n) th.paneEl.append(el('div', { class: 'hint-row', text: 'This agent recorded no readable messages.' }));
      // A long agent pages backwards exactly like main does.
      th.page = pageCursor((before, beforeBytes) =>
        api.subagentMessages(state.current.sessionId, agentId, dir, { tail: OLDER_PAGE, before, beforeBytes }), r);
    }
    // The pane was empty when it was shown, so the land-at-bottom in
    // showThread had nothing to land on. Do it now that it has content.
    if (state.viewing === agentId) {
      scrollToBottom(th);
      await fillViewport(th);
    }
  } catch (err) {
    wait.remove();
    th.paneEl.append(el('div', { class: 'hint-row', text: `could not read this agent: ${err.message}` }));
  } finally {
    th.loading = false;
    th.loaded = true;
  }
}

function backToMain() {
  if (state.viewing === 'main') return false;
  showThread('main');
  return true;
}

/** `main › general-purpose · Build UI mockup artifact` */
function paintCrumbs() {
  const th = viewedThread();
  clear(node.title);
  if (th.kind === 'main') {
    node.title.append(document.createTextNode(state.current.title ?? (currentProject() ? 'New session' : 'Claude Station')));
    return;
  }
  const up = el('button', { class: 'up', text: 'main', title: 'Back to the main thread (Esc)' });
  up.addEventListener('click', backToMain);
  node.title.append(up, el('span', { class: 'caret', text: '›' }), el('span', { class: 'kind', text: th.agentType || 'agent' }));
  if (th.description) {
    node.title.append(el('span', { class: 'of', text: '·' }), el('span', { class: 'desc', text: th.description }));
  }
}

/**
 * Composer targeting.
 *
 * A subagent thread is READ-ONLY, running or not. This is a property of the
 * Agent SDK, not a gap in this server: nothing in the control protocol carries
 * a message to a task, so a "reply" typed here would be delivered to the MAIN
 * thread while the UI showed it inside the agent — the precise lie this app
 * exists to avoid. So we say plainly that you can watch but not steer.
 */
function paintComposerFor(th) {
  /*
   * BUG-149: the "another tab is driving this" banner is an ADDITION to
   * whatever else the composer area is showing, not one of the mutually
   * exclusive replacements below — the composer stays usable because the
   * session can become available again at any moment. Painted first (and
   * unconditionally) so no early return below can leave it stale on screen.
   */
  node.liveElsewhereText.textContent = '';
  if (state.liveElsewhere && th.kind === 'main') {
    // The server's messages are lowercase (they are written for the status
    // strip). Here the same words are a sentence following a bold lead, and
    // "Open in another tab. this session is…" reads as a typo — a screenshot
    // showed it before anything else did.
    const sentence = state.liveElsewhere.charAt(0).toUpperCase() + state.liveElsewhere.slice(1);
    node.liveElsewhereText.append(
      el('b', { text: 'Open in another tab.' }),
      document.createTextNode(` ${sentence}`));
    node.liveElsewhere.hidden = false;
  } else {
    node.liveElsewhere.hidden = true;
  }
  if (state.dropped) {
    node.box.hidden = true;
    node.frozen.hidden = true;
    node.agentDone.hidden = true;
    node.historyBar.hidden = true;
    node.budgetLocked.hidden = true;
    node.dropped.hidden = false;
    return;
  }
  node.dropped.hidden = true;
  // BUG-013: a budget stop outranks every other composer state on the main
  // thread — the session is still readable, but MUST NOT look sendable, and
  // must not silently un-lock just because the user switched threads or the
  // view re-painted. Only closeSocket()/a fresh connect() clears this.
  if (state.budgetLocked && th.kind === 'main') {
    node.agentDone.hidden = true;
    node.box.hidden = true;
    node.frozen.hidden = true;
    node.historyBar.hidden = true;
    node.budgetLockedText.textContent = '';
    node.budgetLockedText.append(
      el('b', { text: 'Budget limit reached.' }),
      document.createTextNode(` ${state.budgetLockReason || 'this session will not send any further turns.'}`));
    node.budgetLocked.hidden = false;
    return;
  }
  node.budgetLocked.hidden = true;
  // BUG-090: the same fork bar also stands in when the server refused a plain
  // resume because the session lives under a pre-isolation store dir — a
  // one-click fork recovers it (see armNeedsFork / paintFrozenBar).
  const frozenFork = !!state.pendingFork && !state.forkFrom;
  const frozenWin = state.current.os === 'windows' && !state.forkFrom;
  const frozen = frozenWin || frozenFork;
  if (th.kind === 'main') {
    node.agentDone.hidden = true;
    // Parked in history (restored at a deep index, newer messages unfetched):
    // the composer would visually attach a reply to the wrong place, so the
    // #history bar stands in until the gap is paid off or "latest" is taken.
    const gap = !!th.gap;
    node.box.hidden = frozen || gap;
    node.frozen.hidden = !frozen;
    node.historyBar.hidden = frozen || !gap;
    if (frozen) paintFrozenBar(frozenFork ? state.pendingFork : null);
    node.prompt.placeholder = 'Message Claude…';
    node.prompt.disabled = false;
    return;
  }
  node.frozen.hidden = true;
  node.historyBar.hidden = true;
  const running = th.status === 'running' && state.live;
  node.box.hidden = true;
  node.agentDone.hidden = false;
  clear(node.agentDoneText);
  if (running) {
    node.agentDoneText.append(
      el('b', { text: `${th.agentType || 'This agent'} is working.` }),
      document.createTextNode(' You can watch it here, but not steer it — a subagent takes no messages, so anything you wrote would reach the main thread instead. Reply on main to change course.'));
    if (th.unsupportedReason) node.agentDoneText.append(el('span', { class: 'u', text: th.unsupportedReason }));
  } else {
    node.agentDoneText.append(
      el('b', { text: `${th.agentType || 'This agent'} has finished` }),
      document.createTextNode(`${th.stats ? ` · ${th.stats}` : ''}. Its thread is read-only.`));
  }
}

/* ------------------------------------------------------- git crown chip */
/*
 * "Is my work safe?" at a glance: branch · dirty count · ahead/behind.
 * Fetched lazily with a short TTL; hidden entirely for non-repos (the drawer's
 * Git group still offers init/create there). Clicking opens that group.
 */

const GIT_TTL_MS = 15_000;

function paintGitChip() {
  const p = currentProject();
  if (!p) { node.gitBtn.hidden = true; return; }
  const g = state.git.get(p.id);
  if (!g || (Date.now() - g.at > GIT_TTL_MS && !g.loading)) { void refreshGit(p.id); }
  const s = g?.status;
  if (!s?.repo) { node.gitBtn.hidden = true; return; }
  // FEAT-139 r3 — the FACE carries only the CATEGORY (branch glyph), the STATE
  // (a shape-coded dot) and the one number the user reads (dirty count). The
  // branch name, +/− line totals and ahead/behind — everything that used to make
  // this a sentence — move to the tooltip (the full original sentence, below) and
  // to the Git panel this chip opens. The dot's state is carried by SHAPE + FILL
  // first, colour only as reinforcement, so it survives colour-blindness:
  //   clean   = hollow ring   (on a branch, nothing to commit)
  //   dirty   = filled disc   (on a branch, uncommitted work)
  //   conflict= filled diamond(mid-merge — a distinct silhouette, not just a hue)
  //   detached= hollow diamond(detached HEAD — the diamond family = unusual state)
  const conflicted = Number.isFinite(s.conflicted) && s.conflicted > 0;
  const detached = !s.branch;
  const dotState = conflicted ? 'conflict' : (detached ? 'detached' : (s.dirty ? 'dirty' : 'clean'));
  node.gitDot.dataset.state = dotState;
  // The single number: dirty count when there is dirt (clean shows none).
  node.gitN.textContent = s.dirty ? String(s.dirty) : '';
  // Full original sentence, on hover — nothing dropped, just relocated.
  const bits = [s.branch ? s.branch : `detached @ ${s.detachedAt ?? '?'}`];
  if (s.dirty) bits.push(`${s.dirty} dirty`);
  if (conflicted) bits.push(`${s.conflicted} conflict${s.conflicted === 1 ? '' : 's'}`);
  const added = Number.isFinite(s.added), removed = Number.isFinite(s.removed);
  const showLineCounts = !(added && removed && s.added === 0 && s.removed === 0);
  if (showLineCounts && added) bits.push(`+${s.added}`);
  if (showLineCounts && removed) bits.push(`−${s.removed}`);
  if (s.untrackedLinesIncluded === false && showLineCounts && (added || removed)) bits.push('(tracked only)');
  if (Number.isFinite(s.ahead) && s.ahead > 0) bits.push(`↑${s.ahead}`);
  if (Number.isFinite(s.behind) && s.behind > 0) bits.push(`↓${s.behind}`);
  const sentence = `⎇ ${bits.join(' · ')}`;
  node.gitBtn.title = `${sentence}\n${s.lastCommit ?? ''}${s.upstream ? ` · tracking ${s.upstream}` : ' · no upstream'}\nOpen the Git panel`;
  node.gitBtn.setAttribute('aria-label', `Git — ${bits.join(', ')}. Open the Git panel.`);
  node.gitBtn.hidden = false;
}

async function refreshGit(projectId) {
  const cur = state.git.get(projectId);
  if (cur?.loading) return;
  const rec = { status: cur?.status ?? null, at: Date.now(), loading: true };
  state.git.set(projectId, rec);
  try {
    rec.status = await api.gitStatus(projectId);
  } catch { /* transient — chip keeps its last honest answer */ }
  rec.loading = false;
  rec.at = Date.now();
  if (state.current.projectId === projectId) paintGitChip();
}

// FEAT-099: the chip used to deep-link to Advanced ▸ Git in the drawer. It now
// routes to the working-tree view — per-file staging and diffs — for the
// project the chip names, so browser Back returns to the full session route.
node.gitBtn.addEventListener('click', () => navGit(currentProject()?.id));

/** Crown chip: the CURRENT project's running processes, at a glance. */
function paintProcChip() {
  const p = currentProject();
  const s = p ? state.procSummary?.[p.id] : null;
  if (!p || !s || !s.count) { node.procBtn.hidden = true; if (node.procPop.classList.contains('open')) closePops(); return; }
  // BUG-082 kept the port list capped inline (first few ports + "+N", full list
  // in #procPop). FEAT-139 — the strip face is a LIVE READOUT, not a reference dump. The old
  // face inlined ":4317 :34699 :36735 +3 · 90 procs" — a port list and a proc
  // count that answer "what does the user do in the next 30 seconds?" with
  // "nothing". Both are session-constant reference material, so the face now
  // carries only a compact running indicator (how many ports are listening, or
  // the proc count when nothing listens) and the full port list + counts live
  // in the popover this chip opens (paintProcPop) and its tooltip. This is the
  // same BUG-082 invariant — the face must not dump ports — taken to its end.
  const ports = orderedPorts(s.ports);
  // FEAT-139 r3 — the activity glyph carries the category, the face carries only
  // the single count. The unit (listening ports vs background procs) and the full
  // port list live in the tooltip + the popover this chip opens.
  const n = ports.length || s.count;
  const unit = ports.length ? `listening port${ports.length === 1 ? '' : 's'}` : `process${s.count === 1 ? '' : 'es'}`;
  node.procN.textContent = String(n);
  node.procBtn.title = procChipTitle(p);
  node.procBtn.setAttribute('aria-label', `${n} ${unit} running here — open the list`);
  node.procBtn.hidden = false;
  // Keep an open popover honest with the latest poll.
  if (node.procPop.classList.contains('open')) paintProcPop();
}

/**
 * BUG-082: the FULL port list, in the shared chip-popover chrome (FEAT-051 /
 * place()/closePops()). Every listening port, in the same stable :4317-first
 * order as the inline preview; a footer that jumps to the drawer's Running-here
 * list where a port can actually be acted on.
 */
function paintProcPop() {
  const p = currentProject();
  const s = p ? state.procSummary?.[p.id] : null;
  clear(node.procPorts);
  if (!s || !s.count) return;
  const ports = orderedPorts(s.ports);
  if (ports.length) {
    for (const x of ports) {
      const row = el('div', { class: 'proc-port' });
      row.append(el('span', { class: 'pn', text: `:${x}` }));
      if (x === STATION_PORT) row.append(el('span', { class: 'pt', text: 'station' }));
      node.procPorts.append(row);
    }
  } else {
    node.procPorts.append(el('div', { class: 'grp-note', text: 'No listening ports — background processes only.' }));
  }
}

node.procBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  if (node.procPop.classList.contains('open')) return closePops();
  closePops();
  paintProcPop();
  place(node.procPop, node.procBtn, 200);
  node.procPop.classList.add('open');
  node.procBtn.setAttribute('aria-expanded', 'true');
});
// FEAT-054: land on Advanced ▸ Running here, not the drawer's default top.
$('#procPopSettings').addEventListener('click', () => { closePops(); void drawer.open('settings', { focus: 'processes' }); });

/* ------------------------------------------------------------- rendering */

/**
 * Claude Code writes slash commands and their output into the log as XML-ish
 * wrappers. They are machinery, not conversation — a mono caption, not a bubble.
 */
const CMD_WRAPPER = /^\s*<(command-name|command-message|command-args|local-command-stdout|local-command-stderr)>/;

function commandCaption(text) {
  if (!CMD_WRAPPER.test(text)) return null;
  const name = /<command-name>([\s\S]*?)<\/command-name>/.exec(text)?.[1]?.trim();
  const args = /<command-args>([\s\S]*?)<\/command-args>/.exec(text)?.[1]?.trim();
  if (name) return el('div', { class: 'ran-lbl', text: `${name.startsWith('/') ? name : `/${name}`}${args ? ` ${args}` : ''}` });
  const out = /<local-command-(?:stdout|stderr)>([\s\S]*?)<\/local-command-(?:stdout|stderr)>/.exec(text)?.[1]?.trim() ?? text;
  const flat = out.replace(/\x1b?\[[0-9;]*m/g, '').replace(/\s+/g, ' ').trim();
  if (!flat) return el('div', { class: 'ran-lbl', text: '(command produced no output)' });
  return el('div', { class: 'ran-lbl', text: flat.length > 140 ? `${flat.slice(0, 140)}…` : flat });
}

/**
 * BUG-028 — honest attribution for a shutdown-cut turn. The Claude CLI writes
 * the literal "[Request interrupted by user]" (or "…for tool use]") into the
 * transcript BOTH for a real user stop AND when the CLI itself was shut down
 * mid-turn (a server restart/redeploy — the FEAT-015 event class). The entry
 * itself says which: a real user stop carries `interruptedMessageId`; a
 * shutdown-cut entry carries `interruptedByShutdown: true` (verified against
 * live transcripts — 181 user-stop vs 45 shutdown entries, zero overlap; the
 * server passes the flag through in TranscriptMessage). Rendering the shutdown
 * case as a USER bubble asserts a false cause — the user did nothing. It gets
 * a system caption naming the real cause instead; a genuine user stop (no
 * flag) still renders as the user's own bubble, so the honest case is intact.
 */
const INTERRUPT_MARKER_RX = /^\s*\[Request interrupted by user( for tool use)?\]\s*$/;
const SHUTDOWN_BREAK_TEXT = '[Turn interrupted — the server restarted or shut down mid-turn, not a user stop; the thread resumed from its saved transcript]';
function shutdownBreakCaption(m, text) {
  if (m.interruptedByShutdown !== true || !INTERRUPT_MARKER_RX.test(text)) return null;
  return el('div', { class: 'ran-lbl shutdown-break', text: SHUTDOWN_BREAK_TEXT });
}

/*
 * BUG-067 — harness-injected user-role lines are NOT the user's words. When a
 * background agent finishes, the "[station] While you were away…" briefing
 * fires (FEAT-057), or a <system-reminder>/<task-notification> is injected, the
 * CLI writes it into the transcript as a role:user entry. Rendering that as a
 * user bubble puts a wall of XML in the user's mouth (the reported symptom).
 *
 * We recognise these by their KNOWN sentinels, matched ONLY at position 0 of
 * the left-trimmed text — so a real user message that merely QUOTES
 * "<task-notification>" (or any sentinel) mid-sentence never matches and keeps
 * its bubble. Leading whitespace is tolerated (the CLI sometimes prefixes a
 * newline) because that does not change authorship; anything before the
 * sentinel means a human wrote around it, which is a real message.
 */
const HARNESS_SENTINELS = [
  '[SYSTEM NOTIFICATION - NOT USER INPUT]',
  '<task-notification>',
  '<system-reminder>',
  '[station]',
];

/*
 * BUG-168 — the server (#withBriefing, src/server/agent-bridge.ts) PREPENDS a
 * "[station] While you were away…" briefing (and, on the first turn, the board
 * snapshot) to the user's typed prompt and the CLI writes ONE role:user entry:
 * injected text first, human's words last. Without a boundary the whole entry was
 * swallowed into the collapsed notice chip and the human's own sentence vanished
 * on any re-read. The server now terminates the injected prefix with this exact
 * sentinel; we split on it, collapse the prefix into the chip, and render the
 * REMAINDER as the normal user bubble (the FEAT-072 queuedCaption peel pattern).
 * Keep this literal byte-identical with the server's BRIEFING_TERMINATOR (the two
 * cannot share a module — the client is a browser file).
 */
const BRIEFING_TERMINATOR = '⟦STATION-BRIEFING-END⟧';
/* The known tail line of BOTH briefing kinds (takeBriefing + boardAnswerBriefing),
 * used only to split LEGACY entries written before the terminator existed. */
const LEGACY_BRIEF_TAIL = '[station] This is a server-recorded fact';
/* The first-turn board snapshot (FEAT-113) head + the `---` rule the server joins
 * it to the user's prompt with — the legacy first-turn boundary. */
const BOARD_SNAPSHOT_HEAD = '# Project state (live board snapshot)';
const BOARD_SNAPSHOT_SEP = '\n\n---\n\n';

/**
 * LEGACY split: entries written before BRIEFING_TERMINATOR existed carry no
 * boundary marker, so recover the user's words heuristically from the KNOWN
 * briefing shape. Returns { prefix, body } when the boundary is found CONFIDENTLY,
 * or null to fall back to collapsing the whole entry (never guess a boundary and
 * risk rendering briefing text as the user's words). `t` is left-trimmed.
 */
function legacyBriefingSplit(t) {
  const tailStart = t.lastIndexOf(LEGACY_BRIEF_TAIL);
  if (tailStart < 0) return null; // not a [station] briefing (e.g. a bare notification) → collapse whole
  const nl = t.indexOf('\n', tailStart);
  const afterTail = nl < 0 ? t.length : nl; // through the end of the tail line
  const rest = t.slice(afterTail).replace(/^\s+/, '');
  if (!rest) return { prefix: t.slice(0, afterTail), body: '' }; // pure briefing, no user words
  if (rest.startsWith(BOARD_SNAPSHOT_HEAD)) {
    // First-turn: a board snapshot sits between the briefing and the user's words,
    // joined by the `---` rule. The board snapshot itself contains no `---`, so the
    // FIRST separator after the snapshot head is the true boundary.
    const sepInRest = rest.indexOf(BOARD_SNAPSHOT_SEP);
    if (sepInRest < 0) return null; // board snapshot but no separator → can't split confidently
    const body = rest.slice(sepInRest + BOARD_SNAPSHOT_SEP.length).replace(/^\s+/, '');
    if (!body) return null; // separator but nothing after it → don't guess
    // Prefix = everything before the user's words (briefing tail + board snapshot).
    const boundary = t.length - (rest.length - sepInRest);
    return { prefix: t.slice(0, boundary).replace(/\s+$/, ''), body };
  }
  // Follow-up turn: the user's words follow the briefing tail directly.
  return { prefix: t.slice(0, afterTail), body: rest };
}

/**
 * Detect a harness notice. Returns { one, full, body } or null for a real message.
 * `body` (BUG-168) is the user's own words peeled off the injected prefix — empty
 * when the entry is a pure briefing with no user prompt.
 */
function harnessNotice(text) {
  if (typeof text !== 'string') return null;
  const t = text.replace(/^\s+/, '');
  if (!HARNESS_SENTINELS.some((s) => t.startsWith(s))) return null;
  // New format: the injected prefix is terminated by an explicit sentinel; peel it.
  const term = t.indexOf(BRIEFING_TERMINATOR);
  if (term >= 0) {
    const prefix = t.slice(0, term).replace(/\s+$/, '');
    const body = t.slice(term + BRIEFING_TERMINATOR.length).replace(/^\s+/, '');
    return { one: harnessOneLiner(prefix), full: prefix, body };
  }
  // Legacy entry (pre-terminator): recover the user's words heuristically, or
  // collapse the whole entry when the boundary is not confidently found.
  const split = legacyBriefingSplit(t);
  if (split) return { one: harnessOneLiner(split.prefix), full: split.prefix, body: split.body };
  return { one: harnessOneLiner(t), full: text, body: '' };
}

/** Best-effort one-liner for the collapsed notice; parses task-notification. */
function harnessOneLiner(t) {
  // A task-notification block (often wrapped by the SYSTEM NOTIFICATION
  // preamble) carries the interesting fields — surface summary/status when
  // present, falling back to description/id, so the collapsed row is readable.
  if (t.includes('<task-notification>')) {
    const tag = (n) => new RegExp(`<${n}>([\\s\\S]*?)</${n}>`).exec(t)?.[1]?.replace(/\s+/g, ' ').trim();
    const what = tag('summary') || tag('description') || tag('agent-name') || tag('agentType');
    const status = tag('status');
    const id = tag('task-id') || tag('agent-id');
    const label = what || (id ? `task ${id}` : 'a background agent');
    return `⚙ background agent finished — ${label}${status ? ` (${status})` : ''}`;
  }
  if (t.startsWith('[station]')) {
    const first = t.split('\n')[0].replace(/^\[station\]\s*/, '').trim();
    return `⚙ ${first || 'station briefing'}`;
  }
  if (t.startsWith('<system-reminder>')) return '⚙ system reminder';
  return '⚙ system notification';
}

/**
 * The collapsed station-style notice: a distinct, non-bubble row whose summary
 * is the one-liner and whose disclosure reveals the full injected payload. Like
 * youBubble/captions it is a user-side turn boundary, so it closes any open
 * Claude body/stream.
 */
function noticeChip(th, notice) {
  th.paneEl.querySelector(':scope > .waiting')?.remove();
  const det = el('details', { class: 'notice' });
  det.append(el('summary', {},
    el('span', { class: 'tw', text: '▶' }),
    el('span', { class: 'nl', text: notice.one })));
  det.append(el('pre', { class: 'notice-full', text: notice.full }));
  th.paneEl.append(det);
  th.claudeBody = null;
  th.stream = null;
  return det;
}

/*
 * FEAT-132 — the "Session configuration" card, pinned above the first turn of a
 * transcript. It shows what was actually injected into this session's context at
 * launch (the four composed docs, the board snapshot, MCP servers, model, tools)
 * — facts the JSONL never carries, so a reader otherwise cannot see them. The
 * server owns and persists the record (session-config.ts); this only renders it.
 *
 * Collapsed by default. Each source is a chip; clicking one expands its injected
 * body inline. A TRUNCATED (BUG-146) or MISSING doc is marked visibly — exposing
 * silent truncation is the whole reason the card exists. A session with no record
 * (it predates the feature) gets a clearly-labelled partial card, never one that
 * implies full knowledge.
 */
const SC_STATUS_LABEL = { truncated: 'truncated', missing: 'missing', superseded: 'superseded', 'best-effort': '?' };

/*
 * BUG-177 — a quality gate (a Claude Code hook) can fail on EVERY turn and the
 * transcript records it as a `hook_non_blocking_error` attachment, but Orchard
 * used to filter that line out and show nothing. A gate whose failure is
 * invisible is worse than no gate. The server rolls the failures up over the
 * whole session (transcript.ts) and hands them here as `data.hookErrors`.
 *
 * Two things get rendered from it:
 *  - a once-per-session BANNER (this) stating the hook, the error, whether it
 *    ever ran, and how many turns it hit — one banner beats 21 identical badges;
 *  - a small per-turn BADGE (applyHookBadges) on the turn each failure sits on,
 *    so scrolling to a turn shows its gate silently failed there too.
 *
 * The dangerous case is a hook that never RAN (kind:'crash' — module missing,
 * non-zero exit at launch): it manufactures the confidence it was meant to earn.
 * That case is coloured as an error; a hook that ran and merely reported
 * something is a warning.
 */
function hookBannerSeverity(he) {
  return he.crashRecords > 0 ? 'crash' : 'reported';
}

function mountHookErrorBanner(th, hookErrors, scope) {
  const he = hookErrors;
  if (!he || !(he.totalRecords > 0)) return; // healthy session — render nothing
  if (scope != null && scope !== state.txScope) return;
  if (th.paneEl.querySelector(':scope > .hookfail')) return;

  th.hookErrors = he; // kept so later-paged turns can still be badged

  const sev = hookBannerSeverity(he);
  const groups = Array.isArray(he.groups) ? he.groups : [];
  const crashNames = [...new Set(groups.filter((g) => g.kind === 'crash').map((g) => g.hookName).filter(Boolean))];

  const card = el('section', { class: 'hookfail', 'data-sev': sev, 'data-open': 'false', role: 'alert' });

  const headline = sev === 'crash'
    ? 'A quality-check step never ran'
    : 'A quality-check step reported a problem';
  let sub;
  if (sev === 'crash') {
    const t = he.crashRecords;
    sub = `${crashNames.join(', ') || 'A hook'} failed to start on ${t} turn${t === 1 ? '' : 's'} — the check has been silently skipped.`;
    if (he.reportedRecords > 0) sub += ` (+${he.reportedRecords} other hook warning${he.reportedRecords === 1 ? '' : 's'}.)`;
  } else {
    const t = he.reportedRecords;
    sub = `Reported on ${t} turn${t === 1 ? '' : 's'}.`;
  }

  const tw = el('span', { class: 'tw', text: '▶' });
  const head = el('button', { class: 'hf-head', 'aria-expanded': 'false', type: 'button' },
    tw,
    el('span', { class: 'hf-ico', 'aria-hidden': 'true', text: sev === 'crash' ? '⛔' : '⚠' }),
    el('span', { class: 'hf-title', text: headline }),
    el('span', { class: 'hf-sub', text: sub }));

  const body = el('div', { class: 'hf-body', hidden: true });
  for (const g of groups.slice(0, 20)) {
    const kindLbl = g.kind === 'crash' ? 'never ran' : 'reported';
    const row = el('div', { class: 'hf-grp', 'data-kind': g.kind },
      el('div', { class: 'hf-grp-head' },
        el('span', { class: 'hf-hook', text: g.hookName || 'hook' }),
        g.hookEvent ? el('span', { class: 'hf-evt', text: g.hookEvent }) : null,
        el('span', { class: 'hf-kind', text: kindLbl }),
        el('span', { class: 'hf-count', text: `${g.count} turn${g.count === 1 ? '' : 's'}` })),
      el('pre', { class: 'hf-msg', text: g.message || '(no message)' }));
    body.append(row);
  }
  if (groups.length > 20) body.append(el('div', { class: 'hf-more', text: `…and ${groups.length - 20} more` }));
  if (he.recordsCapped) body.append(el('div', { class: 'hf-note', text: 'Turn badges are shown for the first occurrences only.' }));

  head.addEventListener('click', () => {
    const open = card.getAttribute('data-open') === 'true';
    card.setAttribute('data-open', open ? 'false' : 'true');
    head.setAttribute('aria-expanded', open ? 'false' : 'true');
    body.hidden = open;
    tw.textContent = open ? '▶' : '▼';
  });

  card.append(head, body);
  th.paneEl.prepend(card);
}

/*
 * Best-effort per-turn badge: for each failure occurrence whose owning message
 * (its parentUuid) is currently in the pane, tag that turn. Idempotent — safe to
 * re-run after each page render; a turn already badged is skipped. Turns not yet
 * paged in simply get no badge; the session banner carries the whole truth.
 */
function applyHookBadges(th) {
  const he = th && th.hookErrors;
  if (!he || !Array.isArray(he.records) || !he.records.length) return;
  // Worst kind per parent uuid: a crash outranks a report.
  const byParent = new Map();
  for (const r of he.records) {
    if (!r || typeof r.parentUuid !== 'string' || !r.parentUuid) continue;
    const prev = byParent.get(r.parentUuid);
    if (!prev || (prev.kind !== 'crash' && r.kind === 'crash')) byParent.set(r.parentUuid, r);
  }
  if (!byParent.size) return;
  for (const [uuid, r] of byParent) {
    const nodes = th.paneEl.querySelectorAll(`[data-uuid="${cssEscape(uuid)}"]`);
    if (!nodes.length) continue;
    const node = nodes[nodes.length - 1]; // the last block of that turn
    if (node.querySelector(':scope > .hook-turn-badge')) continue;
    const label = r.kind === 'crash' ? 'gate skipped' : 'gate warning';
    node.append(el('span', {
      class: 'hook-turn-badge',
      'data-kind': r.kind,
      title: `${r.hookName}${r.hookEvent ? ' (' + r.hookEvent + ')' : ''}: ${r.message}`,
      text: label,
    }));
  }
}

/** Minimal CSS.escape fallback for attribute selectors (uuids are safe hex). */
function cssEscape(s) {
  if (typeof window !== 'undefined' && window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(s);
  return String(s).replace(/["\\\]]/g, '\\$&');
}

async function mountSessionConfigCard(th, sess, scope) {
  let rec = null;
  try { rec = await api.sessionConfig(sess.sessionId); } catch { rec = null; }
  // Dropped if the user navigated away while the fetch was in flight (same guard
  // the transcript paint uses), or if the pane already carries a card.
  if (scope != null && scope !== state.txScope) return;
  if (th.paneEl.querySelector(':scope > .sesscfg')) return;

  const card = el('section', { class: 'sesscfg', 'data-open': 'false' });
  const tw = el('span', { class: 'tw', text: '▶' });
  const title = el('span', { class: 'sc-title', text: 'Session configuration' });

  if (!rec) {
    // Partial card — no record. Honest about WHY, never implies full knowledge.
    const head = el('button', { class: 'sc-head', 'aria-expanded': 'false', type: 'button' },
      tw, title,
      el('span', { class: 'sc-sub', text: 'not recorded' }));
    const body = el('div', { class: 'sc-body', hidden: true },
      el('p', { class: 'sc-note', text:
        'Orchard has no configuration record for this session. It was launched before this feature existed (or by a server that does not record it), so what was injected into its context cannot be shown here.' }));
    head.addEventListener('click', () => toggleSessCfg(card, head, body));
    card.append(head, body);
    th.paneEl.prepend(card);
    return;
  }

  const warned = rec.sources.filter((s) => s.status === 'truncated' || s.status === 'missing').length;
  const sub = [rec.model || null, `${rec.sources.length} source${rec.sources.length === 1 ? '' : 's'}`]
    .filter(Boolean).join(' · ');
  const head = el('button', { class: 'sc-head', 'aria-expanded': 'false', type: 'button' },
    tw, title,
    el('span', { class: 'sc-sub', text: sub }),
    warned ? el('span', { class: 'sc-warn', title: `${warned} source(s) truncated or missing`, text: `⚠ ${warned}` }) : null);

  const body = el('div', { class: 'sc-body', hidden: true });
  // Meta line: the facts that are single values, not sources.
  const metaBits = [
    rec.model ? `model ${rec.model}` : null,
    rec.provider ? `provider ${rec.provider}` : null,
    rec.isolation ? `isolation ${rec.isolation}` : null,
    `prompt ${rec.mode}`,
  ].filter(Boolean);
  body.append(el('div', { class: 'sc-meta', text: metaBits.join('  ·  ') }));

  const chips = el('div', { class: 'sc-chips' });
  const detail = el('pre', { class: 'sc-src', hidden: true });
  let openChip = null;

  const show = (chip, src) => {
    if (openChip === chip) { // toggle off
      detail.hidden = true; chip.setAttribute('aria-expanded', 'false'); openChip = null; return;
    }
    if (openChip) openChip.setAttribute('aria-expanded', 'false');
    openChip = chip; chip.setAttribute('aria-expanded', 'true');
    if (src.body && src.body.trim()) {
      detail.textContent = src.body;
    } else if (src.note) {
      detail.textContent = src.note;
    } else if (src.status === 'missing') {
      detail.textContent = `${src.label}: referenced but could not be read at launch — nothing was injected for it.`;
    } else {
      detail.textContent = `${src.label}: no recorded body.`;
    }
    detail.hidden = false;
  };

  // The composed/persisted sources, plus a synthetic "Tools" chip from the real
  // attached tool list the CLI reported.
  const allSources = [...rec.sources];
  if (Array.isArray(rec.tools) && rec.tools.length) {
    allSources.push({ id: 'tools', label: 'Tools', status: 'applied', chars: rec.tools.length,
      body: rec.tools.join('\n'), note: `${rec.tools.length} tools` });
  }

  for (const src of allSources) {
    const badge = SC_STATUS_LABEL[src.status];
    const chip = el('button', { class: 'sc-chip', type: 'button', 'data-status': src.status, 'aria-expanded': 'false' },
      el('span', { class: 'sc-lbl', text: src.label }),
      src.status === 'truncated' && src.droppedChars != null
        ? el('span', { class: 'sc-bad', text: `truncated −${kilo(src.droppedChars)}` })
        : badge ? el('span', { class: 'sc-bad', text: badge }) : null);
    chip.addEventListener('click', () => show(chip, src));
    chips.append(chip);
  }
  body.append(chips, detail);
  head.addEventListener('click', () => toggleSessCfg(card, head, body));
  card.append(head, body);
  th.paneEl.prepend(card);
}

function toggleSessCfg(card, head, body) {
  const open = card.getAttribute('data-open') === 'true';
  card.setAttribute('data-open', open ? 'false' : 'true');
  head.setAttribute('aria-expanded', open ? 'false' : 'true');
  body.hidden = open;
  const tw = head.querySelector('.tw');
  if (tw) tw.textContent = open ? '▶' : '▼';
}

/*
 * FEAT-072 — a queued/batch-delivered user message arrives with a bracketed
 * harness metadata prefix at position 0, always in one of a few fixed shapes:
 *   [msg N/M · queued 1m46s ago, composed while the previous response was still being written]
 *   [Queued Ns ago, composed while the previous response was still being written — it predates…]
 * The bracket is boilerplate the eye has to skip every time to find the real
 * words. This is a SIBLING of BUG-067's harnessNotice: that path replaces the
 * whole bubble for a fully-injected line; here the line is a REAL user message
 * that merely wears a metadata hat, so we peel the hat off into a dim caption
 * and keep the user's actual words in a normal bubble below.
 *
 * Conservative by construction: only a bracket at position 0 (leading
 * whitespace tolerated) whose INNER content matches the known queued-metadata
 * phrasing — the strong, always-present "composed while the previous response",
 * or a "queued … ago" pair. A real message that merely opens with "[" (a
 * markdown link, a code snippet, "[queued for review]") never matches, because
 * none of those carry that phrasing.
 */
const QUEUED_META_RX = /composed while the previous response|queued\b[^\]]*\bago\b/i;
function queuedCaption(text) {
  if (typeof text !== 'string') return null;
  const m = /^\s*\[([^\]]{1,400})\]/.exec(text);
  if (!m) return null;
  if (!QUEUED_META_RX.test(m[1])) return null;
  const body = text.slice(m[0].length).replace(/^\s+/, '');
  return { caption: m[1].trim(), body };
}

/**
 * The dim queued-metadata caption: a small, right-aligned mono line that sits
 * directly above the user's bubble (they share the message index), reading as a
 * quiet timestamp the eye skips rather than as part of the message. Like
 * youBubble it is a user-side turn boundary, so it closes any open Claude body.
 */
function queuedCap(th, capText) {
  th.paneEl.querySelector(':scope > .waiting')?.remove();
  const c = el('div', { class: 'qmeta' }, el('span', { class: 'qmeta-txt', text: capText }));
  th.paneEl.append(c);
  th.claudeBody = null;
  th.stream = null;
  return c;
}

/** A collapsed hairline chip for a stored tool call or thinking block. */
function historyChip(th, name, arg, res, body, input = null) {
  const chip = el('details', { class: 'tool' });
  chip.append(el('summary', {},
    el('span', { class: 'tw', text: '▶' }),
    el('span', { class: 'nm', text: name }),
    el('span', { class: 'arg', text: arg }),
    el('span', { class: 'res', text: res })));
  const out = el('div', { class: 'out' });
  const diff = diffElementFor(name, input);
  if (diff) out.append(diff);
  else out.append(el('pre', { text: body }));
  chip.append(out);
  toolsGroup(th).append(chip);
  return chip;
}

/* ------------------------------------------------------------ edit diffs */
/*
 * Edit/Write chips expand into the CHANGE, not the raw JSON envelope — the
 * envelope buries the one thing worth reading (what changed) in escaping.
 * Palette rule holds for transcript diffs. Git surfaces explicitly use the
 * existing semantic done/high tokens for conventional green/red scanability.
 */

const DIFF_MAX_LINES = 400;

/** Trim lines common to both ends so only the changed middle renders. */
function trimmedDiff(oldStr, newStr) {
  const a = String(oldStr ?? '').split('\n');
  const b = String(newStr ?? '').split('\n');
  let pre = 0;
  while (pre < a.length && pre < b.length && a[pre] === b[pre]) pre++;
  let post = 0;
  while (post < a.length - pre && post < b.length - pre && a[a.length - 1 - post] === b[b.length - 1 - post]) post++;
  return { del: a.slice(pre, a.length - post), add: b.slice(pre, b.length - post), context: pre + post };
}

function diffLines(box, lines, cls, sign) {
  for (const l of lines.slice(0, DIFF_MAX_LINES)) {
    box.append(el('div', { class: `dl ${cls}` }, el('span', { class: 'sg', text: sign }), document.createTextNode(l || ' ')));
  }
  if (lines.length > DIFF_MAX_LINES) {
    box.append(el('div', { class: 'dl more', text: `… ${lines.length - DIFF_MAX_LINES} more line${lines.length - DIFF_MAX_LINES === 1 ? '' : 's'}` }));
  }
}

/** A rendered change for Edit/MultiEdit/Write inputs, or null to keep raw JSON. */
function diffElementFor(name, input) {
  if (!input || typeof input !== 'object') return null;
  const box = el('div', { class: 'diff' });
  const one = (o) => {
    if (typeof o?.old_string !== 'string' || typeof o?.new_string !== 'string') return false;
    const d = trimmedDiff(o.old_string, o.new_string);
    diffLines(box, d.del, 'del', '-');
    diffLines(box, d.add, 'add', '+');
    if (o.replace_all) box.append(el('div', { class: 'dl more', text: 'applied to every occurrence (replace_all)' }));
    return true;
  };
  if (name === 'Edit') {
    if (!one(input)) return null;
  } else if (name === 'MultiEdit' && Array.isArray(input.edits)) {
    let any = false;
    input.edits.forEach((e, i) => {
      if (i) box.append(el('div', { class: 'dl more', text: `— edit ${i + 1} —` }));
      any = one(e) || any;
    });
    if (!any) return null;
  } else if ((name === 'Write' || name === 'NotebookEdit') && typeof input.content === 'string') {
    diffLines(box, String(input.content).split('\n'), 'add', '+');
  } else if (name === 'Write' && typeof input.new_source === 'string') {
    diffLines(box, String(input.new_source).split('\n'), 'add', '+');
  } else {
    return null;
  }
  return box;
}

/**
 * Render stored messages into a thread. Blocks are emitted in their recorded
 * order so prose and tool chips interleave the way they actually happened.
 * Used for both the main transcript and a recorded subagent thread — the
 * contract says the shapes are identical, so this renderer is shared.
 */
function renderMessages(th, messages) {
  let shown = 0;
  for (const m of messages) {
    const useful = (m.blocks ?? []).filter(
      (b) => (b.type === 'text' && b.text?.trim()) || b.type === 'tool_use' || (b.type === 'thinking' && b.text?.trim()),
    );
    if (!useful.length) continue;
    shown++;
    // Marker for the scroll<->index mapping: the element(s) this stored message
    // produced carry its absolute index, so the URL can name — and later land
    // on — "the message at the top of the viewport".
    const mark = (n) => {
      if (n && Number.isInteger(m.index)) n.dataset.i = String(m.index);
      // FEAT-126 Step 4 — stamp the server-generated message uuid so a request's
      // declared `source` can deep-link to the exact message that opened it.
      if (n && typeof m.uuid === 'string' && m.uuid) n.dataset.uuid = m.uuid;
      return n;
    };
    if (m.role === 'user') {
      for (const b of useful) {
        if (b.type !== 'text') continue;
        // BUG-028: a shutdown-cut interrupt marker is NOT the user's message —
        // caption it with its real cause instead of putting words (a stop) in
        // the user's mouth. Checked before commandCaption; both return captions.
        const cap = shutdownBreakCaption(m, b.text) ?? commandCaption(b.text);
        if (cap) { th.paneEl.append(mark(cap)); th.claudeBody = null; }
        else {
          // BUG-067: harness-injected notices (task-notification / [station] /
          // <system-reminder> / SYSTEM NOTIFICATION) are not the user's words —
          // render a collapsed system notice, not a user bubble.
          // BUG-168: when the notice PREFIXES a real user message (a "[station]"
          // briefing prepended to the human's typed prompt), peel the prefix into
          // the chip and render the user's own words (notice.body) as their bubble.
          // An empty body (pure briefing, no user prompt) stays chip-only.
          const notice = harnessNotice(b.text);
          if (notice) {
            mark(noticeChip(th, notice));
            if (notice.body) stampTime(mark(youBubble(th, notice.body)), m.timestamp);
          }
          else {
            // FEAT-072: a real user message wearing a queued-metadata prefix —
            // peel the prefix into a dim caption, keep the words in the bubble.
            const q = queuedCaption(b.text);
            if (q) {
              mark(queuedCap(th, q.caption));
              if (q.body) stampTime(mark(youBubble(th, q.body)), m.timestamp);
            } else {
              stampTime(mark(youBubble(th, b.text)), m.timestamp);
            }
          }
        }
      }
      continue;
    }
    const body = claudeBody(th);
    for (const b of useful) {
      if (b.type === 'text') { body.append(stampTime(mark(assistantProse(b.text)), m.timestamp)); continue; }
      if (b.type === 'thinking') {
        mark(historyChip(th, 'thinking', '', `${b.text.length.toLocaleString()} chars`, b.text));
        continue;
      }
      // tool_use: `text` is the JSON-serialised input. Show the same one-line
      // summary the live path shows, with the raw input available on expand.
      let input = null;
      try { input = JSON.parse(b.text ?? 'null'); } catch { input = b.text ?? null; }
      const name = b.toolName ?? 'tool';
      let pretty = b.text ?? '';
      try { pretty = JSON.stringify(input, null, 2); } catch { /* keep raw */ }
      mark(historyChip(th, name, toolArg(name, input), b.truncated ? 'truncated' : '', pretty || 'No recorded input.', b.truncated ? null : input));
    }
  }
  return shown;
}

/* ---------------------------------------------- recorded subagent threads */

function agentStats(a) {
  const u = a.usage ?? {};
  const ms = u.duration_ms ?? (a.endedAt && a.startedAt ? Date.parse(a.endedAt) - Date.parse(a.startedAt) : 0);
  const tools = u.tool_uses ?? 0;
  return `${mmss(ms || 0)} · ${tools} tool${tools === 1 ? '' : 's'} · ${kilo(u.total_tokens ?? 0)}`;
}

/** One hairline row that both summarises an agent and opens its thread. */
function ranRow(th, { agentId, agentType, description, status, stats, body }, opts = {}) {
  const det = el('details', { class: 'ran' });
  const open = el('span', { class: 'open', text: 'open ›' });
  const summary = el('summary', {},
    el('span', { class: 'tw', text: '▶' }),
    el('span', { class: 'ty', text: agentType || 'agent' }),
    el('span', { class: 'de', text: description || '' }),
    el('span', { class: 'stats', text: stats }),
    open);
  det.append(summary);
  det.append(body);
  // The disclosure triangle expands the summary in place; the `open ›` chip and
  // the agent type switch the pane into the agent's own thread.
  const enter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    void viewAgent(agentId);
  };
  open.addEventListener('click', enter);
  summary.querySelector('.ty').addEventListener('click', enter);
  ranStack(th).append(det);
  if (!opts.silent) {
    const stack = det.parentElement;
    const n = stack.querySelectorAll('.ran').length;
    stack.querySelector('.ran-lbl').textContent = `${n} agent${n === 1 ? '' : 's'} ran in this session`;
  }
  return det;
}

/** After a historical transcript loads, hang the recorded agents off the end. */
async function loadRecordedAgents(th, sessionId) {
  let list;
  try {
    list = await api.sessionSubagents(sessionId, state.current.encodedDir ?? undefined);
  } catch (err) {
    say(`agent index unavailable: ${err.message}`, true);
    return null;
  }
  if (list === null) {
    state.caps.subagents = false;
    return null; // route not on this server yet — say nothing rather than cry wolf
  }
  state.caps.subagents = true;
  const agents = Array.isArray(list) ? list : (list.subagents ?? []);
  if (!agents.length) return agents;

  // Newest last is how they ran; keep that order but reveal from the end,
  // because the agents you want after an overnight run are the recent ones.
  let shown = 0;
  const stack = ranStack(th);
  const label = stack.querySelector('.ran-lbl');
  const moreBtn = el('button', { class: 'more' });

  const renderSlice = (n) => {
    const next = agents.slice(Math.max(0, agents.length - shown - n), agents.length - shown).reverse();
    for (const a of next) {
      const agentId = a.agentId;
      const meta = {
        // BUG-171: carry the declared kind so a historical tool lane (local_bash)
        // opens with the tool lede, not the agent lede + never-clearing wait hint.
        kind: agentKind(a),
        agentType: a.subagentType ?? a.agentType ?? 'agent',
        description: a.description ?? '',
        status: a.status ?? 'completed',
        stats: agentStats(a),
      };
      if (!state.threads.has(agentId)) newThread(agentId, meta);
      else { Object.assign(state.threads.get(agentId), meta); refreshLede(state.threads.get(agentId)); }
      const fields = el('div', { class: 'ran-out' },
        el('div', { class: 'prose' }, el('p', { text: 'Open this thread to read what the agent actually did.' })),
        el('div', { class: 'fields' },
          el('span', {}, document.createTextNode('status '), el('b', { text: meta.status })),
          el('span', {}, document.createTextNode('messages '), el('b', { text: String(a.messageCount ?? 0) })),
          el('span', {}, document.createTextNode('tool_uses '), el('b', { text: String(a.usage?.tool_uses ?? 0) })),
          el('span', {}, document.createTextNode('total_tokens '), el('b', { text: (a.usage?.total_tokens ?? 0).toLocaleString() }))));
      ranRow(th, { agentId, ...meta, body: fields }, { silent: true });
    }
    shown += next.length;
    label.textContent = `${agents.length} agent${agents.length === 1 ? '' : 's'} ran in this session`
      + (shown < agents.length ? ` · newest ${shown}` : '');
    const left = agents.length - shown;
    moreBtn.textContent = `${left} older`;
    moreBtn.hidden = left <= 0;
    stack.append(moreBtn); // keep it last
  };

  moreBtn.addEventListener('click', () => renderSlice(RAN_MORE));
  renderSlice(RAN_PAGE);
  return agents;
}

/* ---------------------------------------------------------- open a session */

async function openSession(p, sess, opts = {}) {
  // BUG-083 — keep the outgoing session's unsent draft before state.current is
  // reassigned below, so it can be restored if the user returns here.
  saveDraft(state.current);
  selectProject(p.id, { quiet: true });
  // Opening a session restores ITS OWN armed overrides (skip/plan/model) and
  // nothing else's — a reload must not silently disarm what the user enabled
  // for this session, and a DIFFERENT session must never inherit it.
  restoreOverrides(sess.encodedDir, sess.sessionId);
  state.current = {
    projectId: p.id,
    encodedDir: sess.encodedDir,
    sessionId: sess.sessionId,
    title: rowTitle(sess),
    os: sess.os,
  };
  // BUG-106 — record the project that OWNS this now-open session, distinct from
  // the sidebar selection. A later bare selectProject moves current.projectId but
  // not this, which is how the dock's surfaces know they are foreign to the view.
  state.openProjectId = p.id;
  state.pendingNew = null; // FEAT-073 — a real session is open; no pending-new row
  state.forkFrom = null;
  // FEAT-022: a different session must never inherit this one's autonomous mode
  // or station id. Cleared here; re-learned from the `start` ack + refreshAuto.
  state.stationSessionId = null;
  // FEAT-126 — the outgoing session's request bindings must never show under the
  // incoming one; cleared here, refetched once this session's id is known.
  state.requests = [];
  state.autonomous = { autonomous: false, maxTurns: null, turnsDone: 0, remaining: null, stopReason: null };
  // A newly-opened session starts from a clean status slate — none of the
  // PREVIOUS session's error/detached/reconnecting flags may leak into it.
  state.sessError = null;
  state.provError = null; // BUG-031: nor its provider-error attribution
  state.lastTurnPrompt = null;
  state.sessReconnecting = false;
  // BUG-079: the outgoing session's pending-delivery pointers (drain-wait
  // self-retry, force-send stash) and their live timers must not act on this
  // one — clear them before the switch, alongside the other "never inherit".
  clearPendingDelivery();
  // A subagent thread viewed in the PREVIOUS session must never leak into this
  // session's URL: currentRoute() reads state.viewing, and resetTranscript()
  // (which clears it back to 'main') doesn't run until below. Clear it here,
  // before the push, so a stale agent= id is never captured — see BUG-011.
  state.viewing = 'main';
  syncUrl('push'); // BEFORE resetTranscript — its repaints replace-sync the URL
  closeSocket();
  paintCrown();
  renderTree();
  // BUG-150 — resetTranscript re-binds the queue to state.current and hands
  // back this session's outbox descriptor SYNCHRONOUSLY, before the transcript
  // fetch below is awaited. So queueKey is set from the first moment the session
  // is on screen: a message queued while the transcript is still loading
  // persists under the right key instead of vanishing into the tab's heap. Only
  // the outbox delivery-judgment (which reads the painted transcript) is
  // deferred, via judgeAdoptedOutbox once the pane is on screen.
  const adoptedOutbox = resetTranscript();
  restoreDraft(state.current); // BUG-083 — this session's own saved draft (empty if none)
  // BUG-087 — capture the transcript-pane scope AFTER resetTranscript bumped it.
  // If the user opens another session before this one's transcript fetch lands,
  // that next open bumps txScope again and the awaited answer below is dropped —
  // it belongs to the session we left, and painting it would put this (prior)
  // session's messages under the newly-opened session's header (the reported bug).
  const scope = state.txScope;
  // BUG-217: until this open has decided how the tab reaches the session
  // (reattach a live bridge, follow another program, or nothing live), a
  // boundary flush must not start resuming it on its own — see driveQueue.
  state.queueSettling = scope;
  const th = mainThread();
  const wait = el('div', { class: 'hint-row', text: 'reading the transcript…' });
  th.paneEl.append(wait);
  const frozen = sess.os === 'windows';
  node.box.hidden = frozen;
  node.frozen.hidden = !frozen;
  const at = Number.isInteger(opts.at) && opts.at >= 0 ? opts.at : null;
  try {
    // The NEWEST page, not the oldest. Everything before it is fetched on
    // scroll-up by loadOlder(). Fetched even when restoring at a deep index,
    // because it carries `total` — needed to know the restore IS deep.
    const t = await api.transcriptTail(sess.encodedDir, sess.sessionId, { limit: TAIL_PAGE });
    // BUG-196 round 3 — record the engine THIS session id is pinned to, as the
    // server declared it (resumeProviderOf). Keyed by the id, so it is true
    // whatever is on screen when it lands — recorded BEFORE the scope guard.
    declareLockedProvider(sess.sessionId, t.lockedProvider);
    // BUG-087 — switched away while this fetch was in flight: the pane now belongs
    // to a different session (resetTranscript already cleared it and bumped the
    // scope). Drop this answer rather than paint the prior session's transcript
    // under the current header. `wait` was detached by that reset, so leave it.
    if (scope !== state.txScope) return;
    wait.remove();
    paintIntegrations();
    paintAccountSel();
    // FEAT-132 — the session-configuration card pinned above the first turn.
    // Fire-and-forget: it fetches its own record and prepends when ready, so it
    // never delays the transcript paint, and it stays the pane's top child
    // regardless of when it lands (prependNodes anchors older pages below it).
    mountSessionConfigCard(th, sess, scope);
    // BUG-177 — a session-level roll-up of any silently-failed quality gates,
    // pinned at the top. Rendered nothing when the session is healthy.
    mountHookErrorBanner(th, t.hookErrors, scope);
    const tailStart = Number.isInteger(t.messages?.[0]?.index) ? t.messages[0].index : (t.offset ?? 0);
    if (at != null && at < tailStart) {
      // The remembered message is OLDER than the newest page: render a window
      // around it instead, and owe the rest forward (see the gap machinery).
      await openHistoryWindow(th, sess, at, t.total ?? 0, frozen);
      applyHookBadges(th);
    } else {
      const shown = renderMessages(th, t.messages);
      applyHookBadges(th);
      if (!shown) th.paneEl.append(el('div', { class: 'hint-row empty-session-hint', text: 'This session has no readable messages.' }));
      th.page = pageCursor((before, beforeBytes) =>
        api.transcript(sess.encodedDir, sess.sessionId, { tail: OLDER_PAGE, before, beforeBytes }), t);
      // High-water mark for external appends: a message the tail page already
      // rendered must not re-render when the watcher replays it as an append.
      // BUG-190 round 5: an EMPTY transcript (total 0) is a KNOWN anchor, -1 —
      // "nothing rendered yet, the next message is #0" — not an unknown one. The
      // old `t.total ? … : null` turned 0 into null, which the catch-up read as
      // "no anchor, nothing to do", so the first message of an empty session was
      // lost across a reconnect. null now means only "the store did not say".
      const lastMsg = t.messages[t.messages.length - 1];
      th.lastIndex = Number.isInteger(lastMsg?.index) ? lastMsg.index : (Number.isInteger(t.total) ? t.total - 1 : null);
      // Follow AFTER the tail is in hand and the high-water mark is set: the
      // watcher starts at the file's current end, so this order cannot duplicate
      // what was just fetched, and the index dedupe covers any millisecond overlap.
      followCurrent();
      // FEAT-118 — seed the read boundary from the persisted mark BEFORE the
      // programmatic scroll, then land at the newest page as before. The scroll
      // is suppressed from advancing the mark, so a restored "unread" boundary
      // survives the open (the divider shows above + the Resume pill offers the
      // one-action return) instead of being cleared by landing at the bottom.
      seedReadMark(th);
      withoutReadAdvance(() => { if (at != null) scrollToIndex(th, at); else scrollToBottom(th); });
      paintMarks(th);
      say(`${shown} of ${t.total}${t.totalIsLowerBound ? '+' : ''} messages · newest page · ${(t.tookMs ?? 0)} ms`
        + `${th.page.done ? '' : ' · scroll up for older'}`
        + `${frozen ? ' · read-only, Windows origin' : ''}`);
    }
    if (opts.highlightAt != null) highlightMessageAt(th, opts.highlightAt);
    /*
     * BUG-129: this session's undelivered messages come back here — AFTER its
     * transcript is on screen, because a handed-off batch is only judged
     * undelivered by NOT being in that transcript (transcriptHasAll). Before
     * this point the pane is empty and every restored batch would read as lost.
     * BUG-150: the ROWS were already adopted synchronously before the fetch;
     * only the outbox delivery-judgment is settled here, against the now-painted
     * transcript.
     */
    judgeAdoptedOutbox(adoptedOutbox);
    // Is this session being written LIVE right now (dashboard bridge OR an
    // external terminal this tab only follows)? Decided BEFORE the agent
    // summary, because a live session must not get one dumped into its tail.
    const liveRec = await liveRecordFor(sess.sessionId);

    /*
     * The recorded-agents "N agents ran in this session" stack hangs off the
     * END of the transcript.
     *  - forward gap outstanding: the rendered end is mid-history — defer it.
     *  - session LIVE: the rendered end is the STREAMING turn, and appending a
     *    historical summary there injected an old sub-agent into the live
     *    message ("Fix stale example-app permissionMode" reading as if it
     *    just finished). The live strip already surfaces current agents, so
     *    fetch the list for agent= validation but render NO tail summary.
     *  - otherwise (idle history): render the summary as before.
     */
    let agents;
    // `liveRec` is null for a session THIS tab's own bridge owns
    // (`liveRecordFor`'s `state.live` short-circuit — "our own bridge already
    // owns the tail"), so `state.live` must be OR'd in here too: otherwise a
    // self-owned live session with an outstanding gap read as neither gapped
    // nor live or fell straight into the `else` below and got the historical
    // summary appended (BUG-017).
    if (th.gap || liveRec || state.live) {
      // Defer the summary for a closed session's outstanding gap (paid off by
      // loadNewer once the reader scrolls to the true end — see the forward-gap
      // comment above loadNewer). A LIVE session must never queue it: paying off
      // the gap would splice the historical "N agents ran" stack into the live
      // tail exactly like the direct-open case above guards against (BUG-004),
      // and `liveRec` already unions mtime-liveness with an open live bridge
      // (`liveRecordFor`), so a bridge-idle live session is correctly excluded
      // here too — see BUG-014. `state.live` (our OWN bridge) is excluded the
      // same way — see BUG-017.
      if (th.gap && !liveRec && !state.live) th.agentsPending = true;
      try {
        const l = await api.sessionSubagents(sess.sessionId, sess.encodedDir ?? undefined);
        agents = l === null ? null : (Array.isArray(l) ? l : (l.subagents ?? []));
      } catch { agents = null; }
    } else {
      agents = await loadRecordedAgents(th, sess.sessionId);
    }
    if (at == null && th.stick !== false && state.viewing === 'main') scrollToBottom(th);
    await fillViewport(th);
    if (opts.agent) {
      // Only enter a thread that is really recorded here — a bogus agent id in
      // a link must say so, not open an empty pane that looks like a thread.
      if ((agents ?? []).some((a) => (a.agentId ?? a.id) === opts.agent)) await viewAgent(opts.agent);
      else say(`this link names an agent thread not recorded in this session (${String(opts.agent).slice(0, 12)}…)`, true);
    }
    // HONESTY ON REOPEN: a still-running session must not present as finished
    // history (the content leaks in via file-follow and startles). Reflect the
    // real busy state from the record fetched above.
    if (liveRec) {
      if (liveRec.drivenByDashboard) {
        // A dashboard bridge (detached after this or another tab looked away):
        // reattachable, and busy is knowable on a new-enough server.
        /*
         * FEAT-040: genuinely "detached (running headless)" — the server-side
         * bridge is busy but THIS tab is not driving it (no `start`/resume sent
         * yet). BUG-153: this used to ALSO raise `state.sessDetached`, a second
         * flag saying the same thing that any later socket open then cleared
         * while this one survived. `followingLive` is the durable half — it is
         * cleared where it is actually resolved: by the `start` ack that makes
         * us the driver, by refreshLive when the run really ends, and at the
         * session boundary — so the status now derives from it and liveness.
         */
        state.followingLive = true;
        if (liveRec.busy !== false) {
          // BUG-033: adopt the server's REAL turn start; if it does not report
          // one (older server, or a turn whose start this process never saw),
          // mark the duration unknown instead of stamping "now" and counting
          // from when this tab happened to open the session.
          if (Number.isFinite(liveRec.turnStartedAt) && liveRec.turnStartedAt > 0) {
            state.turnStartedAt = liveRec.turnStartedAt;
            state.turnStartUnknown = false;
          } else {
            state.turnStartedAt = 0;
            state.turnStartUnknown = true;
          }
          setBusy(true);
        }
        paintSessStatus();
        say('this session is still running (it kept working after the tab looked away) — reattaching to drive it here.');
        /*
         * BUG-160: a SOLE tab that reloaded holds its own still-alive bridge,
         * but the code above only FOLLOWS it — `isDriving()` stays false, so the
         * tab reads "not driving the session" though nothing else drives it, and
         * any message restored from before the reload can never flush. Re-take
         * the driving socket automatically. Safe: a bridge driven in ANOTHER tab
         * is not detached and comes back `live-elsewhere`, so a genuine second
         * tab still follows read-only (the honest "not driving" state stands).
         *
         * ONLY when viewing the live tail (`at == null`): a deep history-parked
         * restore holds the pane at an old index with a forward gap, and driving
         * would splice live bridge frames onto it (the BUG-004 shape). There the
         * user keeps following read-only until they scroll to the end and send.
         */
        if (at == null && !th.gap) void reattachDriving(sess);
      } else {
        // External: written by another process (your terminal). The live badge
        // and file-follow already track it; we just must not fake a summary.
        // Mark it so the permission toggles read HONESTLY — there is no bridge
        // to send `set-permission-mode` to, and the terminal owns the mode, so
        // a toggle here only ARMS the takeover, it changes nothing now.
        state.followingExternal = true;
        paintPerm();
        say('this session is being written live by another process — following along as it goes.');
      }
    }
    /*
     * BUG-217: the session is on screen and this tab knows how it reaches it.
     * Any message restored from before a reload or a switch now has an owner:
     * a reattach just started above delivers it at its boundary; otherwise
     * flushQueue → driveQueue resumes the session carrying it. (Another tab or
     * another program owning the session is the dock's "Send now" to make.)
     */
    if (state.queueSettling === scope) state.queueSettling = null;
    flushQueue();
  } catch (err) {
    // BUG-087 — a fetch that REJECTS after the user switched away is not this
    // session's error to render: resetTranscript()+the message would wipe and
    // scribble on the pane that now belongs to the newly-opened session.
    if (scope !== state.txScope) return;
    if (state.queueSettling === scope) state.queueSettling = null; // BUG-217: settled, if badly
    // BUG-129 + BUG-150: the transcript could not be read, but the session's
    // undelivered rows are still its own. resetTranscript re-binds ownership and
    // restores those rows by construction (it is the sole owner of the queue↔
    // session binding), so this failure path CANNOT leave queueKey null — the
    // round-1 regression where a message typed after a failed fetch was written
    // nowhere. With no transcript on screen a handed-off batch cannot be
    // confirmed, so the returned outbox is judged (its own fetch fallback) and
    // comes back as an honest "not confirmed" row, which is the truth here.
    judgeAdoptedOutbox(resetTranscript());
    mainThread().paneEl.append(el('div', { class: 'hint-row', text: `could not read this session: ${err.message}` }));
    say(err.message, true);
    // BUG-217: deliberately NO automatic resume here — the session could not be
    // read, so this tab does not know what it would be sending into. The dock
    // says "not sent yet" and offers Send now (the user's call, not ours).
    paintQueue();
  }
}

/**
 * Restore parked at absolute index `at`: one backward window ending a little
 * PAST `at` (so the remembered message keeps context on both sides), the
 * normal backward cursor for everything older, and a recorded forward gap for
 * everything newer. No live follow until the gap is paid off.
 */
const RESTORE_AFTER = 40; // messages of forward context fetched past `at`

async function openHistoryWindow(th, sess, at, total, frozen) {
  const before = Math.min(at + RESTORE_AFTER, total);
  const t = await api.transcript(sess.encodedDir, sess.sessionId, { tail: TAIL_PAGE, before });
  const shown = renderMessages(th, t.messages);
  if (!shown) th.paneEl.append(el('div', { class: 'hint-row', text: 'This session has no readable messages.' }));
  th.page = pageCursor((b, bb) =>
    api.transcript(sess.encodedDir, sess.sessionId, { tail: OLDER_PAGE, before: b, beforeBytes: bb }), t);
  const grandTotal = Number.isInteger(t.total) ? t.total : total;
  const lastMsg = t.messages[t.messages.length - 1];
  const lastIdx = Number.isInteger(lastMsg?.index) ? lastMsg.index : before - 1;
  th.lastIndex = lastIdx;
  if (th.page && Number.isInteger(th.page.total)) th.page.total = grandTotal;
  if (lastIdx + 1 < grandTotal) {
    th.gap = { next: lastIdx + 1, total: grandTotal };
    followCurrent(false); // the gap machinery owns the tail until caught up
  } else {
    th.gap = null;
    followCurrent();
  }
  scrollToIndex(th, at);
  if (state.viewing === 'main') paintComposerFor(th);
  say(`${shown} messages around #${at}`
    + `${th.gap ? ` · ${th.gap.total - th.gap.next} newer below` : ''}`
    + ` · ${(t.tookMs ?? 0)} ms${frozen ? ' · read-only, Windows origin' : ''}`);
}

function selectProject(id, { quiet = false } = {}) {
  if (state.current.projectId !== id) {
    state.current.projectId = id;
    // BUG-198 — the override bag is NOT cleared here: it belongs to the session
    // open in the dock (overridesOwner), which a sidebar selection does not change.
    // Transitions that DO change the session reset it themselves (restoreOverrides,
    // startNew, armFork, the dead-link route).
  }
  paintCrown();
  void refreshRail();
  scheduleRailPoll();
  // BUG-106 — a bare project switch (this "look at another project" header click)
  // moves the sidebar selection without touching the open session. Re-scope the
  // dock's session-bound surfaces so they follow the match in BOTH directions:
  // hide the strip / hairline / live-count while the open session is foreign, and
  // restore them from the still-present state.snap + session config on switch-back.
  // Only meaningful when a session is actually open — browsing projects with an
  // empty dock changes nothing here, and paintPerm must not fire for a mere
  // selection (it would repaint the tray/hairline for a project with no session).
  if (state.openProjectId != null) {
    renderStrip();
    if (dockIsForeign()) node.permLine.hidden = true; else paintPerm();
    renderRailSummary();
  }
}

/* ═══════════════════════════════════════════ Needs-You rail (FEAT-018) ══ */
/*
 * The right rail turns the current project's 👤 board items into interactive
 * cards, with the read-only in-flight / done-today board below. Source of truth
 * is the server's board reader over docs/bugs/; this only renders and submits.
 *
 * Scope (first cut): renders 👤 tickets that exist ON THE BOARD. A session
 * dynamically raising a decision card at runtime is a separate, later channel.
 *
 * BUG-016: the rail was optimistic on its OWN submit only and reconciled just
 * on a manual reload, so an item resolved OUT OF BAND (chat, an orchestrator
 * INDEX edit, another client, a runtime decision resolved elsewhere) lingered
 * in the panel indefinitely. The rail must be a LIVE mirror of the board — see
 * the poll loop below.
 */
async function refreshRail(force = false) {
  const pid = state.current.projectId;
  if (!pid) { state.board = null; state.boardProjectId = null; renderRail(); return; }
  if (!force && state.boardProjectId === pid && state.board) { renderRail(); return; }
  if (state.boardBusy) return;
  state.boardBusy = true;
  try {
    const b = await api.board(pid);
    // A late response for a project the user already navigated away from must
    // not overwrite the newer one.
    if (state.current.projectId !== pid) return;
    state.board = b;
    state.boardProjectId = pid;
  } catch {
    // A board read never blocks the app: on failure show the quiet empty rail.
    if (state.current.projectId === pid) { state.board = null; state.boardProjectId = pid; }
  } finally {
    state.boardBusy = false;
    renderRail();
  }
  void refreshOutcomes(); // FEAT-057 — deaths are project-scoped too
  void refreshRequests(); // FEAT-126 — declared request bindings for the open session
}

/* ══════════════════════════ FEAT-057 — agents that stopped, and why ═══════
 *
 * THE REQUIREMENT THIS SATISFIES, restated because it is unusual: this surface
 * must cost ZERO model tokens and must not depend on the orchestrator ever
 * having run a turn. An account-wide usage limit stops the very turn that would
 * otherwise have had to notice the deaths — so the SERVER records them as they
 * happen and this renders that record. Everything below reads
 * `/api/agent-outcomes`; nothing here is derived from events, and nothing waits
 * for a session to be open.
 *
 * Dismissal is a server write, so a cleared banner stays cleared across
 * reloads, and one the user did not clear comes back.
 */

/** Fold snapshot-carried outcomes into the rail set without a refetch. */
function mergeOutcomes(list) {
  const seen = new Set(state.outcomes.map((o) => o.id));
  let added = 0;
  for (const o of list) {
    if (!o || seen.has(o.id) || o.dismissedAt) continue;
    state.outcomes.push(o);
    seen.add(o.id);
    added++;
  }
  if (added) { state.outcomes.sort((a, b) => b.at - a.at); renderOutcomes(); }
}

/**
 * BUG-070 — the rail's DEFAULT view is recent-only (deaths in the last 48h,
 * undismissed) so a mass event days ago does not bury today's real death. The
 * client fetches the FULL bounded set (incl. dismissed) and windows it itself,
 * so "show all" flips instantly and stays reachable even when the recent view
 * is empty (dismissed/old records still exist on disk — the ledger is never
 * truncated by this). The high limit ensures "dismiss all" reaches every id of
 * even a 50-agent mass-cut swarm.
 */
const OUTCOMES_RECENT_MS = 48 * 60 * 60 * 1000;
async function refreshOutcomes() {
  if (state.caps.outcomes === false) return;
  let list;
  try { list = await api.agentOutcomes({ projectId: state.current.projectId ?? undefined, all: true, limit: 200 }); }
  catch { return; /* transient — the rail keeps its last honest answer */ }
  if (list === null) { state.caps.outcomes = false; return; } // older server
  state.caps.outcomes = true;
  // FEAT-118 — the sidebar's died-without-answering marker reads state.outcomes,
  // so a poll that changes the death set must repaint the tree too, or a session
  // that just died would keep reading 'finished' until some unrelated re-render.
  const before = (state.outcomes ?? []).map((o) => `${o.id}:${o.dismissedAt ? 'd' : ''}`).join(',');
  state.outcomes = list;
  renderOutcomes();
  if (before !== list.map((o) => `${o.id}:${o.dismissedAt ? 'd' : ''}`).join(',')) renderTree();
}

/**
 * FEAT-126 — fetch the DECLARED request bindings for the open session. The
 * bindings change rarely (only when the orchestrator declares a new request or
 * updates one), so this is fetched on session/rail changes, not on every running
 * poll — the live join (execution/completion) is recomputed on every snapshot in
 * applySnapshot without a refetch. `null` from the API means the route is absent
 * (older server): the section stays hidden and the rail is exactly as before.
 */
async function refreshRequests() {
  if (state.caps.requests === false) return;
  const sid = state.stationSessionId || state.sdkSessionId || state.current.sessionId;
  if (!sid) { state.requests = []; renderRailRequests(); return; }
  let list;
  try { list = await api.sessionRequests(sid); }
  catch { return; /* transient — keep the last honest answer */ }
  if (list === null) { state.caps.requests = false; return; } // older server — degrade to today's rail
  state.caps.requests = true;
  state.requests = list;
  renderRailRequests();
}

/** BUG-070 — the recent-view predicate: within 48h and not dismissed. */
function isRecentOutcome(o) {
  return !o.dismissedAt && (Date.now() - o.at) <= OUTCOMES_RECENT_MS;
}

/**
 * BUG-070 — relative day label ("today", "yesterday", "Aug 10") for a death's
 * timestamp. Mirrors `outcomes.dayLabel()` on the server so the two surfaces
 * never date the same record differently. The reported bug was that the rail
 * dropped the date and showed time-of-day alone, so a 2-day-old fossil read as
 * "7pm today". Calendar-day boundaries, not a rolling 24h.
 */
const DAY_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function dayLabel(atMs, nowMs = Date.now()) {
  if (!Number.isFinite(atMs)) return '';
  const at = new Date(atMs);
  const now = new Date(nowMs);
  const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const days = Math.round((startOfDay(now) - startOfDay(at)) / 86400000);
  if (days <= 0) return 'today';
  if (days === 1) return 'yesterday';
  return `${DAY_MONTHS[at.getMonth()]} ${at.getDate()}`;
}

/** BUG-070 — "today 19:08" / "yesterday 19:08" / "Aug 10 19:08" for a death. */
function datedTime(atMs) {
  const t = new Date(atMs);
  const clock = `${String(t.getHours()).padStart(2, '0')}:${String(t.getMinutes()).padStart(2, '0')}`;
  return `${dayLabel(atMs)} ${clock}`;
}

/** "resets 13:40" from an epoch-ms the SERVER normalised, or '' when unknown. */
function resetsAtText(pe) {
  if (!pe || !Number.isFinite(pe.resetsAt)) return '';
  const d = new Date(pe.resetsAt);
  return `resets ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/**
 * The headline. Mirrors `outcomes.headline()` on the server deliberately: two
 * surfaces wording the same facts differently is how a user learns to distrust
 * both. Never invents a cause — a death with no known reason reads
 * "reason unknown", which is the honest sentence.
 */
/**
 * BUG-041 — mirror of the server's `clustersOf`: records stamped with one
 * cluster id (or written same-session within 10ms) are ONE host-level event.
 * Only the count is needed here, for the "stopped together" headline.
 */
function clusterOutcomes(list) {
  const sorted = [...list].sort((a, b) => a.at - b.at);
  const out = [];
  const byClusterId = new Map();
  let lastImplicit = null;
  for (const o of sorted) {
    const sess = o.sdkSessionId || o.stationSessionId || '?';
    if (o.clusterId) {
      const key = `${sess}|${o.clusterId}`;
      const c = byClusterId.get(key);
      if (c) { c.push(o); continue; }
      const fresh = [o];
      byClusterId.set(key, fresh);
      out.push(fresh);
      lastImplicit = null;
      continue;
    }
    const prev = lastImplicit && lastImplicit[lastImplicit.length - 1];
    const prevSess = prev && (prev.sdkSessionId || prev.stationSessionId || '?');
    if (prev && prevSess === sess && o.at - prev.at <= 10) { lastImplicit.push(o); continue; }
    lastImplicit = [o];
    out.push(lastImplicit);
  }
  return out;
}
function outcomeClusterCount(list) {
  return clusterOutcomes(list).length;
}

function outcomesHeadline(list) {
  if (!list.length) return '';
  const n = list.length;
  // BUG-041 — one host-level event is one fact, not N independent deaths.
  if (n > 1 && outcomeClusterCount(list) === 1) {
    const pe = list.map((o) => o.providerError).find((p) => !!p);
    const kinds = [...new Set(list.map((o) => (o.kind === 'unknown' ? 'reason unknown' : o.kind)))];
    return `${n} stopped together — one event (${pe ? pe.kind : kinds.join(', ')})`;
  }
  const quota = list.find((o) => o.kind === 'provider-error' && o.providerError);
  const noun = `${n} agent${n === 1 ? '' : 's'} stopped`;
  if (quota) {
    const r = resetsAtText(quota.providerError);
    return `${noun} — ${quota.providerError.kind}${r ? `, ${r}` : ''}`;
  }
  const kinds = [...new Set(list.map((o) => (o.kind === 'unknown' ? 'reason unknown' : o.kind)))];
  return `${noun} — ${kinds.join(', ')}`;
}

function outcomeDetailLine(o) {
  const who = o.row === 'main' ? 'main turn' : (o.label || 'agent');
  // BUG-070 — dated, never bare time: an old entry must never read as today's.
  const when = datedTime(o.at);
  // BUG-041 — name the actual cause, not just its category: the reported gap
  // was "tooling-unavailable tells me nothing about what actually happened".
  const why = o.kind === 'provider-error' && o.providerError
    ? `${o.providerError.kind} (${o.providerError.provider})`
    : o.kind === 'unknown' ? 'ended, reason unknown' : o.kind;
  return `${who} · ${why} · ${when}`;
}

/** BUG-041 — the hover carries the FULL stored evidence for one death. */
function outcomeEvidence(o) {
  return [
    o.detail,
    o.providerError ? `${o.providerError.kind} (${o.providerError.provider}): ${o.providerError.detail}` : '',
    new Date(o.at).toISOString(),
  ].filter(Boolean).join('\n');
}

/** BUG-070 — persist a dismissal, optimistically (server is authoritative). */
function dismissOutcomeIds(ids) {
  if (!ids.length) return;
  const set = new Set(ids);
  const now = Date.now();
  for (const o of state.outcomes) if (set.has(o.id) && !o.dismissedAt) o.dismissedAt = now;
  renderOutcomes();
  void api.dismissOutcomes(ids).catch(() => void refreshOutcomes());
}

/* ------------------------------ ARCH-017 step 2: the pending-results rail */
/**
 * Results Orchard is HOLDING, and the two things a user can do with them.
 *
 * The collapse is the feature: when every lane in a group has finished, the N
 * results are ONE row with ONE "process" — a fan-out costs one collection
 * instead of N wakeups. While a group is still in flight its finished members
 * are listed individually and marked with what they are waiting on; "process"
 * on one of those is the ESCAPE HATCH the user asked for — pull this result now
 * without waiting for its siblings.
 *
 * HONESTY: `state.pending === null` means the rail has no answer yet and the
 * section stays hidden. An empty array means a real, current "nothing is
 * waiting". They must not render the same, because this surface exists to tell
 * the user something IS waiting for them.
 */
async function refreshPending() {
  if (state.caps.pending === false) return;
  let r;
  try { r = await api.pendingLanes({ projectId: state.current.projectId ?? undefined }); }
  catch { return; /* transient — the rail keeps its last honest answer */ }
  if (r === null) { state.caps.pending = false; return; } // older server: no such route
  state.caps.pending = true;
  if (r.problem) { state.pendingProblem = r.problem; renderPending(); return; }
  state.pendingProblem = null;
  state.pending = r.items;
  renderPending();
}

/**
 * The headline must account for EVERY row on the rail, not just the ready ones.
 *
 * Found by looking at the render rather than at the DOM: with five items the
 * section (a shared `.rail-sub`, `max-height:158px; overflow:auto`) scrolled
 * the last row out of sight, while the headline read "6 results ready in 3
 * items" — so the two rows you could not see were also not counted anywhere,
 * and the surface silently under-reported what was waiting for you. The
 * waiting count is the thing that makes the number on screen add up to the
 * number of rows.
 */
function pendingHeadline(list) {
  const ready = list.filter((i) => i.ready);
  const waiting = list.length - ready.length;
  const results = ready.reduce((n, i) => n + i.laneIds.length, 0);
  const tail = waiting ? ` · ${waiting} still finishing` : '';
  if (!ready.length) return `${list.length} lane result${list.length === 1 ? '' : 's'} finishing`;
  return `${results} result${results === 1 ? '' : 's'} ready in ${ready.length} item${ready.length === 1 ? '' : 's'}${tail}`;
}

/**
 * The ONE sentence the user has to act on, lifted out of a long store message.
 *
 * Deliberately conservative: it returns a hint only when the text really
 * contains an instruction, and NEVER paraphrases — a fabricated "recovery step"
 * on a storage error would be worse than the clipping this exists to fix. The
 * full message is always rendered underneath regardless, so a miss here costs
 * prominence, not information.
 */
function recoveryHint(msg) {
  const sentences = String(msg).split(/(?<=\.)\s+/).map((x) => x.trim()).filter(Boolean);
  // Imperative recovery language used by the lane store's own error messages.
  const imperative = /\b(stop it|point CLAUDE_STATION_DATA|move it aside|repair|recover by|try again|re-?run)\b/i;
  for (let i = sentences.length - 1; i >= 0; i--) {
    if (imperative.test(sentences[i])) return sentences[i].length > 240 ? `${sentences[i].slice(0, 240)}…` : sentences[i];
  }
  return null;
}

function renderPending() {
  const host = node.railPending;
  if (!host) return;
  // FEAT-153 r4 — an unchanged poll must not clear()+rebuild the held-results list.
  const psig = JSON.stringify([
    state.pending, state.pendingProblem, state.pendingActionProblem,
    state.lastDrain, state.showAllPending,
  ]);
  if (railUnchanged(host, psig)) return;
  clear(host);
  const list = state.pending ?? [];
  if (state.pendingProblem) {
    // The ledger is refused WHOLE (round 7's deliberate choice). Say so in the
    // store's own words — the recovery path is in them — instead of hiding,
    // which would claim nothing is waiting while results sit undeliverable.
    host.hidden = false;
    host.classList.add('stopped');
    host.append(el('div', { class: 'sub-h', text: 'Held results — unreadable' }));
    host.append(el('div', { class: 'brow', title: state.pendingProblem },
      el('span', { class: 'g', text: '⛔' }),
      el('span', { class: 'bt', text: state.pendingProblem.slice(0, 220) })));
    return;
  }
  host.hidden = state.pending === null || (list.length === 0 && !state.pendingActionProblem && !state.lastDrain);
  if (host.hidden) return;
  host.classList.add('stopped');

  /*
   * §7 — THE FAILED ACTION, FIRST AND UNMISSABLE. Rendered above the rows
   * because it explains why a row the user just clicked is still here. The
   * server's own words: a non-writer store, a 503, a skipped lane all carry
   * their recovery path in the message.
   */
  if (state.pendingActionProblem) {
    /*
     * ROUND 3 — THE MESSAGE HAS TO BE READABLE, NOT MERELY PRESENT.
     *
     * The round-2 fix surfaced the 503 "with the store's OWN words, because the
     * recovery path is in them" — and then rendered those words in a `.bt`,
     * which is `white-space:nowrap; overflow:hidden; text-overflow:ellipsis` in
     * a 210px rail, on top of a `.slice(0, 220)`. Measured by a verifier:
     * `{textLen:220, clientWidth:210, scrollWidth:1195, approxVisibleChars:38}`
     * of a 1115-character message, with the actual instruction living in the
     * TAIL and surviving only in a `title` tooltip. So the error was technically
     * surfaced and practically unreadable — and a non-writer server is the state
     * a user is least able to hover their way out of.
     *
     * Both cuts are gone: no slice, and `.brow.problem .bt` wraps. The recovery
     * sentence is ALSO lifted to the front, because it is the only part the user
     * has to act on and it was the part furthest from the eye.
     */
    const msg = state.pendingActionProblem;
    const warn = el('div', { class: 'brow problem' });
    warn.dataset.pendingProblem = '1';
    warn.append(el('span', { class: 'g', text: '⚠' }));
    const body = el('span', { class: 'bt' });
    const hint = recoveryHint(msg);
    /*
     * The instruction is lifted to the front, so it must NOT also be left in
     * the body — measured after the round-4 dedupe: the row was 753 chars for a
     * 597-char message because the recovery sentence appeared twice, and this
     * row already takes ~70% of the rail's viewport. Removed by exact match
     * only; if the sentence is not found verbatim the full message renders
     * unchanged, so this can shorten the text but never lose any of it.
     */
    if (hint) body.append(el('strong', { class: 'fix-first', text: hint }), el('br'));
    const rest = hint && msg.includes(hint) ? msg.replace(hint, '').replace(/\s{2,}/g, ' ').trim() : msg;
    body.append(document.createTextNode(rest));
    warn.append(body);
    const dismissWarn = el('button', { type: 'button', class: 'lnk', text: 'ok', title: 'Hide this message. It will come back if the next attempt fails too.' });
    dismissWarn.addEventListener('click', () => { state.pendingActionProblem = null; renderPending(); });
    warn.append(dismissWarn);
    host.append(warn);
  }

  /*
   * §5 — THE COLLECTED BUNDLE HAS A DOM SURFACE. It used to go only to
   * `console.info`, so a user "collected" N results into devtools. The text is
   * put in the message composer (that is the actual one-wakeup path: N results
   * land in your draft and you send ONCE), and this row confirms it and can
   * re-copy it.
   */
  // Nothing left to act on, but a just-collected bundle still has to render —
  // otherwise collecting the LAST item makes its own receipt vanish.
  if (!list.length) { renderLastDrain(host); return; }
  const head = el('div', { class: 'sub-h', text: pendingHeadline(list) });
  const readyIds = list.filter((i) => i.ready).map((i) => i.id);
  if (readyIds.length > 1) {
    const all = el('button', {
      type: 'button', class: 'lnk', text: 'process all',
      title: 'Collect every READY item in one go. Items still waiting on a sibling are deliberately left alone — pulling one early is a per-item choice.',
    });
    all.addEventListener('click', () => void processPending(readyIds));
    head.append(all);
  }
  const dismissAll = el('button', {
    type: 'button', class: 'lnk', text: 'dismiss all',
    title: 'Discard these WITHOUT collecting them. The result files stay on disk under the lane directories; only the claim on your attention goes away.',
  });
  dismissAll.addEventListener('click', () => void dismissPending(list.map((i) => i.id)));
  head.append(dismissAll);
  host.append(head);

  /*
   * §4 — NO ROW IS UNREACHABLE. The old hard `break` at 12 left 5 of 17 items
   * with no row at all: no per-item process, no per-item dismiss, and no
   * indication they existed. `process all` did still collect them (it reads the
   * list, not the DOM), which is exactly what makes the omission dangerous —
   * the user acts on more than they can see. Capped for length, never hidden.
   */
  const CAP = 12;
  const shown = state.showAllPending ? list : list.slice(0, CAP);
  const overflow = list.length - shown.length;
  for (const it of shown) {
    const row = el('div', { class: 'brow', title: `${it.reason}\n\n${it.excerpt}` });
    row.dataset.pendingId = it.id;
    row.append(el('span', { class: 'g', text: it.ready ? (it.kind === 'group' ? '📦' : '📥') : '⏳' }));
    const n = it.laneIds.length;
    row.append(el('span', {
      class: 'bt',
      /*
       * §6 — `waitingOn` is the count of unsettled SIBLINGS, which is 0 for an
       * open group whose members have all settled (the normal state for up to
       * GROUP_CLOSE_TTL_MS). The old string rendered "ready, waiting on 0 more",
       * which is incoherent: the reason it is not ready is that the group is
       * still OPEN, not that anything is running. Say the true reason.
       */
      text: it.ready
        ? `${it.label} — ${n} result${n === 1 ? '' : 's'} ready`
        : it.waitingOn > 0
          ? `${it.label} — ready, waiting on ${it.waitingOn} more`
          : `${it.label} — ready, group still open`,
    }));
    const go = el('button', {
      type: 'button', class: 'lnk', text: it.ready ? 'process' : 'process now',
      title: it.ready ? it.reason : `Escape hatch: collect this result now instead of waiting for ${it.waitingOn} sibling lane(s).`,
    });
    go.addEventListener('click', () => void processPending([it.id]));
    row.append(go);
    const x = el('button', { type: 'button', class: 'lnk', text: 'dismiss', title: 'Discard without collecting.' });
    x.addEventListener('click', () => void dismissPending([it.id]));
    row.append(x);
    host.append(row);
  }
  if (overflow > 0 || state.showAllPending) {
    const more = el('button', {
      type: 'button', class: 'rail-more',
      title: state.showAllPending
        ? 'Collapse back to the first 12.'
        : `${overflow} more held result(s) have no row yet — show them so you can process or dismiss each one.`,
    },
      el('span', { class: 'rm-n', text: state.showAllPending ? '−' : `+${overflow}` }),
      el('span', { class: 'rm-l', text: state.showAllPending ? 'show fewer' : 'more — show all' }));
    more.dataset.pendingMore = '1';
    more.addEventListener('click', () => { state.showAllPending = !state.showAllPending; renderPending(); });
    host.append(more);
  }
  renderLastDrain(host);
}

/*
 * The collected bundle, rendered BELOW the actionable rows.
 *
 * Ordering is load-bearing and was got wrong first: rendered above the list,
 * the bundle's <pre> filled the section's whole 158px and pushed every
 * process/dismiss row out of view, so collecting one item hid the sixteen you
 * had not dealt with yet. The rail's job is the rows; this is the receipt.
 */
function renderLastDrain(host) {
  if (state.lastDrain) {
    const d = state.lastDrain;
    const row = el('div', { class: 'brow', title: d.bundle.slice(0, 1200) });
    row.dataset.lastDrain = '1';
    row.append(el('span', { class: 'g', text: '✓' }));
    row.append(el('span', { class: 'bt', text: `collected ${d.lanes.length} result${d.lanes.length === 1 ? '' : 's'} → added to your message` }));
    const copy = el('button', { type: 'button', class: 'lnk', text: 'copy', title: 'Copy the collected results to the clipboard.' });
    copy.addEventListener('click', () => { void navigator.clipboard?.writeText(d.bundle); });
    row.append(copy);
    const hide = el('button', { type: 'button', class: 'lnk', text: 'hide' });
    hide.addEventListener('click', () => { state.lastDrain = null; renderPending(); });
    row.append(hide);
    host.append(row);
    // The full text, present in the DOM and selectable — not just a tooltip.
    const pre = el('pre', { class: 'drain-bundle', text: d.bundle });
    pre.dataset.drainBundle = '1';
    host.append(pre);
  }
}


/**
 * Collect. TWO calls, and not by accident: `process` stamps Orchard's handoff
 * and hands back the bytes, then `ack` stamps the acknowledgement against a
 * digest only a holder of those bytes can produce. If this browser dies in
 * between, the lanes stay HELD and come back on the next poll — re-offered, not
 * lost. Optimistic removal keeps the click instant; the poll is authoritative.
 */
async function processPending(ids) {
  if (!ids.length) return;
  const set = new Set(ids);
  const before = state.pending ?? [];
  state.pending = before.filter((i) => !set.has(i.id));
  state.pendingActionProblem = null;
  renderPending();

  /*
   * ROUND 9 (finding 5) — DELIVERY IS BOUND TO THE SESSION THAT INITIATED IT.
   *
   * `processPending` awaits the drain, and the user can switch project/session in
   * that gap. The composer (`node.prompt`) is a boot-time cache, so after a switch
   * it is the NEW session's box — and A's collected results were written into B's
   * composer and acknowledged: `rail switch: destination:"B" contains:true acks:1`,
   * a cross-project data leak. The initiating session+project are captured here and
   * re-checked before the results are placed and again before the ack; if the user
   * has moved on, nothing is delivered or acknowledged (the results stay held and
   * are re-offered) and they are told.
   */
  /*
   * ROUND 10 (finding 1) — COMPARE THE FIELD SESSION SELECTION ACTUALLY STORES.
   * Round 9 read `state.current.id`, but a selected session is `state.current`
   * `{sessionId, projectId, encodedDir}` — there is no `.id` — so the guard
   * compared `undefined` to `undefined` and passed for EVERY session, including
   * none at all (`same/other/gone` all delivered A's result and acked). The
   * screenshot that "proved" it showed only the happy path, which passes either
   * way. This reads `sessionId`, and the negative case (C10) fails if this guard
   * is deleted.
   */
  /*
   * ROUND 11 (finding 2) — REFUSE AN ABSENT DESTINATION, KEY ON EVERYTHING
   * SELECTION STORES, AND CATCH A RE-OPENED SAME-ID CONTEXT.
   *
   * The seventh review showed round 10's guard still delivered when it must not:
   *   absent:    sessionId null on both sides ⇒ null === null passed
   *   directory: `encodedDir` changed (which session selection DOES key on,
   *              `openSession` sets it) but the guard never compared it
   *   recreated: the same id re-selected is a NEW `state.current` object with
   *              identical fields — field equality alone cannot tell it apart
   * So delivery now refuses unless ALL of these hold at the delivery instant:
   *   1. there IS a session (`sessionId` non-null) — you cannot deliver a
   *      result into "no open session"; an absent id is a refusal, not a pass;
   *   2. `sessionId`, `projectId` AND `encodedDir` all still equal the origin —
   *      `encodedDir` is the store directory selection keys on, so a changed
   *      one is a different destination even if the id string repeats;
   *   3. `state.current` is the SAME object reference captured at the start —
   *      `state.current` is only ever reassigned by navigation (openSession /
   *      new-session, three sites, all verified), so a replaced reference means
   *      the context was re-opened, which is the recreated-same-id case.
   */
  const originRef = state.current ?? null;
  const origin = {
    sessionId: state.current?.sessionId ?? null,
    projectId: state.current?.projectId ?? null,
    encodedDir: state.current?.encodedDir ?? null,
  };
  const sessionMoved = () =>
    (state.current?.sessionId ?? null) == null ||               // (1) no destination
    state.current !== originRef ||                              // (3) context re-opened
    (state.current?.sessionId ?? null) !== origin.sessionId || // (2) …
    (state.current?.projectId ?? null) !== origin.projectId ||
    (state.current?.encodedDir ?? null) !== origin.encodedDir;

  /*
   * §7 — EVERY FAILURE PATH ENDS IN SOMETHING THE USER CAN SEE.
   *
   * Reproduced by an independent verifier against a non-writer server: the
   * drain answered 200 with `lanes: []` and the reason inside `skipped[]`, this
   * function ignored it, called `ack` with an empty list, got a 400, and threw
   * out through a `finally` with no `catch` — the row reappeared and NOTHING
   * was shown. For a surface whose whole purpose is "these results are waiting
   * for you", a silent no-op is the worst available behaviour.
   */
  let r;
  try {
    r = await api.processLanes(ids, state.current.projectId ?? undefined);
  } catch (err) {
    state.pendingActionProblem = `could not collect: ${err.message}`;
    await refreshPending();
    return;
  }
  if (r === null) {
    state.pendingActionProblem = 'this server does not support collecting held lane results (no /api/lanes/process route).';
    await refreshPending();
    return;
  }
  if (!r.receipt || !Array.isArray(r.lanes)) {
    state.pendingActionProblem = 'the server answered without a receipt, so nothing could be collected. The results are still held.';
    await refreshPending();
    return;
  }
  // Partial success is still a failure FOR THE SKIPPED LANES, and they are the
  // ones that will silently reappear — so they are named.
  if (r.skipped?.length) {
    state.pendingActionProblem = `${r.skipped.length} result(s) could not be handed over and are still held: ${r.skipped.map((x) => x.why).join('; ')}`;
  }
  if (!r.lanes.length) {
    state.pendingActionProblem = state.pendingActionProblem || 'nothing was handed over — the results are still held.';
    await refreshPending();
    return;
  }
  /*
   * DELIVER FIRST, ACKNOWLEDGE SECOND — the order is the whole point.
   *
   * A cross-provider review measured `4 ack: composerHasResult=false`: the
   * acknowledgement was sent BEFORE the bundle reached the composer, so a
   * failure or a reload in between left the ledger saying "collected" for a
   * result that had arrived nowhere the user could see. An acknowledgement is
   * the consumer's statement that it HAS the bytes where it said it would put
   * them; making it before putting them there is a claim about the future.
   *
   * This is the same rule the store already enforces on itself (settle → write
   * → handoff → acknowledge); the client half was doing it backwards.
   */
  /*
   * DELIVERY IS VERIFIED, NOT ASSUMED, BEFORE ANYTHING IS ACKNOWLEDGED.
   *
   * Round 5 moved the composer write ahead of the ack, which was necessary and
   * not sufficient. A second cross-provider review drove three failure modes
   * through it and all three acknowledged, or escaped, silently:
   *   5-order {"mode":"missing","diskAcknowledged":true,"composerHasFullResult":false}
   *   5-order {"mode":"throws","refreshes":0,"visibleError":null,"escaped":"composer failed"}
   *   5-order {"mode":"partial","diskAcknowledged":true,"composerHasFullResult":false}
   * i.e. no composer at all, a composer that throws, and a composer that ended
   * up holding only part of the bundle — the first and third stamped the ledger
   * "collected" for a result the user never got, and the second left the turn
   * with no refresh and nothing on screen.
   *
   * An acknowledgement claims the bytes ARE where we said we put them, so the
   * claim is now checked against the composer's actual contents. A failure
   * here is reported and NOT acknowledged: the results stay held and are
   * re-offered, which is the outcome this whole design prefers.
   */
  // The session may have changed while the drain was in flight — do not write one
  // project's results into another's composer.
  if (sessionMoved()) {
    state.pendingActionProblem = 'you switched session while these results were being collected, so they were NOT placed anywhere — they stay held and will be offered again where they belong.';
    await refreshPending();
    return;
  }
  let delivery;
  try {
    delivery = showPendingBundle(r);
  } catch (err) {
    delivery = { delivered: false, why: `the collected results could not be placed in your message box (${err.message})` };
  }
  if (!delivery.delivered) {
    state.pendingActionProblem = `${delivery.why}. Nothing was marked collected, so these results are still held and will be offered again.`;
    await refreshPending();
    return;
  }
  /*
   * The digest is computed the way the STORE computes it — `lanes.receiptDigest`
   * — over what actually arrived: sha256(nonce ‖ len(channel) ‖ ':' ‖ channel ‖
   * bytes). The length delimiter matters now that the channel is a free string:
   * without it, channel `"a"` over `"bc"` and channel `"ab"` over `"c"` hash the
   * same. The nonce makes an earlier receipt useless for a later identical
   * bundle, and the channel states where these bytes were put.
   */
  /*
   * ROUND 9 (finding 5) — A DIGEST FAILURE IS A REFUSAL, NOT AN ESCAPE. When
   * `sha256Hex` (SubtleCrypto) is unavailable or throws, the `await` used to
   * propagate out of `processPending` with no refresh and nothing shown (`rail
   * digest-fails: escaped:true refresh:0 problem:false`). Without a digest no
   * honest receipt can be produced, so the ack is refused and the user told.
   */
  const channelBytes = new TextEncoder().encode(r.receipt.channel ?? '').length;
  let digest;
  try {
    digest = await sha256Hex(`${r.receipt.nonce}${channelBytes}:${r.receipt.channel ?? ''}${r.bundle ?? ''}`);
  } catch (err) {
    state.pendingActionProblem = `the delivery receipt could not be computed (${err && err.message}), so nothing was acknowledged — these results stay held and will be offered again.`;
    await refreshPending();
    return;
  }

  /*
   * RE-CHECK AT THE MOMENT THE ACK IS SENT — NOT BEFORE THE AWAIT.
   *
   * Round 6 added an `isConnected` test inside `showPendingBundle`, and a third
   * cross-provider review showed it only proves something about the instant it
   * runs:
   *
   *   4 replace-on-input      {"acks":1,"refresh":1,"connected":false,"error":false}
   *   4 replace-during-digest {"acks":1,"refresh":1,"connected":false,"error":false}
   *
   * The composer can be torn down by a listener on the very `input` event we
   * dispatch, or during the `await` above — a genuine gap, since re-rendering
   * on input is ordinary UI behaviour. An initially-detached node was correctly
   * refused, which is exactly why this looked fixed.
   *
   * An acknowledgement is a statement about where the bytes ARE, so the only
   * honest place to check is immediately before making it. This re-asks the
   * whole question — still on screen, still ours, still visible, still holding
   * these bytes — after every await has settled.
   */
  /*
   * ROUND 8 — THE RE-CHECK ITSELF MUST NOT ESCAPE. A fourth cross-provider
   * review made `composerProblem` THROW (an `isConnected` getter that throws) and
   * the whole turn escaped: `4 throw-recheck {"acks":0,"refresh":0,"rejected":true,
   * "problem":false}` — no ack (good), but no refresh and NOTHING shown to the
   * user (bad). A check that cannot answer is a refusal, not an exception: any
   * throw here is treated as "could not confirm", which refuses the ack and tells
   * the user, exactly as an explicit problem does.
   */
  if (sessionMoved()) {
    state.pendingActionProblem = 'you switched session before these results could be acknowledged, so nothing was marked collected — they stay held and will be offered again where they belong.';
    await refreshPending();
    return;
  }
  let lost;
  try { lost = composerProblem(node.prompt, r.bundle); }
  catch (err) { lost = `the message box could not be confirmed (${err && err.message})`; }
  if (lost) {
    state.pendingActionProblem = `${lost}. Nothing was marked collected, so these results are still held and will be offered again.`;
    await refreshPending();
    return;
  }

  try {
    const ack = await api.ackLanes(r.lanes.map((l) => l.id), { bytes: r.receipt.bytes, digest, nonce: r.receipt.nonce, channel: r.receipt.channel });
    if (ack?.refused?.length) {
      state.pendingActionProblem = `${ack.refused.length} result(s) were sent but could not be marked collected, so they will be offered again: ${ack.refused.map((x) => x.why).join('; ')}`;
    }
  } catch (err) {
    state.pendingActionProblem = `collected, but the acknowledgement failed (${err.message}) — these results will be offered again rather than lost.`;
  }
  await refreshPending();
}

/** SubtleCrypto sha256, hex. Fed `nonce ‖ channel ‖ bytes` — the store's own
 *  receipt rule (`lanes.receiptDigest`), not a second local one. */
async function sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * §5 — PUT THE COLLECTED BUNDLE WHERE THE USER ACTUALLY WANTS IT.
 *
 * This used to write the drain to `console.info` and nothing else, so a user
 * "collected" N results into a devtools console — verified by a reviewer: after
 * clicking process, no DOM node anywhere contained the collected text.
 *
 * The composer is the right destination, not a modal: the point of this whole
 * ticket is that an N-lane fan-out should cost ONE wakeup, and N results landing
 * in your draft so you can send ONCE is that outcome made concrete. The rail row
 * and the `<pre>` rendered next to it are the confirmation and the copy path.
 */
function showPendingBundle(r) {
  const n = (r.lanes ?? []).length;
  if (!n) return { delivered: false, why: 'the drain returned no results to deliver' };
  /*
   * `node.prompt` IS A CACHE, NOT A QUESTION.
   *
   * `node` is built once at boot (`prompt: $('#prompt')`), so this reference
   * survives the composer being removed, replaced or re-rendered. A detached
   * textarea is truthy, accepts `.value`, and reads back exactly what you wrote
   * — so the existence check passed, the read-back below passed, and the
   * acknowledgement went out, for a result that had been written into a node no
   * longer in the document. "Collected" for bytes the user cannot see is the
   * precise failure this whole delivery-verdict change exists to prevent, and
   * it survived the change.
   *
   * Measured in round 6: with `#prompt` removed from the DOM, the client still
   * sent the ack (`ackWasSent:true`) and reported no problem. `isConnected` is
   * the actual question — is this node in the document RIGHT NOW.
   */
  const box = node.prompt;
  const problem = composerProblem(box, null);
  if (problem) return { delivered: false, why: problem };
  const header = `Results collected by Orchard (${n} lane${n === 1 ? '' : 's'}, one drain):`;
  const before = box.value ?? '';
  box.value = `${before ? `${before.replace(/\s+$/, '')}\n\n` : ''}${header}\n${r.bundle}\n`;
  box.dispatchEvent(new Event('input', { bubbles: true }));
  /*
   * READ IT BACK. The composer is a DOM node other code also writes to, so the
   * only honest basis for "it is there" is that it is there NOW. A partial or
   * swallowed write is otherwise indistinguishable from a successful one.
   */
  const after = box.value ?? '';
  if (!after.includes(r.bundle)) {
    return { delivered: false, why: 'the collected results did not survive being written to your message box (it holds something else now)' };
  }
  state.lastDrain = { at: Date.now(), lanes: r.lanes.map((l) => l.id), bytes: r.receipt.bytes, bundle: r.bundle };
  try { saveDraft(state.current); } catch { /* draft persistence is a nicety; the text is already in the box */ }
  console.info(`[orchard] ARCH-017 drain — ${n} result(s), ${r.receipt.bytes} bytes:\n${r.bundle}`);
  return { delivered: true, why: null };
}

/*
 * IS THE COMPOSER A PLACE THESE BYTES REALLY ARE? — the ONE rule, asked twice.
 *
 * `node.prompt` is a boot-time cache (`prompt: $('#prompt')`), so its mere
 * existence proves nothing: a detached, replaced, hidden or foreign-document
 * textarea is truthy, accepts `.value`, and reads back exactly what you wrote.
 * Round 6 checked `isConnected` once, before an `await`; a review then showed
 * every way that is still evadable. So the question lives in one function and
 * is asked at BOTH moments that matter — when writing, and again immediately
 * before the acknowledgement.
 *
 * `wantBundle` is optional: pass it to also require that the box still HOLDS
 * those bytes, which is the actual claim an acknowledgement makes.
 */
function composerProblem(box, wantBundle) {
  if (!box) return 'there is no message box on screen to deliver the collected results into';
  if (!box.isConnected) return 'the message box was removed from the page before the collected results could be confirmed in it';
  /*
   * A node whose ownerDocument is not this page's (a detached fragment, an
   * iframe, a stub) is not a destination the user can read. `document` is
   * referenced defensively so this is testable outside a browser.
   */
  const doc = typeof document === 'undefined' ? undefined : document;
  if (box.ownerDocument && box.ownerDocument !== doc) return 'the message box no longer belongs to this page, so the collected results are not where the user is looking';
  /*
   * ROUND 8 — HIDDEN is inherited, so walk the ANCESTORS, not just the box.
   * `4 hidden-ancestor {"acks":1,...}` — a composer whose own `hidden` is false
   * but whose PARENT is hidden still acknowledged, because only `box.hidden` was
   * checked. A textarea inside a `hidden` (or `display:none`) ancestor is not on
   * screen; the user cannot see the result there. Walk up while ancestors are
   * reachable and refuse if any is hidden.
   */
  const cs = (typeof getComputedStyle === 'function') ? getComputedStyle : null;
  for (let el = box; el; el = el.parentElement) {
    if (el.hidden === true) return 'the message box (or a container it is inside) is hidden, so the collected results would not be visible';
    /*
     * ROUND 9 (finding 5) — STRUCTURE IS NOT VISIBILITY. The `hidden` walk missed
     * a CSS-hidden ancestor (`display:none`/`visibility:hidden`), and the result
     * was acknowledged into a composer the user cannot see (`rail css: acks:1`).
     * Computed style is authoritative in a real browser; the inline-style fallback
     * keeps this answerable in a stubbed test environment where layout is absent.
     */
    const st = (cs && el.nodeType === 1) ? cs(el) : (el.style || null);
    if (st && (st.display === 'none' || st.visibility === 'hidden')) {
      return 'the message box (or a container it is inside) is not visible (display:none / visibility:hidden), so the collected results would not be seen';
    }
  }
  if (wantBundle != null && !String(box.value ?? '').includes(wantBundle)) {
    return 'the collected results are no longer in your message box (it holds something else now)';
  }
  return null;
}

async function dismissPending(ids) {
  if (!ids.length) return;
  const set = new Set(ids);
  state.pending = (state.pending ?? []).filter((i) => !set.has(i.id));
  state.pendingActionProblem = null;
  renderPending();
  // §7 — a 503 here (corrupt ledger, non-writer server) used to be swallowed and
  // the row silently returned with no explanation.
  try { await api.dismissPendingLanes(ids, state.current.projectId ?? undefined); }
  catch (err) { state.pendingActionProblem = `could not discard: ${err.message}`; }
  finally { await refreshPending(); }
}

/**
 * BUG-070 — the rail's death list. The DEFAULT view is recent + undismissed so
 * a mass event days ago cannot bury today's real death; "show all" reveals the
 * old and the dismissed. Grouped events (BUG-041 clusters — one host-level
 * moment) collapse to a dated header with a per-cluster dismiss, so yesterday's
 * 50-agent session-limit cut is cleared with one click, not fifty. Every row is
 * DATED (today/yesterday/Aug 10), the reported core defect.
 */
function renderOutcomes() {
  const full = (state.outcomes ?? []).slice().sort((a, b) => b.at - a.at);
  const showAll = state.showAllOutcomes;
  const list = showAll ? full : full.filter(isRecentOutcome);
  // FEAT-153 r4 — an unchanged outcomes poll must not clear()+rebuild the death
  // list (its rows are recreated otherwise, churning the panel every ~2.6s).
  // FEAT-153 r5 — but the rows carry TIME-DERIVED output the array alone misses:
  // datedTime()→dayLabel() renders calendar-relative "today/yesterday/Sep 27",
  // and (default view) isRecentOutcome() filters to a rolling 48h window. A
  // byte-stable death set therefore still changes on screen at a day boundary
  // (a "today 23:50" death must read "yesterday 23:50" after midnight — BUG-070's
  // own guarantee) or when a record ages out of 48h. Fold both into the sig so a
  // boundary crossing invalidates it while an unchanged poll still costs 0 DOM:
  //   · the local calendar day (captures every day-label transition), and
  //   · the exact set of ids passing the 48h filter (captures recent-view churn
  //     AND the "show all (+N)" hidden-count that both views display).
  const dayToken = new Date().toDateString();
  const recentIds = full.filter(isRecentOutcome).map((o) => o.id);
  const osig = JSON.stringify([state.outcomes, showAll, dayToken, recentIds]);
  if (railUnchanged(node.railStopped, osig)) { renderRailSummary(); return; }
  clear(node.railStopped);
  setHidden(node.railStopped, list.length === 0);
  // FEAT-067: keep the top-of-rail summary's "stopped" chip in lockstep with
  // this section — outcomes refresh on their own poll (refreshOutcomes), not
  // renderRail's, so repaint the derived card here too or its count goes stale.
  renderRailSummary();
  if (!list.length) { state.showAllOutcomes = false; return; }
  node.railStopped.classList.add('stopped');

  const head = el('div', { class: 'sub-h', text: outcomesHeadline(list) });
  const dismissAll = el('button', {
    type: 'button', class: 'lnk', text: 'dismiss all',
    title: 'Stop showing these. Persisted server-side — they will not come back on a reload (the ledger on disk is kept).',
  });
  dismissAll.addEventListener('click', () => dismissOutcomeIds(list.map((o) => o.id)));
  head.append(dismissAll);
  // "show all" reveals dismissed + older-than-48h; only offered when some exist.
  const hiddenCount = full.length - full.filter(isRecentOutcome).length;
  if (showAll || hiddenCount > 0) {
    const toggle = el('button', {
      type: 'button', class: 'lnk', text: showAll ? 'show recent' : `show all${hiddenCount ? ` (+${hiddenCount})` : ''}`,
      title: showAll ? 'Back to recent, undismissed deaths only.' : 'Reveal older-than-48h and dismissed deaths (still on disk).',
    });
    toggle.addEventListener('click', () => { state.showAllOutcomes = !showAll; renderOutcomes(); });
    head.append(toggle);
  }
  node.railStopped.append(head);

  const clusters = clusterOutcomes(list); // newest cluster first (list is desc → re-sort asc inside)
  clusters.sort((a, b) => b[0].at - a[0].at);
  let rendered = 0;
  for (const c of clusters) {
    if (rendered >= 12) break;
    if (c.length === 1) {
      const o = c[0];
      node.railStopped.append(el('div', { class: 'brow', title: outcomeEvidence(o) },
        el('span', { class: 'g', text: o.kind === 'provider-error' ? '⛔' : '✖' }),
        el('span', { class: 'bt', text: outcomeDetailLine(o) })));
      rendered++;
      continue;
    }
    // A grouped host-level event: one dated header + a per-cluster dismiss.
    const cause = (() => {
      const pe = c.map((o) => o.providerError).find((p) => !!p);
      if (pe) return `${pe.kind} (${pe.provider})`;
      return [...new Set(c.map((o) => (o.kind === 'unknown' ? 'reason unknown' : o.kind)))].join(', ');
    })();
    const header = el('div', { class: 'brow', title: c.map(outcomeEvidence).join('\n\n') },
      el('span', { class: 'g', text: '⛔' }),
      el('span', { class: 'bt', text: `${c.length} ended together · ${cause} · ${datedTime(c[0].at)}` }));
    const cDismiss = el('button', {
      type: 'button', class: 'lnk', text: 'dismiss',
      title: 'Dismiss this whole event (all its records) at once. Persisted server-side.',
    });
    cDismiss.addEventListener('click', () => dismissOutcomeIds(c.map((o) => o.id)));
    header.append(cDismiss);
    node.railStopped.append(header);
    rendered++;
    for (const o of c.slice(0, 4)) {
      node.railStopped.append(el('div', { class: 'brow sub', title: outcomeEvidence(o) },
        el('span', { class: 'bt', text: `· ${outcomeDetailLine(o)}` })));
    }
    if (c.length > 4) {
      node.railStopped.append(el('div', { class: 'brow sub' },
        el('span', { class: 'bt', text: `· …and ${c.length - 4} more in this event` })));
    }
  }
  if (clusters.length > rendered) {
    node.railStopped.append(el('div', { class: 'brow' },
      el('span', { class: 'bt', text: `…and ${clusters.length - rendered} more event${clusters.length - rendered === 1 ? '' : 's'}` })));
  }
}

/**
 * FEAT-053: one read-only board row. Stays a div (BUG-025: these rows answer
 * nothing), but clicking it opens the ticket MODAL — the full file the agents
 * read — so it carries button semantics for keyboard users too. Opening a
 * ticket is not answering it.
 */
function boardRow(it, glyph) {
  const row = el('div', {
    class: 'brow', role: 'button', tabindex: '0',
    'data-id': it.id,
    title: `${it.id} — open the full ticket (goal, context, activity log)`,
  },
  glyph ? el('span', { class: 'g', text: glyph }) : null,
  el('span', { class: 'bid', text: it.id }),
  el('span', { class: 'bt', text: it.title }),
  it.sev ? el('span', { class: 'bsev', text: it.sev }) : null);
  row.addEventListener('click', () => void openTicketModal(it.id));
  row.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); void openTicketModal(it.id); }
  });
  return row;
}

/**
 * FEAT-153 r4 — anti-flicker gate. A rail section that clear()+rebuilds on every
 * ~2.6s poll churns the DOM even when its inputs are byte-identical, and any row
 * carrying a `rise` entrance animation visibly re-flashes each cycle (the "it keeps
 * flickering every few seconds" report). Each gated renderer computes a signature
 * of the exact inputs it reads and early-returns when it matches the last paint, so
 * an UNCHANGED poll produces ZERO DOM mutations and no animation replay; a genuine
 * change rebuilds exactly as before. The signature rides on the host node.
 */
function railUnchanged(host, sig) {
  if (!host) return true;
  if (host.__railSig === sig) return true;
  host.__railSig = sig;
  return false;
}

function renderRail() {
  const b = state.board;
  const needs = b?.needsYou ?? [];
  const queued = b?.queued ?? [];
  const inflight = b?.inflight ?? [];
  const done = b?.doneToday ?? [];

  // FEAT-153 r2 — the header count badge repeated the FEAT-067 "needs" chip and
  // the grid's own needs cards, three places for one number. With the header now
  // "Board", a needs-count beside it also mislabels the role, so it is retired
  // (the element is kept as a stable anchor, just never populated). The
  // narrow-viewport reopen badge (railBadge) is a distinct surface — kept.
  setText(node.railCount, '');
  setHidden(node.railCount, true);
  setText(node.railBadgeN, String(needs.length));
  node.railBadge.classList.toggle('none', needs.length === 0);

  // FEAT-066: the persistent board entries (topbar pill + rail-head link) — a
  // board is reachable from anywhere in the UI, not just a deep link. Shown for
  // any project that HAS a board; the open-count rides along as a quiet cue.
  paintBoardEntry(b);

  // FEAT-067: the server-derived status summary card at the very top of the rail.
  renderRailSummary();

  // FEAT-126: "Your requests" — the persistent, request-centred status surface,
  // the rail's primary top section above the reused Needs-You cards.
  renderRailRequests();

  // FEAT-153 — the board grid is the primary immediate view (current-session
  // tickets first, the rest of the board de-emphasised); #railNeeds is now the
  // on-demand answer MOUNT for whichever needs-you card the user opened.
  renderBoardGrid(needs, inflight, queued);
  renderAnswerMount(needs);

  // FEAT-079: OBSERVATIONS — automated, read-only findings (WA-consolidation /
  // architecture-recurrence). A distinct, lower-priority lane BELOW the asks:
  // standing attention, never a to-do. Each row is read-only + dismissible.
  const observations = b?.observations ?? [];
  const obsSig = JSON.stringify(observations);
  if (!railUnchanged(node.railObservations, obsSig)) {
    clear(node.railObservations);
    setHidden(node.railObservations, observations.length === 0);
    if (observations.length) {
      node.railObservations.classList.add('observations');
      node.railObservations.append(el('div', { class: 'sub-h', text: 'Observations' }));
      for (const it of observations) node.railObservations.append(observationRow(it));
    }
  }

  // FEAT-153 — queued (owner —) and in-flight (🤖) are now the board grid's own
  // "in progress"/"queued" cards, so the separate read-only lists here would just
  // repeat them below the fold. They are left EMPTY and hidden (their metric
  // chips scroll to the grid instead); nothing is lost — the grid is the one
  // place unresolved tickets live, and the full ordered list is a click to the
  // board. Kept as nodes so the summary strip and older code have stable anchors.
  setHidden(node.railQueued, true);
  setHidden(node.railInflight, true);

  // done today — read-only (the grid is unresolved-only, so done stays its own
  // small list, and remains the "done" chip's scroll target).
  const doneSig = JSON.stringify(done);
  if (!railUnchanged(node.railDone, doneSig)) {
    clear(node.railDone);
    setHidden(node.railDone, done.length === 0);
    if (done.length) {
      node.railDone.classList.add('done');
      node.railDone.append(el('div', { class: 'sub-h', text: 'Done today' }));
      for (const it of done) node.railDone.append(boardRow(it, null));
    }
  }
}

/* ═══════════════════════════════════════ FEAT-153 — the board grid ═══════
 *
 * The rail's PRIMARY surface. The old immediate view was a long vertical list of
 * needs-you answer cards; here the current session's tickets and the rest of the
 * board's unresolved work read as a dense, scannable grid of state cards, so
 * "what is my session doing, and what else is open" is one glance instead of a
 * scroll. Two ideas carry it:
 *
 *   1. WHOSE work — the current session's tickets are shown first and at full
 *      weight; every other unresolved ticket follows, de-emphasised (lower
 *      opacity, full on hover) and collapsible. The session↔ticket fact is not
 *      re-derived here: it is READ from the declarations their owners already
 *      made — the orchard-request bindings (state.requests) and each live lane's
 *      Dispatch attribution (state.snap.running[].ticket), per ARCH-010.
 *   2. WHAT STATE — position (this-session vs board) + a state chip + an accent
 *      ring (needs-you) carry the state; the words stay minimal (id + title).
 *
 * Answering is preserved: a needs-you card opens the SAME answer flow (needsCard)
 * on click, mounted into #railNeeds one ticket at a time.
 */
const GRID_STATE_PRIO = { needs: 0, prog: 1, queued: 2 };
const GRID_STATE_LABEL = { needs: 'needs you', prog: 'in progress', queued: 'queued' };
const RAIL_BOARD_OTHERS_KEY = 'cs.rail.boardOthers';

function boardOthersOpen() {
  try { return localStorage.getItem(RAIL_BOARD_OTHERS_KEY) !== '0'; } catch { return true; }
}
function setBoardOthersOpen(v) {
  try { localStorage.setItem(RAIL_BOARD_OTHERS_KEY, v ? '1' : '0'); } catch { /* private mode — volatile is fine */ }
}

/**
 * A needs-you item the user can ACT on (opens the answer flow), vs one that is
 * read-only board status. Mirrors needsCard's own routing: a stall is advisory;
 * a finding is dismissible; a decision always answerable; a plain ticket only
 * when it actually carries a `## Question` (BUG-025 — a bare 👤 ticket is status,
 * not an ask, and opens the ticket rather than an answer box).
 */
function isAnswerable(it) {
  if (it.kind === 'stall') return false;
  if (it.kind === 'finding' || it.kind === 'decision') return true;
  return !!it.question;
}

/**
 * The set of ticket ids belonging to the OPEN session, read from the two places
 * their owners declared them (never guessed from frame order — ARCH-010):
 *   · state.requests[].tickets — the orchard-request bindings for this session;
 *   · state.snap.running[].ticket — each live lane's charter Dispatch attribution.
 * Guarded by dockIsForeign(): when the open session is not the selected project's,
 * its work is not this board's to claim (the BUG-106 observability rule), so the
 * "this session" grid is simply empty rather than mis-attributing another
 * project's tickets.
 */
function currentSessionTicketIds() {
  const ids = new Set();
  if (dockIsForeign()) return ids;
  for (const r of state.requests ?? []) {
    for (const t of (Array.isArray(r.tickets) ? r.tickets : [])) if (t) ids.add(t);
  }
  const snap = state.snap;
  if (snap && Array.isArray(snap.running)) {
    for (const lane of snap.running) {
      for (const t of (Array.isArray(lane.ticket) ? lane.ticket : [])) if (t) ids.add(t);
    }
  }
  return ids;
}

/**
 * Fold the board's three unresolved lanes into one deduped, priority-ordered set,
 * partitioned into the open session's tickets ("mine") and everything else. A
 * ticket in more than one lane keeps its highest-attention state (needs > prog >
 * queued), reached by inserting in that order and never overwriting.
 */
function boardGridModel(b) {
  const byId = new Map();
  const add = (it, st, answerable, isNeeds) => {
    if (!it || !it.id || byId.has(it.id)) return;
    byId.set(it.id, { it, state: st, answerable, isNeeds });
  };
  for (const it of (b?.needsYou ?? [])) add(it, 'needs', isAnswerable(it), true);
  for (const it of (b?.inflight ?? [])) add(it, 'prog', false, false);
  for (const it of (b?.queued ?? [])) add(it, 'queued', false, false);

  const mineIds = currentSessionTicketIds();
  const all = [...byId.values()];
  const key = (x) => {
    const sev = NC_SEV_RANK[String(x.it.sev || '').toLowerCase()] || 0;
    // needs-you first, then in-progress, then queued; within a state, higher
    // severity first, then a stable id sort so the order never flickers on poll.
    return [GRID_STATE_PRIO[x.state] ?? 9, -sev, x.it.id];
  };
  const cmp = (a, b2) => {
    const ka = key(a), kb = key(b2);
    for (let i = 0; i < ka.length; i++) { if (ka[i] < kb[i]) return -1; if (ka[i] > kb[i]) return 1; }
    return 0;
  };
  const mine = all.filter((x) => mineIds.has(x.it.id)).sort(cmp);
  const others = all.filter((x) => !mineIds.has(x.it.id)).sort(cmp);
  return { mine, others };
}

/**
 * The card's rendered SIGNATURE — everything that decides its DOM. A keyed poll
 * update reuses a card whose signature is unchanged (so it never replays the
 * `rise` entrance and never loses scroll/focus context) and only rebuilds one
 * whose state/title/etc actually moved. Cheap string, compared on data-sig.
 */
function cardSig(x) {
  return `${x.state}|${x.answerable ? 1 : 0}|${x.isNeeds ? 1 : 0}|${x.it.title}|${x.it.sev || ''}|${x.it.kind || ''}`;
}

/**
 * One ticket card in the grid: id, severity mark, title, and — for the non-needs
 * cards — a state chip. FEAT-153 r2: the KIND tag ("BUG") was dropped because it
 * duplicated the id prefix ("BUG-201"). Needs-you emphasis is carried by the
 * amber accent RING alone (not also a "needs you" chip — one signal, not two);
 * the accessible name still says "needs you" for a screen reader.
 */
function ticketCard(x) {
  const { it, state: st, answerable, isNeeds } = x;
  const card = el('button', {
    type: 'button', class: 'tc', 'data-id': it.id, 'data-state': st,
    'data-answerable': answerable ? '1' : null,
    'data-sig': cardSig(x),
    'aria-label': `${it.id} — ${it.title}${isNeeds ? ' — needs you' : ''}`,
    title: `${it.id} — ${it.title}${isNeeds ? (answerable ? ' · click to answer' : ' · needs you (read-only)') : ' · open ticket'}`,
  });
  const top = el('span', { class: 'tc-top' }, el('span', { class: 'tc-id', text: it.id }));
  const mark = ncSevMark(it.sev);
  if (mark) top.append(mark);
  card.append(top);
  card.append(el('span', { class: 'tc-title', text: it.title }));
  // Needs-you is signalled by the ring; every other card gets a quiet state chip.
  if (!isNeeds) card.append(el('span', { class: 'tc-state', 'data-state': st, text: GRID_STATE_LABEL[st] ?? st }));
  card.addEventListener('click', () => {
    if (answerable) openAnswer(it);
    else void openTicketModal(it.id);
  });
  return card;
}

/**
 * Find or create a section (mine/others) in place and refresh its header, label,
 * count and — for the collapsible "others" — its toggle, without discarding the
 * section or its card nodes. Reused across polls so nothing below churns.
 */
function ensureSection(host, cls, label, count, collapsible) {
  let sec = host.querySelector(`.bg-section.${cls}`);
  if (!sec) {
    sec = el('div', { class: `bg-section ${cls}` });
    sec.append(el('div', { class: 'bg-h' },
      el('span', { class: 'bg-lbl' }), el('span', { class: 'bg-n' })),
      el('div', { class: 'bg-grid' }));
  }
  setText(sec.querySelector('.bg-lbl'), label);
  setText(sec.querySelector('.bg-n'), String(count));
  if (collapsible) {
    const open = boardOthersOpen();
    sec.classList.toggle('collapsed', !open);
    let chev = sec.querySelector('.bg-toggle');
    if (!chev) {
      chev = el('button', { type: 'button', class: 'bg-toggle' }, svg('M4 6.5 8 10.5 12 6.5', 9, 'chev'));
      chev.addEventListener('click', () => { setBoardOthersOpen(!boardOthersOpen()); renderRail(); });
      sec.querySelector('.bg-h').append(chev);
    }
    setAttr(chev, 'aria-expanded', String(open));
    setAttr(chev, 'aria-label', open ? 'Collapse' : 'Expand');
    setAttr(chev, 'title', open ? 'Collapse' : 'Expand');
  }
  return sec;
}

/**
 * Reconcile one grid's cards to `items` IN PLACE, keyed by ticket id, reusing
 * `existing` nodes (shared across both sections so a card can migrate between
 * "This session" and "others" without being destroyed). A node whose signature
 * still matches is moved into place untouched (no `rise` replay); a changed one
 * is rebuilt; a vanished one is dropped by the caller from whatever stays in
 * `existing`. Mirrors reconcileNeeds — the same anti-flicker walk.
 */
function reconcileGridCards(grid, items, existing) {
  // Position-indexed keyed reconcile. For each desired item i, ensure the right
  // node sits at grid.children[i]: reuse a matching node (from either section,
  // since `existing` is shared — a card can migrate), rebuild it in place with
  // replaceWith when its signature moved, or mint a new one. We never track a
  // cursor node that we might detach, so a sig-change / removal on the node the
  // walk is standing on can no longer orphan the insert reference (the round-2
  // NotFoundError in insertBefore). Stale nodes left in `existing` are dropped
  // by the caller; any surplus children beyond items.length are stale too.
  for (let i = 0; i < items.length; i++) {
    const x = items[i];
    const id = x.it.id;
    let card = existing.get(id);
    if (card) {
      existing.delete(id);
      if (card.dataset.sig !== cardSig(x)) {
        const fresh = ticketCard(x); // rebuild only the card whose signature moved
        card.replaceWith(fresh);     // in-place swap wherever it currently lives
        card = fresh;
      }
    } else {
      card = ticketCard(x); // genuinely new → plays the `rise` entrance once
    }
    const ref = grid.children[i] || null;
    if (ref !== card) grid.insertBefore(card, ref); // moves an existing node, never recreates
  }
}

/**
 * Paint the board grid. Hidden entirely for a project with no board. When the
 * board exists but nothing is unresolved, a quiet "board is clear" stands in.
 *
 * FEAT-153 r2 — this is a KEYED, in-place update, never a clear()+rebuild. The
 * round-1 render rebuilt the whole subtree on every ~3s poll, which (a) replayed
 * every card's entrance animation (periodic flicker), (b) reset scroll, and (c)
 * combined with a per-section max-height/overflow scroller, trapped the grid in a
 * nested scrollbox inside the taller rail. The rail column (#railPanel) is the
 * ONE scroll surface (the FEAT-139 r4 intent, see `.bg-grid` / `.needs` CSS);
 * reusing nodes here keeps that surface's scroll position and only animates cards
 * that are genuinely new.
 */
function renderBoardGrid(needs /* , inflight, queued */) {
  const host = node.railBoardGrid;
  if (!host) return;
  const b = state.board;
  if (!b || !b.hasBoard) { clear(host); host.hidden = true; return; }
  host.hidden = false;

  const { mine, others } = boardGridModel(b);

  // Empty board: a single quiet message, no sections, no error.
  if (!mine.length && !others.length) {
    for (const s of host.querySelectorAll('.bg-section')) s.remove();
    const msg = needs.length ? 'nothing needs you' : 'board is clear — nothing open';
    let empty = host.querySelector('.bg-empty');
    if (!empty) {
      host.append(el('div', { class: 'bg-empty' },
        el('span', { class: 'ok', text: '✓' }), el('span', { class: 'bg-msg', text: msg })));
    } else {
      empty.querySelector('.bg-msg').textContent = msg;
    }
    return;
  }
  host.querySelector('.bg-empty')?.remove();

  // Every current card, keyed — shared so a ticket can move between sections
  // (e.g. a new request binding pulls it into "This session") without a rebuild.
  const existing = new Map();
  for (const c of host.querySelectorAll('.tc')) existing.set(c.dataset.id, c);

  let mineSec = null, othersSec = null;
  if (mine.length) {
    mineSec = ensureSection(host, 'mine', 'This session', mine.length, false);
    reconcileGridCards(mineSec.querySelector('.bg-grid'), mine, existing);
  } else {
    host.querySelector('.bg-section.mine')?.remove();
  }
  if (others.length) {
    othersSec = ensureSection(host, 'others', mine.length ? 'Elsewhere on the board' : 'Open tickets', others.length, true);
    reconcileGridCards(othersSec.querySelector('.bg-grid'), others, existing);
  } else {
    host.querySelector('.bg-section.others')?.remove();
  }
  // Whatever stayed in `existing` is no longer on the board — drop it.
  for (const stale of existing.values()) stale.remove();

  // Order: "This session" first, then "others". FEAT-153 r4 — appendChild is a
  // MOVE (remove + re-insert), and re-inserting a still-connected subtree RESTARTS
  // every descendant's CSS animation, so an unconditional re-append replayed every
  // `.tc` card's `rise` entrance on every poll (~40 cards, the reported flicker).
  // Only move a section when it is not already at its target index, so an unchanged
  // poll touches nothing and no card re-animates.
  const secs = [mineSec, othersSec].filter(Boolean);
  for (let i = 0; i < secs.length; i++) {
    if (host.children[i] !== secs[i]) host.insertBefore(secs[i], host.children[i] || null);
  }
}

/**
 * The on-demand answer MOUNT. Exactly one needs-you ticket's answer flow lives in
 * #railNeeds at a time; opening a card mounts needsCard(it) here, and it is
 * cleared once the ticket resolves (answered here, or out-of-band on a poll). A
 * card already mounted for the open id is LEFT UNTOUCHED so a background refresh
 * never blows away text the user is mid-typing or steals their focus (the
 * BUG-016 property, now scoped to the single open card).
 */
function renderAnswerMount(needs) {
  const host = node.railNeeds;
  if (!host) return;
  const id = state.openAnswerId;
  if (!id) { clear(host); return; }
  const it = (needs ?? []).find((x) => x.id === id);
  if (!it) { state.openAnswerId = null; clear(host); return; } // resolved out-of-band
  const esc = window.CSS?.escape ? CSS.escape(id) : id;
  if (host.querySelector(`.needs-card[data-id="${esc}"]`)) return; // preserve typing/focus
  clear(host);
  const wrap = el('div', { class: 'answer-open' });
  const close = el('button', { type: 'button', class: 'answer-x', title: 'Close', 'aria-label': 'Close', text: '✕' });
  close.addEventListener('click', closeAnswer);
  wrap.append(el('div', { class: 'answer-bar' },
    el('span', { class: 'answer-lbl', text: 'Answering' }), close));
  const card = needsCard(it);
  card.classList.remove('collapsed'); // always fully open in the mount
  card.dataset.userToggled = '1';     // keep it open across a poll's reconcile
  wrap.append(card);
  host.append(wrap);
  const ta = card.querySelector('textarea.nc-input');
  if (ta) ta.focus();
}

/** Open the answer flow for a needs-you ticket (mounts it into #railNeeds). */
function openAnswer(it) {
  state.openAnswerId = it.id;
  renderAnswerMount(state.board?.needsYou ?? []);
  node.railNeeds?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/** Close the open answer flow without answering. */
function closeAnswer() {
  state.openAnswerId = null;
  renderAnswerMount([]);
}

/**
 * FEAT-067 — paint the top-of-rail status summary card: a Focus line + a counts
 * strip (done · needs · queued · running · stopped), each count a chip that
 * scrolls to its existing rail section. This is a header/INDEX over the sections
 * below, NOT a fifth list.
 *
 * HONESTY (the whole point — the BUG-041/074 "observability must not lie" class):
 * every field is DERIVED LIVE, never a stored/emitted snapshot. `focus` + the
 * done/needs/queued/running counts come from `state.board.summary`, which the
 * server recomputes from the fully-merged board on every poll; the "stopped"
 * count is read straight off the already-fetched `state.outcomes` (its default
 * recent-view, matching what railStopped renders). So a change in the board,
 * running-set, or outcomes moves the card on the next poll — it cannot drift.
 * Reads state directly (no args) so both renderRail and renderOutcomes can
 * repaint it the instant either of their inputs changes.
 */
function renderRailSummary() {
  const host = node.railSummary;
  if (!host) return;
  const pid = state.current.projectId;
  const b = state.board;
  const sum = b?.summary ?? null;
  const needs = b?.needsYou ?? [];
  const inflight = b?.inflight ?? [];
  // "stopped" = live agent outcomes, in the same default recent-undismissed view
  // that railStopped renders (BUG-070) — so the chip's number matches the
  // section it jumps to, never a stale or all-time count.
  const stopped = (state.outcomes ?? []).filter(isRecentOutcome).length;
  // FEAT-067 fast-follow — "live" = the TRUE count of processes running NOW, read
  // straight off the running-set snapshot the strip already polls (state.snap,
  // GET /api/sessions/:id/running). This is DISTINCT from `inflight` (board rows
  // the INDEX marks 🤖): live processes now vs tickets tagged in-flight. HONESTY:
  // with no snapshot there is no session id in hand — omit the chip (null), never
  // fake a zero that could read as "nothing is running" when we simply don't know.
  const snap = state.snap;
  // BUG-106 — omit the live count while the open session is foreign to the
  // selected project: its running processes are not this view's to report, and a
  // number here would attribute one project's live work to another (the same
  // observability lie the strip gate closes above).
  const live = snap && Array.isArray(snap.running) && !dockIsForeign() ? snap.running.length : null;

  // FEAT-153 r4 — skip the full clear()+rebuild when every input this card reads
  // is byte-identical to the last paint (an unchanged poll → zero DOM churn).
  const sig = JSON.stringify([
    pid, b?.hasBoard, sum,
    needs.map((x) => [x.id, x.kind, x.title, x.sev]),
    // FEAT-153 r5 — the FOCUS row reads the focus item's `kind` to decide whether
    // to render the click-to-open link (isTicket gate below), so a same-id
    // same-title kind flip on an in-flight focus item would leave the affordance
    // stale. Capture kind on the inflight tuple too (needs already carries it).
    inflight.map((x) => [x.id, x.kind, x.title]),
    stopped, live,
  ]);
  if (railUnchanged(host, sig)) return;
  clear(host);

  // The card indexes the rail's sections: show it when there's a board to
  // summarize OR deaths to point at OR a live running-set to report (any of these
  // can exist even with no docs/bugs/). None of them → nothing to index → stay
  // quietly out of view.
  if ((!b?.hasBoard || !sum) && stopped === 0 && !live) { host.hidden = true; return; }
  host.hidden = false;

  // --- Focus: the single highest-priority open item (server-picked) ---
  const focus = sum?.focus ?? null;
  const focusRow = el('div', { class: 'rs-focus' });
  focusRow.append(el('span', { class: 'rs-lbl', text: 'Focus' }));
  if (focus) {
    // A 👤 needs-you row (blocked ON the user) is the focus glyph when the focus
    // id is in needsYou; otherwise it's in-flight (🤖). Link honesty: only a
    // real ticket opens the modal — a runtime decision / finding / stall focus
    // has no ticket file, so it stays plain text (a fake "open" affordance would
    // be exactly the lie this feature exists to avoid).
    const fit = needs.find((x) => x.id === focus.id) ?? inflight.find((x) => x.id === focus.id) ?? null;
    const isNeeds = needs.some((x) => x.id === focus.id);
    const isTicket = !!fit && fit.kind !== 'decision' && fit.kind !== 'finding' && fit.kind !== 'stall';
    focusRow.append(el('span', { class: 'rs-glyph', text: isNeeds ? '👤' : '🤖' }));
    const body = [
      el('span', { class: 'rs-id', text: focus.id }),
      el('span', { class: 'rs-ft', text: focus.title }),
    ];
    if (isTicket) {
      const link = el('button', {
        type: 'button', class: 'rs-focus-open', 'data-id': focus.id,
        title: `${focus.id} — open the full ticket`,
      }, ...body);
      link.addEventListener('click', () => void openTicketModal(focus.id));
      focusRow.append(link);
    } else {
      focusRow.append(el('span', { class: 'rs-focus-open static' }, ...body));
    }
  } else {
    focusRow.append(el('span', { class: 'rs-clear', text: 'board is clear — nothing open' }));
  }
  host.append(focusRow);

  // --- counts strip: one chip per section, scrolls to it (or navigates) on click ---
  // Each chip is {label, n, target?, action?, title}: a `target` chip scrolls to a
  // rail section; an `action` chip runs a navigation (deploy → the board portal,
  // where those tickets live). `deployPending` rides the server-derived summary;
  // `live` is client-derived above (omitted when null → no snapshot in hand).
  const c = sum?.counts ?? { needs: 0, observations: 0, queued: 0, inflight: 0, doneToday: 0, deployPending: 0 };
  const deploy = c.deployPending ?? 0;
  const chips = [
    { label: 'done', n: c.doneToday, target: node.railDone, hint: 'jump to the section below' },
    // FEAT-153 — needs / queued / running are all board-grid cards now, so their
    // chips scroll to the grid (the one place those tickets live) rather than to
    // the retired per-lane lists.
    { label: 'needs', n: c.needs, target: node.railBoardGrid, hint: 'jump to the board grid' },
    // FEAT-079 — observations are a distinct read-only count, next to needs so the
    // split (asks vs standing findings) reads at a glance.
    { label: 'observations', n: c.observations ?? 0, target: node.railObservations, hint: 'jump to the section below' },
    { label: 'queued', n: c.queued, target: node.railBoardGrid, hint: 'jump to the board grid' },
    // deploy-pending is scattered across sections (needs/queued/inflight), so it
    // links to the board portal (FEAT-066) where those tickets are all listed.
    { label: 'deploy', n: deploy, action: () => { if (pid) navTickets(pid, null); }, hint: 'open the board' },
    { label: 'running', n: c.inflight, target: node.railBoardGrid, hint: 'jump to the board grid' },
    // "live" (real running processes) sits next to "running" (board 🤖 rows) so the
    // two distinct truths read side by side; it jumps to the running strip up top.
    ...(live === null ? [] : [{ label: 'live', n: live, target: node.strip, hint: 'jump to the running strip' }]),
    { label: 'stopped', n: stopped, target: node.railStopped, hint: 'jump to the section below' },
  ];
  const strip = el('div', { class: 'rs-counts' });
  for (const { label, n, target, action, hint } of chips) {
    const chip = el('button', {
      type: 'button',
      class: `rs-chip st-${label}${n ? '' : ' zero'}`,
      'data-count': String(n),
      'data-target': label,
      title: n ? `${n} ${label} — ${hint}` : `no ${label}`,
    }, el('span', { class: 'rs-n', text: String(n) }), el('span', { class: 'rs-clbl', text: label }));
    if (n && action) {
      chip.addEventListener('click', action);
    } else if (n && target) {
      chip.addEventListener('click', () => {
        if (target.hidden) return; // an empty section isn't rendered — nothing to reach
        target.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      });
    } else {
      chip.disabled = true;
    }
    strip.append(chip);
  }
  host.append(strip);
}

/**
 * FEAT-126 — paint "Your requests": the persistent, request-centred status
 * surface. Each row is a DECLARED user request (the server-owned binding store)
 * joined LIVE against the board + running snapshot into TWO INDEPENDENT CHANNELS:
 *
 *   · execution  — is work RUNNING for this request now (moss ▶ N running / idle
 *                  / stalled), driven by lane/owner presence only.
 *   · completion — is this request DONE (open · N/M verified · done), driven by
 *                  ticket STATUS only.
 *
 * They are two separate elements from two separate reads (see requests-view.js),
 * which is the structural guarantee that "0 lanes running" can never render as
 * "done": completion:'done' requires every bound ticket done regardless of the
 * lane count, and an idle request with any open ticket reads `idle · open`.
 *
 * DEGRADES GRACEFULLY: no declared requests (or an older server with no route) →
 * the section stays hidden and the rail is exactly as it was before this feature.
 * The store holds no status, so this join is recomputed every repaint and cannot
 * go stale. Reads state directly so both renderRail and applySnapshot can repaint
 * it the instant either the board or the running snapshot changes.
 */
function renderRailRequests() {
  const host = node.railRequests;
  if (!host) return;
  // FEAT-153 r4 — the requests join is recomputed every repaint by design; gate the
  // clear()+rebuild so an unchanged poll (same bindings, same board statuses, same
  // running lanes) produces no DOM churn. Captures every input the join reads.
  const rqSig = JSON.stringify([
    state.requests ?? [],
    (state.board?.needsYou ?? []).map((x) => [x.id, x.status]),
    (state.board?.queued ?? []).map((x) => [x.id, x.status]),
    (state.board?.inflight ?? []).map((x) => [x.id, x.status]),
    (state.board?.doneToday ?? []).map((x) => [x.id, x.status]),
    // FEAT-153 r5 — capture l.request too: attributedLanes() (requests-view.js)
    // matches a lane to a request by `lane.request === requestId`, so an in-place
    // change of an existing lane's .request (no length/ticket/state change) is a
    // real join change the old tuple missed. (`owner` is kept though unused — it
    // is a cheap, honest witness of the lane identity.)
    (state.snap?.running ?? []).map((l) => [l.owner, l.ticket, l.state, l.request]),
    // FEAT-153 r6 — DISCRIMINATE snapshot-unknown from snapshot-known-empty. The
    // `?? []` map above collapses snap=null (liveness UNKNOWN → executionOf's coarse
    // fallback reads a bound-but-unconfirmed ticket as `running`) and snap.running=[]
    // (liveness KNOWN-idle → same ticket reads `idle`) to the same `'[]'`, so an
    // empty snapshot that confirms the lane went idle never repaints the exec badge
    // off "N running" (the "0 running must never read as running" observability lie
    // FEAT-126 exists to prevent). Mirror renderRailSummary's `live` (null|count) by
    // encoding whether the snapshot is known at all. (`state.snap` is reset to null
    // on every session switch — BUG-034 — so this is reachable in normal use.)
    Array.isArray(state.snap?.running),
    dockIsForeign(),
  ]);
  if (railUnchanged(host, rqSig)) return;
  renderRequestsInto(host, state.requests ?? [], { board: state.board, snap: state.snap }, {
    el, clear,
    onTicket: (id) => void openTicketModal(id),
    // Step 3 — a 👤 ticket's blocker lives in the REUSED Needs-You rail below; the
    // row's next-step routes there rather than inventing a second blocker surface.
    onNeeds: () => {
      const t = node.railNeeds;
      if (t && !t.hidden) t.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    },
    // Step 4 — jump to the user message that opened this request.
    onSource: (source) => goToSource(source),
  });
}

/**
 * FEAT-126 Step 4 — jump to the message that opened a request. The orchestrator
 * declares `source`; a transcript entry carries a server-generated `uuid`
 * (orchard-transcripts.ts) which the user renderer stamps as `data-uuid`, so an
 * exact uuid match scrolls precisely. Because the orchestrator rarely holds that
 * server uuid, we ALSO accept a short quote: the first user bubble whose text
 * contains `source` wins. No match on screen → a quiet no-op (the window renderer
 * may not have this message loaded); never an error, never a wrong jump.
 */
function goToSource(source) {
  const s = String(source ?? '').trim();
  if (!s) return;
  const pane = node.panes ?? document;
  let target = pane.querySelector?.(`[data-uuid="${(window.CSS?.escape ? CSS.escape(s) : s)}"]`);
  if (!target) {
    for (const b of pane.querySelectorAll?.('.you, [data-uuid]') ?? []) {
      if ((b.textContent ?? '').includes(s)) { target = b; break; }
    }
  }
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    target.classList.add('source-flash');
    setTimeout(() => target.classList.remove('source-flash'), 1600);
  }
}

/**
 * FEAT-066: keep the two persistent board entries — the topbar pill and the
 * rail-head "Open board →" link — pointed at the current project and shown only
 * when it actually has a board (opt-in; no docs/bugs/ → no affordance, no dead
 * link). The open count (needs + queued + in-flight) rides on the pill as a
 * quiet cue; it stays out of the way when there's nothing open.
 */
function paintBoardEntry(b) {
  const pid = state.current.projectId;
  const has = !!(pid && b && b.hasBoard);
  const href = has ? formatTicketsHash({ projectId: pid }) : '#/tickets';
  setHidden(node.boardBtn, !has);
  setHidden(node.railBoardLink, !has);
  if (!has) { setText(node.boardBtnN, ''); return; }
  setAttr(node.boardBtn, 'href', href);
  setAttr(node.railBoardLink, 'href', href);
  const open = (b.needsYou?.length ?? 0) + (b.queued?.length ?? 0) + (b.inflight?.length ?? 0);
  setText(node.boardBtnN, open ? String(open) : '');
}

// The board entries navigate IN PLACE (pushState) so Back returns to the
// session view exactly as it was — the ticket route is a cover, never a teardown.
function openBoardFromChrome(e) {
  const pid = state.current.projectId;
  if (!pid) return;
  if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return; // keep new-tab
  e.preventDefault();
  navTickets(pid, null);
}
node.boardBtn.addEventListener('click', openBoardFromChrome);
node.railBoardLink.addEventListener('click', openBoardFromChrome);

/**
 * BUG-016: reconcile the rendered `.needs-card`s to the fetched `needs` set
 * IN PLACE, rather than clearing + rebuilding the whole rail on every poll.
 * A card whose id is still present is moved (not recreated) so a user mid-typing
 * in its response field keeps their focus and partial text across a background
 * refresh; a card whose id has disappeared (resolved out-of-band — via chat, an
 * INDEX edit, another client, or a runtime decision answered elsewhere) is
 * dropped; a card for a newly-appeared id is freshly built.
 */
/**
 * FEAT-139 — the rail's default view is IMMEDIATE, not a reference list. Show
 * at most the focus item plus the next couple of asks as full interactive
 * cards; everything beyond that collapses to a single one-click "+N more →
 * board" count. No ask is deleted and no route is lost — the complete list is
 * one click away on the board (navTickets). The in-place reconcile below is
 * preserved for the SHOWN set, so a card a user is mid-typing in is left
 * untouched as long as it stays within the cap.
 */
/*
 * FEAT-139 r4 — the cap was 3 (round 6) because each shown card was a ~400px
 * WALL: title + full question + every option + a textarea, all always-on, so
 * three was already too tall and eighteen was untenable. r4 collapses every
 * non-focus card to a one-line scannable UNIT (kind tag + id + a severity MARK
 * + the title), so the reason for the tight cap is gone: eighteen collapsed
 * rows are shorter than three walls AND let the user pattern-match across the
 * whole set — which is exactly what the user asked for. The count valve below
 * still bounds a pathological board (nothing becomes unreachable — the overflow
 * is one click to the board).
 */
const NEEDS_RAIL_CAP = 24;

/** A one-click "N label → board" count row for the collapsed rail sections. */
function railMoreRow(n, label) {
  const pid = state.boardProjectId ?? state.current.projectId;
  const row = el('button', {
    type: 'button', class: 'rail-more',
    title: `${n} ${label} — open the board to see them all`,
  }, el('span', { class: 'rm-n', text: String(n) }),
     el('span', { class: 'rm-l', text: `${label} → board` }));
  row.addEventListener('click', () => { if (pid) navTickets(pid, null); });
  return row;
}

/* ───────────────────── FEAT-139 r4 — scannable rail unit ─────────────────
 *
 * The user's diagnosis: "immediate view … cluttered with too much text; it
 * should be represented in UI elements for pattern-matching processing for
 * humans." Governing rule (same as the header strip): SHAPE carries the
 * category (ticket kind), a MARK carries the state (severity), POSITION carries
 * identity (the id), and text survives only where the words themselves are what
 * is read (the title). So a rail row leads with a kind TAG and a severity MARK
 * — not the words "BUG"/"high" a reader has to parse — and the question and its
 * options collapse behind the row until the user opens it. The focus item stays
 * expanded, so its answer flow is unchanged (one click on an option, exactly as
 * before); every other item is one click to expand and then the same controls.
 */

/** Category of a rail item, as a short hue-independent tag. */
function ncKindOf(it) {
  if (it.gitWrite) return { kt: 'git', tag: 'GIT', word: 'git-write request' };
  if (it.services) return { kt: 'svc', tag: 'SVC', word: 'services request' };
  if (it.kind === 'decision') return { kt: 'dec', tag: 'DEC', word: 'runtime decision' };
  if (it.kind === 'finding') return { kt: 'find', tag: 'FIND', word: 'finding — a decision is asked' };
  if (it.kind === 'observation') return { kt: 'obs', tag: 'OBS', word: 'read-only finding' };
  if (it.kind === 'stall') return { kt: 'stall', tag: 'STALL', word: 'stalled work — advisory' };
  const m = typeof it.id === 'string' && it.id.match(/^([A-Z]+)-/);
  const p = m ? m[1] : null;
  if (p === 'BUG') return { kt: 'bug', tag: 'BUG', word: 'bug' };
  if (p === 'FEAT') return { kt: 'feat', tag: 'FEAT', word: 'feature' };
  if (p === 'ARCH') return { kt: 'arch', tag: 'ARCH', word: 'architecture' };
  return { kt: 'other', tag: p || '•', word: 'ticket' };
}

/** The kind TAG element — category by letters + a per-kind SHAPE (both hue-free). */
function ncKindTag(it) {
  const { kt, tag, word } = ncKindOf(it);
  return el('span', { class: 'nc-kind', 'data-kt': kt, title: `${tag} — ${word}` }, tag);
}

const NC_SEV_RANK = { high: 3, med: 2, medium: 2, low: 1 };

/**
 * Severity as a three-bar signal MARK, not the word. The RANK is the count of
 * filled bars (3/2/1) — a shape/quantity signal that survives greyscale and any
 * colour-vision deficiency; the accent hue is a redundant enhancement, never the
 * sole carrier. Returns null when the item has no severity (decisions, findings).
 */
function ncSevMark(sev) {
  const rank = NC_SEV_RANK[String(sev || '').toLowerCase()] || 0;
  if (!rank) return null;
  const m = el('span', {
    class: 'nc-sevmark', 'data-sev': String(sev).toLowerCase(),
    role: 'img', 'aria-label': `severity ${sev}`, title: `severity: ${sev}`,
  });
  for (let i = 1; i <= 3; i++) m.append(el('span', { class: `bar${i <= rank ? ' on' : ''}` }));
  return m;
}

/**
 * Turn a freshly-built rail card into a collapsible UNIT: prepend the kind tag,
 * replace the severity WORD with the mark, add a chevron, and default to
 * collapsed (the question / options / form / detail are hidden by CSS until the
 * row is opened). `reconcileNeeds` promotes the first card to `.focus` and
 * expands it. A user's own toggle wins over the auto-expand (data-userToggled),
 * so a poll re-render never collapses a row the user just opened.
 */
function makeCollapsible(card, it) {
  const head = card.querySelector('.nc-head');
  if (!head) return card;
  head.prepend(ncKindTag(it));
  const sevEl = head.querySelector('.nc-sev');
  const mark = ncSevMark(it.sev);
  if (sevEl) { sevEl.textContent = ''; if (mark) sevEl.append(mark); }
  const chev = el('button', {
    type: 'button', class: 'nc-chev', 'aria-expanded': 'false', 'aria-label': 'Expand',
    title: 'Expand',
  }, svg('M4 6.5 8 10.5 12 6.5', 9, 'chev'));
  const setState = (expanded) => {
    card.classList.toggle('collapsed', !expanded);
    chev.setAttribute('aria-expanded', String(expanded));
    chev.setAttribute('aria-label', expanded ? 'Collapse' : 'Expand');
    chev.title = expanded ? 'Collapse' : 'Expand';
  };
  const toggle = (e) => {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    card.dataset.userToggled = '1';
    setState(card.classList.contains('collapsed'));
  };
  chev.addEventListener('click', toggle);
  // The whole meta row is a hit target for expand — but never swallow a click
  // on the title (opens the ticket), an option, the textarea or a real button.
  head.addEventListener('click', (e) => {
    if (e.target.closest('button, a, textarea, input, .nc-title')) return;
    toggle(e);
  });
  head.append(chev);
  card.classList.add('collapsed');
  return card;
}

function reconcileNeeds(needs) {
  const container = node.railNeeds;
  // The overflow count is re-derived every render — drop any prior one first so
  // the cursor walk below sees only real cards.
  container.querySelector('.rail-more')?.remove();
  const shown = needs.slice(0, NEEDS_RAIL_CAP);
  const overflow = needs.length - shown.length;

  const existing = new Map();
  for (const c of container.querySelectorAll('.needs-card')) existing.set(c.dataset.id, c);

  if (!shown.length) {
    for (const c of existing.values()) c.remove();
    if (!container.querySelector('.rail-empty')) {
      container.append(el('div', { class: 'rail-empty' },
        el('span', { class: 'ok', text: '✓' }),
        el('span', { text: 'nothing needs you' })));
    }
    return;
  }
  const emptyEl = container.querySelector('.rail-empty');
  if (emptyEl) emptyEl.remove();

  // Walk the fetched order, moving existing cards into place (a no-op DOM-wise
  // when they're already there) and inserting fresh ones for new ids. Moving a
  // node within the SAME live parent (never through a detached fragment) keeps
  // it connected the whole time, so a focused textarea does not blur.
  let cursor = container.firstChild;
  for (const it of shown) {
    const have = existing.get(it.id);
    const target = have ?? needsCard(it);
    if (have) existing.delete(it.id);
    if (target === cursor) cursor = target.nextSibling; // already in place — leave untouched
    else container.insertBefore(target, cursor); // moves/inserts; cursor is still the right anchor
  }
  // Anything left in `existing` is no longer shown (resolved out-of-band, or
  // pushed past the cap) — drop its card. BUG-016's lingering card dies here too.
  for (const stale of existing.values()) stale.remove();

  // FEAT-139 r4 — the first card is the FOCUS: more prominent, and expanded so
  // its answer flow is unchanged (one click on an option). Every other card is
  // collapsed to a scannable unit. A user's own toggle wins (data-userToggled),
  // so a background poll can never collapse a row the user just opened — nor
  // re-expand one they closed.
  const cards = [...container.querySelectorAll('.needs-card')];
  cards.forEach((c, i) => {
    const isFocus = i === 0;
    c.classList.toggle('focus', isFocus);
    // Only the answerable ticket/decision cards are collapsible (they carry a
    // chevron). The read-only variants — findings, board-status, stall — keep
    // their single affordance always visible, so never toggle `collapsed` on a
    // card that has no way to expand again.
    const chev = c.querySelector('.nc-chev');
    if (!chev) { c.classList.remove('collapsed'); return; }
    if (c.dataset.userToggled === '1') return; // respect the user's choice
    c.classList.toggle('collapsed', !isFocus);
    chev.setAttribute('aria-expanded', String(isFocus));
    chev.setAttribute('aria-label', isFocus ? 'Collapse' : 'Expand');
    chev.title = isFocus ? 'Collapse' : 'Expand';
  });

  // The rest of the asks are reference material now — one click to the board.
  if (overflow > 0) container.append(railMoreRow(overflow, 'more need you'));
}

/**
 * BUG-025: a 👤 ticket with NO `question` is board STATUS ("user-owned"),
 * not an ask — it must NOT render a response box (the whole bug this fixes
 * was "a card that asks nothing but 'ok'"). Render it read-only: title +
 * an "open ticket" affordance, no textarea, nothing to submit.
 */
function needsStatusRow(it) {
  /*
   * FEAT-058: "Open ticket" now points at the ticket DASHBOARD route rather
   * than a `file://` URL. A file:// link opened a raw markdown blob (or, in
   * most browsers, nothing at all); this opens the ticket rendered, with its
   * activity log and the write actions — and, because it stays a real anchor
   * with `target=_blank`, it lands in a SECOND TAB, leaving this session tab
   * live. The tooltip still names the file on disk.
   */
  const pid = state.boardProjectId ?? state.current.projectId;
  const openLink = el('a', {
    class: 'nc-send',
    href: formatTicketsHash({ projectId: pid, ticketId: it.id }),
    target: '_blank',
    rel: 'noopener',
    text: 'Open ticket',
    title: it.file ?? 'ticket file not found on disk',
  });
  const card = el('div', { class: 'needs-card status', 'data-id': it.id, 'data-kind': 'status' },
    el('div', { class: 'nc-head' },
      el('span', { class: 'nc-id', text: it.id }),
      el('span', { class: 'nc-sev', text: it.sev || '' })),
    el('div', { class: 'nc-title', text: it.title }),
    el('div', { class: 'nc-form' },
      el('div', { class: 'nc-acts' },
        el('span', { class: 'nc-err', text: '👤 board status — no question raised' }),
        openLink)));
  wireTitleModal(card, it); // FEAT-053 — the title opens the full ticket in place
  return card;
}

/**
 * FEAT-079: a PROMOTED finding (kind:'finding' with a `question`) — a finding
 * that crossed from a bare read-only Observation into a real ASK because a
 * writer attached a concrete decision ("file ARCH-### for this class, or keep
 * patching?"). It earns a place on the DECISION rail (needsYou); a bare finding
 * without a `question` never reaches here — it renders in the Observations lane
 * via `observationRow`. The ask is shown prominently; the evidence rides under
 * it; Dismiss still acks it server-side (a promotion the user chooses not to act
 * on stays dismissed until a later pass re-raises it with a newer date).
 */
function needsFindingRow(it) {
  const pid = state.boardProjectId ?? state.current.projectId;
  const isArch = typeof it.id === 'string' && it.id.startsWith('arch-recurrence-');
  const label = isArch ? 'Architecture decision' : 'WA consolidation';
  const err = el('span', { class: 'nc-err', text: '👤 finding — a decision is asked' });
  const dismiss = el('button', {
    class: 'nc-send', type: 'button', text: 'Dismiss',
    title: 'Acknowledge — stays dismissed unless a later pass re-detects it',
  });
  const card = el('div', { class: 'needs-card finding promoted', 'data-id': it.id, 'data-kind': 'finding' },
    el('div', { class: 'nc-head' },
      el('span', { class: 'nc-id', text: label }),
      el('span', { class: 'nc-sev', text: '' })),
    el('div', { class: 'nc-title', text: it.title }),
    // The concrete ASK is the point of a promoted finding — show it first; the
    // evidence detail follows as supporting context.
    it.question ? el('div', { class: 'nc-question ask', text: it.question }) : null,
    it.detail ? el('div', { class: 'nc-detail', text: it.detail }) : null,
    el('div', { class: 'nc-form' },
      el('div', { class: 'nc-acts' }, err, dismiss)));
  dismiss.addEventListener('click', async () => {
    dismiss.disabled = true;
    // Optimistic: drop the row now; the board refresh reconciles the truth.
    card.remove();
    if (state.board) state.board.needsYou = (state.board.needsYou ?? []).filter((x) => x.id !== it.id);
    renderRail();
    try {
      await api.dismissFinding(pid, it.id);
      say(`dismissed finding ${it.id} — returns only if a later consolidation pass re-detects it`);
    } catch (e) {
      // Reconcile: the refresh re-adds the row if the ack never landed.
      say(`could not dismiss ${it.id}: ${e.message}`, true);
    }
    void refreshRail(true);
  });
  return card;
}

/**
 * BUG-046: a ⚠ stalled-work card — ADVISORY, read-only, evidence-carrying.
 * Computed fresh from the running set on every board read; the moment the row
 * recovers (or ends) the card stops being produced, so there is nothing to
 * dismiss and no action to offer. Deliberately actionless (ARCH-002): the
 * evidence asks a human to look; acting on it requires ground truth the card
 * itself does not have.
 */
/**
 * FEAT-079: an OBSERVATIONS-lane row — an automated, read-only finding
 * (WA-consolidation FEAT-047, or architecture-recurrence FEAT-056). NOT an ask:
 * it carries no question and no response field, exactly like a finding on the
 * decision rail used to, but it now lives in its own lower-priority lane so it
 * cannot dilute "needs you". The one affordance is Dismiss, which acks it
 * server-side (dismissArchFinding / dismissConsolidationFinding); the row then
 * stays gone until a LATER pass re-detects the finding with a newer date.
 */
function observationRow(it) {
  const pid = state.boardProjectId ?? state.current.projectId;
  // Arch-recurrence ids are minted `arch-recurrence-*`; everything else here is
  // a WA-consolidation finding. Label + provenance glyph follow suit.
  const isArch = typeof it.id === 'string' && it.id.startsWith('arch-recurrence-');
  const label = isArch ? 'Architecture review' : 'WA consolidation';
  const provenance = isArch ? '📐 architecture finding — read-only' : '🧭 methodology finding — read-only';
  const err = el('span', { class: 'nc-err', text: provenance });
  const dismiss = el('button', {
    class: 'nc-send', type: 'button', text: 'Dismiss',
    title: 'Acknowledge — stays dismissed unless a later pass re-detects it',
  });
  const card = el('div', { class: 'needs-card status finding observation', 'data-id': it.id, 'data-kind': 'observation' },
    el('div', { class: 'nc-head' },
      el('span', { class: 'nc-id', text: label }),
      el('span', { class: 'nc-sev', text: '' })),
    el('div', { class: 'nc-title', text: it.title }),
    it.detail ? el('div', { class: 'nc-question', text: it.detail }) : null,
    el('div', { class: 'nc-form' },
      el('div', { class: 'nc-acts' }, err, dismiss)));
  dismiss.addEventListener('click', async () => {
    dismiss.disabled = true;
    // Optimistic: drop the row now; the board refresh reconciles the truth.
    card.remove();
    if (state.board) state.board.observations = (state.board.observations ?? []).filter((x) => x.id !== it.id);
    renderRail();
    try {
      await api.dismissFinding(pid, it.id);
      say(`dismissed observation ${it.id} — returns only if a later pass re-detects it`);
    } catch (e) {
      say(`could not dismiss ${it.id}: ${e.message}`, true);
    }
    void refreshRail(true);
  });
  return card;
}

function needsStallRow(it) {
  const card = el('div', { class: 'needs-card status stall', 'data-id': it.id, 'data-kind': 'stall' },
    el('div', { class: 'nc-head' },
      el('span', { class: 'nc-id', text: '⚠ stalled work' }),
      el('span', { class: 'nc-sev', text: '' })),
    el('div', { class: 'nc-title', text: it.title }),
    it.detail ? el('div', { class: 'nc-question', text: it.detail }) : null,
    el('div', { class: 'nc-form' },
      el('div', { class: 'nc-acts' },
        el('span', { class: 'nc-err', text: 'advisory — clears itself if progress resumes' }))));
  return card;
}

function needsCard(it) {
  // BUG-046: a stalled-work advisory is read-only and actionless — its own row.
  if (it.kind === 'stall') return needsStallRow(it);
  // FEAT-047: a consolidation finding is read-only + dismissible — its own row.
  if (it.kind === 'finding') return needsFindingRow(it);
  // BUG-025: only an item that actually carries a `question` gets a response
  // field. A bare 👤 ticket (board status, no `## Question` section) has
  // none — it is read-only, not answerable.
  if (!it.question) return needsStatusRow(it);
  const pid = state.boardProjectId ?? state.current.projectId;
  // FEAT-029: a runtime-raised decision reads as '👤 decision' rather than a
  // ticket sev, and — when it carries options — offers them as buttons.
  const isDecision = it.kind === 'decision';
  // FEAT-108 r3 — a git-write PERMISSION request is a decision that carries a
  // gitWrite payload: an agent asked to commit/push and the user approves or
  // declines with one click. It reads as a permission ask (not a generic
  // decision) and offers ONLY Allow/Decline — no free-text box, since the
  // grant is a yes/no. Approving ("Allow") is what mints the runtime grant.
  const isGitWrite = isDecision && !!it.gitWrite;
  // FEAT-112 — a service-sidecar PROPOSAL: an agent proposed a set of services and
  // the user approves or declines with one click. Like git-write, it offers ONLY
  // Allow/Decline (no free-text) and approving ("Allow") writes the services into
  // the project settings. The proposing agent never applies its own proposal.
  const isServices = isDecision && !!it.services;
  const opts = Array.isArray(it.options) ? it.options : [];
  const input = el('textarea', { class: 'nc-input', rows: '2', placeholder: 'Your response…', 'aria-label': `Response for ${it.id}` });
  const err = el('span', { class: 'nc-err' });
  const send = el('button', { class: 'nc-send', type: 'button', text: 'Respond' });
  const card = el('div', { class: `needs-card${isDecision ? ' decision' : ''}${isGitWrite ? ' git-write' : ''}${isServices ? ' services' : ''}`, 'data-id': it.id, 'data-kind': it.kind || 'ticket' },
    el('div', { class: 'nc-head' },
      el('span', { class: 'nc-id', text: isGitWrite ? '🔑 git-write request' : isServices ? '🧩 services request' : isDecision ? '👤 decision' : it.id }),
      el('span', { class: 'nc-sev', text: isDecision ? '' : (it.sev || '') })),
    el('div', { class: 'nc-title', text: it.title }));
  // Show exactly what would be added, so the user approves in context.
  if (isServices && Array.isArray(it.services.services)) {
    const list = el('div', { class: 'nc-question' },
      document.createTextNode(it.services.services.map((s) => `${s.name} → ${s.image}`).join('  ·  ')));
    card.append(list);
  }
  // BUG-025: a ticket's `## Question` text can differ from the ticket H1
  // title — show it explicitly so the card asks something concrete. A
  // decision's `question` already equals `title` (server sets both), so
  // this only fires for a ticket that posed its own question.
  if (!isDecision && it.question && it.question !== it.title) {
    card.append(el('div', { class: 'nc-question', text: it.question }));
  }

  // A submit that removes the card optimistically and reconciles on refresh —
  // shared by the free-text Respond button and each option button.
  const submit = async (answer) => {
    const text = (answer ?? '').trim();
    if (!text) { input.focus(); return; }
    send.disabled = true;
    err.textContent = '';
    // Optimistic: drop the card now; the board refresh reconciles the truth.
    card.classList.add('going');
    card.remove();
    // Keep in-memory board honest so a same-project reselect doesn't flash it back.
    if (state.board) state.board.needsYou = (state.board.needsYou ?? []).filter((x) => x.id !== it.id);
    renderRail();
    try {
      const r = await api.answerBoard(pid, it.id, text);
      // FEAT-090: answering a TICKET records the decision to the board and hands
      // it back via the answered-awaiting lane — it dispatches NOTHING. A live
      // session that RAISED a decision is the exception (that is a reply it asked
      // for), so only that path reports a delivery.
      const label = isDecision
        ? (r.delivered ? 'delivered to the raising session' : 'recorded (session not live)')
        : `recorded to ${it.id} — awaiting handover`;
      say(`answered ${it.id} — ${label}`);
    } catch (e) {
      // Reconcile: the refresh re-adds the card if the answer never landed.
      say(`could not record answer for ${it.id}: ${e.message}`, true);
    }
    void refreshRail(true);
  };

  if (opts.length) {
    const row = el('div', { class: 'nc-opts' });
    for (const opt of opts) {
      const b = el('button', { class: 'nc-opt', type: 'button', text: opt });
      b.addEventListener('click', () => void submit(opt));
      row.append(b);
    }
    card.append(row);
  }

  // A git-write request and a services proposal are answered ONLY by their
  // Allow/Decline buttons (above) — no free-text form, so approving is
  // unambiguously "Allow".
  if (!isGitWrite && !isServices) {
    card.append(el('div', { class: 'nc-form' },
      input,
      el('div', { class: 'nc-acts' }, err, send)));
    send.addEventListener('click', () => void submit(input.value));
    input.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); void submit(input.value); }
    });
  } else {
    card.append(el('div', { class: 'nc-form' }, el('div', { class: 'nc-acts' }, err)));
  }
  wireTitleModal(card, it); // FEAT-053 — the title opens the full ticket in place
  return makeCollapsible(card, it);
}

/* ─────────────────────────────── FEAT-053 — rail ticket modal ────────────
 *
 * Clicking any rail row opens the ticket's FULL markdown in a modal — the same
 * file the dispatched agents read (goal, context pack, verification bar, the
 * append-only Activity log), rendered by FEAT-058's ticketDetailNode
 * (`{compact:true}`: read-only, no write actions — opening is not answering,
 * BUG-025). No summary layer in between; a missing ticket degrades to an
 * honest message. Esc closes (top of the Esc ladder); the body scrolls with a
 * plain max-height + overflow-y and deliberately NO overscroll-behavior
 * (BUG-032: `contain` swallows wheel chaining at the scroll boundary).
 */
const TICKET_ID_RE = /^[A-Z]+-\d+$/;

function ticketModalOpen() {
  return node.ticketModal && !node.ticketModal.hidden;
}

function closeTicketModal() {
  if (!node.ticketModal) return;
  node.ticketModal.hidden = true;
  clear(node.ticketModalBody);
}

async function openTicketModal(id) {
  const pid = state.boardProjectId ?? state.current.projectId;
  if (!pid || !node.ticketModal) return;
  node.ticketModal.hidden = false;
  clear(node.ticketModalBody).append(el('div', { class: 'tv-empty', text: `loading ${id}…` }));
  try {
    const t = await api.ticket(pid, id);
    if (!ticketModalOpen()) return; // closed while loading
    clear(node.ticketModalBody).append(ticketDetailNode(t, { compact: true }));
  } catch (err) {
    if (!ticketModalOpen()) return;
    // Honest degrade: the row named a ticket the board no longer has a file
    // for (deleted, renamed, drifted INDEX). Say so; never crash the rail.
    clear(node.ticketModalBody).append(el('div', { class: 'tv-empty' },
      el('b', { text: `Cannot open ${id}.` }),
      document.createTextNode(` ${err.message} — the row may be stale; the board refreshes on its next poll.`)));
  }
}

$('#ticketModalClose').addEventListener('click', closeTicketModal);
$('#ticketModalBack').addEventListener('click', closeTicketModal);

/**
 * FEAT-053: make a needs-card's title the modal affordance (all rail row types
 * open the full ticket). Only for items that ARE tickets on this board —
 * runtime decisions and consolidation/arch findings have no ticket file, and a
 * fake affordance would be a lie.
 */
function wireTitleModal(card, it) {
  if (it.kind === 'decision' || it.kind === 'finding' || it.kind === 'stall') return;
  if (!TICKET_ID_RE.test(it.id)) return;
  const title = card.querySelector('.nc-title');
  if (!title) return;
  title.classList.add('nc-open');
  title.setAttribute('role', 'button');
  title.setAttribute('tabindex', '0');
  title.title = `${it.id} — open the full ticket (goal, context, activity log)`;
  title.addEventListener('click', () => void openTicketModal(it.id));
  title.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); void openTicketModal(it.id); }
  });
}

// Narrow viewport: the badge opens the rail as an overlay; a click outside closes it.
node.railBadge.addEventListener('click', () => {
  node.rail.classList.toggle('open');
});
document.addEventListener('click', (e) => {
  if (!node.rail.classList.contains('open')) return;
  if (node.rail.contains(e.target) || node.railBadge.contains(e.target)) return;
  node.rail.classList.remove('open');
});

/* -------------------------------------------- BUG-016: live rail poll loop */
/*
 * The rail's whole point is state honesty — its cards ARE the board's current
 * unresolved 👤 set, not a snapshot from the last submit or reload. Poll the
 * board on a modest interval so an out-of-band resolution (chat, an INDEX edit,
 * another client, a runtime decision answered elsewhere) leaves the panel
 * without the user having to reload, and a newly-raised item appears the same
 * way. `reconcileNeeds` (above) makes this safe to run in the background: it
 * moves/removes cards rather than rebuilding them, so a card the user is
 * mid-typing in is left alone as long as its item is still open.
 */
const RAIL_POLL_MS = 5000;
let railPollTimer = null;

function clearRailPoll() {
  if (railPollTimer) { clearTimeout(railPollTimer); railPollTimer = null; }
}

function scheduleRailPoll() {
  clearRailPoll();
  // Paused while the tab/rail is not visible — no point polling a background
  // tab; visibilitychange below catches up immediately on return.
  if (document.hidden || !state.current.projectId) return;
  railPollTimer = setTimeout(() => { void pollRail(); }, RAIL_POLL_MS);
}

async function pollRail() {
  // Self-healing: a throw anywhere in a poll cycle (e.g. a render bug in
  // refreshRail → renderRail) must NEVER kill the loop. The finally always
  // re-arms the next poll, so one bad render degrades to a logged blip, not a
  // permanently frozen rail (FEAT-153 round-2: a reconcile NotFoundError used to
  // propagate out here and stop scheduleRailPoll forever).
  try {
    if (!document.hidden && state.current.projectId) {
      await refreshRail(true);
      // FEAT-057: the death ledger rides the SAME poll — an agent that dies while
      // nothing else is happening (the whole point of the feature) must surface
      // without any other traffic to piggyback on.
      await refreshOutcomes();
      // ARCH-017 — held lane results ride the SAME poll, for the same reason the
      // death ledger does: a background fan-out that settles while nothing else
      // is happening is precisely the case this feature exists for, so it must
      // surface with no other traffic to piggyback on.
      await refreshPending();
    }
  } catch (err) {
    console.error('pollRail cycle failed (loop kept alive):', err);
  } finally {
    scheduleRailPoll();
  }
}

document.addEventListener('visibilitychange', () => {
  if (document.hidden) { clearRailPoll(); return; }
  // Coming back into view: refresh right away rather than waiting out a stale
  // interval — this is the server-restart-while-tab-was-away case from BUG-016.
  void refreshRail(true);
  scheduleRailPoll();
});
window.addEventListener('focus', () => { void refreshRail(true); });

function startNew(projectId) {
  saveDraft(state.current); // BUG-083 — keep the outgoing session's draft before we leave it
  selectProject(projectId, { quiet: true });
  // No override — model, effort, budget, permissionMode, allowed/disallowed
  // tools — survives into a new session, same-project or not. Each new
  // session starts honestly from the project's own default; the user
  // re-arms whatever they want per-session.
  resetOverrides(ovrPending()); // BUG-198 round 2 — a fresh pending token: persisted only once ITS session-init names the id
  state.current = { projectId, encodedDir: null, sessionId: null, title: 'New session', os: 'linux' };
  state.openProjectId = projectId; // BUG-106 — the pending-new dock is owned by this project
  state.pendingNew = projectId; // FEAT-073 — this drives the derived pending-new row
  state.forkFrom = null;
  // FEAT-073: expand the owning project so its pending-new row is actually on
  // screen (the row lives in the group's kids, hidden while collapsed). Loading
  // its history in the background lets the real row take over seamlessly once the
  // first message lands.
  state.expanded.add(projectId);
  saveExpanded();
  void loadSessions(projectId);
  clearPendingDelivery(); // BUG-079: no outgoing session's pending delivery may leak into the new one
  syncUrl('push'); // BEFORE resetTranscript, whose repaints replace-sync the URL
  followCurrent(); // no session on screen any more: drops every watch
  closeSocket();
  // BUG-129/BUG-150 — resetTranscript re-binds ownership and restores this
  // project's pending-new undelivered rows (same key) by construction; judge the
  // handed-off outbox it hands back.
  const adoptedOutbox = resetTranscript();
  restoreDraft(state.current); // BUG-083 — this project's pending-new draft (empty if none)
  judgeAdoptedOutbox(adoptedOutbox);
  node.box.hidden = false;
  node.frozen.hidden = true;
  node.agentDone.hidden = true;
  paintCrown();
  paintModelBtn();
  paintModelPop();
  renderTree();
  node.prompt.focus();
}

/* ------------------------------------------------------------- live strip */


/* ═══════════════════ ARCH-001 phase 2 / BUG-034 — THE STRIP IS A RENDERER ══
 *
 * WHAT CHANGED, AND WHY IT IS A DESIGN CHANGE RATHER THAN A SIXTH PATCH.
 *
 * This strip used to DERIVE what was running: a union of `agent-*` event
 * fragments it happened to receive, `replayAgents()` on attach, `state.busy`,
 * the mtime live list, a live-bridge override and two client-side sweeps. Every
 * input is lossy, so the answer was wrong in both directions and depended on
 * when you looked — three dispatched subagents showing as none (BUG-034), and a
 * tab that lived through a server restart still counting a killed agent's
 * timers up to 0:53 while the server had no such state at all. Five patches
 * (BUG-004/017/020/030/033) treated the arithmetic; the defect was that the
 * client was answering a question it cannot answer.
 *
 * Now: THE SERVER ANSWERS, THIS RENDERS. `state.snap` is the server-authored
 * running-set snapshot (pushed on every change, fetched on attach and on a
 * poll). Rows are reconciled to it in place. Deltas still arrive and still
 * drive threads and "ran" rows — they no longer decide what is ALIVE.
 *
 * WHAT THAT BUYS, stated as the invariants it must never break:
 *  - BUG-030 (◐ only while a live process can be behind it): a row exists only
 *    while the SERVER's authority still vouches for it. Strictly stronger than
 *    the client-side sweeps, which had to infer death from silence.
 *  - BUG-034 (correct AND empty without a reload): an empty snapshot is a real
 *    answer and empties the strip. That is the whole indictment in the ticket.
 *  - BUG-004 (never resurrect finished work): nothing here reads history. A row
 *    is drawn from the current snapshot or not at all.
 *  - BUG-033 (honest clock): `startedAt`/`turn.since` are the SERVER's, and
 *    `null` renders "—". This tab never stamps a start time it did not observe.
 *  - BUG-020 (reattach shows in-flight agents): the handshake pushes a snapshot,
 *    so a reattached tab is correct immediately rather than by luck.
 *
 * THE MAIN ROW — DECIDED (BUG-034 asked for a decision, not a guess): the strip
 * KEEPS a `main` row, and it is authored by the same snapshot as every other
 * row (`turn.running` / `turn.since` straight from the authority). The crown
 * (FEAT-040 `#sessStatus`) stays the session-STATE affordance —
 * thinking/streaming/detached/reconnecting/idle — and is deliberately not
 * duplicated here. Rationale: the strip answers "what work is in flight" and
 * the orchestrator's own turn IS work in flight; removing it would leave the
 * user's original report ("should be main (you)") unanswered and make the strip
 * silent during the most common case of all (a turn with no subagents). The two
 * surfaces are kept consistent by construction — `paintSessStatus()` is called
 * on every snapshot apply, and both read the same server truth: if the snapshot
 * says no turn is running, the strip has no main row AND the crown cannot say
 * "Thinking…".
 */

/**
 * Elapsed for one row, or an honest "—".
 *
 * BUG-033's rule, now with the only start time that was ever legitimate: the
 * SERVER's. A duration may be shown only when something actually knows when the
 * work began. Reattaching to a turn that started before this tab existed used
 * to stamp `Date.now()` and count up from there, so a session wedged for three
 * days displayed a confident "1:08" — a number about the TAB presented as a
 * fact about the turn. A null/absent `startedAt` renders "—", forever if need be.
 */
function rowElapsed(startedAt, stale = false) {
  if (!Number.isFinite(startedAt) || startedAt <= 0) return '—';
  // Frozen at the moment we lost the ability to check: a clock that keeps
  // ticking while nothing can confirm the work is still running is the same
  // fabricated stopwatch in slower motion.
  const at = stale ? (state.snapStaleAt || Date.now()) : Date.now();
  return mmss(at - startedAt);
}

/**
 * Can the current answer still be vouched for? False the moment the socket
 * drops or the poll cannot reach the server — see `state.snapStale`.
 */
function snapshotIsStale() {
  return !!(state.snapStale || state.dropped);
}

/** Note that nothing can confirm the running set any more (freezes the rows). */
function markSnapshotStale() {
  if (state.snapStale) return;
  state.snapStale = true;
  state.snapStaleAt = Date.now();
  renderStrip();
}

/**
 * The rows to draw, from the SERVER's snapshot. Never from `state.agents`.
 *
 * The one case with no snapshot is a tab whose own send has been acked but
 * whose first snapshot has not landed yet (or an older server without the
 * route). It draws a `main` row from FIRST-HAND knowledge — this tab started
 * this turn — with the same honest clock rules, and nothing else. That is not
 * the old union: it never invents a row for an agent, which is the thing this
 * tab genuinely cannot know.
 */
function stripModel() {
  const snap = state.snap;
  if (snap && Array.isArray(snap.running)) {
    const stale = snapshotIsStale();
    return snap.running.map((r) => ({
      key: r.id,
      row: r.row,
      // FEAT-154 (round 6) — a background SHELL is labelled plainly (the engine's
      // `local_bash` name means nothing to a reader), and is stoppable from here.
      ty: r.row === 'main' ? 'main'
        : (r.row === 'tool' && r.background === true ? 'background command' : (r.label || 'agent')),
      stoppable: r.row === 'tool' && r.background === true,
      de: r.row === 'main' ? (state.current.title ?? 'working') : (r.description || r.lastTool || ''),
      startedAt: r.startedAt,
      stale,
      // BUG-046 — the server's evidence state for the row. Absent (older
      // server) reads as running. A stalled row is still a member of the
      // running set — it is rendered ⚠ with its evidence, never dropped.
      stalled: r.state === 'stalled',
      stallWhy: r.stall?.checked ?? '',
      // BUG-187 — the broker's own verdict that this lane cannot run (blocked:
      // its tool calls are refused, nobody is attached) or was stopped. Such a
      // row is NEVER drawn as running.
      blocked: r.state === 'blocked',
      stopped: r.state === 'stopped',
      stateWhy: r.stateDetail ?? '',
    }));
  }
  if (state.busy) {
    return [{
      key: 'main',
      row: 'main',
      ty: 'main',
      de: state.current.title ?? 'working',
      startedAt: state.turnStartUnknown ? null : (state.turnStartedAt || null),
    }];
  }
  return [];
}

function renderStrip() {
  // BUG-106 — the strip describes the OPEN session's live work. When the user has
  // selected a different project in the sidebar, that work is foreign to the view:
  // present nothing (the same absent end-state resetTranscript produces) rather
  // than attribute one project's running agents to another. state.snap and the
  // socket are kept, so switching back restores the real rows immediately.
  if (dockIsForeign()) {
    clear(node.stripRows);
    node.stripSum.textContent = '';
    node.stripClk.textContent = '—';
    node.strip.hidden = true;
    return;
  }
  const model = stripModel();
  // Stays visible while inside a subagent so switching is one click and the
  // other agents remain in peripheral view.
  if (!model.length && state.viewing === 'main') {
    // BUG-033: EMPTY it, don't just hide it. Leaving the last "◐ main · 3:07"
    // row in the hidden DOM keeps a stale running claim alive in the document
    // (assertable, screenshot-able, and one CSS change away from visible) for a
    // turn that is over. Nothing may say "running" once nothing is.
    clear(node.stripRows);
    // …and the SUMMARY with it. "3 agents running · 0:07" left behind in the
    // hidden strip is the same stale claim in text form — assertable,
    // screenshot-able, and one CSS change from visible.
    node.stripSum.textContent = '';
    node.stripClk.textContent = '—';
    node.strip.hidden = true;
    return;
  }
  if (!model.length && state.viewing !== 'main') {
    node.strip.hidden = false;
    clear(node.stripRows);
    const back = el('button', { type: 'button', class: 'lag main', 'data-thread': 'main', 'aria-current': 'false', title: 'Back to the main thread' },
      el('span', { class: 'ty', text: 'main' }),
      el('span', { class: 'de', text: state.current.title ?? '' }),
      el('span', { class: 'gl', text: '·' }),
      el('span', { class: 'el', text: '—' }));
    back.addEventListener('click', () => showThread('main'));
    node.stripRows.append(back);
    for (const [key, th] of state.threads) {
      if (key === 'main') continue;
      const row = el('button', { type: 'button', class: 'lag wait', 'data-thread': key, 'aria-current': String(state.viewing === key), title: `Open ${th.agentType}'s thread` },
        el('span', { class: 'ty', text: th.agentType || 'agent' }),
        el('span', { class: 'de', text: th.description || '' }),
        el('span', { class: 'gl', text: '✓' }),
        el('span', { class: 'el', text: '—' }));
      row.addEventListener('click', () => void viewAgent(key));
      node.stripRows.append(row);
    }
    node.stripSum.textContent = 'viewing an agent thread';
    node.stripClk.textContent = '—';
    return;
  }
  node.strip.hidden = false;
  clear(node.stripRows);

  /*
   * Every row in the model is, by construction, something the SERVER says is
   * running right now — so every row gets ◐. There is no "wait" state to infer
   * any more: a row that is not running is simply absent from the snapshot.
   */
  const rows = model.map((r) => ({
    key: r.key,
    // A row whose answer cannot be checked any more keeps its place but loses
    // its running mark: ◐ is a claim, and there is nothing left to back it.
    // BUG-046: a STALLED row keeps its place too, but wears ⚠ instead of ◐ —
    // "running" is a claim the server's evidence no longer backs, and "gone"
    // would assert an end nobody proved. The reason rides the tooltip.
    cls: r.stale ? (r.row === 'main' ? 'lag main wait' : 'lag wait')
      : r.blocked ? 'lag blocked'
        : r.stopped ? 'lag stopped'
          : r.stalled ? (r.row === 'main' ? 'lag main stall' : 'lag stall')
            : (r.row === 'main' ? 'lag main run' : 'lag run'),
    ty: r.ty,
    de: r.blocked || r.stopped ? (r.stateWhy || (r.blocked ? 'blocked — Orchard is not attached' : 'stopped')) : r.de,
    gl: r.stale ? '·' : (r.blocked ? '⊘' : r.stopped ? '■' : (r.stalled ? '⚠' : '◐')),
    el: rowElapsed(r.startedAt, r.stale),
    stallWhy: r.blocked || r.stopped ? (r.stateWhy || (r.blocked ? 'blocked' : 'stopped'))
      : r.stalled ? (r.stallWhy || 'no progress evidence for this row') : '',
    notRunning: r.blocked || r.stopped,
    stale: r.stale,
    stoppable: r.stoppable === true,
  }));
  for (const r of rows) {
    const row = el('button', {
      type: 'button',
      class: r.cls,
      'data-thread': r.key,
      'aria-current': String(state.viewing === r.key),
      title: r.notRunning
        ? r.stallWhy
        : r.stallWhy
          ? `⚠ stalled — ${r.stallWhy}`
          : (r.key === 'main' ? 'Back to the main thread' : `Open ${r.ty}'s thread`),
    },
      el('span', { class: 'ty', text: r.ty }),
      el('span', { class: 'de', text: r.de }),
      el('span', { class: 'gl', text: r.gl }),
      el('span', { class: 'el', text: r.el }));
    row.addEventListener('click', () => (r.key === 'main' ? showThread('main') : void viewAgent(r.key)));
    if (r.stoppable && !r.notRunning && !r.stale) {
      // FEAT-154 (round 6) — a background command keeps the session alive but is
      // not an agent, so it no longer colours the list; it is listed here with a
      // stop control instead, through the engine's own per-task stop (`stop_task`).
      // A sibling of the row button (a button may not nest a button), wrapped so
      // the strip keeps ONE child per model row (the 1s tick indexes by child).
      const stop = el('button', { type: 'button', class: 'lag-stop', title: `Stop this background command${r.de ? ` — ${r.de}` : ''}`, 'aria-label': `Stop background command ${r.key}`, text: 'stop' });
      stop.addEventListener('click', (ev) => {
        ev.stopPropagation();
        // FEAT-154 (round 7) — addressed by (session, task) over HTTP, so it reaches
        // the owning bridge whether or not this tab drives it (an adopted session
        // viewed after a restart is the case round 6 missed). The session is the
        // one the strip's snapshot is about — never whatever this socket holds.
        const sid = state.snap?.stationSessionId || state.snap?.sdkSessionId || state.current.sessionId;
        if (!sid) { say('cannot tell which session this command belongs to — reload and try again', true); return; }
        if (!confirm(`Stop this background command?\n\n${r.de || r.key}`)) return;
        stop.disabled = true;
        void api.stopTask(sid, r.key).then((res) => {
          if (res.ok) {
            say('stop sent — the command leaves the list once the engine confirms it ended');
            void pollRunning();
            return;
          }
          stop.disabled = false;
          say(res.reason === 'no-bridge'
            ? 'could not stop it: this server is no longer driving that session (it may already have ended) — reload to refresh'
            : `could not stop that command: ${res.error || res.reason || 'the server refused'}`, true);
          void pollRunning();
        });
      });
      node.stripRows.append(el('div', { class: 'lag-wrap stoppable', 'data-thread': r.key }, row, stop));
      continue;
    }
    node.stripRows.append(row);
  }
  paintStripSummary(model);
}

/**
 * The summary line. The clock is the MAIN turn's honest age (the server's
 * `turn.since`); with no main row it is the first running row's, and "—"
 * wherever nothing actually knows — never a stopwatch this tab started.
 */
function paintStripSummary(model) {
  const main = model.find((r) => r.row === 'main');
  const agents = model.filter((r) => r.row !== 'main');
  const stale = model.some((r) => r.stale);
  const clock = main ? rowElapsed(main.startedAt, stale) : (agents.length ? rowElapsed(agents[0].startedAt, stale) : '—');
  node.stripClk.textContent = clock;
  // BUG-046: stalled rows are counted out loud — "2 agents running" over a set
  // where one has silently stopped progressing is the fleet-level lie the
  // detector exists to end.
  const stalled = agents.filter((r) => r.stalled && !r.blocked && !r.stopped).length;
  const stallNote = stalled ? ` · ⚠ ${stalled} stalled` : '';
  // BUG-187 — blocked/stopped lanes are counted out loud and NEVER as running.
  const blocked = agents.filter((r) => r.blocked).length;
  const stoppedN = agents.filter((r) => r.stopped).length;
  const blockNote = (blocked ? ` · ⊘ ${blocked} blocked (Orchard not attached)` : '') + (stoppedN ? ` · ${stoppedN} stopped` : '');
  const runningN = agents.length - stalled - blocked - stoppedN;
  // BUG-187 — the header must not say "Running" (with the live spark) over a set
  // in which nothing runs: only blocked/stopped lanes and no main turn.
  const nothingRuns = !main && runningN === 0 && stalled === 0 && (blocked + stoppedN) > 0;
  node.strip.classList.toggle('norun', nothingRuns);
  const lbl = node.strip.querySelector('.strip-top .lbl');
  if (lbl) lbl.textContent = nothingRuns ? (blocked ? 'Blocked' : 'Stopped') : 'Running';
  node.stripSum.textContent = stale
    // Says the true thing: this is the last answer we got, not the current one.
    ? `${agents.length} agent${agents.length === 1 ? '' : 's'} — unverified, the server is unreachable (as of ${clock})`
    : `${runningN} agent${runningN === 1 ? '' : 's'} running${stallNote}${blockNote} · ${clock}`;
}

/*
 * The one-second tick advances the CLOCKS ONLY — it can never add, remove or
 * revive a row, because the set of rows is the server's answer and this timer
 * has no opinion about it. (The previous version walked `state.agents` here,
 * which is how a tab kept a killed agent's stopwatch climbing.)
 */
setInterval(() => {
  // BUG-178: keep the dock chip's foreground-wait elapsed honest without
  // repainting the whole queue box (which would clobber an in-progress edit).
  // Only the `.q-el` text is touched — the set of rows is never changed here.
  const qel = document.getElementById('queueBox')?.querySelector('.q-el');
  if (qel) {
    const fw = foregroundWait();
    if (fw && fw.startedAt) qel.textContent = fmtElapsed(Date.now() - fw.startedAt);
  }
  if (node.strip.hidden) return;
  const model = stripModel();
  const rows = [...node.stripRows.children];
  if (rows.length !== model.length) { renderStrip(); return; } // set changed under us
  model.forEach((r, i) => {
    const el2 = rows[i]?.querySelector('.el');
    if (el2) el2.textContent = rowElapsed(r.startedAt);
  });
  paintStripSummary(model);
}, 1000);

/**
 * Is this snapshot about the session on screen?
 *
 * A snapshot arriving on THIS session's own socket is ours by construction and
 * is trusted (`trusted`), which matters at the very start of a turn: the server
 * publishes the running set the instant the turn begins — before this tab has
 * even been told its station session id — and that push is precisely the fix
 * for "the main row appears eventually, not at turn start". A POLLED snapshot
 * is checked, because the user may have navigated away while it was in flight.
 */
function snapshotIsForCurrent(snap) {
  const ids = [state.stationSessionId, state.sdkSessionId, state.current.sessionId].filter(Boolean);
  if (!ids.length) return true;
  return ids.includes(snap.stationSessionId) || ids.includes(snap.sdkSessionId);
}

/**
 * BUG-106 — is the session open in the transcript dock FOREIGN to the project the
 * user has now selected in the sidebar? True after a bare selectProject (a "look
 * at another project" header click) that lands on a project other than the one
 * that owns the open session. While true, the dock's session-bound surfaces — the
 * running strip, the permission hairline, the rail's live-count chip, the running
 * poll — must present nothing (the same absent end-state resetTranscript gives)
 * rather than attribute one project's live work to another. It does NOT close the
 * open session: state.snap and the socket are kept, so a switch BACK restores the
 * real strip. Not foreign when nothing is open (openProjectId null) or when the
 * selection matches the open session's owner.
 */
function dockIsForeign() {
  return state.openProjectId != null
    && state.current.projectId != null
    && state.openProjectId !== state.current.projectId;
}

/*
 * BUG-106 — the ONE place the open session's LIVE report is resolved for a VIEW
 * surface. dockIsForeign() gated the strip, the hairline, the rail live-count and
 * the poll one call site at a time; the crown model chip (and the integrations
 * strip, and the permission tray/seal) still read the open session's live fields
 * directly, so they kept leaking A's live model/provider/tools/posture under B.
 *
 * The structural fix: a surface that PAINTS the open session's live state must
 * read its live inputs through these accessors, never `state.*` directly. When
 * the dock is foreign the open session's live report is not about the thing on
 * screen, so these return ABSENT and every such surface falls back to the SELECTED
 * project's predicted/planned view — blank of A's live work BY CONSTRUCTION rather
 * than by each call site remembering to call dockIsForeign(). A newly added
 * surface that reads state.snap/live/effective/liveTools/liveWireModel directly is
 * not covered — scripts/verify-bug-106-foreign-surfaces.mjs drives a rich foreign
 * live-state and enumerates every live-reading surface so a new leak FAILs loudly.
 */
const dockSnap = () => (dockIsForeign() ? null : state.snap);
const dockLive = () => (dockIsForeign() ? false : state.live);
const dockEffective = () => (dockIsForeign() ? null : state.effective);
const dockLiveTools = () => (dockIsForeign() ? null : state.liveTools);
const dockLiveModel = () => (dockIsForeign() ? null : liveWireModel);

/**
 * BUG-159 — the STRAND, read from the server's own authority. The session is
 * live with background work in flight, but the honest liveness verdict says NO
 * main turn is running (`turn.running:false` — liveness.ts now returns this for
 * a stuck woken `busy` a live lane was shielding). In that state a typed message
 * is NOT a mid-turn interject waiting on a far-off `turn-end`: the server holds
 * it and the idle CLI runs it at the next boundary (Part A). So the tab routes
 * it straight through and captions it "queued behind background work". Requires a
 * visible background row so a just-started main turn (server not yet reporting
 * running, no lanes) is never mistaken for the strand.
 */
function idleBehindBackground() {
  const snap = dockSnap();
  return !!snap
    && !!snap.turn && snap.turn.running === false
    && Array.isArray(snap.running) && snap.running.some((r) => r.row !== 'main');
}

/**
 * BUG-178 — the FOREGROUND twin of idleBehindBackground(). The main turn is
 * genuinely RUNNING (turn.running is not false — the strand is handled above),
 * and there is a non-`main` running row: a subagent or a long tool lane held
 * inside a single in-flight tool call. That is the state where "delivers at the
 * next pause" is a lie by omission — the pause is that step finishing, which can
 * be minutes or tens of minutes away (measured: a foreground Agent subagent held
 * a queued message unseen for 20 min). This reads the server's own snapshot — no
 * guess — and returns the OLDEST such lane so the chip can name it and show how
 * long it has already run. Returns null when the boundary is genuinely close (an
 * ordinary tool chain hits one every few seconds, no non-main row) so the plain
 * "delivers at the next pause" — which is honest there — is kept.
 *
 * BUG-178 round 2 — the FOREGROUND fact is NOT re-derived here. Round 1 read
 * "turn.running !== false plus a non-`main` row" as foreground, which is FALSE
 * in the common workload: the orchestrator keeps its turn running while a
 * `run_in_background` fan-out persists, so several concurrent background lanes
 * coexist with a running main turn whose next boundary is seconds away. That
 * misfire named an arbitrary background lane and steered the user to a
 * destructive Force send. The server now DECLARES the fact per lane
 * (`RunningEntry.background`, owned by the bridge — ARCH-010), and this reads
 * ONLY lanes explicitly marked foreground (`background === false`). A lane whose
 * background-ness the server did not declare (older server, survivor lane) is
 * treated as "not known to be foreground" and never triggers the blocked copy —
 * deleting a claim we cannot substantiate beats guessing it.
 */
function foregroundWait() {
  const snap = dockSnap();
  if (!snap || !Array.isArray(snap.running)) return null;
  // turn.running === false is the strand (idleBehindBackground); absent turn on
  // an older server reads as running, which is correct here — state.busy holds.
  if (snap.turn && snap.turn.running === false) return null;
  // Only lanes the SERVER declared foreground block the boundary. `background`
  // absent ⇒ not known to be foreground ⇒ excluded (never the scary copy).
  const lanes = snap.running.filter((r) => r.row !== 'main' && r.background === false);
  if (!lanes.length) return null;
  const timed = lanes.filter((r) => Number.isFinite(r.startedAt) && r.startedAt > 0);
  const oldest = timed.length
    ? timed.reduce((a, b) => (a.startedAt <= b.startedAt ? a : b))
    : lanes[0];
  return {
    count: lanes.length,
    // A neutral name: the row may be a real subagent OR a bash tool lane
    // (BUG-171), so "step" is the honest word for both. Prefer the server's
    // short label, fall back to what it is doing, then a generic phrase.
    label: oldest.label || oldest.description || oldest.lastTool || 'a long tool call',
    startedAt: Number.isFinite(oldest.startedAt) && oldest.startedAt > 0 ? oldest.startedAt : null,
  };
}

/**
 * RECONCILE to the server's answer. The only writer of `state.snap`.
 *
 * It corrects in both directions — rows this tab never heard about appear, rows
 * the server no longer vouches for disappear — and an EMPTY snapshot empties
 * the strip, with no page reload. That last sentence is BUG-034's entire ask.
 */
function applySnapshot(snap, { trusted = false } = {}) {
  if (!snap || snap.v !== 1 || !Array.isArray(snap.running)) return false;
  if (!trusted && !snapshotIsForCurrent(snap)) return false;
  state.snap = snap;
  state.snapStale = false; // a fresh answer — the rows can be vouched for again
  state.snapStaleAt = 0;
  if (Array.isArray(snap.ended) && snap.ended.length) mergeOutcomes(snap.ended);
  // BUG-113: this is the evidence turn-end's nominations were waiting for — and
  // it must run BEFORE the repaint below, so the strip is painted once, from the
  // reconciled state, rather than flashing the pre-judgement rows.
  settleCutAgentsAgainst(snap);
  renderStrip();
  // FEAT-040 consistency: the crown and the strip must never disagree about
  // whether work is in flight — repaint it from the same answer.
  paintSessStatus();
  // FEAT-067 fast-follow: the summary card's "live" chip reads THIS snapshot's
  // running-set, so it must repaint every time the set changes — otherwise the
  // one honesty invariant (derived live every poll, never a stored snapshot)
  // would break for that count alone.
  renderRailSummary();
  // FEAT-126 — "Your requests" execution channel reads THIS snapshot's live
  // running set, so it repaints every time the set changes, for the same honesty
  // reason as the summary card above: execution status must track the live truth,
  // never a stored copy. The bindings are not refetched here — only the live join
  // is recomputed, so idle→running→done moves the instant the snapshot does.
  renderRailRequests();
  // BUG-159 — the poll/push just told us the main turn is not running while a
  // lane is live (the strand). Any message queued behind the stuck `busy` would
  // otherwise wait for a `turn-end` that may be hours away; deliver it now.
  deliverQueuedBehindBackground();
  return true;
}

/**
 * BUG-159 — flush queued messages held behind the STRAND to the server, which
 * holds+pushes them into the runtime queue (Part A) so the idle CLI runs them at
 * the next boundary. This is the pre-queued counterpart to submit()'s direct
 * route: a message queued while a turn was genuinely running, whose turn then
 * stuck as a woken `busy`, would otherwise never flush (flushQueue waits for the
 * busy→idle transition that never comes). Delivers ONLY when the authority
 * confirms the strand shape, and does NOT touch `state.busy` — the composer
 * stays consistent with the server, and once the CLI picks the message up the
 * next snapshot reports the turn running again.
 */
function deliverQueuedBehindBackground() {
  if (!state.busy || !idleBehindBackground()) return;
  syncQueue(); // BUG-217 r2: the shared store first — see flushQueue
  const items = sendableRows(); // BUG-217 round 3: in order; they stay rows, `sending`, until the server answers
  if (!items.length) return;
  const text = items.map((q, i) => `${queueItemNote(q, i, items.length)}\n${q.text.trim()}`).join('\n\n');
  markRowsSending(items);
  const bgEl = youBubble(mainThread(), text);
  if (state.viewing === 'main') scrollDown();
  if (!sendTurn(text, { rows: items, el: bgEl })) {
    // Socket died between the decision and the send — nothing was handed over.
    for (const q of items) q.sending = false;
    bgEl?.remove?.();
    paintQueue();
    return;
  }
  say(items.length === 1
    ? 'delivered the queued message behind background work'
    : `delivered ${items.length} queued messages behind background work`);
  paintQueue();
}

/* -------------------------------------------- BUG-034: the correcting poll */
/*
 * Push is not enough and never was. A frame can be dropped, a tab can be
 * backgrounded through the whole turn, a socket can die mid-flight, and a
 * server can restart under an open tab — all of which produced the reported
 * symptom in one direction or the other. This poll is the backstop that makes
 * the strip SELF-CORRECTING: whatever happened to the event stream, the tab
 * converges on the server's answer within one interval, without a reload.
 */
const SNAP_POLL_MS = 4000;

async function pollRunning() {
  if (state.caps.running === false) return; // older server — no route to ask
  const id = state.stationSessionId || state.sdkSessionId || state.current.sessionId;
  if (!id) return;
  // BUG-106 — while the open session is foreign to the sidebar selection the strip
  // is gated absent; re-fetching and re-applying its running set would only feed a
  // hidden surface and churn the network every 4s. A push on the session's own
  // socket still keeps state.snap warm for the switch-back, and the interval poll
  // resumes the instant the selection returns to the owning project.
  if (dockIsForeign()) return;
  // BUG-083 — remember which session boundary this poll belongs to. If the user
  // switches away while the request is in flight, the answer that lands is the
  // OLD session's running set; dropping it is what stops it repainting the
  // outgoing session's agents under the newly-selected one.
  const scope = state.snapScope;
  let snap;
  try {
    snap = await api.sessionRunning(id);
  } catch {
    // Unreachable, not "nothing is running": freeze the rows and say so rather
    // than either deleting work that may still be running or letting a
    // stopwatch keep climbing on an answer nobody can confirm. But only for the
    // session still on screen — a switched-away poll's failure is not ours.
    if (scope === state.snapScope) markSnapshotStale();
    return;
  }
  if (scope !== state.snapScope) return; // switched sessions mid-flight — this answer is the session we left
  if (snap === null) { state.caps.running = false; return; }
  state.caps.running = true;
  applySnapshot(snap);
}

function startRunningPolling() {
  if (state.snapPollTimer) return;
  state.snapPollTimer = setInterval(() => { if (!document.hidden) void pollRunning(); }, SNAP_POLL_MS);
  // A tab coming back to the foreground is the single most likely moment to be
  // holding a stale picture — reconcile immediately rather than up to a tick later.
  document.addEventListener('visibilitychange', () => { if (!document.hidden) void pollRunning(); });
}

$('#stripTop').addEventListener('click', function () {
  const shut = node.strip.classList.toggle('shut');
  this.setAttribute('aria-expanded', shut ? 'false' : 'true');
});

/**
 * BUG-030 — which kind of row this is. 'tool' = a single tool call the CLI
 * surfaces as its own task (task_type "local_bash"); everything else is a real
 * subagent. Falls back on the agentType for events from an older server that
 * does not send `kind`.
 */
function agentKind(a) {
  return a.kind ?? ((a.agentType || '').startsWith('local_') && a.agentType !== 'local_agent' ? 'tool' : 'agent');
}

/**
 * BUG-171 — the DECLARED kind for a live agent id, for the rare path that has to
 * create a thread before an `agent-started` frame stamped it (viewAgent from a
 * strip-row click). Read, never re-derive: the live agent record carries `kind`;
 * the running snapshot row carries the same fact as `row` ('tool'|'agent'). Falls
 * back to 'agent' when neither authority has spoken yet.
 */
function threadKindFor(agentId) {
  const a = state.agents.get(agentId)?.agent;
  if (a) return agentKind(a);
  const r = state.snap?.running?.find((x) => x.id === agentId);
  if (r) return r.row === 'tool' ? 'tool' : 'agent';
  return 'agent';
}

/*
 * BUG-030 — the in-flight invariant: a card may show ◐ only while a live
 * process/turn can actually be behind it. Two ground truths enforce it:
 *  - after a turn's `result` (turn-end) NOTHING from that turn can still be
 *    running (the bridge sweeps its own #agents at `result`, so any row still
 *    `running` at client turn-end belongs to a bridge/CLI that died);
 *  - on (re)attach, everything genuinely alive is re-announced by the server's
 *    replayAgents() within the same handshake, so a pre-existing row that no
 *    frame refreshes right after the `start` ack has no live process behind it
 *    (its terminal frame died with a cut host CLI — a server restart/shutdown,
 *    the same cut BUG-028's interruptedByShutdown marks in the transcript).
 * Such a zombie is settled honestly as "cut by shutdown" instead of spinning
 * forever with a growing timer.
 */
function settleCut(cur) {
  cur.settled = true;
  cur.agent = { ...cur.agent, status: 'cut', elapsedMs: Math.max(0, Date.now() - (cur.t0 ?? Date.now())) };
  const th = state.threads.get(cur.agent.agentId);
  if (th) { th.status = 'cut'; refreshLede(th); }
  // A tool-call row settles silently (its parent agent's row carries the
  // story); a real subagent leaves the honest "ran" row with the cut caption.
  if (agentKind(cur.agent) !== 'tool') {
    finishStream(state.threads.get(cur.agent.agentId));
    settleAgent(cur);
  }
}

/*
 * BUG-113 — the turn-end half of the invariant, corrected. "After a turn's
 * `result` nothing from it can still be running" is FALSE for a background
 * agent: the server's own turn-end sweep deliberately SPARES rows belonging to
 * live background work, so they stay `running` and emit no completion, and the
 * snapshot force-pushed one frame later still lists them. The old sweep settled
 * every unsettled row right at `turn-end` with no background knowledge and
 * without consulting the server — flipping live work to `cut` and writing a
 * durable "Cut by shutdown" ledger row. The snapshot that arrived a frame later
 * repainted the strip, but the card, the thread and the ledger row never
 * re-opened: three surfaces, two answers, and the wrong one was the permanent
 * one.
 *
 * So turn-end no longer settles anything. It only NOMINATES the rows that
 * cannot be judged yet, and the judgement waits for positive evidence: the next
 * applied snapshot whose `turn.running === false` — computed at or after the
 * result, so its `running[]` is the server's answer to "what survived the
 * turn". Candidates absent from that list are settled; candidates present in it
 * are live background work and are simply released. If no qualifying snapshot
 * ever arrives, NOTHING is settled — a death may not be asserted from mere
 * absence of evidence, and an unreachable server is already surfaced as stale
 * rows by markSnapshotStale().
 *
 * BUG-030's honest case is untouched: a zombie of a cut host CLI is absent from
 * the fresh snapshot, so it still settles to "cut by shutdown".
 */
let cutCandidates = null; // Set<agentId> awaiting a qualifying snapshot, or null

/** turn-end: nominate every row that MAY be a zombie. Settles nothing. */
function nominateCutAgents() {
  const ids = new Set();
  for (const [id, cur] of state.agents) {
    if (!cur.settled && cur.agent.status === 'running') ids.add(id);
  }
  cutCandidates = ids.size ? ids : null;
  return ids.size;
}

/**
 * The judgement, against the server's own post-turn answer. The ONLY path that
 * can settle a row as cut at turn-end — there is deliberately no fallback that
 * settles without a snapshot in hand.
 */
function settleCutAgentsAgainst(snap) {
  if (!cutCandidates) return 0;
  // Positive evidence only: a snapshot computed while the turn was still
  // running says nothing about what outlived it.
  if (!snap || !snap.turn || snap.turn.running !== false) return 0;
  const alive = new Set(snap.running.map((r) => r.id).filter(Boolean));
  let n = 0;
  for (const id of cutCandidates) {
    if (alive.has(id)) continue; // the server still vouches for it — live background work
    const cur = state.agents.get(id);
    if (!cur || cur.settled || cur.agent.status !== 'running') continue;
    settleCut(cur);
    n++;
  }
  // Judged either way: rows the snapshot vouched for are released, not re-judged
  // on the next snapshot (their own completion frames will settle them).
  cutCandidates = null;
  if (n) renderStrip();
  return n;
}

/**
 * BUG-030 — reattach half of the invariant. Called on the `start` ack: rows
 * already on screen (an open tab that lived through a server/CLI cut keeps its
 * state.agents) are only alive if this attach's replayAgents() re-announces
 * them, and those frames land right behind the ack. Snapshot what exists now,
 * give the replay a beat, then settle whatever nothing refreshed.
 */
let cutSweepTimer = null;
function scheduleCutSweep() {
  const snap = new Map();
  for (const [id, cur] of state.agents) {
    if (!cur.settled && cur.agent.status === 'running') snap.set(id, cur.seenAt ?? 0);
  }
  if (!snap.size) return;
  clearTimeout(cutSweepTimer);
  cutSweepTimer = setTimeout(() => {
    let n = 0;
    for (const [id, seen] of snap) {
      const cur = state.agents.get(id);
      if (!cur || cur.settled || cur.agent.status !== 'running') continue;
      if ((cur.seenAt ?? 0) !== seen) continue; // refreshed since the ack — genuinely alive
      settleCut(cur);
      n++;
    }
    if (n) renderStrip();
  }, 1500);
}

/** A finished subagent leaves one navigable hairline row in the main thread. */
function settleAgent(entry) {
  const a = entry.agent;
  const th = mainThread();
  const stats = `${mmss(a.elapsedMs)} · ${a.toolUses} tool${a.toolUses === 1 ? '' : 's'} · ${kilo(a.totalTokens)}`;
  const agentThread = state.threads.get(a.agentId);
  if (agentThread) {
    agentThread.status = a.status;
    agentThread.stats = stats;
    agentThread.agentType = a.agentType || agentThread.agentType;
    agentThread.description = a.description || agentThread.description;
    agentThread.loaded = true; // its messages already streamed into the pane
    refreshLede(agentThread);
    if (state.viewing === a.agentId) paintComposerFor(agentThread);
  }
  const text = state.agentText.get(a.agentId);
  const body = el('div', { class: 'ran-out' },
    text ? prose(text) : el('div', { class: 'prose' }, el('p', {
      text: a.status === 'completed' ? 'No text was returned.'
        // BUG-030: the honest terminal state for a call/agent whose result
        // frame died with a cut host CLI — never "still running".
        : a.status === 'cut' ? 'Cut by shutdown — the host CLI was stopped mid-flight (server restart or shutdown) and no result was recorded.'
          : `Ended: ${a.status}.`,
    })),
    el('div', { class: 'fields' },
      el('span', {}, document.createTextNode('duration_ms '), el('b', { text: a.elapsedMs.toLocaleString() })),
      el('span', {}, document.createTextNode('tool_uses '), el('b', { text: String(a.toolUses) })),
      el('span', {}, document.createTextNode('total_tokens '), el('b', { text: a.totalTokens.toLocaleString() })),
      el('span', {}, document.createTextNode('status '), el('b', { text: a.status }))));
  ranRow(th, { agentId: a.agentId, agentType: a.agentType, description: a.description, status: a.status, stats, body });
  if (state.viewing === 'main') scrollDown();
}

/* -------------------------------------------------------------- approvals */

function renderAsk(e) {
  node.asks.hidden = false;
  /*
   * BUG-187 P1 — UPSERT by requestId. The same request can arrive twice: a
   * reattach replays it (BUG-008), and after a server restart the CLI
   * REDELIVERS a still-pending permission with the SAME request id. Appending
   * again drew a duplicate card and orphaned the first one's map entry. An
   * existing, unsettled card is refreshed in place and kept answerable.
   */
  const prior = state.asks.get(e.requestId);
  if (prior && prior.isConnected && !prior.dataset.done) {
    prior.dataset.redelivered = '1';
    const acts = prior.querySelector('.acts');
    for (const b of acts ? acts.querySelectorAll('button') : []) b.disabled = false;
    const v = prior.querySelector('.verdict');
    if (v && v.textContent.startsWith('not ')) v.textContent = '';
    return;
  }
  if (prior) { prior.remove(); state.asks.delete(e.requestId); }
  const box = el('div', { class: 'ask' });
  box.dataset.requestId = String(e.requestId);
  let arg = '';
  try { arg = typeof e.input === 'string' ? e.input : JSON.stringify(e.input, null, 2); } catch { arg = '(uninspectable input)'; }
  box.append(el('div', { class: 'hd' },
    el('span', { class: 'nm', text: e.toolName }),
    el('span', { class: 'ti', text: e.title || e.description || 'wants permission to run' }),
    el('span', { class: 'who', text: e.agentId ? 'subagent' : 'main' })));
  box.append(el('div', { class: 'arg', text: arg }));

  const acts = el('div', { class: 'acts' });
  const verdict = el('span', { class: 'verdict' });
  const answer = (allow) => {
    const word = allow ? 'allowed' : 'denied';
    for (const b of acts.querySelectorAll('button')) b.disabled = true;
    verdict.textContent = `sending ${word}…`;

    const restore = (why) => {
      // Nothing landed — say so and give the decision back to the user.
      delete box.dataset.done;
      verdict.textContent = `not ${word} — ${why}`;
      for (const b of acts.querySelectorAll('button')) b.disabled = false;
    };

    if (!send({ type: 'approval-response', requestId: e.requestId, allow })) {
      return restore('no live connection, nothing was sent');
    }

    // The ack echoes requestId, so concurrent approvals match exactly.
    const pending = {
      settle: (matched) => {
        clearTimeout(pending.timer);
        /*
         * BUG-187 P3 — after the server has published a COMPLETE pending list,
         * "no such pending request" is authoritative: the request is gone (a
         * restart, or it was answered elsewhere). Settle the card as expired;
         * re-arming it would invite a click into nothing.
         */
        if (matched === false && state.approvalsComplete) return expireAsk(e.requestId, 'this request no longer exists (the server has no such pending request)');
        if (matched === false) return restore('the server had no such pending request');
        box.dataset.done = word;
        verdict.textContent = `${word} · confirmed by the server`;
        for (const b of acts.querySelectorAll('button')) b.remove();
        state.asks.delete(e.requestId);
        setTimeout(() => {
          box.remove();
          if (!node.asks.childElementCount) node.asks.hidden = true;
        }, 2600);
      },
      fail: (why) => { clearTimeout(pending.timer); restore(why); },
    };
    pending.timer = setTimeout(() => {
      state.pendingAnswers.delete(e.requestId);
      restore('the server never confirmed');
    }, 6000);
    state.pendingAnswers.set(e.requestId, pending);
  };
  const deny = el('button', { class: 'mini', text: 'Deny' });
  deny.addEventListener('click', () => answer(false));
  const allow = el('button', { class: 'solid', text: 'Allow' });
  allow.addEventListener('click', () => answer(true));
  acts.append(verdict, el('span', { class: 'grow' }), deny, allow);
  box.append(acts);

  node.asks.append(box);
  state.asks.set(e.requestId, box);
  scrollDown();
}

/**
 * BUG-187 P2/P3 — settle a card whose request no longer exists. Kept visible
 * (dimmed, with the reason) for a moment so the user sees what happened, then
 * removed; its buttons are gone at once so nothing can be clicked into nothing.
 */
function expireAsk(requestId, why) {
  const box = state.asks.get(requestId);
  state.pendingAnswers.delete(requestId);
  if (!box) return;
  state.asks.delete(requestId);
  box.dataset.done = 'expired';
  for (const b of box.querySelectorAll('.acts button')) b.remove();
  const v = box.querySelector('.verdict');
  if (v) v.textContent = `expired — ${why}`;
  setTimeout(() => {
    box.remove();
    if (!node.asks.childElementCount) node.asks.hidden = true;
  }, 6000);
}

/**
 * BUG-187 P2 — the server's authoritative pending list. `complete:false` (an
 * adopted session still recovering its prompts) expires NOTHING; `complete:true`
 * expires every card whose id is absent.
 */
function applyApprovalsSnapshot(e) {
  state.approvalsComplete = e.complete === true;
  if (e.complete !== true) return;
  const live = new Set((e.requestIds ?? []).map(String));
  for (const id of [...state.asks.keys()]) {
    if (!live.has(String(id))) expireAsk(id, 'this request no longer exists (the server restarted or it was answered elsewhere)');
  }
}

/* ------------------------------------------------------- decisions (Q / plan) */
/*
 * `AskUserQuestion` and `ExitPlanMode` are moments where the model STOPS and
 * waits for a person. They render inline, at the point Claude asked, because
 * they are part of the conversation — not a modal that hides the reasoning that
 * led to the question.
 *
 * The settle discipline is the approvals one, for the same reason: an answer is
 * only real once the server acks it. `pendingAnswers` is shared with approvals
 * and keyed by requestId, so concurrent decisions match exactly.
 */

const DECISION_TOOLS = new Set(['AskUserQuestion', 'ExitPlanMode']);

/** Cards live per thread so a subagent's question lands in its own transcript. */
function decisionMap(th) {
  if (!th.decisions) th.decisions = new Map();
  return th.decisions;
}

/** Returns true when the tool-call was rendered as a decision card. */
function renderDecisionCall(th, e) {
  if (!DECISION_TOOLS.has(e.name)) return false;
  if (e.name === 'AskUserQuestion') {
    const questions = parseQuestions(e.input);
    // An unparseable question must fall back to the chip rather than showing an
    // empty card — a blank card would hide the question entirely.
    if (!questions.length) return false;
    renderQuestion(th, { toolUseId: e.toolUseId, requestId: e.requestId ?? null, questions });
    return true;
  }
  const plan = parsePlan(e.input);
  if (!plan) return false;
  renderPlan(th, { toolUseId: e.toolUseId, requestId: e.requestId ?? null, plan });
  return true;
}

/**
 * Send a decision and refuse to show it as settled until the ack arrives.
 * Mirrors renderAsk()'s pending/settle/fail shape exactly.
 */
function sendDecision({ requestId, payload, ui, onMatched, word = 'answer' }) {
  ui.sending(word);
  if (!send(payload)) return ui.failed('no live connection, nothing was sent');

  const pending = {
    settle: (matched) => {
      clearTimeout(pending.timer);
      if (matched === false) return ui.failed('the server had no such pending request');
      onMatched();
    },
    fail: (why) => { clearTimeout(pending.timer); ui.failed(why); },
  };
  pending.timer = setTimeout(() => {
    state.pendingAnswers.delete(requestId);
    ui.failed('the server never confirmed');
  }, 6000);
  state.pendingAnswers.set(requestId, pending);
}

function renderQuestion(th, { toolUseId, requestId, questions }) {
  const existing = toolUseId && decisionMap(th).get(toolUseId);
  if (existing) {
    // The typed event can follow the tool-call for the same question; adopt the
    // requestId rather than drawing the card twice.
    if (requestId && !existing.requestId) upgradeAnswerable(existing, requestId);
    return existing;
  }

  const card = createQuestionCard({
    questions,
    answerable: !!requestId,
    onSubmit: (answers, ui) => {
      sendDecision({
        requestId: card.requestId,
        payload: { type: 'question-response', requestId: card.requestId, answers },
        ui,
        word: 'answer',
        onMatched: () => { card.answered = true; settleDecisionOwner(card); ui.answered(answers); },
      });
    },
  });
  card.requestId = requestId;
  card.kind = 'question';
  card.questions = questions;

  appendDecision(th, card.node);
  if (toolUseId) decisionMap(th).set(toolUseId, card);
  if (requestId) state.decisionsByRequest.set(requestId, card);
  return card;
}

function renderPlan(th, { toolUseId, requestId, plan }) {
  const existing = toolUseId && decisionMap(th).get(toolUseId);
  if (existing) {
    if (requestId && !existing.requestId) upgradeAnswerable(existing, requestId);
    return existing;
  }
  const card = createPlanCard({
    plan,
    answerable: !!requestId,
    onDecide: (approved, ui) => {
      sendDecision({
        requestId: card.requestId,
        payload: { type: 'plan-response', requestId: card.requestId, approved },
        ui,
        word: approved ? 'approval' : 'rejection',
        onMatched: () => { card.answered = true; settleDecisionOwner(card); ui.decided(approved); },
      });
    },
  });
  card.requestId = requestId;
  card.kind = 'plan';
  appendDecision(th, card.node);
  if (toolUseId) decisionMap(th).set(toolUseId, card);
  if (requestId) state.decisionsByRequest.set(requestId, card);
  return card;
}

/*
 * BUG-166 (ARCH-010) — is the model STOPPED, waiting on the user to answer a
 * decision it raised (an AskUserQuestion or a plan)? This is a FACT owned by the
 * pending decision cards: `decisionsByRequest` holds exactly the questions/plans
 * still awaiting the user — each is added when the card becomes answerable and
 * PRUNED the instant it settles (answered, or the model proceeded without one).
 *
 * The composer-send path (submit) and the session-status label
 * (computeSessState) both read THIS one declaration rather than each re-reading
 * `state.busy`. `busy` cannot tell "the model is working" from "the model is
 * paused on a question", so two readers deriving from it disagreed: the label
 * said "Claude is working" while the composer silently held the user's message
 * behind a turn-end that only their own answer could produce — the lockout +
 * mislabel this ticket is about.
 */
function awaitingUserDecision() {
  for (const card of state.decisionsByRequest.values()) if (!card.answered) return true;
  return false;
}

/** A requestId arrived after the card was drawn — rebuild it as answerable. */
function upgradeAnswerable(card, requestId) {
  card.requestId = requestId;
  state.decisionsByRequest.set(requestId, card);
  // Actually add the submit / decision buttons. This previously only swapped
  // the note for a "ready" label, which left the user with a selectable
  // question and nothing to press.
  card.ui?.enable?.();
}

/**
 * Put the card in the transcript and make sure it is not missed.
 *
 * A decision is the one thing a user must not scroll past, so when they are
 * scrolled away it deliberately lights the `Latest` pill instead of yanking
 * the viewport — same rule as every other append, but flagged as unseen.
 */
function appendDecision(th, node) {
  claudeBody(th).append(node);
  if (state.viewing === th.key) {
    if (th.stick === false) { th.unseen = true; paintJump(); }
    else scrollDown();
  } else {
    th.unseen = true;
  }
}

/*
 * BUG-166 — a card is no longer awaiting the user the instant it settles, so its
 * owner drops it from `decisionsByRequest`. Called from EVERY settle path
 * (answered, and proceeded-without-answer) so awaitingUserDecision() reflects
 * only cards still genuinely pending — never a stale one that survives its own
 * turn and mislabels the next one.
 */
function settleDecisionOwner(card) {
  if (card?.requestId != null) state.decisionsByRequest.delete(card.requestId);
}

/**
 * The tool returned. If no ack ever settled this card, the model proceeded
 * WITHOUT an answer — the exact failure that started this work.
 */
function settleDecisionFromResult(card, e) {
  if (card.answered) return;
  settleDecisionOwner(card); // the model moved on — this card no longer awaits the user
  if (card.kind === 'plan') {
    return markUnanswered(card.node, 'No decision was sent — the session continued without your approval.');
  }
  markUnanswered(card.node, e.isError
    ? 'The question errored out — no answer was recorded.'
    : 'No answer was given — the session continued without your choice.');
}

/* -------------------------------------------------------------- websocket */

/*
 * BUG-153 — THE liveness predicate. One question, asked in one place: does this
 * tab hold a socket it can actually drive this session over, right now?
 *
 * It exists because the status the user READ and the guard that REFUSED their
 * action were computed from different things. computeSessState() decided
 * "Claude is working" from `state.busy` alone and decided "running in the
 * background" from `state.sessDetached` — an EVENT-set flag, raised on one
 * reopen path and cleared by ANY socket open, including one belonging to a
 * different session or to a `start` the server went on to refuse. Meanwhile
 * forceSend/flushQueue/the interrupt button asked the honest question
 * (`state.live && state.ws`). Two answers that could not be reconciled: a
 * session presented as attached and working, over which nothing could be sent.
 *
 * So the flag is gone, and every one of those callers now reads this. They can
 * disagree again only by someone re-deriving liveness somewhere else.
 *
 * Three clauses, each carrying its own case:
 *  - `state.live` — a socket was opened and has not closed.
 *  - `readyState === OPEN` — and it is not mid-close; `send()` already refuses
 *    a CLOSING socket, so anything gated on this predicate must too.
 *  - `!state.deliveryRelay` — FEAT-065's relay socket is open but holds NO
 *    session: it exists only to carry approvals for a turn delivered into a
 *    drain-held survivor. Sending over it earns "no session on this socket",
 *    which is precisely the refusal this predicate exists to predict.
 */
function isDriving() {
  return !!(state.live && state.ws && state.ws.readyState === WebSocket.OPEN && !state.deliveryRelay);
}

function connect() {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://${location.host}/ws`);
    const fail = () => reject(new Error('the session socket would not open'));
    ws.addEventListener('open', () => {
      state.ws = ws;
      state.live = true;
      state.closingOnPurpose = false;
      state.dropped = false;
      state.sessReconnecting = false;
      state.budgetLocked = false;
      state.budgetLockReason = '';
      state.pendingSend = null;
      paintSessStatus();
      resolve(ws);
    });
    ws.addEventListener('error', fail);
    ws.addEventListener('close', () => {
      const wasLive = state.live;
      state.live = false;
      state.ws = null;
      state.deliveryRelay = null; // FEAT-065: the approval relay is per-socket state
      setBusy(false);
      // BUG-191: a drain-wait retry whose socket died before ANY answer — the
      // server may have delivered it (its ack lost with the socket). Keep it
      // dead and visible ("not confirmed"); never resend it blindly. It is a
      // retry's own socket, so it is not a dropped DRIVING session either.
      const ghost = !state.closingOnPurpose && state.pendingStart != null && !!state.drainWaitAttempt;
      if (ghost) keepUnconfirmedStart();
      // BUG-217 round 3: any queued row whose `send` answer died with this socket
      // is asked of the server (by id) once it is clearly not coming.
      for (const [sid, a] of state.sendAttempts) {
        if (!a.rows?.length) continue;
        state.sendAttempts.delete(sid);
        for (const q of a.rows) if (q.sending && !q.dead) { q.sending = false; q.remote = 'check'; }
        scheduleReconcile(1000);
      }
      // Our own close() is routine. A close we did not ask for, on a session
      // that had started, is a fault the user must see — and until they
      // resolve it we refuse to send, because the alternative (silently
      // starting a fresh session) throws away the conversation on screen.
      if (!ghost && !state.closingOnPurpose && wasLive && state.sdkSessionId) {
        state.dropped = true;
        say('the session connection dropped — nothing on screen was lost, but the agent is no longer attached', true);
        paintComposerFor(viewedThread());
      }
      state.closingOnPurpose = false;
      paintSessStatus();
      for (const [, p] of state.pendingAnswers) p.fail('the socket closed before the server confirmed');
      state.pendingAnswers.clear();
      // An in-flight mode change dies with the socket; never leave the button
      // implying a switch that was never confirmed.
      if (permModePending) finishPermMode(permModePending.requestId, false, 'the connection dropped before the server confirmed');
      if (modelPending) finishModel(modelPending.requestId, false, 'the connection dropped before the server confirmed');
      renderTree();
    });
    ws.addEventListener('message', (ev) => {
      let e;
      try { e = JSON.parse(ev.data); } catch { return say('malformed event from the server', true); }
      onEvent(e, ws); // BUG-198 round 2 — the socket is part of the frame's identity (session-init adoption)
    });
  });
}

/* ------------------------------------------------------- auto-follow (external) */
/*
 * A session running in another terminal is written to disk by a process this
 * dashboard did not spawn, so there is no bridge and there are no token
 * deltas. The server watches the file and pushes `session-appended` with whole
 * persisted messages, a second or two behind. That is what this consumes — it
 * is FOLLOW, not streaming, so nothing here fakes a caret or a typing effect.
 *
 * Why a second socket: `state.ws` exists only while the dashboard is driving a
 * session (openSession closes it), which is precisely when we do NOT need
 * appends. This one is passive — it never sends a command, so the server never
 * gives it a session — and it stays open for the life of the page, which is
 * when we DO need appends. The driving socket ignores `session-appended`
 * outright so a broadcast reaching both cannot be applied twice.
 */

const WATCH_BACKOFF_MS = [1000, 2000, 5000, 10_000, 30_000];

function watch() {
  if (state.watchWs) return;
  let ws;
  try { ws = new WebSocket(`ws://${location.host}/ws`); } catch { return; }
  state.watchWs = ws;
  ws.addEventListener('open', () => {
    state.watchTries = 0;
    // A reconnect must re-ask: follows live on the socket that requested them.
    // Except while parked in history — the gap machinery owns the tail then.
    followCurrent(!mainThread().gap);
  });
  ws.addEventListener('message', (ev) => {
    let e;
    try { e = JSON.parse(ev.data); } catch { return; }
    if (e?.t === 'session-appended') return applyAppend(e);
    if (e?.t === 'follow-status') return onFollowStatus(e);
  });
  const retry = () => {
    if (state.watchWs !== ws) return;
    state.watchWs = null;
    state.following = false; // BUG-190: the watch died with its socket; the reconnect re-follows and catches up
    const wait = WATCH_BACKOFF_MS[Math.min(state.watchTries++, WATCH_BACKOFF_MS.length - 1)];
    setTimeout(watch, wait);
  };
  ws.addEventListener('close', retry);
  ws.addEventListener('error', () => { try { ws.close(); } catch { /* already gone */ } });
}

/**
 * The watched file was truncated or rotated, so the appends that follow are not
 * a continuation of what is rendered. Reload the session from scratch.
 */
function resyncTranscript() {
  const cur = state.current;
  const p = state.projects.find((x) => x.id === cur.projectId);
  if (!p || !cur.sessionId || !cur.encodedDir) return;
  say('this session file was rewritten on disk — reloading the transcript');
  return openSession(p, { encodedDir: cur.encodedDir, sessionId: cur.sessionId, displayTitle: cur.title, os: cur.os });
}

/** Ask the server to watch whatever session is on screen. Silent no-op if it can't. */
function followCurrent(follow = true) {
  const ws = state.watchWs;
  const { sessionId, encodedDir } = state.current;
  // Dropping the watches means NOT following, immediately — waiting for the
  // server to confirm would leave `following` asserting the previous session's
  // state. It flips back to true only when a follow-status says so.
  state.following = false;
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  try {
    ws.send(JSON.stringify({ type: 'unfollow' }));           // no args = drop all
    // `follow=false` drops every watch and stops there — used while a restored
    // view is parked in history, where appends must not be spliced on anyway.
    if (follow && sessionId && encodedDir) ws.send(JSON.stringify({ type: 'follow', sessionId, dir: encodedDir }));
  } catch { /* the socket died between the check and the send; the reconnect re-follows */ }
}

/**
 * The server's answer to `follow`. A refusal is normal in one case — it will
 * not watch a session the dashboard's own bridge is driving — so that one is
 * silent. Any OTHER refusal means the user is looking at a session that will
 * not update, and they are told, because a stale transcript that looks live is
 * the exact bug this feature exists to remove.
 */
function onFollowStatus(e) {
  if (e.sessionId !== state.current.sessionId) return;
  state.following = e.following === true;
  // BUG-190: every fresh follow starts at the file's CURRENT end, so whatever was
  // written between the last thing rendered and this subscribe — a reconnect gap,
  // a turn delivered while the watch was down — is caught up from the store.
  if (e.following) return void catchUpFollow(e.sessionId, e.dir);
  // Expected refusal: the dashboard's own bridge is already feeding this
  // session, and watching the file too would double-emit. Not an error.
  if (isBridged(e.sessionId) || /driven by the dashboard/i.test(e.reason ?? '')) return;
  if (e.reason) say(`not following this session live: ${e.reason}`, true);
}

/*
 * BUG-190 — converge the open view to the transcript after ANY (re)subscribe.
 *
 * The server's watch starts at the file's end when it is created, and nothing
 * carries a resume point across an unfollow, a dropped watch socket or a fresh
 * follow. So every line written after the last message this view rendered and
 * before the new watch existed was silently skipped: a reconnect gap, or a turn
 * delivered into a survivor while the watch was down, stayed missing until a
 * reload. The client already holds the resume point — `th.lastIndex`, in the one
 * coordinate system the store and the watcher share — so on every successful
 * follow it reads forward from there. Appends that arrive meanwhile are buffered
 * and replayed AFTER the catch-up, through the same index dedupe, so nothing is
 * rendered out of order or twice: the fetch covers everything before the watch
 * started, the watch covers everything after, and the overlap is dropped by index.
 */
async function catchUpFollow(sessionId, dir) {
  const th = mainThread();
  const cur = state.current;
  if (!cur.sessionId || cur.sessionId !== sessionId || !cur.encodedDir) return;
  if (dir && dir !== cur.encodedDir) return;
  if (th.gap || isBridged(sessionId)) return; // the gap machinery owns the tail / the bridge renders it
  if (th.lastIndex == null) {
    /*
     * BUG-190 round 5: an absent anchor is never "nothing to do".
     *  - Nothing rendered in this thread: the anchor is the start, so read from
     *    #0 (-1). An empty session's first message is caught up like any other.
     *  - Messages rendered WITHOUT store indices (a thread the live bridge drew,
     *    now followed from the file after the bridge went away): nothing can
     *    splice onto it by index, so re-read the whole view from the store —
     *    one reload that converges it, instead of silently skipping the gap.
     */
    if (th.paneEl.querySelector(':scope > .you, :scope > .claude')) {
      const p = state.projects.find((x) => x.id === cur.projectId);
      if (!p) return;
      say('catching this view up from the transcript');
      return void openSession(p, { encodedDir: cur.encodedDir, sessionId, displayTitle: cur.title, os: cur.os });
    }
    th.lastIndex = -1;
  }
  if (th.catchUp) { th.catchUp.again = true; return; } // one in flight: it loops once more instead
  const run = { buffer: [], again: false };
  th.catchUp = run;
  const stillHere = () => state.current.sessionId === sessionId && state.current.encodedDir === cur.encodedDir && mainThread() === th;
  const idx = (t) => (t?.messages ?? []).filter((m) => Number.isInteger(m?.index));
  // A hung read counts as a failed read (retried below), never an endless wait.
  const read = (opts) => Promise.race([
    api.transcript(cur.encodedDir, sessionId, opts),
    new Promise((_, rej) => setTimeout(() => rej(new Error('catch-up read timed out')), 20_000)),
  ]);
  /*
   * One pass: everything after `th.lastIndex`, contiguous, or it THROWS — a pass
   * never renders a partial gap (BUG-190 round 3). Read BACKWARD from the file's
   * end (never forward past it), newest page first, then older pages anchored by
   * the previous page's byte cursor while the oldest message read is still newer
   * than what is on screen. Every page must link to the next by index; a short
   * or empty page is a failed read, not "nothing older".
   */
  const readGap = async () => {
    const next = th.lastIndex + 1;
    let t = await read({ tail: OLDER_PAGE });
    if (!stillHere()) return null;
    let page = idx(t);
    let got = page.filter((m) => m.index >= next);
    for (let pages = 0; page.length && page[0].index > next; pages++) {
      if (pages >= 1000) throw new Error('the gap is too long to page through');
      const before = page[0].index;
      t = await read({
        tail: Math.min(OLDER_PAGE, before - next), before,
        beforeBytes: Number.isInteger(t?.cursorBytes) ? t.cursorBytes : undefined,
      });
      if (!stillHere()) return null;
      page = idx(t);
      if (!page.length || page[page.length - 1].index !== before - 1) {
        throw new Error(`an older page did not link up (asked for messages before #${before}, got ${page.length ? `#${page[0].index}–#${page[page.length - 1].index}` : 'none'})`);
      }
      got = page.filter((m) => m.index >= next).concat(got);
    }
    const seen = new Set();
    const fresh = got.filter((m) => m.index > th.lastIndex && !seen.has(m.index) && seen.add(m.index))
      .sort((a, b) => a.index - b.index);
    if (fresh.length && (fresh[0].index !== next || fresh[fresh.length - 1].index - next + 1 !== fresh.length)) {
      throw new Error(`the read left a hole (#${next}…#${fresh[fresh.length - 1].index}, ${fresh.length} messages)`);
    }
    return fresh;
  };
  const RETRY_MS = [500, 1000, 2000, 4000, 8000, 15_000];
  let hint = null;
  try {
    for (let attempt = 0; ; attempt++) {
      let fresh;
      try {
        fresh = await readGap();
      } catch (err) {
        if (!stillHere()) return;
        // Never silent: say that messages written while the view was
        // reconnecting are still being read, and keep retrying. Live appends
        // stay buffered meanwhile so nothing renders ahead of the missing ones.
        if (!hint) { hint = el('div', { class: 'hint-row bad' }); th.paneEl.append(hint); }
        hint.textContent = `could not yet read the messages written while this view was reconnecting (${err.message}) — retrying`;
        await new Promise((r) => setTimeout(r, RETRY_MS[Math.min(attempt, RETRY_MS.length - 1)]));
        if (!stillHere()) return;
        continue;
      }
      if (fresh == null) return; // navigated away mid-read
      if (fresh.length) {
        finishStream(th);
        th.settledStream = null; // persisted units replace any live body (BUG-169)
        th.claudeBody = null;
        th.paneEl.querySelector(':scope > .empty-session-hint')?.remove(); // BUG-190 r5: no longer true
        renderMessages(th, fresh);
        th.lastIndex = fresh[fresh.length - 1].index;
        if (th.page && Number.isInteger(th.page.total)) th.page.total = Math.max(th.page.total, th.lastIndex + 1);
        if (state.viewing === 'main') scrollDown();
      }
      if (!run.again) break;
      run.again = false; // a later follow landed while this one ran — read once more
    }
    if (hint) say('caught up on the messages written while this view was reconnecting');
  } finally {
    hint?.remove();
    if (th.catchUp === run) th.catchUp = null;
    for (const e of run.buffer) applyAppend(e);
  }
}

/** True when the dashboard itself is driving this session id over the bridge. */
function isBridged(sessionId) {
  if (!state.live) return false;
  return state.sdkSessionId === sessionId || (state.busy && state.current.sessionId === sessionId);
}

function applyAppend(e) {
  const cur = state.current;
  if (!cur.sessionId || e.sessionId !== cur.sessionId) return;      // not what is on screen
  if (e.dir && cur.encodedDir && e.dir !== cur.encodedDir) return;  // same id, other store dir
  if (isBridged(e.sessionId)) return;                               // the bridge already showed it

  // The file shrank under the watcher, so the cursor restarted: what follows is
  // NOT a continuation of what is on screen. Splicing it on would fabricate a
  // conversation that never happened — refetch instead.
  if (e.resynced === true) return void resyncTranscript();
  // BUG-190: a catch-up read is in flight — replay this after it, in order.
  if (mainThread().catchUp) return void mainThread().catchUp.buffer.push(e);

  const msgs = Array.isArray(e.messages) ? e.messages : [];
  if (!msgs.length) return;

  const th = mainThread();
  // Parked in history with newer messages still unfetched: an append rendered
  // after the window would sit directly under a message it did not follow.
  // Refuse it — the gap machinery fetches everything in order instead.
  if (th.gap) {
    for (const m of (Array.isArray(e.messages) ? e.messages : [])) {
      if (Number.isInteger(m?.index)) th.gap.total = Math.max(th.gap.total, m.index + 1);
    }
    return;
  }
  // Appends now carry REAL sequential indices continuing from the file's end
  // (one coordinate system with the tail page), so dedupe is a plain index
  // comparison: the tail page and the first append can overlap by a message or
  // two when the file grew between the two reads — those are dropped by index.
  const fresh = msgs.filter((m) => Number.isInteger(m?.index)
    ? (th.lastIndex == null || m.index > th.lastIndex)
    : true); // an index-less message cannot be deduped, so show it
  if (!fresh.length) return;
  for (const m of fresh) if (Number.isInteger(m.index)) th.lastIndex = Math.max(th.lastIndex ?? -1, m.index);

  // A persisted message is a complete unit; end any half-open stream first so
  // it does not get appended into the previous turn's body.
  finishStream(th);
  th.settledStream = null; // persisted units replace the live body; no trailing 'text' will re-render (BUG-169)
  th.claudeBody = null;
  const shown = renderMessages(th, fresh);
  if (!shown) return;
  th.paneEl.querySelector(':scope > .empty-session-hint')?.remove(); // BUG-190 r5: no longer true
  if (th.page && Number.isInteger(th.page.total)) th.page.total += fresh.length;
  // Straight into the existing rule: follow if stuck, otherwise light the pill.
  if (state.viewing === 'main') scrollDown();
}

/* -------------------------------------------------------- live session badges */
/*
 * "Being written by something else right now." Quiet by construction: the same
 * moss dot the app already uses for alive, on the row, with a slow pulse. No
 * word, no colour that is not already in the palette. If the server does not
 * report it, nothing is drawn — an absent signal must not look like "nothing
 * is running".
 */

const LIVE_POLL_MS = 5000;
const liveKey = (dir, sessionId) => `${dir ?? ''} ${sessionId}`;

/**
 * The server's record for `sessionId` IF it is being written LIVE right now —
 * by a dashboard bridge OR an external terminal — else null.
 *
 * Liveness is the UNION of two signals, because neither alone is complete:
 *  - the mtime live list (`/api/sessions/live`, `LIVE_WINDOW_MS = 30s`) — catches
 *    an external terminal writing the jsonl, but DROPS a session that is still
 *    running yet idle >30s (thinking, between writes).
 *  - a live BRIDGE (`/api/sessions`, by `sdkSessionId`) — catches a session this
 *    server still owns regardless of file recency, which is exactly the
 *    bridge-driven-but-mtime-idle case that made reload dump the historical
 *    "N agents ran" summary into the streaming tail (BUG-004).
 * If EITHER says live, the session is live and must NOT get the summary. A
 * genuinely finished session (NO bridge AND stale file) matches neither and
 * correctly still shows the summary — the review view.
 */
async function liveRecordFor(sessionId) {
  if (!sessionId || state.live) return null; // our own bridge already owns the tail
  let list;
  try { list = await api.liveSessions(); } catch { return null; }
  const mtimeRec = (list ?? []).find((x) => x.sessionId === sessionId);
  if (mtimeRec) return mtimeRec; // authoritative: already carries drivenByDashboard/busy
  // Not in the mtime list — but a live bridge for this sdk id means the session
  // is still running server-side, just idle on disk. Treat it as live, and as
  // dashboard-driven (a bridge IS this dashboard's server owning the session).
  let bridges;
  try { bridges = await api.liveBridges(); } catch { return null; }
  const bridge = (bridges ?? []).find((b) => b.sdkSessionId === sessionId);
  // BUG-033: carry the bridge's honest turn clock through with its busy flag —
  // `undefined` on an older server, which openSession renders as an unknown
  // duration rather than a stopwatch started at reopen.
  if (bridge) return { sessionId, dir: null, drivenByDashboard: true, busy: bridge.busy, turnStartedAt: bridge.turnStartedAt };
  return null;
}

async function refreshLive() {
  if (state.caps.live === false) return;
  let list;
  try {
    list = await api.liveSessions();
  } catch {
    return; // transient; the next poll tries again
  }
  if (list === null) {
    state.caps.live = false; // route not on this server — stop asking, draw nothing
    if (state.liveIds.size) { state.liveIds.clear(); renderTree(); }
    return;
  }
  state.caps.live = true;
  /*
   * The route is now the ONLY authority. The `live` flag on the session list is
   * a snapshot from whenever that list was fetched, and merging it in kept a
   * badge burning for a session that had been finished for a minute — the exact
   * dishonesty this feature is supposed to remove. The flag is still used, but
   * only as a fallback when the route is absent (see liveInfo).
   */
  const next = new Map(list.map((x) => [liveKey(x.dir, x.sessionId), x]));
  // Following a run we don't drive (opened while it was still live): when the
  // server stops reporting it as busy, the run ended — flip honestly to idle.
  // BUT the mtime list is not the whole story: a session still owned by a live
  // BRIDGE (idle, just not writing its jsonl) has dropped out of this list yet is
  // NOT finished — tearing the follow down for it is the same mtime blindness that
  // made reload dump the agent summary (BUG-004). Only declare the run over when
  // NEITHER the mtime list (busy) NOR a live bridge still owns the session.
  if (state.followingLive && state.current.sessionId) {
    const mine = list.find((x) => x.sessionId === state.current.sessionId && x.drivenByDashboard && x.busy);
    if (!mine) {
      let bridged = false;
      // On error, keep following rather than falsely declare the run over.
      try { bridged = (await api.liveBridges() ?? []).some((b) => b.sdkSessionId === state.current.sessionId); }
      catch { bridged = true; }
      if (!bridged) {
        state.followingLive = false;
        // BUG-217: no bridge is left, so no other tab is driving it either — a
        // row held back by that refusal may go now (setBusy's flush below).
        state.liveElsewhere = '';
        setBusy(false);
        state.turnStartedAt = 0;
        say('the run finished');
        void refreshCurrentProjectSessions();
      }
    }
  }
  const same = next.size === state.liveIds.size && [...next.keys()].every((k) => state.liveIds.has(k));
  // A session that WAS live and no longer is = Claude finished work there.
  // Its row's lastActivityAt is stale until the list refetches, and the
  // unseen badge reads that field — so refresh the lists of the projects
  // whose live sessions just ended, or "finished" would never badge.
  const ended = [...state.liveIds.entries()].filter(([k]) => !next.has(k));
  state.liveIds = next;
  // BUG-045: a drain-wait row retries the moment its session leaves the live
  // set — that transition IS "the drain settled". The slow interval in
  // armDrainWaitRetry stays as the fallback for a transition this poll missed.
  if (ended.some(([, rec]) => state.queue.some((q) => !q.dead && q.drainWait === rec.sessionId))) {
    attemptDrainRetry({ immediate: true });
  }
  /*
   * BUG-217: "written by another program" is only ever inferred from a fresh
   * transcript mtime (no bridge), and it is also exactly how THIS dashboard's
   * own session reads for ~30s after its bridge closed. Once nothing has written
   * it for the live window, nobody is writing it: stop claiming otherwise, and
   * let a queued message go (flushQueue → driveQueue) instead of waiting on a
   * writer that is not there.
   */
  if (state.followingExternal && state.current.sessionId
    && !list.some((x) => x.sessionId === state.current.sessionId)) {
    state.followingExternal = false;
    paintPerm();
    if (state.queue.some((q) => !q.dead)) flushQueue();
  }
  for (const [, rec] of ended) {
    for (const [projectId, s] of state.sessions) {
      if (!s.loaded) continue;
      if ((rec.dir && s.dirs?.includes(rec.dir)) || s.list.some((x) => x.sessionId === rec.sessionId)) {
        void loadSessions(projectId, { force: true });
        break;
      }
    }
  }
  // FEAT-154 — refresh the "waiting on you" set from the BRIDGE list, which the
  // server owns and keeps alive as long as the bridge lives (unlike the mtime
  // live list, which drops a session that has been paused-on-a-question and
  // silent for >30s). The server publishes `awaitingUser` per bridge; we read it
  // and never re-derive it. Keyed by sdkSessionId (the nav row's own id).
  let awaitingChanged = false;
  try {
    const bridges = await api.liveBridges();
    if (Array.isArray(bridges)) {
      const nextAwaiting = new Set(
        bridges.filter((b) => b && b.awaitingUser === true && b.sdkSessionId).map((b) => b.sdkSessionId));
      awaitingChanged = nextAwaiting.size !== state.awaitingIds.size
        || [...nextAwaiting].some((id) => !state.awaitingIds.has(id));
      state.awaitingIds = nextAwaiting;
    }
  } catch { /* transient — keep the last honest set */ }
  if (!same || awaitingChanged) renderTree(); // only repaint when the answer actually changed
}

function startLivePolling() {
  if (state.liveTimer) return;
  const tick = () => { if (!document.hidden) void refreshLive(); };
  void refreshLive();
  state.liveTimer = setInterval(tick, LIVE_POLL_MS);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) void refreshLive(); });
}

/** The liveness record for a sidebar row, or null when nothing is writing it. */
function liveInfo(sess) {
  const hit = state.liveIds.get(liveKey(sess.encodedDir, sess.sessionId));
  if (hit) return hit;
  // Only trust the row's own flag while the route cannot be consulted: it is as
  // old as the list it came with, and a stale one is a badge that lies.
  if (state.caps.live !== true && sess.live === true) {
    return { sessionId: sess.sessionId, dir: sess.encodedDir, drivenByDashboard: false };
  }
  return null;
}

function closeSocket() {
  // Only claim intent when a socket actually exists — otherwise the flag
  // survives to the NEXT socket and makes a genuine drop look routine.
  state.closingOnPurpose = !!state.ws;
  if (state.ws) {
    try { state.ws.send(JSON.stringify({ type: 'close' })); state.ws.close(); } catch { /* already gone */ }
  }
  state.ws = null;
  ovrStart = null; // BUG-198 round 2 — a start's pending bag binding dies with its socket
  state.live = false;
  state.dropped = false;
  state.deliveryRelay = null; // FEAT-065: the relay (if that is what this was) dies with its socket
  state.resumeOnNextSend = null;
  state.sdkSessionId = null;
  state.effective = null;
  state.liveTools = null; // FEAT-051 — the live attach report died with the socket
  paintIntegrations();    //            back to the planned (hollow) view
  state.startSnapshot = null;
  state.pendingAnswers.clear();
  // FEAT-042: the chip's live report and change-baseline belong to the socket's
  // session — a new session must start clean, never inherit a stale flag.
  liveWireModel = null;
  expectedLiveModel = null;
  clearModelFlag();
  paintModelChip();
  setBusy(false);
}

/**
 * Re-arm the dropped session. We deliberately do NOT fire a turn here: the
 * bridge can only attach by starting one, and inventing a prompt on the user's
 * behalf spends their money on a message they never wrote. Instead the next
 * message they send resumes the same SDK session, with the transcript intact.
 */
function reconnectDropped() {
  const resume = state.sdkSessionId;
  if (!resume) return say('nothing to resume — start a new session', true);
  state.dropped = false;
  state.resumeOnNextSend = resume;
  paintSessStatus();
  const th = mainThread();
  th.claudeBody = null;
  th.paneEl.append(el('div', { class: 'ran-lbl', text: `reconnected · resuming session ${resume.slice(0, 8)} on your next message` }));
  paintComposerFor(viewedThread());
  say(`ready — your next message resumes session ${resume.slice(0, 8)}`);
  node.prompt.focus();
}

/** Returns true only when the frame was actually handed to an OPEN socket. */
function send(cmd) {
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
    say('no live session on this socket', true);
    return false;
  }
  try {
    state.ws.send(JSON.stringify(cmd));
    return true;
  } catch (err) {
    say(`could not send: ${err.message}`, true);
    return false;
  }
}

/**
 * True for the ONE error that means "this session will never send again":
 * either the server's authoritative `budgetStopped:true` flag (the initial
 * budget-stop notice, fired independent of any send), or — belt and braces,
 * since the flag only travels on that one event — the exact rejection
 * message `AgentSession.send()` throws for a budget-stopped session
 * (agent-bridge.ts `session stopped: budget exceeded`), which reaches the
 * client through the generic ws catch with no flag attached. Matched on the
 * literal string, not a substring, so an unrelated error never mis-fires this.
 */
function isBudgetStop(e) {
  return e.budgetStopped === true || e.message === 'session stopped: budget exceeded';
}

/**
 * Undo the optimistic "you" bubble `submit()` paints before the server has
 * confirmed delivery. Mirrors what the mid-turn queue already does for a
 * message that never reached Claude (see queueMessage/failQueue) — a bubble
 * must never claim delivery for a turn the agent never saw (BUG-013).
 */
function rollBackPendingSend() {
  const pending = state.pendingSend;
  state.pendingSend = null;
  if (!pending) return;
  pending.el.remove();
  // Give the text back to the composer rather than dropping it — the user
  // should not have to retype a message that silently failed to send.
  if (!node.prompt.value) node.prompt.value = pending.text;
  autosize();
}

/**
 * BUG-029: a `start`/resume the server refused BEFORE it acked — i.e. the turn
 * never began. The prime case is BUG-022's guard, which refuses to resume while
 * a prior server's FEAT-015 survivor broker is still draining the SAME
 * transcript ("still finishing its previous turn after a server restart…"). That
 * refusal is RETRYABLE, but the old path left the optimistic bubble on screen,
 * dropped the typed text (it lives nowhere on disk — a reload loses it), and
 * armed a 4s watchdog whose "composer released" flip-flopped the status banner.
 * Undo it honestly instead: pull the phantom bubble, hand the text back to the
 * composer, tear down the half-open socket (it has no server-side session, so it
 * could only answer a retry with "no session on this socket"), and arm the next
 * Enter to re-attempt the SAME resume so one keystroke retries cleanly.
 */
function rollBackPendingStart() {
  const text = state.pendingStart;
  const resume = state.pendingStartResume;
  // BUG-132: a self-retry's text belongs to its queue row, not to the composer —
  // returning it here overwrote the user's in-progress typing every 7s.
  const keepComposer = state.pendingStartKeepComposer;
  // BUG-217: any queued row this refused start carried keeps its text, marked —
  // callers with a better reason settle it first (failDrainWaitAttempt).
  failDrainWaitAttempt('the session refused it — press Send again to retry');
  state.pendingStart = null;
  state.pendingStartResume = null;
  state.pendingStartKeepComposer = false;
  // The optimistic bubble startTurn painted is the last top-level `.you` in main
  // (same idiom the reattach path uses to reclaim it into the queue).
  const bs = mainThread().paneEl.querySelectorAll(':scope > .you');
  bs[bs.length - 1]?.remove();
  if (text && !keepComposer && !node.prompt.value) { node.prompt.value = text; autosize(); }
  // Close the socket we opened for this refused start; without a server-side
  // session a retry over it only earns "no session on this socket".
  if (state.ws) { state.closingOnPurpose = true; try { state.ws.close(); } catch { /* already gone */ } }
  if (resume) state.resumeOnNextSend = resume; // next Enter re-attempts the same resume
  setBusy(false);
  state.turnStartedAt = 0;
  state.sessReconnecting = false;
  paintSessStatus();
}

/**
 * BUG-149 — the server refused this send because ANOTHER TAB is driving the
 * session (`code: 'live-elsewhere'`). Two things went wrong before, and the
 * second is the one that cost the user their words:
 *
 *  1. The refusal arrived as a `fatal` error frame, so it fell into the generic
 *     fatal branch below: `say()` put it in the transient footer strip and
 *     `console.warn`, which is where the user eventually found it — after
 *     waiting for a reply that could never come. That branch also latched
 *     `sessError` and marked every OTHER queued row dead ("the session hit a
 *     fatal error"), which is simply false: the session is alive and well, in
 *     the other tab.
 *  2. The fatal branch RETURNS before the BUG-029 pre-ack hand-back, so
 *     `state.pendingStart` — the only copy of the typed text anywhere — was
 *     never reclaimed. Nothing persisted it and a reload destroyed it. That is
 *     exactly the loss BUG-129 shipped storage durability to end; this route
 *     never reached the code that stores.
 *
 * The invariant restored here, in the user's words: keep it in browser storage
 * unless the server acknowledged it. The text becomes an ordinary dock row —
 * durable through persistQueue, saying plainly that it was NOT delivered, and
 * recoverable into the composer in one click — and never a bubble claiming a
 * delivery the server explicitly refused. It is deliberately NOT auto-resent
 * when the other tab lets go: sending a person's message on their behalf,
 * minutes later, into a conversation that has moved on is a different harm
 * (the same reason BUG-129's restored rows come back dead).
 */
function handleLiveElsewhere(message) {
  const fromStart = state.pendingStart != null;
  // BUG-217: a start carrying a QUEUED row (driveQueue's resume, or a drain
  // retry) — that row is still in the dock, so it stays there, pending; minting
  // a second, dead copy of its text would double it. While another tab drives,
  // driveQueue will not re-attempt it on its own (liveElsewhere gates it), and
  // the dock says so and offers Send now.
  const attempt = fromStart ? state.drainWaitAttempt : null;
  if (attempt) {
    state.drainWaitAttempt = null;
    attempt.sending = false;
    attempt.drainWait = null;
    if (!drainWaitItem()) disarmDrainWaitRetry();
  }
  const text = attempt ? null : fromStart ? state.pendingStart : (state.pendingSend?.text ?? null);
  const resume = state.pendingStartResume;
  state.pendingStart = null;
  state.pendingStartResume = null;
  state.pendingStartKeepComposer = false;
  // Reclaim the optimistic bubble — the turn never began, so nothing was said.
  // Which bubble depends on which path painted it, and guessing wrong would
  // delete an innocent message: `pendingSend` knows its own element, while a
  // refused `start` is the last top-level `.you` (rollBackPendingStart's idiom).
  if (fromStart) {
    // The exact element, recorded when the start painted it. The old "last
    // top-level .you" idiom is a guess, and in a two-tab session it guesses
    // wrong: the transcript follower appends the OTHER tab's real messages
    // while this one waits for its ack. Falling back to it only when there is
    // no recorded element keeps the older paths' behaviour unchanged.
    if (state.pendingStartEl) state.pendingStartEl.remove();
    else {
      const bs = mainThread().paneEl.querySelectorAll(':scope > .you');
      bs[bs.length - 1]?.remove();
    }
  }
  state.pendingStartEl = null;
  if (state.pendingSend) { state.pendingSend.el.remove(); state.pendingSend = null; }
  // Close the half-open socket this refused start opened: it has no server-side
  // session, so a retry over it could only earn "no session on this socket".
  if (state.ws) {
    state.closingOnPurpose = true;
    try { state.ws.close(); } catch { /* already gone */ }
    // Mark it dead NOW rather than at its close event — setBusy(false) below
    // schedules a flush, and a still-"live" closing socket would push rows into
    // a session-less socket (the window queueRetryableRefusal guards the same way).
    state.ws = null;
    state.live = false;
  }
  if (resume) state.resumeOnNextSend = resume; // one Enter re-attempts the same resume
  setBusy(false);
  state.turnStartedAt = 0;
  state.sessReconnecting = false;
  if (text && text.trim()) {
    const storable = queueTargetKey() != null;
    state.queue.push({
      text,
      dead: 'another tab is driving this session',
      composedAt: Date.now(),
    });
    // paintQueue mirrors the row into storage (BUG-129: every mutation repaints,
    // and that repaint IS the write path).
    paintQueue();
    if (!storable) {
      // Storage is unavailable / this view owns no session key: the row is on
      // screen but WILL NOT survive a reload. Say so rather than imply durability.
      say('your message is in the dock but could not be saved for a reload — copy it out before reloading', true);
    }
  }
  state.liveElsewhere = message;
  say(message, true);
  paintSessStatus();
  paintComposerFor(viewedThread());
}

/*
 * BUG-217 round 3 — the server refused a frame because a queued row it carried
 * is already taken: delivered, discarded, in flight from another sender, or
 * held as unconfirmed. Nothing was sent, attached or spawned. Undo exactly what
 * this frame painted, then settle each row by the server's answer — a delivered
 * row leaves (never sent twice), an in-flight one waits and is asked again, and
 * a row the frame carried that nobody else has is simply pending again.
 */
function handleQueueDuplicate(e) {
  const states = e.states ?? {};
  let rows = [];
  if (e.of === 'send' && e.sendId && state.sendAttempts.has(e.sendId)) {
    const a = state.sendAttempts.get(e.sendId);
    state.sendAttempts.delete(e.sendId);
    unwindSendAttempt(a);
    rows = a.rows ?? [];
    for (const q of rows) q.sending = false;
    applyLedgerStates(rows, states);
    setBusy(false); // this frame started no turn; the boundary flush re-judges what is left
    return;
  }
  if (state.pendingStart == null) return;
  const attempt = state.drainWaitAttempt;
  state.drainWaitAttempt = null;
  state.pendingStart = null;
  state.pendingStartResume = null;
  state.pendingStartKeepComposer = false;
  if (state.pendingStartEl) state.pendingStartEl.remove();
  state.pendingStartEl = null;
  // The socket this refused start opened has no server-side session.
  if (state.ws) {
    state.closingOnPurpose = true;
    try { state.ws.close(); } catch { /* already gone */ }
    state.ws = null;
    state.live = false;
  }
  state.turnStartedAt = 0;
  state.sessReconnecting = false;
  if (attempt) { attempt.sending = false; applyLedgerStates([attempt], states); }
  setBusy(false);
  paintSessStatus();
}

/*
 * BUG-090 — the server refused a plain resume ONLY because the session was
 * recorded under a pre-isolation store dir (classically: before the container
 * was enabled, when the cwd — and so the encoded store dir — was different).
 * Roll the optimistic start back, then arm a one-click fork bar with plain,
 * context-aware copy. ONE CLICK, never a silent auto-fork: forking mints a new
 * session id, so branching is always the user's explicit act.
 */
function armNeedsFork(nf) {
  // The turn never began (pendingStart still set): reclaim the phantom bubble
  // and the typed text and close the refused socket. rollBack re-arms a plain
  // resume, but pendingFork/forkFrom win in submit(), so the next send forks.
  // BUG-217: a queued row this start was carrying stays in the dock, marked —
  // it cannot go until the user forks, and it must not look like it will.
  failDrainWaitAttempt('this session has to be forked before it can continue — use the fork bar, then Send again');
  if (state.pendingStart != null) rollBackPendingStart();
  else setBusy(false);
  state.resumeOnNextSend = null; // a plain resume cannot work here — the fork replaces it
  state.sessError = null;        // not a dead end; the fork bar is the way forward
  state.pendingFork = { resumeSessionId: nf.resumeSessionId, resumeEncodedDir: nf.resumeEncodedDir, cause: nf.cause, toContainer: nf.toContainer };
  say(nf.cause === 'isolation-changed'
    ? (nf.toContainer === false
      // container→direct: the project used to run in a container and now runs
      // direct on the host. Saying "into the container" here is backwards.
      ? 'This session ran in a container, but the project now runs directly on the host — resuming it here can’t reach that history. Fork it to continue here; the original stays untouched.'
      : 'This session was recorded before you enabled the container — resuming it here can’t reach that history. Fork it into the container to continue; the original stays on the host.')
    : nf.cause === 'path-changed'
      // BUG-138: the project's directory was renamed and the project repointed.
      // The transcript is intact and still listed — the CLI just cannot continue
      // a conversation in a directory that no longer exists under that name.
      ? 'This session ran before this project’s directory was renamed — the history is intact, but it can’t resume against the old path. Fork it to continue here; the original stays untouched.'
      : 'This session was recorded on another machine — it can’t resume here. Fork it into a session on this machine; the original stays untouched.');
  paintComposerFor(viewedThread());
}

/*
 * BUG-090 — the fork bar (#frozen) is shared by two "can't resume here, fork
 * it" cases, so its copy and the #forkBtn label are context-aware. `ctx` null =
 * the Windows-origin default (client-detected, os==='windows'); a pendingFork
 * object = the server's needs-fork signal (container vs cross-OS).
 */
function paintFrozenBar(ctx) {
  const span = node.frozen.querySelector('span');
  const btn = $('#forkBtn');
  if (!span || !btn) return;
  clear(span);
  if (ctx && ctx.cause === 'isolation-changed' && ctx.toContainer === false) {
    // container→direct: the mirror of the classic case. "Into the container" is
    // the wrong direction here — the project now runs direct on the host.
    span.append(
      el('b', { text: 'Recorded in a container.' }),
      document.createTextNode(' This session ran in a container; the project now runs directly on the host. Fork it to continue here? The original stays untouched.'));
    btn.textContent = 'Fork to continue here';
  } else if (ctx && ctx.cause === 'isolation-changed') {
    span.append(
      el('b', { text: 'Recorded before the container.' }),
      document.createTextNode(' This session was recorded before you enabled the container. Fork it into the container? The original stays on the host.'));
    btn.textContent = 'Fork into the container';
  } else if (ctx && ctx.cause === 'path-changed') {
    // BUG-138 — naming the rename, because "recorded on another machine" sent
    // the reader looking for a Windows checkout that was never involved.
    span.append(
      el('b', { text: 'Recorded before the rename.' }),
      document.createTextNode(' This session ran under this project’s previous directory name. The history reads here; it can’t resume against a path that is gone. Fork it to continue? The original stays untouched.'));
    btn.textContent = 'Fork to continue here';
  } else if (ctx) {
    span.append(
      el('b', { text: 'Recorded on another machine.' }),
      document.createTextNode(' The history reads here; it can’t resume on this machine. Fork it into a session here? The original stays untouched.'));
    btn.textContent = 'Fork to a session here';
  } else {
    span.append(
      el('b', { text: 'Started on Windows.' }),
      document.createTextNode(' The history reads here; it can’t resume on this machine.'));
    btn.textContent = 'Fork to a Linux session';
  }
}

/* ============== BUG-191: a refused or unconfirmed send is never lost ========
 * Every `send` carries a client `sendId`, and the tab records what THAT attempt
 * carried (its rows' texts and the exact bubble it painted). The server echoes
 * the id on its ack and on a refusal, so a refusal recovers exactly that
 * attempt's rows — never a neighbour's, and never from `pendingSend`/`outbox`
 * guesses, which other attempts and turn-ends overwrite.
 *  - retryable (definitely NOT delivered, e.g. an adoption still settling):
 *    the rows go back to the FRONT of the queue as drain-wait rows, in their
 *    original order, persisted before the socket is released and the BUG-045
 *    retry armed.
 *  - uncertain (the delivery went out, its acceptance never came back): the
 *    rows come back DEAD — visible, editable, one click to resend — and are
 *    never resent automatically (it may already have arrived).
 * ------------------------------------------------------------------------- */

/** BUG-191: the queued-line for a refusal from an adopt-gated session, or null for any other refusal. */
function adoptQueuedLine(drain) {
  if (drain?.adoptState === 'pending') return 'message queued — the session is still re-attaching after a server restart; it will send itself';
  if (drain?.adoptState) return 'message queued — the session is finishing an earlier server\'s work after a restart; it will send itself';
  return null;
}

/*
 * BUG-217 round 3: `rows` — the queued rows this prompt carries (the flush, the
 * background delivery, a force-send). Their ids ride the frame, so the server
 * claims them and never lets the same row through twice; the attempt keeps the
 * row OBJECTS, so an answer settles exactly those rows in place (never a
 * re-made copy with a new id). A typed message passes `texts` and no rows.
 */
function sendTurn(prompt, { texts, rows, el }) {
  const sendId = `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  state.sendAttempts.set(sendId, {
    texts: (rows ? rows.map((q) => q.text.trim()) : (texts ?? [])).filter((t) => t && t.trim()),
    rows: rows ?? null,
    el: el ?? null,
    at: Date.now(),
    resume: state.sdkSessionId ?? state.current?.sessionId ?? null,
  });
  const ok = send({ type: 'send', prompt, sendId, ...queueFrameFields(rows) });
  if (!ok) state.sendAttempts.delete(sendId);
  return ok;
}

/** Undo what one attempt painted — only its own bubble. */
function unwindSendAttempt(a) {
  a.el?.remove?.();
  if (state.pendingSend && state.pendingSend.el === a.el) state.pendingSend = null;
}

/** BUG-217 round 3: the server acknowledged an attempt that carried queued rows — they are delivered; they leave. */
function settleAttemptDelivered(a) {
  if (!a?.rows?.length) return;
  for (const q of a.rows) { q.sending = false; removeQueueRow(q); }
  if (!drainWaitItem()) disarmDrainWaitRetry();
  paintQueue();
}

/** Release this tab's socket after a refusal, so the BUG-045 retry can re-attempt the resume. */
function releaseSocketForRetry(resume) {
  if (state.ws) {
    state.closingOnPurpose = true;
    try { state.ws.close(); } catch { /* already gone */ }
    state.ws = null; // dead NOW — see queueRetryableRefusal for why not at its close event
    state.live = false;
  }
  if (resume) state.resumeOnNextSend = resume;
  setBusy(false);
  state.turnStartedAt = 0;
  state.sessReconnecting = false;
  paintSessStatus();
}


function queueRefusedSend(a, drain) {
  unwindSendAttempt(a);
  const now = Date.now();
  const retry = { drainWait: a.resume ?? true, drainProject: state.current.projectId, drain: drain ?? null, drainAt: now };
  if (a.rows?.length) {
    // BUG-217 round 3: the same rows, same ids — the server released them.
    for (const q of a.rows) { q.sending = false; q.force = false; Object.assign(q, retry); if (!state.queue.includes(q)) state.queue.unshift(q); }
  } else {
    state.queue.unshift(...a.texts.map((text) => ({ id: newQueueId(), text, dead: null, composedAt: a.at, ...retry })));
  }
  paintQueue(); // BUG-129: persisted before anything below can lose it
  releaseSocketForRetry(a.resume);
  say(adoptQueuedLine(drain) ?? 'message queued — the session cannot take it yet; it will send itself');
  armDrainWaitRetry();
  paintQueue();
}

function keepUnconfirmedSend(a) {
  unwindSendAttempt(a);
  if (a.rows?.length) for (const q of a.rows) { q.sending = false; q.dead = UNCONFIRMED_NOTE; if (!state.queue.includes(q)) state.queue.push(q); }
  else for (const text of a.texts) state.queue.push({ id: newQueueId(), text, dead: UNCONFIRMED_NOTE, composedAt: a.at });
  setBusy(false);
  paintQueue();
  say(`${a.texts.length === 1 ? 'a message' : `${a.texts.length} messages`} could not be confirmed as delivered — kept in the dock, not resent`, true);
}

/** A start (fresh Enter or a drain-wait retry) whose delivery could not be confirmed. */
function keepUnconfirmedStart() {
  const text = state.pendingStart;
  const resume = state.pendingStartResume;
  const retried = state.drainWaitAttempt;
  state.drainWaitAttempt = null;
  state.pendingStart = null;
  state.pendingStartResume = null;
  state.pendingStartKeepComposer = false;
  if (state.pendingStartEl) state.pendingStartEl.remove();
  else { const bs = mainThread().paneEl.querySelectorAll(':scope > .you'); bs[bs.length - 1]?.remove(); }
  state.pendingStartEl = null;
  // BUG-217 round 3: a queued row is not guessed about — the server is asked, by id
  // (it answers `uncertain` for a handover it could not confirm, `none` for one
  // that never reached it — which is then simply sent again).
  if (retried) { retried.drainWait = null; retried.sending = false; retried.remote = 'check'; scheduleReconcile(1000); }
  else if (text) state.queue.push({ id: newQueueId(), text, dead: UNCONFIRMED_NOTE, composedAt: Date.now() });
  paintQueue();
  releaseSocketForRetry(resume);
  if (!drainWaitItem()) disarmDrainWaitRetry();
  say('your message could not be confirmed as delivered — kept in the dock, not resent', true);
  paintQueue();
}

/* ============== BUG-045: retryable refusal queues + retries itself ==========
 * BUG-029 stopped the refusal LOSING the message; this stops it stranding the
 * user. A `retryable:true` pre-ack refusal (the BUG-022 survivor-drain guard,
 * BUG-033's frameless drop) means "this will work soon" — so the text becomes
 * a row in the SAME queue the busy path uses (visible, editable, discardable)
 * marked drain-wait, and the client re-attempts the SAME resume itself:
 * immediately when the live poll sees the draining session leave the live set
 * (the drain settled — see refreshLive), and on a slow interval as fallback.
 * Every retry is a full `start` the server's gate re-judges — nothing here
 * weakens BUG-033's liveness gate or races a second CLI (BUG-022); it only
 * automates the Enter the old message told the user to press.
 * ------------------------------------------------------------------------- */

const DRAIN_RETRY_MS = 7000;      // slow-poll fallback while a drain-wait row exists
const DRAIN_RETRY_MIN_GAP = 4500; // transition + interval triggers must not compound into a hammer

function queueRetryableRefusal(drain) {
  const text = state.pendingStart;
  const resume = state.pendingStartResume;
  const retried = state.drainWaitAttempt; // a self-retry that was re-refused — its row is still queued
  state.drainWaitAttempt = null;
  // FEAT-064: the server's refusal now says WHAT holds the drain (background
  // task count/ids + how long the broker has been holding). Keep it on the row
  // — refreshed on every re-refusal — so the chip states the reason and an
  // elapsed that stays honest between retries.
  if (retried && drain) { retried.drain = drain; retried.drainAt = Date.now(); }
  // BUG-217: a driveQueue resume that the server refused RETRYABLY joins the
  // drain-wait loop (its own paced retry) rather than being re-driven at once by
  // the setBusy(false) flush below — which would hammer the gate.
  if (retried && !retried.drainWait) {
    retried.drainWait = resume ?? true;
    retried.drainProject = state.current.projectId;
    retried.drain = drain ?? null;
    retried.drainAt = Date.now();
  }
  if (retried) retried.sending = false;
  state.pendingStart = null;
  state.pendingStartResume = null;
  state.pendingStartKeepComposer = false; // BUG-132: this start is settled either way
  // Same rollback as rollBackPendingStart, minus the composer hand-back — the
  // text's home is its queue row now (created below on the first refusal).
  const bs = mainThread().paneEl.querySelectorAll(':scope > .you');
  bs[bs.length - 1]?.remove();
  if (state.ws) {
    state.closingOnPurpose = true;
    try { state.ws.close(); } catch { /* already gone */ }
    // Mark the socket dead NOW, not when its close event lands: setBusy(false)
    // below schedules flushQueue, and a still-"live" closing socket would let
    // it push the drain-wait row into a session-less socket — the exact
    // double-delivery window settleDrainWaitDelivery exists to prevent.
    state.ws = null;
    state.live = false;
  }
  if (resume) state.resumeOnNextSend = resume; // a manual Enter still re-attempts the same resume
  setBusy(false);
  state.turnStartedAt = 0;
  state.sessReconnecting = false;
  paintSessStatus();
  if (!retried && text) {
    state.queue.push({
      id: newQueueId(), text, dead: null, composedAt: Date.now(),
      drainWait: resume ?? true,                // which session the retry must resume
      drainProject: state.current.projectId,    // retries only run while this project is current
      drain: drain ?? null, drainAt: Date.now(), // FEAT-064: what holds the drain, per the server
    });
    say(adoptQueuedLine(drain) ?? 'message queued — waiting for the previous turn to finish draining; it will send itself');
  }
  armDrainWaitRetry();
  paintQueue();
}

/** The oldest live drain-wait row whose retry is legal right now, or null. */
function drainWaitItem() {
  return state.queue.find((q) => !q.dead && q.drainWait && q.text.trim()
    && (!q.drainProject || q.drainProject === state.current.projectId)) ?? null;
}

function armDrainWaitRetry() {
  if (state.drainWaitTimer) return;
  state.drainWaitTimer = setInterval(() => attemptDrainRetry(), DRAIN_RETRY_MS);
}

function disarmDrainWaitRetry() {
  clearInterval(state.drainWaitTimer);
  state.drainWaitTimer = null;
}

/**
 * One self-retry of the next drain-wait row: a full startTurn over the SAME
 * resume, judged by the same server gate. Exactly-once by construction: the
 * row leaves the queue ONLY on this start's `ack` (settleDrainWaitDelivery),
 * a re-refusal keeps it queued (queueRetryableRefusal's `retried` branch),
 * and while an attempt is in flight flushQueue skips the row, so a busy
 * transition can never deliver the same text a second time.
 */
function attemptDrainRetry({ immediate = false } = {}) {
  // An attempt whose socket died with neither an ack nor a refusal reaching us
  // would guard a ghost forever — release it once it is clearly not in flight.
  // BUG-191: it may have been delivered (its ack lost with the socket), so it
  // is kept DEAD — visible, one click to resend — never re-sent blindly.
  // BUG-217 round 3: not guessed — the server is asked what became of it, by id.
  if (state.drainWaitAttempt && !state.busy && state.pendingStart == null
    && Date.now() - (state.drainWaitLastTry || 0) > 15000) {
    const ghost = state.drainWaitAttempt;
    state.drainWaitAttempt = null;
    ghost.sending = false;
    ghost.remote = 'check';
    paintQueue();
    void reconcileQueue();
  }
  if (state.drainWaitAttempt || state.busy || state.pendingStart != null || state.live) return;
  syncQueue(); // BUG-217 r2: a row discarded or sent from another tab is not retried here
  const item = drainWaitItem();
  if (!item) { if (!state.queue.some((q) => !q.dead && q.drainWait)) disarmDrainWaitRetry(); return; }
  const now = Date.now();
  if (!immediate && now - (state.drainWaitLastTry || 0) < DRAIN_RETRY_MIN_GAP) return;
  state.drainWaitLastTry = now;
  state.drainWaitAttempt = item;
  markRowsSending([item]); // BUG-217 round 3: stored as `sending` — a reload asks the server, by id
  /*
   * BUG-132: the composer is NOT this retry's channel — `keepComposer` makes
   * startTurn (and the refusal rollback behind it) leave the box alone entirely.
   * The previous save-and-restore-around-the-promise could not work: startTurn
   * blanked the box synchronously and the restore only ran a server round-trip
   * later, guarded on the box still being empty — and the refusal in between had
   * already filled it with the QUEUED row's text, so the guard declined and the
   * user's typing was gone. Never save/restore across an await what you can
   * simply not touch.
   */
  Promise.resolve(startTurn(item.text, {
    resumeSessionId: typeof item.drainWait === 'string' ? item.drainWait : undefined,
    keepComposer: true,
    queueRows: [item],
  })).catch(() => { state.drainWaitAttempt = null; item.sending = false; });
}

/** The retry's `start` was ACKED with its prompt delivered — retire the row, exactly once. */
function settleDrainWaitDelivery({ quiet = false } = {}) {
  const item = state.drainWaitAttempt;
  if (!item) return;
  state.drainWaitAttempt = null;
  const wasDrive = !!item.sending && !item.drainWait; // BUG-217: driveQueue's resume, not a drain retry
  item.sending = false;
  const idx = state.queue.indexOf(item);
  if (idx !== -1) state.queue.splice(idx, 1);
  if (!drainWaitItem()) disarmDrainWaitRetry();
  paintQueue();
  // FEAT-065: a survivor delivery says its own (more accurate) line — the
  // drain did NOT finish, the message was injected into it.
  if (!quiet) say(wasDrive ? 'sent your queued message' : 'the previous turn finished draining — delivered your queued message');
}

/**
 * A self-retry refused NON-terminally keeps its row, marked dead, so the text
 * stays recoverable.
 *
 * BUG-132: this used to RETIRE the row whenever the composer was empty, because
 * the rollback right after would deposit the text there instead (BUG-029's
 * composer-return). A retry no longer touches the composer at all — it never
 * took the text from there — so retiring the row now would be the one thing
 * neither side holds it: always keep it. The row is the durable copy (BUG-129
 * mirrors it to storage on the repaint below).
 */
function failDrainWaitAttempt(why) {
  const item = state.drainWaitAttempt;
  if (!item) return;
  state.drainWaitAttempt = null;
  item.sending = false;
  item.dead = why;
  if (!drainWaitItem()) disarmDrainWaitRetry();
  paintQueue();
}

/* ======================= BUG-031: provider/API error relay ==================
 * The runtime maps its provider's native failures into a provider-agnostic
 * shape; the bridge relays it as `provider-error`. Here it renders ATTRIBUTED
 * — provider + failure class + the provider's own detail text verbatim — as a
 * transcript card (durable, unlike the one-line #fine ticker), with the status
 * page linked when one exists and a Retry affordance when retrying can work.
 * ------------------------------------------------------------------------- */

const PROVIDER_ERROR_LABELS = {
  'overloaded': 'servers overloaded',
  'rate-limited': 'rate limited',
  'quota-window': 'usage limit reached',
  'auth-expired': 'authentication expired',
  'network': 'network failure',
  'model-unavailable': 'model unavailable',
  // BUG-035: an attached MCP tool server that never started. Not a turn
  // failure — the turn runs fine, just without those tools — so it is worded
  // as the capability loss it is.
  'tooling-unavailable': 'tools missing — an MCP server failed to start',
  'internal': 'provider error',
};

function provErrorLabel(e) {
  return PROVIDER_ERROR_LABELS[e.kind] ?? 'provider error';
}

/** One-line attribution used for the session-status hint and the ticker. */
function provErrorLine(e) {
  return `${e.provider} — ${provErrorLabel(e)}: ${e.detail || '(no detail given)'}`;
}

function retryLastTurn() {
  if (state.busy) return say('a turn is already running — wait for it or interrupt first', true);
  if (state.budgetLocked) return say(state.budgetLockReason || 'this session hit its budget limit', true);
  const text = node.prompt.value.trim() || state.lastTurnPrompt || '';
  if (!text) return say('nothing to retry — type the message again', true);
  node.prompt.value = text;
  autosize();
  void submit();
}

function renderProviderError(e) {
  const body = claudeBody(mainThread());
  const card = el('div', { class: 'provider-error', 'data-kind': e.kind, 'data-provider': e.provider },
    el('div', { class: 'pe-head', text: `${e.provider} — ${provErrorLabel(e)}` }),
    el('div', { class: 'pe-detail', text: e.detail || '(the provider gave no detail)' }),
  );
  const foot = el('div', { class: 'pe-foot' });
  if (typeof e.resetsAt === 'number' && e.resetsAt > 0) {
    // The wire carries epoch seconds; tolerate ms defensively.
    const ms = e.resetsAt < 1e12 ? e.resetsAt * 1000 : e.resetsAt;
    foot.append(el('span', { class: 'pe-reset', text: `resets ${new Date(ms).toLocaleString()}` }));
  }
  if (e.statusUrl) {
    foot.append(el('a', {
      class: 'pe-status', href: e.statusUrl, target: '_blank', rel: 'noopener',
      text: e.statusUrl.replace(/^https?:\/\//, ''),
    }));
  }
  if (e.retryable) {
    foot.append(el('button', { class: 'pe-retry', type: 'button', text: 'Retry', onclick: retryLastTurn }));
  }
  if (foot.childElementCount) card.append(foot);
  body.append(card);
  card.scrollIntoView?.({ block: 'nearest' });
}

/**
 * A turn is "busy" until `turn-end`. If the server reports an error instead,
 * the turn may or may not still be alive — so we arm a short watchdog rather
 * than guessing. Any further event cancels it; silence releases the composer.
 */
function armBusyWatchdog(why) {
  clearTimeout(state.busyWatchdog);
  state.busyWatchdog = setTimeout(() => {
    if (!state.busy) return;
    setBusy(false);
    state.turnStartedAt = 0;
    state.pendingSend = null; // ambiguous outcome (see comment above) — stop tracking it either way
    cancelForceSend(`${why} — no turn is running`);
    say(`${why} — no turn is running, composer released`, true);
  }, 4000);
}

/*
 * FEAT-040 — session-state legibility. One computed, ALWAYS-painted label so a
 * transitional state (reconnecting, running detached, mid-thought before any
 * text) never reads as indistinguishable from "broken". Priority order below
 * is deliberate: a down transport outranks everything (we cannot vouch for
 * what is happening behind it), an explicit error outranks routine busy-ness,
 * and only true silence — nothing running, nothing pending — reads as idle.
 *
 * BUG-153 added the rule that was missing under all of that: NO label may
 * promise something this tab cannot do. "Thinking…"/"Responding…" describe a
 * turn the user can interrupt, queue into and force-send over, so they are
 * gated on actually holding the socket those three act on (isDriving()). Work
 * that is running where we cannot reach it gets the label that says so, and
 * says what to do about it.
 */
const SESS_STATUS_META = {
  thinking: { label: 'Thinking…', hint: 'Claude is working — no reply text yet.' },
  streaming: { label: 'Responding…', hint: 'Claude is streaming its reply.' },
  awaiting: { label: 'Waiting on you', hint: 'Claude asked a question above and is paused for your answer — it is not working. You can also send a new message; it runs as your next turn.' },
  detached: { label: 'Running in background', hint: 'This turn is continuing server-side without this tab attached — send a message to take it over.' },
  reconnecting: { label: 'Reconnecting…', hint: 'Reattaching to the session — resuming shortly.' },
  error: { label: 'Error', hint: '' }, // hint filled from state.sessError at paint time
  idle: { label: 'Idle', hint: 'Nothing is running.' },
};

function computeSessState() {
  if (state.sessReconnecting || state.dropped) return 'reconnecting';
  if (state.sessError) return 'error';
  /*
   * BUG-153 — detachment is DERIVED, never remembered. A tab that holds no
   * driving socket is not steering this session, whatever flags a past event
   * left behind, so it may never say "Claude is working": that label promises
   * a turn this tab can interrupt, queue into and force-send over, and the
   * guards on all three refuse in exactly this state. Either something IS
   * running out there (`busy` from the reopen path, `followingLive` from a run
   * we only watch) — and then "running in the background · send to take it
   * over" is both true and the way out — or nothing is, and it is idle.
   *
   * `state.sessDetached` used to gate this line and was cleared by any socket
   * open; the honest state then silently downgraded to "Claude is working"
   * while force-send answered "no live session". See isDriving().
   */
  if (!isDriving()) return (state.busy || state.followingLive) ? 'detached' : 'idle';
  /*
   * BUG-166 (ARCH-010) — a pending decision is the model STOPPED, waiting on the
   * user, not working. The pending question owns that fact
   * (awaitingUserDecision, from decisionsByRequest); read it here rather than
   * presenting `busy` as "Thinking… / Claude is working" — the mislabel this
   * ticket is about. Gated on `busy` so a card left behind by a finished turn
   * cannot keep an idle session reading "waiting on you".
   */
  if (state.busy && awaitingUserDecision()) return 'awaiting';
  if (state.busy) return state.sessPhase === 'streaming' ? 'streaming' : 'thinking';
  return 'idle';
}

/*
 * FEAT-048 — survival ground truth (FEAT-040's machine half, BUG-027's
 * adopted/scoped fields) surfaced on the SAME affordance the human half
 * already reads. `state.sessSurvival` identifies the CURRENT session by
 * `state.stationSessionId` (this tab's live bridge) falling back to
 * `state.sdkSessionId` (still matches a `surviving-unadopted` broker entry,
 * which carries no stationSessionId of its own — see the health route's
 * `sdkSessionId ?? h.resumeHint` fallback in src/server/index.ts).
 */
function sessSurvivalKey() {
  return state.stationSessionId || state.sdkSessionId || null;
}

/** Renders the ground-truth line from a /api/health `sessions[]` entry (or
 * null when nothing has been fetched yet / no session is open). Mirrors
 * scripts/station-doctor.mjs's vocabulary so the human and machine halves
 * never disagree about what "protected" means. */
function survivalHintLine(entry) {
  if (!entry) return '';
  if (entry.adopted === false) {
    const brokerState = entry.broker?.state ?? 'unknown';
    return `Survived a restart — broker alive (${brokerState}), not yet adopted by this server; resume to continue the thread.`;
  }
  if (!entry.survivalConfigured) return 'Not protected — survival is not configured for this session.';
  if (entry.survivalScoped === true) return 'Protected — survives a server restart.';
  if (entry.survivalScoped === false) return '⚠ survival configured but NOT scoped — not actually protected against a restart right now.';
  return ''; // survivalScoped null (no broker to check) with nothing else to say
}

function paintSessStatus() {
  if (!node.sessStatus) return;
  const s = computeSessState();
  const meta = SESS_STATUS_META[s];
  node.sessStatus.dataset.state = s;
  node.sessStatusLbl.textContent = meta.label;
  const base = (s === 'error' && state.sessError) ? state.sessError : meta.hint;
  const key = sessSurvivalKey();
  const survival = (key && state.sessSurvival.key === key) ? survivalHintLine(state.sessSurvival.entry) : '';
  node.sessStatus.title = survival ? `${base}\n${survival}` : base;
  paintAuto();
}

/*
 * FEAT-048 — fetch /api/health lazily, ONLY on hover/focus of #sessStatus
 * (never a hot poll: this data changes at most once per restart/spawn, so
 * polling it on a timer would burn a request cycle for information that is
 * almost always unchanged — a hover is the actual moment the user wants it).
 * A short cache absorbs repeated hovers/mouse jitter without re-fetching.
 */
const SESS_SURVIVAL_CACHE_MS = 15_000;
let sessSurvivalInFlight = null;
function refreshSessSurvival() {
  const key = sessSurvivalKey();
  if (!key) return; // no session open yet — nothing to look up
  const fresh = state.sessSurvival.key === key && (Date.now() - state.sessSurvival.at) < SESS_SURVIVAL_CACHE_MS;
  if (fresh || sessSurvivalInFlight) return;
  sessSurvivalInFlight = api.health().then((health) => {
    const sessions = Array.isArray(health?.sessions) ? health.sessions : [];
    const entry = sessions.find((s) => s.stationSessionId === key || s.sdkSessionId === key) ?? null;
    state.sessSurvival = { key, entry, at: Date.now() };
    paintSessStatus();
  }).catch(() => { /* route absent/unreachable — title just stays without the survival line */
  }).finally(() => { sessSurvivalInFlight = null; });
}

// Hover OR keyboard focus (title attrs are mouse-only otherwise, and this
// affordance is a button) triggers the lazy fetch above.
if (node.sessStatus) {
  node.sessStatus.addEventListener('mouseenter', refreshSessSurvival);
  node.sessStatus.addEventListener('focus', refreshSessSurvival);
}

/* ============================ FEAT-022: autonomous mode =====================
 * An EXPLICITLY chosen keep-going-until-a-stop-condition loop (WA §M), distinct
 * from the interactive NEEDS-YOU default. The affordance lives in the crown next
 * to #sessStatus: a toggle that arms autonomous with a bounded stop condition
 * ("stop after N turns"), an UNMISTAKABLE running badge showing progress, and a
 * prominent Stop that returns to interactive. All control goes through the
 * /api/sessions/:id/autonomous routes; the server owns the loop and the halt.
 * ------------------------------------------------------------------------- */

// One-time injected style: the running badge must be impossible to miss (this
// is an unattended mode). styles.css is out of this ticket's scope, so the few
// rules the badge needs are injected here rather than added there.
function ensureAutoStyle() {
  if (document.getElementById('autoStyle')) return;
  const st = document.createElement('style');
  st.id = 'autoStyle';
  st.textContent = `
@keyframes csAutoPulse { 0%,100%{opacity:1} 50%{opacity:.55} }
/* An author display rule beats the UA [hidden]{display:none}; restore it so the
   hidden attribute actually hides these (else the badge shows when it must not). */
.auto-wrap[hidden],.auto-badge[hidden],.auto-form[hidden]{display:none!important}
.auto-wrap{position:relative;display:inline-flex;align-items:center;gap:6px;margin-left:10px;font:inherit}
.auto-badge{display:inline-flex;align-items:center;gap:6px;font:700 11px/1 ui-monospace,monospace;letter-spacing:.06em;
  color:#fff;background:#b45309;border:1px solid #f59e0b;padding:3px 8px;border-radius:6px;
  box-shadow:0 0 0 2px rgba(245,158,11,.25);animation:csAutoPulse 1.2s ease-in-out infinite}
.auto-badge .d{width:7px;height:7px;border-radius:50%;background:#fde68a}
.auto-btn{font:600 11px/1 inherit;padding:3px 9px;border-radius:6px;cursor:pointer;
  border:1px solid var(--line,#333);background:transparent;color:inherit}
.auto-btn[data-mode="stop"]{border-color:#f59e0b;color:#fbbf24}
.auto-form{position:absolute;top:100%;left:0;margin-top:6px;z-index:60;white-space:nowrap;
  display:flex;align-items:center;gap:6px;padding:8px 10px;border-radius:8px;
  background:var(--panel,#17171b);border:1px solid var(--line,#333);box-shadow:0 8px 24px rgba(0,0,0,.4)}
.auto-form input{width:52px;font:inherit;padding:2px 4px}
.auto-form .dim{opacity:.7;font-size:11px}
body[data-autonomous="1"]::before{content:"";position:fixed;inset:0 0 auto 0;height:3px;z-index:9999;
  background:linear-gradient(90deg,#b45309,#f59e0b,#b45309);animation:csAutoPulse 1.2s ease-in-out infinite;pointer-events:none}`;
  document.head.append(st);
}

// Build the crown affordance once and cache its nodes on `node`.
function ensureAutoUI() {
  if (node.autoWrap) return;
  ensureAutoStyle();
  const wrap = el('div', { class: 'auto-wrap' });
  const badge = el('span', { class: 'auto-badge' }, el('span', { class: 'd' }), el('span', { class: 'txt' }));
  badge.hidden = true;
  const btn = el('button', { class: 'auto-btn', id: 'autoBtn', type: 'button' });
  const form = el('div', { class: 'auto-form' });
  form.hidden = true;
  const input = el('input', { id: 'autoTurns', type: 'number', min: '1', max: '50', value: '5' });
  const go = el('button', { id: 'autoStart', class: 'auto-btn', type: 'button', text: 'Start' });
  form.append(el('span', { class: 'dim', text: 'Stop after' }), input, el('span', { class: 'dim', text: 'turns' }), go);
  btn.addEventListener('click', () => {
    if (state.autonomous.autonomous) void stopAutonomous();
    else { form.hidden = !form.hidden; if (!form.hidden) input.focus(); }
  });
  go.addEventListener('click', () => void startAutonomous(Number(input.value)));
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') void startAutonomous(Number(input.value)); });
  wrap.append(badge, btn, form);
  node.sessStatus.after(wrap);
  Object.assign(node, { autoWrap: wrap, autoBadge: badge, autoBadgeTxt: badge.querySelector('.txt'), autoBtn: btn, autoForm: form, autoTurns: input });
}

// Reflect state.autonomous into the crown. Hidden until a session is actually
// driven from this tab (no station id ⇒ no route to address).
function paintAuto() {
  if (!node.sessStatus) return;
  ensureAutoUI();
  const a = state.autonomous;
  const canControl = !!(state.live && state.stationSessionId);
  node.autoWrap.hidden = !canControl;
  document.body.dataset.autonomous = a.autonomous ? '1' : '0';
  if (!canControl) { node.autoForm.hidden = true; return; }
  if (a.autonomous) {
    node.autoBadge.hidden = false;
    node.autoForm.hidden = true;
    node.autoBadgeTxt.textContent = `AUTONOMOUS ${a.turnsDone}/${a.maxTurns ?? '?'}`;
    node.autoBadge.title = `Running unattended — auto-continuing up to ${a.maxTurns} turns, then stopping. Working only the agreed scope.`;
    node.autoBtn.textContent = 'Stop';
    node.autoBtn.dataset.mode = 'stop';
    node.autoBtn.title = 'Stop autonomous mode — return to interactive';
  } else {
    node.autoBadge.hidden = true;
    node.autoBtn.textContent = 'Autonomous';
    node.autoBtn.dataset.mode = 'idle';
    node.autoBtn.title = 'Interactive (default). Enable a bounded auto-continue loop.';
  }
}

async function startAutonomous(maxTurns) {
  const id = state.stationSessionId;
  if (!id) { say('no live session to make autonomous', true); return; }
  try {
    const r = await api.api(`/api/sessions/${encodeURIComponent(id)}/autonomous`, {
      method: 'POST', body: JSON.stringify({ action: 'start', maxTurns }),
    });
    state.autonomous = r.autonomous;
    say(`autonomous ON — will auto-continue up to ${state.autonomous.maxTurns} turns, then stop. Working the current scope only; send a turn (or let the one in flight finish) to run the loop.`);
  } catch (err) {
    say(`could not enable autonomous: ${err.message}`, true);
  }
  paintAuto();
}

async function stopAutonomous() {
  const id = state.stationSessionId;
  if (!id) return;
  try {
    const r = await api.api(`/api/sessions/${encodeURIComponent(id)}/autonomous`, {
      method: 'POST', body: JSON.stringify({ action: 'stop' }),
    });
    state.autonomous = r.autonomous;
    say('autonomous stopped — back to interactive. A turn already in flight finishes; nothing new is auto-continued.');
  } catch (err) {
    say(`could not stop autonomous: ${err.message}`, true);
  }
  paintAuto();
}

// Re-read the server's authoritative mode. Called after a session goes live
// (reflects a mode that persisted across a reload) and at every turn boundary
// while autonomous (advances the counter, and catches the halt at the stop
// condition — the server, not the client, decides when the loop ends).
async function refreshAuto() {
  const id = state.stationSessionId;
  if (!id) return;
  try {
    const r = await api.optional(`/api/sessions/${encodeURIComponent(id)}/autonomous`);
    if (!r) return;
    const wasOn = state.autonomous.autonomous;
    state.autonomous = r;
    if (wasOn && !r.autonomous) {
      say(`autonomous complete — stopped (${r.stopReason ?? 'done'}) after ${r.turnsDone} turns; back to interactive.`);
    }
    paintAuto();
  } catch { /* transient — the next boundary re-reads it */ }
}

function setBusy(busy) {
  if (!busy) clearTimeout(state.busyWatchdog);
  state.busy = busy;
  node.go.dataset.mode = busy ? 'stop' : 'send';
  node.go.setAttribute('aria-label', busy ? 'Interrupt' : 'Send message');
  node.go.title = busy ? 'Interrupt' : 'Send';
  clear(node.go).append(busy ? iconStop() : iconSend());
  if (!busy) state.turnStartUnknown = false; // BUG-033: no turn, nothing unknown about it
  if (busy) {
    // BUG-033: never invent a start time. A caller that knows one sets
    // `turnStartedAt` before calling; a caller that does NOT sets
    // `turnStartUnknown`, and the clock renders "—" instead of a fake age.
    if (!state.turnStartUnknown) state.turnStartedAt = state.turnStartedAt || Date.now();
    // A fresh turn starts in "thinking" (no reply text yet) and clears any
    // stale error from a PRIOR turn — the new activity is the honest truth now.
    state.sessPhase = 'thinking';
    state.sessError = null;
    state.provError = null; // BUG-031: a new turn owns its own provider-error state
  }
  renderStrip();
  paintSessStatus();
  /*
   * The queue flushes on the busy TRANSITION, not on one lucky event. It was
   * wired to turn-end only, and busy also drops through interrupt acks,
   * watchdogs and error paths — a queued message then waited forever
   * (observed live: an interrupted turn stranded a queued message). The
   * microtask lets the caller finish first (a fatal handler marks the queue
   * failed before the flush would try a dead socket).
   */
  if (!busy) queueMicrotask(flushQueue);
  paintQueue();
  paintTitle();
}

function iconSend() {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 16 16'); s.setAttribute('width', '14'); s.setAttribute('height', '14');
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.7');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', 'M8 12.8V3.4M4 7.4 8 3.4l4 4'); s.append(p);
  return s;
}
function iconStop() {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 16 16'); s.setAttribute('width', '14'); s.setAttribute('height', '14');
  const r = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  r.setAttribute('x', '4.5'); r.setAttribute('y', '4.5'); r.setAttribute('width', '7'); r.setAttribute('height', '7');
  r.setAttribute('rx', '1.4'); r.setAttribute('fill', 'currentColor'); s.append(r);
  return s;
}

const LIVE_ACTIVITY = new Set(['text', 'text-delta', 'tool-call', 'tool-result', 'tool-progress',
  'agent-started', 'agent-progress', 'agent-completed', 'thinking-tokens', 'session-init']);

function onEvent(e, fromWs = null) { // BUG-198 round 2 — fromWs: the driving socket this frame arrived over (null = not from one)
  if (state.busy && LIVE_ACTIVITY.has(e.t)) clearTimeout(state.busyWatchdog);
  switch (e.t) {
    case 'session-appended':
      // Handled by the passive watch socket only. If the server broadcasts to
      // every socket, the driving one must drop it or the message lands twice.
      return;

    case 'subagent-send-unsupported': {
      // Authoritative refusal from the server. Fall back to the read-only
      // state and quote its reason rather than paraphrasing it.
      const th = state.threads.get(e.targetAgentId);
      if (th) {
        th.unsupportedReason = e.reason;
        if (e.agentStatus) th.status = e.agentStatus;
        if (state.viewing === e.targetAgentId) paintComposerFor(th);
      }
      setBusy(false);
      say(e.reason, true);
      return;
    }

    case 'effective-config':
      // Authoritative: what the SDK was actually spawned with. The drawer
      // reconciles its `overridden` tags against this rather than against
      // what the UI believes it sent.
      state.effective = e;
      drawer.repaintLive();
      paintPerm(); // reflect what the server ACTUALLY applied, not our guess
      paintIntegrations(); // FEAT-051 — provider/capabilities honesty (codex: MCP off)
      paintModelBtn();
      paintModelChip(); // FEAT-042 — the chip tracks the same authoritative value
      if (e.ignoredOverrides?.length) {
        say(`ignored: ${e.ignoredOverrides.map((i) => `${i.field} (${i.reason})`).join('; ')}`, true);
        // BUG-196 round 6 — the server DECLARED that this session's engine cannot run
        // the armed model pick (judged by its one classifier against the real
        // engine). Forget exactly that pick — memory and storage — so it stops
        // riding every start. Never judged here: the client holds no classifier.
        const bad = e.ignoredOverrides.find((i) => i.field === 'model');
        if (bad && !dockIsForeign() && state.overrides.model === bad.value) {
          delete state.overrides.model;
          persistOverrides();
          paintModelBtn();
        }
      }
      return;

    case 'ack':
      if (e.of === 'set-permission-mode') {
        // `ok` is the server's word for "the SDK accepted it". `matched` keeps
        // the same meaning as the approval acks.
        const good = e.ok === true || (e.ok === undefined && e.matched !== false && !e.error);
        finishPermMode(e.requestId, good, e.error || e.reason || 'the server declined the change', e.appliesFrom);
        return;
      }
      if (e.of === 'set-model') {
        const good = e.ok === true || (e.ok === undefined && e.matched !== false && !e.error);
        finishModel(e.requestId, good, e.error || e.reason || 'the server declined the change');
        return;
      }
      if (e.of === 'question-response' || e.of === 'plan-response') {
        const pending = state.pendingAnswers.get(e.requestId);
        if (pending) {
          state.pendingAnswers.delete(e.requestId);
          pending.settle(e.matched);
        }
        return;
      }
      if (e.of === 'approval-response') {
        const pending = state.pendingAnswers.get(e.requestId);
        if (pending) {
          state.pendingAnswers.delete(e.requestId);
          pending.settle(e.matched);
        }
        return;
      }
      // BUG-191: the server confirmed (or declined) THIS attempt — it is settled either way.
      if (e.of === 'send' && e.sendId) {
        const a = state.sendAttempts.get(e.sendId);
        state.sendAttempts.delete(e.sendId);
        // BUG-217 round 3: queued rows it carried are delivered — the server recorded them so.
        if (a && e.delivered !== false) settleAttemptDelivered(a);
        else if (a?.rows) for (const q of a.rows) q.sending = false;
      }
      if (e.of === 'send' && e.delivered === false) {
        setBusy(false);
        paintQueue();
        return; // subagent-send-unsupported carries the explanation
      }
      if (e.of === 'start') {
        // BUG-187 P2: a new attachment starts with no authoritative pending list.
        state.approvalsComplete = false;
        if (e.deliveredVia === 'survivor') {
          /*
           * FEAT-065: the server wrote this start's prompt straight into the
           * drain-held survivor's stdin — a normal turn in the SAME CLI pid.
           * There is NO live bridge: this socket stays open only to relay any
           * approval the injected turn raises (approval-request/-response),
           * and closes on the turn's `survivor-delivery` notice. The turn
           * itself — including the user message — renders from the transcript
           * file-follow, so the optimistic bubble startTurn painted must come
           * out (the follow re-renders it, and doubling it would lie).
           */
          settleDrainWaitDelivery({ quiet: true }); // BUG-045 exactly-once: the retried row is delivered
          state.pendingStart = null;
          state.pendingStartResume = null;
          state.deliveryRelay = e.sdkSessionId ?? true;
          state.sdkSessionId = null; // no bridge — closing this relay later is routine, never a "drop"
          state.turnStartedAt = 0;
          state.sessReconnecting = false;
          setBusy(false); // flushQueue is relay-guarded; other queued rows wait for the retry loop
          const dbs = mainThread().paneEl.querySelectorAll(':scope > .you');
          dbs[dbs.length - 1]?.remove();
          /*
           * The watch socket streams the injected turn in from the transcript.
           * BUG-190: only (re)follow when NOT already following this session. A
           * re-follow is unfollow+follow; the unfollow stops the server's watch
           * and the new one starts at the file's CURRENT end — so the survivor's
           * echo of this very message (written within ms of the stdin write,
           * inside the watcher's 150 ms debounce) was skipped, and the user's
           * message and reply vanished from the open view until a reload.
           */
          if (!state.following) followCurrent(true);
          paintSessStatus();
          paintQueue();
          say('delivered into the still-draining session — it runs there now; the reply streams in from the transcript');
          return;
        }
        state.followingLive = false; // we now DRIVE this session — no longer a passive follow
        state.followingExternal = false; // …and we took over from the external writer
        // BUG-030: rows this attach does not re-announce (replayAgents frames
        // land right behind this ack) have no live process behind them — an
        // open tab that lived through a server/CLI cut keeps stale ◐ rows
        // that nothing else would ever settle. Sweep them after the replay.
        scheduleCutSweep();
        // FEAT-022: the station session id — the key the autonomous routes are
        // addressed by — arrives on this ack (fresh AND reattach). Capture it,
        // then re-read the mode: a session made autonomous before a reload still
        // is, and this is where we learn it.
        if (e.stationSessionId) {
          state.stationSessionId = e.stationSessionId;
          void refreshAuto();
          void refreshRequests(); // FEAT-126 — the real key for the binding store is known now
        }
        // Driving it now (this socket sent `start` and got acked) — whatever
        // detached/reconnecting state applied before this is resolved.
        // (`followingLive` is cleared just above, for the same reason.)
        state.sessReconnecting = false;
        paintSessStatus();
        if (e.effective) {
          state.effective = {
            ...(state.effective ?? {}),
            effective: e.effective,
            overridden: e.overridden ?? [],
            permissionModeSource: e.permissionModeSource ?? state.effective?.permissionModeSource,
            isolation: e.isolation ?? state.effective?.isolation,
            // FEAT-037 P3: the engine's honesty flags + resolved provider ride
            // the ack too, so a reattach knows what to gray out immediately.
            capabilities: e.capabilities ?? state.effective?.capabilities,
            provider: e.effective?.provider ?? state.effective?.provider,
          };
          drawer.repaintLive();
          paintPerm();
          paintModelBtn();
          paintModelChip(); // FEAT-037 P3: the crown's provider mark tracks the ack too
        }
        /*
         * SNAPSHOT PROTECTION, stated per session.
         *
         * `startSnapshotId` is null when this session has NO restore point —
         * either snapshots are off for the project, or the snapshot FAILED (a
         * non-fatal error carried the reason and the session started anyway).
         * That failure is invisible otherwise: the session looks completely
         * normal, so the user would assume protection they do not have.
         *
         * `undefined` means this server does not report it — say nothing rather
         * than guess, since both "protected" and "not protected" would be a
         * claim we cannot support.
         */
        if ('startSnapshotStatus' in e || 'startSnapshotId' in e) {
          state.startSnapshot = readStartSnapshot(e);
          drawer.repaint();
        }
        /*
         * RE-ATTACHED to a session that kept running while no tab was driving
         * it. If a turn is in flight, the prompt this start carried was NOT
         * delivered — the bubble startTurn painted must come back out of the
         * transcript and into the queue, where it delivers at the boundary.
         */
        if (e.reattached) {
          /*
           * BUG-191 — `promptDelivered`: this start's prompt went into an
           * adopt-gated session through the broker's CONFIRMED acceptance, so
           * the turn it opened is why the session is busy. It is delivered —
           * settle it exactly once; re-queuing it (the busy branch below) would
           * send it a second time at the next boundary.
           */
          if (e.promptDelivered) {
            if (Number.isFinite(e.turnStartedAt) && e.turnStartedAt > 0) {
              state.turnStartedAt = e.turnStartedAt;
              state.turnStartUnknown = false;
            }
            settleDrainWaitDelivery({ quiet: true });
            state.pendingStart = null;
            state.pendingStartResume = null;
            state.pendingStartEl = null;
            setBusy(!!e.busy);
            say('re-attached — your message was delivered into the running session');
            return;
          }
          if (e.busy) {
            // BUG-033: the server's honest turn clock, or an honest unknown —
            // never a fresh stamp (see turnClock()).
            if (Number.isFinite(e.turnStartedAt) && e.turnStartedAt > 0) {
              state.turnStartedAt = e.turnStartedAt;
              state.turnStartUnknown = false;
            } else if (!state.turnStartedAt) {
              state.turnStartUnknown = true;
            }
            setBusy(true);
            const t = state.pendingStart;
            if (t) {
              const bs = mainThread().paneEl.querySelectorAll(':scope > .you');
              bs[bs.length - 1]?.remove();
              if (state.drainWaitAttempt) {
                // BUG-045: this text ALREADY sits in the queue as its drain-wait
                // row — re-queueing would double it. The bridge is live now, so
                // the normal boundary flush owns delivery from here.
                // BUG-217: the same for a driveQueue resume that found the run
                // still going — the row waits for the pause, never injected.
                state.drainWaitAttempt.drainWait = null;
                state.drainWaitAttempt.sending = false;
                state.drainWaitAttempt = null;
                if (!drainWaitItem()) disarmDrainWaitRetry();
                paintQueue();
              } else queueMessage(t);
            }
            // BUG-160: a promptless reattach (reattachDriving) carries no `t`, so
            // there may be nothing pending — say what is true either way. A
            // restored queue row (if any) delivers at this turn's boundary; the
            // boundary flush (setBusy(false)/turn-end) owns it now we drive.
            say(state.queue.some((q) => !q.dead)
              ? 're-attached — this session is still working; your queued message goes at the next pause'
              : 're-attached — this session is still working here');
          } else {
            // Idle reattach: the server delivered this start's prompt as a new
            // turn — a drain-wait retry's row is settled (BUG-045), exactly once.
            settleDrainWaitDelivery();
            say('re-attached to the running session');
            // BUG-160: now that we hold the driving socket and the session is
            // idle, THIS is the boundary a message queued before a reload was
            // waiting for — deliver it (flushQueue is guarded on isDriving() &&
            // !busy, so it only fires here because the reattach just made both true).
            flushQueue();
          }
          state.pendingStart = null;
          state.pendingStartResume = null;
          return;
        }
        state.pendingStart = null;
        state.pendingStartResume = null;
        // BUG-045: a fresh ack means the start (and its prompt) was accepted —
        // if it was a drain-wait self-retry, its queue row is delivered.
        settleDrainWaitDelivery();
        const ovr = (e.overridden ?? []).length ? ` · overrides applied: ${e.overridden.join(', ')}` : '';
        const forked = e.fork?.forked ? ` · forked from ${String(e.fork.from ?? '').slice(0, 8)}` : '';
        const ss = state.startSnapshot;
        say(`session started · instructions: ${e.instructionMode}${(e.appliedTemplates || []).length ? ` [${e.appliedTemplates.join(', ')}]` : ''}${ovr}${forked}${ss?.line ? ` · ${ss.line}` : ''}`,
          ss?.status === 'failed');
      }
      return;

    case 'session-init':
      state.sdkSessionId = e.sessionId;
      state.current.sessionId = e.sessionId;
      // BUG-196 — a session made real by its first turn (or reattached) never goes
      // through openSession's transcript-tail fetch, so lockedProvider was never
      // learned and pendingNew stayed set — every provider surface fell back to the
      // project/override and accepted a switch the resume silently ignores. The
      // server DECLARES the engine it dispatched on (session-init.lockedProvider —
      // this.effective.provider, the same fact the transcript is pinned to and
      // resumeProviderOf returns on reopen). Record it, and mark the session real so
      // lockedSessionProvider() stops gating on pendingNew and returns the real engine.
      // BUG-196 round 3 — recorded against the session ID the frame names (the
      // one declared source, lockedProviderOf), never on view state.
      declareLockedProvider(e.sessionId, e.lockedProvider);
      state.pendingNew = null; // a running session is no longer a switchable pending-new view
      paintProvSurfaces();
      // FEAT-051: the CLI's own tool report is the ground truth for which MCP
      // servers ACTUALLY attached (mcp__<name>__… tools) — repaint the strip.
      state.liveTools = Array.isArray(e.tools) ? e.tools : null;
      paintIntegrations();
      // The "new session" now has a real id — the URL picks it up (replace,
      // not push: this is the same place, not a navigation), so a reload
      // lands back IN this session instead of another blank one.
      if (!state.current.encodedDir) state.current.encodedDir = state.sessions.get(state.current.projectId)?.encodedDir ?? null;
      adoptPendingOverrides(state.current.encodedDir, e.sessionId, fromWs); // BUG-198 round 2 — only ITS OWN pending bag, over ITS socket
      persistOverrides(); // a pre-start armed toggle now has a session id to belong to
      /*
       * BUG-129: the same move for undelivered rows. Until this frame the queue
       * was stored under the pending-new PROJECT key; from here the session has
       * a real id and a reload lands in the SESSION, which is where the rows
       * must be found. Doing it here rather than lazily at the next queue
       * mutation is not a refinement — a message queued during this very first
       * turn is mutated once and never again, so a lazy migration would leave it
       * stored under a key nothing reads and the reload would lose it exactly as
       * before. (Caught by the browser leg, which is why it is driven there.)
       */
      retargetQueue();
      persistQueue();
      if (Array.isArray(e.slashCommands) && e.slashCommands.length) {
        state.slashCommands = e.slashCommands;
        try { localStorage.setItem('cs-slash', JSON.stringify(e.slashCommands)); } catch { /* volatile is fine */ }
      }
      /*
       * BUG-021: name the model actually chosen. The pre-spawn `effective-config`
       * can only echo the project's raw setting — often null, "let the CLI
       * decide" — so it can never resolve a truly-unset default to a concrete
       * name. `session-init` is the CLI's OWN report of the wire id it picked
       * (see the normModelId comment above resolveCurrentModelOpt), the only
       * source that can. Fold it into state.effective so the picker's
       * "Project default" readout and the model button tooltip show it instead
       * of the vague placeholder.
       */
      if (e.model) {
        state.effective = { ...(state.effective ?? {}), effective: { ...(state.effective?.effective ?? {}), model: e.model } };
        paintModelBtn();
        // FEAT-042: the CLI's own launch report is both the chip's first live
        // value AND the baseline "what the user launched with" that a later
        // unrequested change is judged against.
        liveWireModel = e.model;
        expectedLiveModel = e.model;
        paintModelChip();
      }
      syncUrl('replace');
      // BUG-195 — the session is now ACTIVE and real. Setting state.current.sessionId
      // above makes the derived pending-new row (pendingNewFor) vanish, but the real
      // row is not yet in this project's s.list — it was fetched at startNew, before
      // the session existed on disk. Without a refetch here the nav shows NO row for
      // the new session until turn-end (refreshCurrentProjectSessions, the same call)
      // or a reload. Refetch now so the just-started session appears in the nav the
      // moment its first message creates it, which is what the user asked for. The
      // CLI has already written the transcript + session-provenance record by
      // session-init, so the row lists as a non-folded user session (BUG-193) and the
      // open session shows immediately via visibleSessions' alwaysIds. Not a poll —
      // it hangs off the live event that already marks the session real.
      void refreshCurrentProjectSessions();
      say(`${shortPath(e.cwd)} · ${e.model} · ${e.tools.length} tools · ${e.sessionId.slice(0, 8)}`);
      return;

    case 'text-delta': {
      // stream_event.parent_tool_use_id is always null — deltas are main-thread.
      const th = mainThread();
      if (!th.stream) {
        if (th.settledStream) {
          // BUG-170 (Case A): th.settledStream is set ONLY by finishStream, and
          // every real block boundary (this block's own 'text', a tool-call,
          // question, plan, turn-end, a gap-fetch) CLEARS it. So if it is still
          // live when a fresh text-delta arrives, finishStream fired MID-block (a
          // background lane's agent-completed between two of this block's deltas)
          // and this delta CONTINUES that same block. Resume it in place — reuse
          // the settled node as the new stream wrap and seed the buffer with the
          // already-settled text — instead of starting a fresh block, which
          // orphaned the partial node (a stray raw-JSON <pre>) beside the final
          // rail. Resuming preserves the streamed text: nothing is discarded.
          const wrap = el('div', { class: 'prose' });
          th.settledStream.node.replaceWith(wrap);
          th.stream = { wrap, text: th.settledStream.text, caret: el('span', { class: 'caret' }), timer: 0, lastRender: 0 };
          th.settledStream = null;
        } else {
          // A NEW live stream starts a new block.
          const body = claudeBody(th);
          const wrap = el('div', { class: 'prose' });
          body.append(wrap);
          th.stream = { wrap, text: '', caret: el('span', { class: 'caret' }), timer: 0, lastRender: 0 };
        }
      }
      th.stream.text += e.text;
      // Leading-edge throttle: render the first token immediately (caret shows
      // at once), then coalesce bursts and always flush the tail via schedule.
      if (Date.now() - (th.stream.lastRender || 0) >= STREAM_RENDER_MS) renderStreamNow(th);
      else scheduleStreamRender(th);
      if (state.sessPhase !== 'streaming') { state.sessPhase = 'streaming'; paintSessStatus(); }
      if (state.viewing === 'main') scrollDown();
      return;
    }

    case 'text': {
      const th = threadFor(e.agentId);
      if (e.agentId) {
        // keep the summary text for the settled row AND show it in the thread
        state.agentText.set(e.agentId, (state.agentText.get(e.agentId) ?? '') + e.text);
        if (e.agentType && !th.agentType) th.agentType = e.agentType;
        claudeBody(th).append(prose(e.text));
        if (state.viewing === e.agentId) scrollDown();
        return;
      }
      if (th.stream) {
        if (th.stream.timer) clearTimeout(th.stream.timer);
        // FEAT-083: on turn-end, the settled main-thread message re-renders
        // through the digest-aware renderer so a leading orchard-digest envelope
        // becomes the structured list (and the raw JSON is hidden).
        th.stream.wrap.replaceWith(assistantProse(e.text || th.stream.text));
        th.stream = null;
      } else if (th.settledStream
          && (e.text || '').replace(/\r\n?/g, '\n').startsWith(th.settledStream.text.replace(/\r\n?/g, '\n'))) {
        // BUG-169: finishStream already settled THIS block (a mid-stream
        // agent-completed / tool-call / turn-end fired before this trailing 'text'
        // arrived). Re-render that same node digest-aware in place — do NOT append,
        // which is what painted the fence a second time. The startsWith guard makes
        // sure this is a continuation of the settled buffer, not a later unrelated
        // block (e.g. a post-tool paragraph or a gap-fetch rewrite).
        //
        // BUG-169 round 2: compare in the renderer's NORMALISED line-ending space
        // (the same `\r\n?`->`\n` boundary renderAssistantText applies). The
        // settled buffer is the raw concatenation of `text-delta` frames; the
        // trailing `text` carries the CLI's canonical `block.text`. When those two
        // disagree on line endings only (LF deltas, CRLF block text is a real
        // divergence), the byte-exact startsWith MISSED, took the else branch, and
        // APPENDED a second, digest-aware render — leaving the mid-stream settle
        // (a RAW-JSON <pre> of the still-unclosed digest fence) orphaned above the
        // rail. That is the reported "raw JSON at top, correct rail below"
        // duplicate. Normalising both sides makes the continuation-of-same-block
        // test robust to line-ending skew without weakening it for a genuinely
        // different later block (which the boundary handlers null settledStream for).
        th.settledStream.node.replaceWith(assistantProse(e.text));
      } else {
        claudeBody(th).append(assistantProse(e.text));
      }
      th.settledStream = null;
      if (state.viewing === 'main') scrollDown();
      return;
    }

    case 'thinking-tokens':
      return; // the log carries no readable thinking text; the strip already shows work is happening

    case 'tool-call': {
      // Subagent tool calls now land in that agent's own thread rather than
      // being dropped — that thread is a real, viewable transcript.
      const th = threadFor(e.agentId);
      if (e.agentId && e.agentType && !th.agentType) { th.agentType = e.agentType; refreshLede(th); }
      finishStream(th);
      th.settledStream = null; // a tool call / decision is a hard block boundary (BUG-169)
      // A question or a plan is a decision, not a tool call. Rendering it as a
      // chip is the bug: it looks like something that already happened.
      if (renderDecisionCall(th, e)) return;
      th.tools.set(e.toolUseId, toolChip(th, e.name, e.input));
      return;
    }

    case 'tool-result': {
      const th = threadFor(e.agentId);
      const card = th.decisions?.get(e.toolUseId);
      if (card) {
        // The tool came back, so the model is moving on. If we never got an ack
        // for an answer, it moved on WITHOUT one — say that, never imply a pick.
        settleDecisionFromResult(card, e);
        return;
      }
      const t = th.tools.get(e.toolUseId);
      if (!t) return;
      t.chip.classList.remove('running');
      t.res.textContent = e.isError ? 'error' : `${e.preview.split('\n').length} lines`;
      t.pre.textContent = e.preview || '(no output)';
      if (e.isError) t.chip.open = true;
      return;
    }

    /*
     * Typed decision events. The server workstream is landing these; until they
     * arrive the cards still render off `tool-call` above, just without an
     * answer channel. Both spellings are accepted so whichever name lands works.
     */
    case 'question-request':
    case 'ask-user-question': {
      const th = threadFor(e.agentId);
      finishStream(th);
      th.settledStream = null; // a question is a hard block boundary (BUG-169)
      renderQuestion(th, {
        toolUseId: e.toolUseId ?? null,
        requestId: e.requestId ?? null,
        questions: parseQuestions(e.input ?? e),
      });
      return;
    }
    case 'plan-request':
    case 'exit-plan-mode': {
      const th = threadFor(e.agentId);
      finishStream(th);
      th.settledStream = null; // a plan is a hard block boundary (BUG-169)
      renderPlan(th, {
        toolUseId: e.toolUseId ?? null,
        requestId: e.requestId ?? null,
        plan: parsePlan(e.input ?? e),
      });
      return;
    }

    case 'tool-progress': {
      const t = threadFor(e.agentId).tools.get(e.toolUseId);
      if (t) t.res.textContent = `${Math.round(e.elapsedSeconds)}s…`;
      return;
    }

    /*
     * ARCH-001 phase 2 / BUG-034 — the server's running-set snapshot, pushed
     * whenever the answer changes (turn start, agent start/end, turn end, a
     * reap, the reattach handshake). Trusted: it arrived on this session's own
     * socket. This is the event the strip renders; the `agent-*` events below
     * keep doing what only they can (threads, "ran" rows, transcript settling).
     */
    case 'running-snapshot':
      applySnapshot(e.snapshot, { trusted: true });
      return;

    case 'agent-started': {
      state.agents.set(e.agent.agentId, { agent: e.agent, t0: Date.now() - (e.agent.elapsedMs || 0), settled: false, seenAt: Date.now() });
      // Give it a thread immediately so the row is clickable the moment it appears.
      const th = state.threads.get(e.agent.agentId) ?? newThread(e.agent.agentId, { kind: agentKind(e.agent) });
      // BUG-171: stamp the server's DECLARED kind (via agentKind, the one reader)
      // onto the thread so a tool lane is not rendered as an agent. Covers a
      // thread that pre-existed as the default 'agent' (e.g. a stream frame that
      // raced ahead of this start).
      th.kind = agentKind(e.agent);
      th.agentType = e.agent.agentType;
      th.description = e.agent.description;
      th.status = 'running';
      th.loaded = true;
      refreshLede(th);
      renderStrip();
      return;
    }
    case 'agent-progress': {
      const cur = state.agents.get(e.agent.agentId);
      if (cur) { cur.agent = e.agent; cur.t0 = Date.now() - (e.agent.elapsedMs || 0); cur.seenAt = Date.now(); }
      else state.agents.set(e.agent.agentId, { agent: e.agent, t0: Date.now() - (e.agent.elapsedMs || 0), settled: false, seenAt: Date.now() });
      const t = state.threads.get(e.agent.agentId);
      if (t) { t.kind = agentKind(e.agent); t.agentType = e.agent.agentType; t.description = e.agent.description; t.status = e.agent.status; refreshLede(t); }
      renderStrip();
      return;
    }
    case 'agent-completed': {
      const cur = state.agents.get(e.agent.agentId) ?? { settled: false };
      cur.agent = e.agent;
      cur.seenAt = Date.now();
      state.agents.set(e.agent.agentId, cur);
      if (!cur.settled) {
        cur.settled = true;
        // BUG-030: a tool-call task (kind 'tool' — e.g. a subagent's Bash call
        // the CLI surfaces as task_type "local_bash") is not a subagent: it
        // must not finish the main stream or leave a "ran" row. Settling just
        // retires its ◐ strip row and marks its thread done.
        if (agentKind(e.agent) === 'tool') {
          const t = state.threads.get(e.agent.agentId);
          if (t) { t.status = e.agent.status; refreshLede(t); }
        } else {
          finishStream(mainThread());
          finishStream(state.threads.get(e.agent.agentId));
          settleAgent(cur);
        }
      }
      renderStrip();
      return;
    }

    case 'approval-request':
      renderAsk(e);
      return;

    case 'approvals-snapshot':
      applyApprovalsSnapshot(e);
      return;

    case 'permission-denied':
      say(`permission denied: ${e.toolName}${e.reason ? ` — ${e.reason}` : ''}`, true);
      return;

    /*
     * FEAT-065: the turn delivered into the drain-held survivor ended. The
     * relay socket has nothing left to relay — close it deliberately (routine,
     * never a "drop") so the drain-wait retry loop resumes for anything still
     * queued; the turn's output already rendered via the transcript follow.
     */
    case 'survivor-delivery':
      if (e.phase === 'turn-done') {
        if (state.deliveryRelay) closeSocket();
        say('the delivered turn finished — the session keeps draining its background work; your next message goes through the normal gate');
      }
      return;

    case 'status': {
      // BUG-100: this event carries anything the server wants to surface —
      // including a dispatched agent's task notification, which for shell work
      // is the RAW running command (a multi-hundred-char heredoc in the report).
      // The footer is not a log: it must never adopt raw command text as its
      // resting content, and it must never displace the isolation label. The
      // running rail (#strip) is the home for what's in flight; here we keep the
      // stable label and, when agents are running, append only a COMPACT bounded
      // indicator. The raw text rides the title so it stays reachable on hover.
      if (state.busy) return; // a live main turn owns the footer; nothing to add
      const raw = String(e.status ?? '');
      const agents = runningAgentCount();
      const commandish = raw.length > 48 || /[\n]/.test(raw);
      if (agents > 0 || commandish) {
        const label = isoLabel(currentProject());
        const activity = agents > 0 ? `${agents} agent${agents === 1 ? '' : 's'} running` : 'working…';
        // BUG-101: structured render — the transient count is set apart from the
        // permanent isolation label (quieter tone + moss dot), never a run-on.
        sayIso(label, activity, raw || null);
      } else {
        // A genuinely short human notice (fork removed, browser starting, a
        // memory warning): show it, still capped by say().
        say(raw);
      }
      return;
    }

    case 'compact-boundary':
      claudeBody(mainThread()).append(el('div', { class: 'ran-lbl', text: `context compacted (${e.trigger || 'auto'})` }));
      return;

    /*
     * FEAT-042 — the per-turn ground truth: the wire model that actually
     * produced the latest main-thread assistant message. Matching the
     * expectation (what the user launched with / last confirmed) just keeps
     * the chip current; NOT matching it is a change the user did not initiate
     * — flag it. A pending user switch (modelPending) or a null expectation
     * (e.g. reattach where session-init never re-fired, or an inherit whose
     * resolution is by definition the CLI's to make) adopts without flagging:
     * claiming "silent switch!" without a baseline would be a false alarm.
     *
     * BUG-084 — the baseline that matters is what the USER SELECTED, not the
     * configured default the CLI reports at `session-init`. When the user has an
     * explicit /model override (`state.overrides.model`), the per-turn report
     * that matches THAT is the user's own choice answering — never a silent
     * switch — even though the init-seeded `expectedLiveModel` (the settings.json
     * default, e.g. Fable) disagrees. Without this, every resume re-seeds the
     * stale default and then flags the user's own opus turn as "Fable → opus"
     * ("per-turn report") on repeat. Matching the choice quietly REALIGNS the
     * baseline so a later GENUINE deviation (live ≠ selection AND ≠ last) still
     * surfaces, exactly as FEAT-042 intends.
     */
    case 'model-observed': {
      const prev = liveWireModel ?? expectedLiveModel;
      const chosen = state.overrides?.model ?? null; // the user's explicit /model
      const matchesChoice = chosen != null && sameModel(chosen, e.model);
      const silent = !modelPending && !matchesChoice
        && expectedLiveModel != null && !sameModel(expectedLiveModel, e.model);
      liveWireModel = e.model;
      if (matchesChoice) expectedLiveModel = e.model; // realign the stale baseline, quietly
      if (silent) {
        expectedLiveModel = e.model; // flag ONCE; this is the new reality
        flagModelChange(prev, e.model, 'per-turn report');
      }
      paintModelChip();
      return;
    }

    /*
     * FEAT-042 — the SDK's one DEDICATED switch signal: a safeguard refusal
     * made the CLI retry on a fallback model, persistently. By definition not
     * user-initiated — always flag. The server also folds it into the
     * effective config (an `effective-config` re-emit follows and will agree).
     */
    case 'model-changed': {
      const from = e.from ?? liveWireModel ?? expectedLiveModel;
      liveWireModel = e.to;
      expectedLiveModel = e.to;
      flagModelChange(from, e.to, `refusal fallback${e.category ? ` · ${e.category}` : ''}`);
      paintModelChip();
      return;
    }

    case 'rate-limit':
      // `allowed` is the normal steady state — only speak up when it isn't.
      // (status 'rejected' ALSO arrives as an attributed `provider-error`
      // quota-window card — this line stays as the lightweight ticker.)
      if (/^(allowed|ok)$/i.test(e.status)) return;
      say(`rate limit: ${e.status}${e.utilization != null ? ` · ${Math.round(e.utilization * 100)}%` : ''}`, true);
      return;

    /*
     * BUG-031 — a provider/API failure, normalized by the runtime (kind,
     * retryable, provider, detail — the provider's own words). Two shapes:
     *  - `retrying` present: the ENGINE is retrying it itself; the turn is
     *    still alive, so only the ticker speaks (no card per attempt — a long
     *    outage emits many of these) and busy stays true honestly.
     *  - terminal: attributed transcript card + ticker + the session status
     *    turns to this error. Busy resolution is the following `turn-end`'s
     *    job (the CLI always emits its result frame after the error carrier);
     *    the watchdog below is the belt-and-braces guarantee that the
     *    composer can NEVER stay stuck if that result never comes.
     */
    case 'provider-error': {
      if (e.retrying) {
        const wait = e.retrying.delayMs >= 1000 ? `${Math.round(e.retrying.delayMs / 1000)}s` : `${e.retrying.delayMs}ms`;
        say(`${e.provider} — ${provErrorLabel(e)}${e.statusCode != null ? ` (HTTP ${e.statusCode})` : ''} · retry ${e.retrying.attempt}/${e.retrying.maxRetries} in ${wait}`, true);
        return;
      }
      /*
       * BUG-035: a missing TOOL server is honest news, but it is not this
       * turn's failure — the turn is alive and will end normally. So it gets
       * the same attributed, durable card + ticker line, and deliberately does
       * NOT become state.provError (which labels the turn-end / session status)
       * and does NOT arm the busy watchdog (the turn still owes us a result).
       */
      if (e.kind === 'tooling-unavailable') {
        // Still starting (the CLI does not block turn one on its MCP servers):
        // an honest one-line "attaching…" notice, no failure card.
        if (e.pending) {
          say(`${e.provider} — ${e.detail}`, true);
          return;
        }
        renderProviderError(e);
        say(provErrorLine(e), true);
        return;
      }
      state.provError = e;
      renderProviderError(e);
      say(provErrorLine(e), true);
      if (state.busy) armBusyWatchdog(`${e.provider} ${provErrorLabel(e)}`);
      paintSessStatus();
      return;
    }

    case 'turn-end': {
      /*
       * BUG-030's invariant, as corrected by BUG-113: anything still `running`
       * here MAY be a zombie from a cut host CLI — or it may be a background
       * agent the server's own turn-end sweep deliberately spared, which
       * outlives this turn by design. This tab cannot tell them apart, so it
       * nominates them and lets the server's next post-turn snapshot answer.
       * Nothing is settled here.
       */
      nominateCutAgents();
      { const mt = mainThread(); finishStream(mt); mt.settledStream = null; } // turn is over; settled node is final (BUG-169)
      setBusy(false);
      state.turnStartedAt = 0;
      // The turn that just ended is exactly the one submit() painted the
      // pending bubble for — it reached the agent, so there is nothing left
      // to roll back (see rollBackPendingSend / BUG-013).
      state.pendingSend = null;
      /*
       * BUG-129: a turn ENDED, so the prompt that started it is in the server's
       * transcript — the handed-off batch is durable somewhere other than this
       * tab and the outbox copy can go. This is the only place that retires it:
       * an ack does not, because the server acks `delivered: true`
       * unconditionally without knowing whether the bridge took the text.
       * Cleared BEFORE the force-send / flush dispatch below, which sets a new one.
       */
      state.outbox = null;
      persistQueue();
      // BUG-031: an API-error turn reports subtype 'success' with is_error:
      // true (terminal_reason 'api_error') — labelling it by subtype would
      // literally print "success" as the error. Prefer the attributed
      // provider-error this turn produced, then the engine's terminal reason,
      // then the subtype.
      /*
       * BUG-136: an error turn carries the engine's OWN sentence about why in
       * `result` — the server has forwarded it as `resultText` all along and
       * nothing has ever read it. So a container whose credentials mount had
       * gone stale ended `subtype:'success'`, `is_error:true`, terminal reason
       * 'completed', and the UI latched a badge that said "Error" over a hint
       * that said "success", while the one line that named the fault — "Not
       * logged in · Please run /login" — was dropped on the floor. Used only
       * where the label would otherwise be the bare subtype, i.e. exactly the
       * case where the alternative is a word that contradicts the badge.
       */
      const engineReason = (e.isError && typeof e.resultText === 'string')
        ? e.resultText.trim().replace(/\s+/g, ' ').slice(0, 200)
        : '';
      const endLabel = e.interrupted ? 'interrupted'
        : (e.isError && state.provError) ? `${state.provError.provider} ${provErrorLabel(state.provError)}`
          : (e.isError && e.terminalReason === 'api_error') ? 'api error'
            : engineReason ? engineReason
              : e.subtype;
      const bits = [endLabel];
      if (e.durationMs) bits.push(`${(e.durationMs / 1000).toFixed(1)}s`);
      // BUG-100: this dollar figure is an API-EQUIVALENT ESTIMATE, not money the
      // user is billed (they run on a fixed plan). Label it so a glance can never
      // read it as real spend — the user was briefly alarmed by an unlabelled
      // "$65.5067" here.
      if (e.costUsd) bits.push(`~$${e.costUsd.toFixed(4)} est.`);
      if (e.numTurns) bits.push(`${e.numTurns} turns`);
      const summary = bits.join(' · ');
      // BUG-100: the run summary is an OUTCOME, not the resting status. It must
      // not be what replaces the isolation label. An ERROR still speaks up in the
      // footer ticker (that IS a transient alert, worded and marked as one); a
      // clean/interrupted outcome goes to the transcript's durable outcome rail
      // and the footer returns to its stable label.
      if (e.isError && !e.interrupted) {
        say(summary, true);
      } else {
        appendTurnOutcome(summary, e.costUsd);
        restLabel();
      }
      // A turn that ended in error (not a deliberate interrupt) is the
      // "Error / stopped — explicit" state; a clean end is honestly idle.
      // With a provider-error on record, the state carries ITS attributed
      // line (provider + kind + the provider's own detail), not the subtype.
      state.sessError = (e.isError && !e.interrupted)
        ? (state.provError ? provErrorLine(state.provError) : summary)
        : null;
      paintSessStatus();
      renderStrip();
      void refreshCurrentProjectSessions();
      // FEAT-022: a turn boundary is exactly when the autonomous loop either
      // advances (server auto-continues) or halts at the stop condition. Re-read
      // the authoritative mode so the badge counter and the halt are both shown.
      if (state.autonomous.autonomous) void refreshAuto();
      // FEAT-031 Part A: a force-send's interrupt lands here as an
      // `interrupted:true` turn-end — this is the ONLY reliable signal that
      // the aborted turn has actually stopped, so deliver the forced item
      // right now, ahead of (and instead of) the normal queue flush this
      // cycle. Whatever else is still queued flushes next time around.
      if (state.forceSend) {
        const item = state.forceSend;
        state.forceSend = null;
        deliverForced(item);
      } else {
        flushQueue(); // the boundary the queue was waiting for
      }
      return;
    }

    case 'error':
      // BUG-090: a resume refused ONLY because the session lives under a
      // pre-isolation store dir isn't a dead end — offer a one-click fork
      // instead of the raw fork:true/resumeEncodedDir prose. Handled before the
      // generic fatal path so it never latches sessError / fails the queue.
      if (e.needsFork && e.needsFork.resumeSessionId && e.needsFork.resumeEncodedDir) {
        armNeedsFork(e.needsFork);
        return;
      }
      /*
       * BUG-149: `fatal` on this frame does not mean the session is dead — it
       * means it is not available to THIS tab. Handled before the generic fatal
       * path, like needsFork above, so it never latches sessError, never marks
       * the other queued rows dead, and — the actual bug — never returns before
       * the un-acked text has been reclaimed into durable storage.
       */
      if (e.code === 'live-elsewhere') {
        handleLiveElsewhere(e.message);
        return;
      }
      // BUG-217 round 3: the server already has (or had) a queued row this frame carried.
      if (e.code === 'queue-duplicate') {
        handleQueueDuplicate(e);
        return;
      }
      /*
       * BUG-160: a promptless reattach (reattachDriving) found the bridge gone —
       * the session is no longer running here. Roll the half-open socket back
       * quietly and let refreshLive/the "To composer" affordance take it from
       * here; never latch sessError or mark queued rows dead for a reattach that
       * simply had nothing to attach to. (No pendingStart to reclaim — promptless.)
       */
      if (e.code === 'nothing-to-reattach') {
        state.pendingStartResume = null;
        state.followingLive = false;
        if (state.ws) {
          state.closingOnPurpose = true;
          try { state.ws.close(); } catch { /* already gone */ }
          state.ws = null;
          state.live = false;
        }
        setBusy(false);
        paintSessStatus();
        paintQueue();
        return;
      }
      say(e.message, true);
      if (e.fatal && state.pendingStart != null) {
        /*
         * BUG-215 round 2 — a FATAL error on a start/fork that never began (e.g. a
         * refused fork: the server's Codex-fork or stage-truncated guard) must not
         * swallow the typed message. Before, the fatal branch below latched
         * sessError and returned WITHOUT reclaiming pendingStart, so the optimistic
         * bubble stayed painted, the composer stayed empty, and a reload destroyed
         * the message with no trace (the fork never created a session/transcript).
         * The turn never started, so this is the same "start refused before ack"
         * recovery the non-fatal branch already uses: rollBackPendingStart removes
         * the phantom bubble and returns the text to the composer, recoverable and
         * with the error still shown (say above) and latched. resumeOnNextSend it
         * re-arms lets the next Send retry the resume (which re-arms the fork bar,
         * or plain-resumes a genuine Codex thread — the very action its error names).
         */
        state.sessError = e.message;
        rollBackPendingStart();
        cancelForceSend('the session hit a fatal error');
        return;
      }
      if (e.fatal) {
        state.sessError = e.message; // set BEFORE setBusy(false) so its repaint sees it
        setBusy(false);
        state.turnStartedAt = 0;
        cancelForceSend('the session hit a fatal error');
        failQueue('the session hit a fatal error');
      }
      else if (isBudgetStop(e)) {
        // BUG-013: lock the composer for good (until a fresh connect), and if
        // this is the rejection of an in-flight send — not just the initial
        // budget-stop notice — undo the optimistic "you" bubble so the
        // transcript never claims Claude received a message it never got.
        state.budgetLocked = true;
        state.budgetLockReason = e.message;
        state.sessError = e.message;
        rollBackPendingSend();
        setBusy(false);
        state.turnStartedAt = 0;
        cancelForceSend('the session hit its budget limit');
        failQueue('the session hit its budget limit');
        paintComposerFor(viewedThread());
      } else if (e.of === 'send' && e.sendId && state.sendAttempts.has(e.sendId)) {
        // BUG-191: a `send` the server did NOT deliver (retryable) or could not
        // confirm (uncertain) — recover exactly that attempt's rows.
        const attempt = state.sendAttempts.get(e.sendId);
        state.sendAttempts.delete(e.sendId);
        if (e.retryable) queueRefusedSend(attempt, e.drain);
        else if (e.uncertain) keepUnconfirmedSend(attempt);
        else if (state.busy) armBusyWatchdog(e.message);
      } else if (state.pendingStart != null && e.uncertain) {
        // BUG-191: a start whose delivery went out but was never confirmed.
        keepUnconfirmedStart();
      } else if (state.pendingStart != null) {
        // BUG-029: a `start`/resume refused before its `ack` — the turn never
        // began (e.g. the retryable survivor-drain guard). BUG-045: when the
        // SERVER says the refusal is retryable (a drain that WILL end), the
        // message becomes a queue row that retries itself — bouncing it to the
        // composer left the user mashing Enter for the length of the drain. A
        // non-retryable refusal keeps BUG-029's composer hand-back exactly.
        if (e.retryable) queueRetryableRefusal(e.drain);
        else {
          failDrainWaitAttempt(e.message);
          rollBackPendingStart();
        }
      } else if (state.busy) armBusyWatchdog(e.message);
      return;

    case 'session-closed':
      say(`session closed (${e.reason})`);
      // BUG-153: the run is over, so nothing is "running in the background"
      // either — this is the third place `sessDetached` was cleared, and the
      // follow flag now carries that meaning on its own.
      state.followingLive = false;
      setBusy(false);
      state.turnStartedAt = 0;
      state.pendingSend = null;
      cancelForceSend(`the session closed (${e.reason})`);
      failQueue(`the session closed (${e.reason})`);
      return;

    default:
      return;
  }
}

async function refreshCurrentProjectSessions() {
  const id = state.current.projectId;
  if (!id) return;
  await loadSessions(id, { force: true });
}

/* --------------------------------------------------------------- composer */

/* --------------------------------------------------- mid-turn send queue */

/* ------------------------------------------------- BUG-129: a queue that
 * survives the tab (option A — the CONTAINED half of the fix)
 *
 * The defect: durability was attached to DELIVERY, not to acceptance. The only
 * durable copy of a typed message was the one the server writes AFTER a
 * successful handoff, so everything between "the composer accepted it" and
 * "the CLI took it" lived in one tab's heap: a reload, a tab close, a crash or
 * a session switch destroyed it silently, and no store on either side had a
 * copy to notice the loss against (see the ticket's Evidence — the lost message
 * was in no file anywhere).
 *
 * What this closes: the reload / close / switch half. Every mutation of
 * state.queue mirrors the rows into localStorage under the SAME session key the
 * composer draft uses (draftKey — BUG-083), and openSession/startNew read them
 * back for the session they belong to.
 *
 * What this deliberately does NOT close (do not read the dock as claiming
 * otherwise — they are option B's, and each is named in the ticket):
 *   - a refusal that arrives AFTER the socket accepted the frame: the server
 *     acks delivery unconditionally, so the optimistic bubble still stands and
 *     the transcript still lies about that one;
 *   - the mid-reply re-attach that deletes a painted bubble (its text lands in
 *     this queue, so it is now at least durable — but the bubble still vanishes);
 *   - the composer box itself, which is still volatile (state.drafts is a Map).
 *
 * Two rules this file keeps deliberately:
 *   - A row is cleared from storage when the USER clears it (discard / edit to
 *     empty) or when it becomes durable somewhere else — never merely because
 *     it was optimistically painted or handed to a socket. That is why
 *     state.outbox exists.
 *   - A row that comes back from storage is marked `restored` and SAYS it was
 *     not delivered. Making the unsent state visible is worth more than making
 *     the loss rarer (and an outbox row comes back `dead`, never auto-resent —
 *     redelivering a message the user already sent is a different harm, and the
 *     ticket's Risks section names it).
 */
const QUEUE_KEY = 'cs.queue.v1';
const QUEUE_MAX_SESSIONS = 20;      // newest N sessions keep rows; older entries are dropped
const QUEUE_MAX_BYTES = 400_000;    // well under the ~5 MB origin quota, with the other keys in mind

/*
 * The storage key state.queue currently mirrors — null means "these rows belong
 * to no session yet / a boundary just happened", and nothing is written. It is
 * nulled by resetTranscript (every session boundary passes through it) BEFORE
 * the rows are dropped, so a boundary can never write the outgoing session's
 * empty queue over the INCOMING session's stored rows, nor the reverse.
 */
let queueKey = null;

/*
 * BUG-217 round 2 — WHO SAYS A QUEUED ROW IS FINISHED: the tab that finished it,
 * in the shared store, and every other tab reads it there.
 *
 * The defect: the store above is shared by every tab of the origin, but each tab
 * copied the rows into its own heap (state.queue) at adoption and never read the
 * store again. So when two tabs had restored the same row and the driving tab
 * delivered it, the store said "gone" while the other tab's heap still said
 * "pending" — a second place holding a different answer (ARCH-010) — and once
 * the driving tab closed, the other tab sent the same message again. (Its next
 * paint could also write the stale row BACK over the store.)
 *
 * The fix is ownership, not a per-tab guard. Every row carries a stable `id`,
 * and the store entry carries `done` — the ids that have left the queue for
 * good (delivered, handed to a socket, discarded, moved to the composer). The
 * tab that removes a row writes its id there, in the same tick; a row a tab is
 * actively delivering is written with `by` (that tab) so no other tab sends it.
 * Every write is a MERGE (persistQueue below), and every tab re-reads the store
 * on the browser's `storage` event and immediately before it sends anything, so
 * a tab's heap is only a view of the store: a row another tab finished leaves
 * this tab's dock, and a row another tab is sending is never sent from here.
 *
 * Known limit (named, not hidden): localStorage is not a cross-process lock. Two
 * tabs that both decide to send the SAME unheld row within the few milliseconds
 * it takes a write to reach the other tab could still both send it. Every
 * trigger that makes a follower send is seconds after the driver's delivery (a
 * live poll noticing the driver let go), so that window is not reachable by the
 * flows this ticket covers; a server-side idempotency key would close it fully.
 */
/*
 * BUG-217 round 3 — WHO SAYS A QUEUED ROW WAS DELIVERED: the SERVER, by row id.
 *
 * Round 2's store (above) still left the delivery question to the tabs: a row
 * another tab marked `by` was never sent from here (and a killed tab never let
 * go — a follower stranded for minutes), and a row handed off before a reload
 * was judged by matching its TEXT against the transcript (an older message with
 * the same words made a new one vanish). Both were a tab reconstructing a fact
 * only the server has.
 *
 * Now every row gets a random `id` when it is created and keeps it for life.
 * Every automatic send of queued rows carries their ids; the server claims them
 * atomically and records them delivered at the handover (src/server/queue-
 * ledger.ts), so the same row can never reach the session twice, whichever tab
 * sends it, and a duplicate is answered `queue-duplicate` with each id's state.
 * A row stays in the queue — marked `sending` — until the server settles it, so
 * the store never declares a row finished before it is (no premature `done`).
 * A row whose fate this tab does not know (restored while `sending`, or another
 * tab marked it `sending`) is `remote: 'check'` and is asked of the server
 * (`reconcileQueue`); `in-flight` elsewhere is `remote: 'in-flight'` and asked
 * again until the server settles it. The store now carries only what the user
 * did to the dock (rows, edits, discards) — never who may send.
 */
const QUEUE_DONE_MAX = 200;       // tombstones kept per session — far more than any live queue
const QUEUE_DONE_TTL = 7 * 86_400_000; // an entry holding only tombstones is dropped after a week

/*
 * BUG-217 round 4: the id carries the row's birth time (`qt-<ms base36>-…`). The
 * server's ledger can forget an old row (it is capped per session), so it
 * answers `none` — never sent, go ahead — only for a row born after everything
 * it has forgotten; an older row comes back `uncertain` and asks the user.
 */
function newQueueId() {
  const born = Date.now().toString(36);
  try { return `qt-${born}-${crypto.randomUUID()}`; }
  catch { return `qt-${born}-${Math.random().toString(36).slice(2, 12)}${Math.random().toString(36).slice(2, 12)}`; }
}
/**
 * A row stored by a client that predates ids: deterministic, so two tabs
 * adopting the same legacy row name it alike (an id only — delivery is never
 * judged from it).
 */
function derivedQueueId(prefix, text, at) {
  let h = 5381;
  const s = `${at}\x00${text}`;
  for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
  return `${prefix}${Number(at || 0).toString(36)}-${h.toString(36)}`;
}

/** Per-key memory of what this tab last wrote/read — the base of the three-way merge. */
/*
 * `gone` is every id THIS tab has finished for this session. It is merged into
 * `done` on every write, so a tombstone lost to two tabs writing at the same
 * instant (localStorage has no compare-and-set) is written again by its owner
 * on its next write — and this tab never re-adopts a row it finished itself.
 */
let queueSync = { key: null, seen: new Map(), gone: new Set() };
function queueSyncFor(k) {
  if (queueSync.key !== k) queueSync = { key: k, seen: new Map(), gone: new Set() };
  return queueSync;
}
/** A row THIS tab is delivering right now or retrying — its own, whatever the store says. */
function queueRowMine(q) {
  return !!(q.sending || q.drainWait || q === state.drainWaitAttempt || q === state.forceSend);
}
/** A row this tab has handed to a `start`/`send` and is awaiting the answer for. */
function queueRowInFlight(q) {
  return !!(q.sending || q === state.drainWaitAttempt);
}

/*
 * BUG-217 round 3 — the rows a delivery may take right now: the LEADING run of
 * pending rows, in composed order. It stops at the first row that is already on
 * its way (this tab's `sending`, the drain retry's attempt) or whose fate the
 * server has not settled (`remote`): sending a later row alone would put it
 * ahead of an earlier one that may still go (plan review #7).
 */
function sendableRows() {
  const out = [];
  for (const q of state.queue) {
    if (q.dead) continue;
    if (q.sending || q.remote || q === state.drainWaitAttempt) break;
    if (typeof q.text !== 'string' || !q.text.trim()) continue;
    out.push(q);
  }
  return out;
}
/** The frame fields that name the queued rows a prompt carries (the server's claim key). */
function queueFrameFields(rows) {
  const ids = (rows ?? []).map((q) => q.id).filter(Boolean);
  if (!ids.length) return {};
  // `queueNow`: this tab's clock, so the server can read each id's birth time on its own (round 4).
  return { queueIds: ids, queueNow: Date.now(), ...(rows.some((q) => q.force) ? { queueForce: true } : {}) };
}
/** BUG-217 round 4: whose ledger a queue key's rows live in — the session's, or (no id yet) the project's. */
function queueLedgerScope(key) {
  const [kind, a, b] = String(key ?? '').split('\x00');
  if (kind === 's') return { session: b, dir: a || undefined, project: state.current?.projectId ?? undefined };
  if (kind === 'p') return { project: a };
  return {};
}
/** Mark rows as handed to a frame (persisted as `sending`, so a reload asks the server about them). */
function markRowsSending(rows) {
  const now = Date.now();
  for (const q of rows) { if (!q.id) q.id = newQueueId(); q.sending = true; q.sentAt = now; q.remote = null; }
}
function removeQueueRow(q) {
  const i = state.queue.indexOf(q);
  if (i !== -1) state.queue.splice(i, 1);
  if (state.drainWaitAttempt === q) state.drainWaitAttempt = null;
}

/**
 * Apply the server's answer about some rows. `delivered`/`discarded` → the row
 * leaves (for every tab, via the store's `done`); `in-flight` → another sender
 * holds it, ask again shortly; `uncertain` → kept, marked not confirmed, never
 * re-sent on its own; `none` → nobody has it — it is pending again, here.
 * Returns true when a row became sendable.
 */
function applyLedgerStates(rows, states) {
  let freed = false, again = false, changed = false, gone = 0;
  for (const q of rows) {
    if (!state.queue.includes(q)) continue;
    const s = states?.[q.id] ?? 'none';
    changed = true;
    if (s === 'delivered' || s === 'discarded') { removeQueueRow(q); if (s === 'delivered') gone++; continue; }
    q.sending = false;
    q.force = false;
    if (s === 'in-flight') { q.remote = 'in-flight'; again = true; continue; }
    q.remote = null;
    if (s === 'uncertain') { q.dead = UNCONFIRMED_NOTE; q.drainWait = null; continue; }
    freed = true;
  }
  if (!drainWaitItem()) disarmDrainWaitRetry();
  if (changed) paintQueue();
  if (gone) say(gone === 1 ? 'a queued message was already sent — it was not sent again' : `${gone} queued messages were already sent — not sent again`);
  if (again) scheduleReconcile(3000);
  return freed;
}

/*
 * Ask the server about every row whose fate this tab does not know: restored or
 * seen `sending` (`remote: 'check'`), held by another sender (`'in-flight'`), or
 * this tab's own `sending` row whose answer never came (its socket died). Never
 * a row this tab is still awaiting on an open socket — its own ack settles that.
 */
const QUEUE_STALE_SEND_MS = 15_000;
let reconcileTimer = null;
let reconcileBusy = false;
function scheduleReconcile(ms = 2500) {
  if (reconcileTimer) return;
  reconcileTimer = setTimeout(() => { reconcileTimer = null; void reconcileQueue(); }, ms);
}
async function reconcileQueue() {
  const key = queueKey;
  const now = Date.now();
  const rows = state.queue.filter((q) => q.id && !q.dead
    && (q.remote || (q.sending && now - (q.sentAt ?? 0) > QUEUE_STALE_SEND_MS)));
  if (!key || !rows.length) return;
  if (reconcileBusy) { scheduleReconcile(1000); return; }
  reconcileBusy = true;
  let states;
  try { states = (await api.queueLedger(queueLedgerScope(key), rows.map((q) => q.id)))?.states ?? null; }
  // 404: the server does not know this session, so it can confirm nothing — the user decides.
  catch (err) { states = err?.status === 404 ? Object.fromEntries(rows.map((q) => [q.id, 'uncertain'])) : null; }
  finally { reconcileBusy = false; }
  if (queueKey !== key) return;
  if (!states) { scheduleReconcile(5000); return; } // unreachable: ask again — never guess
  // A row this tab sent while the answer was in flight is its own attempt's to settle.
  const still = rows.filter((q) => !(q.sending && Date.now() - (q.sentAt ?? 0) <= QUEUE_STALE_SEND_MS));
  if (still.some((q) => q === state.drainWaitAttempt)) state.drainWaitAttempt = null;
  if (applyLedgerStates(still, states) && !state.busy) flushQueue();
}
/*
 * The backstop that makes "never stuck" unconditional: whatever event was
 * missed (a frozen tab, a lost storage event, a socket that died without a
 * close), any row whose fate this tab does not know is re-asked every few
 * seconds until the server settles it. Costs nothing while the dock is clear.
 */
setInterval(() => {
  const now = Date.now();
  if (state.queue.some((q) => !q.dead && q.id && (q.remote || (q.sending && now - (q.sentAt ?? 0) > QUEUE_STALE_SEND_MS)))) void reconcileQueue();
}, 5000);

function readQueueStore() {
  try {
    const o = JSON.parse(localStorage.getItem(QUEUE_KEY) ?? '{}');
    return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
  } catch { return {}; } // garbage / private mode — start fresh rather than throw in a paint
}

function writeQueueStore(store) {
  // Newest-first by `at`, capped by count and then by bytes. Age alone never
  // evicts: dropping a person's undelivered words because they are old is the
  // very failure this exists to stop.
  // BUG-217 r2: an entry holding only tombstones (no rows, no outbox) is kept so
  // a stale tab cannot resurrect a finished row — but it never costs a live row
  // its slot, and it lapses after a week.
  const now = Date.now();
  const onlyDone = (e) => !(e?.rows?.length) && !e?.outbox;
  for (const k of Object.keys(store)) {
    if (onlyDone(store[k]) && now - (store[k]?.at ?? 0) > QUEUE_DONE_TTL) delete store[k];
  }
  let keys = Object.keys(store).sort((a, b) => (onlyDone(store[a]) - onlyDone(store[b]))
    || (store[b]?.at ?? 0) - (store[a]?.at ?? 0));
  for (const k of keys.slice(QUEUE_MAX_SESSIONS)) delete store[k];
  keys = keys.slice(0, QUEUE_MAX_SESSIONS);
  let body = JSON.stringify(store);
  while (body.length > QUEUE_MAX_BYTES && keys.length > 1) {
    delete store[keys.pop()];
    body = JSON.stringify(store);
  }
  try { localStorage.setItem(QUEUE_KEY, body); return true; }
  catch {
    // Quota (or private mode): shed everything but this session and try once.
    try { localStorage.setItem(QUEUE_KEY, JSON.stringify(queueKey && store[queueKey] ? { [queueKey]: store[queueKey] } : {})); }
    catch { /* storage is unavailable — volatile, exactly as before this change */ }
    return false;
  }
}

/**
 * The key to write under, or null to write nothing. STRICT: only the key the
 * rows were adopted under, and only while state.current still agrees with it.
 *
 * It is deliberately not clever about mismatches. A mismatch means a boundary
 * this code has not been told about, and the tempting repair — "assume the key
 * moved, carry the entry over" — destroyed a session's stored rows in testing:
 * mid-`openSession` the key had already become the incoming session's while the
 * queue was momentarily empty, so the "migration" retargeted onto that
 * session's key and the empty-queue write then deleted its rows. Writing
 * NOTHING on a mismatch cannot lose anything; the one real retarget (a
 * pending-new session acquiring its id) is done explicitly by retargetQueue().
 */
function queueTargetKey() {
  const k = draftKey(state.current);
  return queueKey && k && k === queueKey ? k : null;
}

/**
 * The pending-new session just acquired a real id: its rows were stored under
 * `p\0<project>` and a reload now lands in `s\0<dir>\0<id>`, so carry them.
 * Called ONLY from the session-init frame — never inferred from a key mismatch,
 * for the reason above. Refuses to overwrite an existing destination entry:
 * those are another session's undelivered words.
 */
function retargetQueue() {
  const k = draftKey(state.current);
  if (!queueKey || !k || k === queueKey || !queueKey.startsWith('p\x00') || !k.startsWith('s\x00')) return;
  const store = readQueueStore();
  if (store[queueKey] && !store[k]) { store[k] = store[queueKey]; delete store[queueKey]; writeQueueStore(store); }
  queueKey = k;
}

/**
 * Merge state.queue with the shared store, both ways. Never throws. Returns
 * { changed, goneElsewhere } — `changed` when the merge altered THIS tab's rows
 * (another tab finished, edited or added one), so a caller that is not already
 * painting knows to repaint.
 *
 * BUG-217 r2: this used to OVERWRITE the entry with this tab's heap, which is
 * how a stale tab could write a delivered row back. Now:
 *   1. a row whose id is in the store's `done` leaves this tab (unless this tab
 *      is itself delivering it — its own answer settles it);
 *   2. a row another tab edited takes that text (three-way: only if this tab has
 *      not edited it since it last wrote);
 *   3. a row another tab added joins this tab's dock, in composed order;
 *   4. every row this tab last wrote and no longer holds is written to `done`.
 * BUG-217 round 3: a row leaves a tab only once it is really finished (the
 * server settled it, or the user discarded it) — a row being sent stays, marked
 * `sending` — so `done` never runs ahead of the truth. And the store no longer
 * says who may send: another tab's `sending` mark only makes this tab ASK the
 * server (`remote: 'check'`), which is what answers; it holds nothing.
 */
function persistQueue() {
  const k = queueTargetKey();
  if (!k) return { changed: false, goneElsewhere: 0 };
  const sync = queueSyncFor(k);
  const store = readQueueStore();
  const entry = store[k] && typeof store[k] === 'object' ? store[k] : null;
  const done = new Set(Array.isArray(entry?.done) ? entry.done.filter((x) => typeof x === 'string') : []);
  for (const id of sync.gone) done.add(id);
  const theirs = new Map();
  for (const r of (Array.isArray(entry?.rows) ? entry.rows : [])) {
    if (r && typeof r.id === 'string' && typeof r.text === 'string') theirs.set(r.id, r);
  }
  for (const q of state.queue) if (!q.id) q.id = newQueueId();
  if (state.forceSend && !state.forceSend.id) state.forceSend.id = newQueueId();

  let changed = false;
  let goneElsewhere = 0;
  // 1. finished by another tab
  const kept = [];
  for (const q of state.queue) {
    // A row this tab has in flight is settled by its own answer; anything else
    // (a pending row, a drain-wait row between retries) yields to the store.
    if (done.has(q.id) && !queueRowInFlight(q) && q !== state.forceSend) {
      changed = true;
      if (!q.dead) goneElsewhere++;
      continue;
    }
    kept.push(q);
  }
  if (kept.length !== state.queue.length) state.queue = kept;
  // 2. changed by another tab
  const inHeap = new Set(state.queue.map((q) => q.id));
  for (const q of state.queue) {
    const r = theirs.get(q.id);
    if (!r || queueRowMine(q)) continue;
    const base = sync.seen.get(q.id);
    if (r.text !== q.text && (!base || q.text === base.text) && !q.editing) { q.text = r.text; changed = true; }
    const rDead = typeof r.dead === 'string' ? r.dead : null;
    if (rDead !== (q.dead ?? null) && (!base || (q.dead ?? null) === base.dead)) { q.dead = rDead; changed = true; }
    // BUG-217 round 3: another tab has JUST marked this row as sending (the flag
    // is new since this tab last saw the row) — not a lock: this tab asks the
    // server what became of it (reconcileQueue). A flag this tab already asked
    // about is not asked about again; the server's answer stands.
    if (r.sending && !base?.sending && !q.remote && !q.dead) { q.remote = 'check'; changed = true; scheduleReconcile(); }
  }
  // 3. added by another tab (never one this tab already had and let go of)
  let added = false;
  for (const [id, r] of theirs) {
    if (inHeap.has(id) || done.has(id) || sync.seen.has(id)) continue;
    state.queue.push({
      id, text: r.text,
      composedAt: Number.isFinite(r.composedAt) ? r.composedAt : Date.now(),
      dead: typeof r.dead === 'string' ? r.dead : null,
      remote: r.sending ? 'check' : null,
    });
    if (r.sending) scheduleReconcile();
    added = true;
  }
  if (added) {
    changed = true;
    // Composed order is delivery order, whichever tab a row was typed in.
    state.queue = state.queue.map((q, i) => [q, i])
      .sort(([a, i], [b, j]) => ((a.composedAt ?? 0) - (b.composedAt ?? 0)) || (i - j)).map(([q]) => q);
  }

  // What this tab writes. A row whose fate this tab is still asking the server
  // about is written back exactly as the store had it.
  const rowOut = (q) => {
    if (q.remote && theirs.has(q.id)) return theirs.get(q.id);
    return {
      id: q.id, text: q.text, composedAt: q.composedAt ?? Date.now(), dead: q.dead ?? null,
      ...(q.sending && !q.dead ? { sending: true } : {}),
    };
  };
  // A row edited down to nothing is not written (BUG-150: nothing durable, and a
  // reload never restores a blank message) — but it is still this tab's row, so
  // it is not declared finished either (see `blank` below).
  const blank = state.queue.filter((q) => !q.remote && !(typeof q.text === 'string' && q.text.trim()));
  const rows = state.queue.filter((q) => !blank.includes(q)).map(rowOut);
  // A force-send waiting for its interrupt to land is out of state.queue and not
  // yet handed over (FEAT-031 Part A) — a third volatile spot, mirrored as a row
  // this tab holds. cancelForceSend puts the live copy back itself.
  if (state.forceSend?.text?.trim() && !inHeap.has(state.forceSend.id)) rows.push(rowOut(state.forceSend));
  // 4. finished here: every row this tab last wrote and no longer holds.
  const nowIds = new Set([...rows.map((r) => r.id), ...blank.map((q) => q.id)]);
  for (const id of sync.seen.keys()) if (!nowIds.has(id)) { done.add(id); sync.gone.add(id); }

  // BUG-217 round 3: nothing writes an outbox any more — a row being sent stays
  // a row, marked `sending`, and a reload asks the server about it by id. A
  // LEGACY entry's outbox (an older client's) is carried until its adoption
  // retires it (judgeAdoptedOutbox).
  const outbox = entry?.outbox ?? null;

  const doneOut = [...done].slice(-QUEUE_DONE_MAX);
  const body = { rows, outbox, done: doneOut };
  const prev = entry ? { rows: entry.rows ?? [], outbox: entry.outbox ?? null, done: entry.done ?? [] } : null;
  if (!rows.length && !outbox && !doneOut.length) {
    if (entry) { delete store[k]; writeQueueStore(store); }
  } else if (!prev || JSON.stringify(prev) !== JSON.stringify(body)) {
    // Written only when something differs — so answering another tab's write
    // (the `storage` event) cannot echo back and forth between tabs.
    store[k] = { at: Date.now(), ...body };
    writeQueueStore(store);
  }
  const seenBefore = sync.seen;
  sync.seen = new Map(rows.map((r) => [r.id, { text: r.text, dead: r.dead ?? null, sending: !!r.sending }]));
  // A blank row keeps the base it had, so another tab re-writing the old text
  // does not read as an edit and put the words back under the user's cursor.
  for (const q of blank) if (seenBefore.has(q.id)) sync.seen.set(q.id, seenBefore.get(q.id));
  return { changed, goneElsewhere };
}

/**
 * BUG-217 r2: read the store before acting on a row — the delivery paths call
 * this first, so a row another tab already finished or is sending is never
 * sent from here. Repaints only if the store changed this tab's rows.
 */
function syncQueue() {
  const r = persistQueue();
  if (r.changed) {
    paintQueue();
    if (r.goneElsewhere) say(r.goneElsewhere === 1 ? 'a queued message was sent from another tab' : `${r.goneElsewhere} queued messages were sent from another tab`);
  }
  return r;
}

// Another tab wrote the queue store: bring this tab's dock in line with it.
// (BUG-217 round 3: there is no `pagehide` release any more — no tab holds a
// row, so a tab that dies, cleanly or not, leaves nothing to let go of.)
window.addEventListener('storage', (e) => {
  if (e.key !== QUEUE_KEY || !queueTargetKey()) return;
  syncQueue();
  if (!isDriving() && state.queue.some((q) => !q.dead && !q.remote && !q.sending && q.text?.trim())) flushQueue();
});

/**
 * Take ownership of the current session's stored rows and put them back on
 * screen. Called for a pending-new session (startNew) and the re-take paths
 * (route restore, fresh-start) — i.e. wherever state.current settles and
 * resetTranscript has emptied the queue with NO await before this call.
 *
 * openSession has an await (the transcript fetch) between resetTranscript and
 * the point the transcript is on screen, so it does NOT call this: it takes
 * ownership synchronously via adoptQueueRows() BEFORE the fetch (closing the
 * BUG-150 window) and settles the outbox via judgeAdoptedOutbox() after.
 */
function adoptQueue() {
  judgeAdoptedOutbox(adoptQueueRows());
}

/**
 * The SYNCHRONOUS half of adoption, and the one that fixes BUG-150. It assigns
 * `queueKey` — the fact "which session state.queue currently belongs to"
 * (ARCH-010: declared here, its sole owner; read by queueTargetKey and never
 * re-derived) — and restores this session's stored rows onto the dock. Because
 * it is synchronous it can run BEFORE openSession's transcript fetch, with no
 * await between resetTranscript (which nulls queueKey) and here: so from the
 * first moment the session is on screen, persistQueue writes under the right
 * key and a message queued during the load window is durable, not stranded in
 * the tab's heap. Returns the handed-off outbox descriptor (for
 * judgeAdoptedOutbox) or null when there is nothing to judge.
 */
function adoptQueueRows() {
  queueKey = draftKey(state.current);
  if (!queueKey) return null;
  const entry = readQueueStore()[queueKey];
  const sync = queueSyncFor(queueKey);
  sync.seen = new Map();
  sync.gone = new Set();
  if (!entry) return null;
  let restored = 0;
  let unknown = 0;
  const done = new Set(Array.isArray(entry.done) ? entry.done : []);
  for (const r of (Array.isArray(entry.rows) ? entry.rows : [])) {
    if (typeof r?.text !== 'string') continue;
    const composedAt = Number.isFinite(r.composedAt) ? r.composedAt : Date.now();
    // A row stored before ids existed gets the id every tab derives alike.
    const id = typeof r.id === 'string' ? r.id : derivedQueueId('l', r.text, composedAt);
    if (done.has(id)) continue;
    if (!r.text.trim()) continue;
    const dead = typeof r.dead === 'string' ? r.dead : null;
    /*
     * BUG-217 round 3: a row stored as `sending` was handed to a frame — by this
     * tab's previous document or by another tab — and whether it arrived is the
     * SERVER's to say (reconcileQueue, just below), by id. Not the transcript's
     * text: an older message with the same words is not this row.
     */
    const check = !!r.sending && !dead;
    state.queue.push({ id, text: r.text, dead, composedAt, restored: true, remote: check ? 'check' : null });
    sync.seen.set(id, { text: r.text, dead, sending: !!r.sending });
    if (check) unknown++; else restored++;
  }
  const ob = entry.outbox;
  const obTexts = ob && Array.isArray(ob.texts) ? ob.texts.filter((t) => typeof t === 'string' && t.trim()) : [];
  state.outbox = null;
  if (state.queue.length) {
    paintQueue();
    if (restored) say(`${restored} undelivered message${restored === 1 ? '' : 's'} restored from before the reload — in the dock, still unsent`);
    if (unknown) void reconcileQueue();
  } else if (!obTexts.length) {
    persistQueue(); // an entry with nothing left in it — retire it
    return null;
  }
  if (!obTexts.length) return null;
  return { mine: queueKey, texts: obTexts, at: ob.at };
}

/** BUG-217 r2: the judged outbox is settled — clear it from the shared entry (only that one). */
function retireStoredOutbox(at) {
  if (!queueKey) return;
  const store = readQueueStore();
  const e = store[queueKey];
  if (!e?.outbox || e.outbox.at !== at) return;
  e.outbox = null;
  e.at = Date.now();
  writeQueueStore(store);
}

/**
 * A LEGACY outbox — written by a client older than BUG-217 round 3, with no row
 * ids. Nothing can ask the server about it, and its text is not evidence (the
 * same words may have been said before), so it comes back as "not confirmed":
 * readable, editable, never resent on its own. `pending.mine` pins the session
 * this belongs to (the BUG-079 class — never act on the wrong session).
 */
function judgeAdoptedOutbox(pending) {
  if (!pending) return;
  const { mine, texts, at } = pending;
  if (queueKey !== mine) return;
  retireStoredOutbox(at);
  texts.forEach((t, i) => {
    state.queue.push({
      id: derivedQueueId(`u${i}-`, t, at),
      text: t,
      dead: UNCONFIRMED_NOTE,
      composedAt: Number.isFinite(at) ? at : Date.now(),
      restored: true,
    });
  });
  paintQueue();
  say(`${texts.length} message${texts.length === 1 ? '' : 's'} sent before the reload cannot be confirmed as delivered — kept in the dock`, true);
}

function queueMessage(text) {
  // BUG-217 round 3: the id is minted HERE, when the row is created, and kept for life.
  state.queue.push({ id: newQueueId(), text, dead: null, composedAt: Date.now() });
  paintQueue();
  say(`message queued — ${state.queue.length} waiting; it sends at the next pause (Edit or Discard it in the dock)`);
}

/** "2m11s" / "43s" — coarse enough for a factual note, not a stopwatch. */
function fmtElapsed(ms) {
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}m${String(rem).padStart(2, '0')}s`;
}

/*
 * Every item that reaches this queue was queued because `state.busy` was true
 * (queueMessage is only ever called mid-turn — see submit() and the
 * re-attach path) and it only DELIVERS once `state.busy` flips back to false
 * (flushQueue runs off that transition). So anything in state.queue crossed
 * at least one turn boundary between compose and delivery, by construction —
 * unlike a normal submit(), which bubbles and sends in the same tick. That is
 * exactly the "meaningful" case FEAT-002 wants a note for; a directly-typed
 * message never goes through this function at all, so it never gets one.
 *
 * FEAT-031 Part B — PER-ITEM note, not one per batch: FEAT-002 originally
 * gave the whole delivered batch ONE note framed on the earliest item. Live
 * use (FEAT-031, user-confirmed) showed that flattens distinct messages —
 * three texts composed minutes apart at different points in the turn read
 * as ONE message with one timestamp, losing exactly the context the note
 * was meant to preserve. Each item now gets its OWN bracketed header
 * immediately above its OWN text (`[msg 2/3 · queued 1m10s ago]`) so the
 * model can still tell them apart even though they still arrive together
 * in a single combined turn (see flushQueue below — delivery is still one
 * turn, just no longer one undifferentiated blob).
 */
function queueItemNote(item, index, total) {
  const elapsed = fmtElapsed(Date.now() - item.composedAt);
  if (total === 1) {
    return `[Queued ${elapsed} ago, composed while the previous response was still being written — it predates that response.]`;
  }
  return `[msg ${index + 1}/${total} · queued ${elapsed} ago, composed while the previous response was still being written]`;
}

/**
 * The queue lives in the DOCK, not the transcript: a bubble at a transcript
 * position would claim the message was said there — it was not said at all
 * yet. Rows collapse to a preview and expand to an EDITABLE textarea; the
 * text sent is whatever the row holds at delivery time.
 */
function paintQueue() {
  const box = $('#queueBox');
  // BUG-129: storage mirrors the queue at EVERY mutation, and every mutation
  // repaints — so this one call is the whole write path. It runs before the
  // early return too: emptying the queue (discarding the last row) must clear
  // the stored copy, or a discarded message would come back from the dead.
  // BUG-217 r2: it is a merge, and it runs BEFORE anything below reads the
  // rows — so what is painted is what the shared store says, not a stale copy.
  persistQueue();
  const pending = state.queue.filter((q) => !q.dead);
  const undo = state.queueUndo && state.queueUndo.key === queueKey && state.queueUndo.until > Date.now() ? state.queueUndo : null;
  if (!state.queue.length && !undo) { box.hidden = true; clear(box); return; }
  clear(box);
  /*
   * BUG-217 r2 — Discard destroys the user's words, so it can be taken back:
   * for a few seconds the dock says what was discarded and offers Undo, which
   * puts the text back as a new row where it was.
   */
  if (undo) {
    const bar = el('div', { class: 'q-undo', role: 'status' });
    const gist = undo.text.replace(/\s+/g, ' ').trim();
    bar.append(el('span', { class: 'q-undo-t', text: `Discarded “${gist.length > 48 ? `${gist.slice(0, 47)}…` : gist}”` }));
    const b = el('button', { class: 'mini q-undo-b', text: 'Undo' });
    b.addEventListener('click', () => undoQueueDiscard());
    bar.append(b);
    box.append(bar);
    if (!state.queue.length) { box.hidden = false; return; }
  }
  /*
   * BUG-134 — this chip said three things, and all three were wrong.
   * (Filed as BUG-135 in commit e9efb92; renumbered when another lane minted the
   * same id minutes earlier.)
   *
   * FEAT-064 rendered the server's refusal payload verbatim: an elapsed, a
   * count of background agents and their ids. Read live, it said "held 45m59s
   * by 2 background agents (a3d3e1022ec985f4e, a3ba9374904af5e4d)". Against the
   * broker's own record at that moment:
   *
   *  - The 45m59s was `drainHeldSince` — the epoch of the FIRST decline this
   *    broker ever made, deliberately never reset (session-host.mjs: "an epoch,
   *    not a ticker"). The user's message had been queued for a fraction of it.
   *    Presenting a broker-lifetime statistic in a sentence about the user's
   *    message reads as "your message has been ignored for 46 minutes".
   *  - The ids were captured at ONE refusal and never refreshed; the broker's
   *    level frames reported 4, 5 and 6 lanes with different ids over two
   *    minutes of sampling. Opaque, and stale besides.
   *  - The attribution was false. Background agents do NOT hold delivery:
   *    FEAT-065 delivers into a drain-held survivor precisely while they run,
   *    and the journal shows it doing so 13 times in the hour this was
   *    displayed. What delays a message is the FOREGROUND turn (`midTurn`),
   *    which opens and closes continuously.
   *
   * So: report the user's OWN wait, from the row this tab has held all along,
   * and name the condition that actually resolves it. No ids — nothing the user
   * can act on was ever in them.
   */
  const heldRow = pending.find((q) => q.drainWait && q.drain);
  const heldWhy = (row) => {
    // A row restored from storage may predate composedAt — then say nothing
    // about elapsed rather than render a NaN.
    const waited = Number.isFinite(row.composedAt) ? ` · queued ${fmtElapsed(Date.now() - row.composedAt)} ago` : '';
    // BUG-191: a refusal from an adopt-gated session names the real reason.
    if (row.drain?.adoptState === 'pending') return `waiting for the session to finish re-attaching after a server restart — this retries every few seconds and goes in once it is ready${waited} — edit or discard below`;
    if (row.drain?.adoptState) return `waiting — the session is finishing an earlier server's work after a restart (${row.drain.why ?? 'not ready'}); this retries every few seconds${waited} — edit or discard below`;
    return `waiting on drain — the session is mid-reply; this retries every few seconds and goes in at its next pause${waited} — edit or discard below`;
  };
  /*
   * BUG-129: rows can now outlive the tab, so for the first time the dock can
   * hold pending text while this tab is NOT driving the session (a reload
   * mid-reply follows the live session but does not take it over until the user
   * sends). Nothing flushes in that state — so the ordinary "delivers at the
   * next pause" would be a promise the client cannot keep, which is the same
   * class of lie as the transcript claiming a refused message was delivered.
   * Say what is actually true and name the action that resolves it.
   */
  /*
   * BUG-149 widened this from `restored rows only` to the actual condition, and
   * moved it below the branches that are MORE specific about the same state.
   *
   * The test was `some(restored) && !live`, but nothing about a restored row is
   * what stops delivery — flushQueue's own first line is `!state.live ||
   * !state.ws`, so ANY pending row in a tab that holds no socket is going
   * nowhere. Observed in a screenshot of the two-tab refusal: a message queued
   * in a read-only tab sat under "1 queued message · delivering…" while nothing
   * was delivering or could. Same class of lie as the transcript claiming a
   * refused message was delivered, in the one place the user looks for the
   * truth about undelivered text.
   *
   * The drain-wait rows are the exception and are handled ABOVE: those DO have
   * a self-retry loop that reconnects, so "not driving" would understate them.
   */
  const notDriving = !isDriving(); // BUG-153: the same predicate the chip and the guards read
  // BUG-217: a row driveQueue has handed to a resume `start` right now.
  const sendingRow = pending.find((q) => q.sending) ?? null;
  const settling = state.queueSettling != null && state.queueSettling === state.txScope;
  /*
   * BUG-178: when a message is queued behind a genuinely-running main turn that
   * is held inside a long-lived FOREGROUND step (a subagent or a long tool
   * lane), the bare "delivers at the next pause" reads identically to a
   * two-second wait while the real wait can be tens of minutes. Detect that one
   * state — same guards as the busy/not-strand chip branch below — and render a
   * copy that names the step and shows its live elapsed. Null everywhere else,
   * so every other branch (including the ordinary tool chain, where the pause
   * really is seconds away) keeps its existing honest wording.
   */
  const fg = (pending.length && !heldRow && !pending.some((q) => q.drainWait)
    && !state.dropped && !notDriving && state.busy && !idleBehindBackground())
    ? foregroundWait() : null;
  const allUnconfirmed = state.queue.every((q) => q.dead === UNCONFIRMED_NOTE);
  /*
   * BUG-217 — the dock says, in plain words, what will happen to the message
   * next. It used to describe the machinery instead ("this tab is not driving
   * the session — send a message (or reconnect) and these go with the next
   * turn…"), which a user could not act on — and, in the state it described,
   * nothing was ever going to happen. Now that a not-driving tab resumes the
   * session itself (driveQueue), the only not-driving states left to explain
   * are the ones where it deliberately does not, and each names the one action.
   *
   * (BUG-130/BUG-159/BUG-191/BUG-045/BUG-149 wordings are kept where they are
   * still true: a batch delivers TOGETHER; a strand behind background work is
   * named as such; an unconfirmed send is never called undelivered.)
   */
  // BUG-217: rows another sender has in flight (the server says so), or whose
  // fate this tab is still asking about — "what happens next" is about the rest.
  const ownPending = pending.filter((q) => !q.remote);
  const why = !pending.length
    ? (allUnconfirmed
      ? 'check the transcript before sending it again'
      : 'press Send again, edit it, or discard it')
    : heldRow
      ? heldWhy(heldRow)
      : pending.some((q) => q.drainWait)
      // BUG-045: the visible "why is this waiting" chip for a retryable refusal.
      ? 'waiting for the previous turn to finish draining — this retries by itself'
      : state.dropped
        ? 'the connection dropped — reconnect, and it sends at the next pause'
        : !ownPending.length
          ? 'another tab is sending this — it leaves this dock once it is sent'
        : sendingRow
          ? 'sending now'
          : notDriving
            ? (settling
              ? 'getting ready to send…'
              : state.liveElsewhere
                ? 'another tab is driving this session — send it from there, or press Send now once that tab is closed'
                : state.followingExternal
                  ? 'another program is writing this session — press Send now when it has finished'
                  : 'press Send now to send it')
            : state.busy
              /*
               * BUG-130: a batch is delivered as ONE turn — say so, and in the
               * plural only when there IS a batch. BUG-159: idle behind a live
               * background lane is not "Claude is working"; say what is true.
               */
              ? (idleBehindBackground()
                  ? 'queued behind background work — the idle session delivers it at the next pause'
                  : fg
                    // BUG-178: rendered specially below (live elapsed span).
                    ? ''
                    : (pending.length > 1
                        ? 'Claude is working — these deliver together at the next pause, as one turn'
                        : 'Claude is working — delivers at the next pause'))
              : 'sending now';
  const n = pending.length || state.queue.length;
  const s = n === 1 ? '' : 's';
  // BUG-191: rows that were sent but never confirmed are "not confirmed", not "not sent".
  // BUG-217 r2 (UI review #3): "kept from before you reloaded" is said ONCE,
  // here, instead of as the same long sentence on every restored row.
  const keptNote = ownPending.some((q) => q.restored) ? ' (kept from before you reloaded or left this session)' : '';
  const prefix = pending.length ? `${n} queued message${s}${keptNote} · `
    : allUnconfirmed ? `${n} message${s} not confirmed as sent · ` : `${n} message${s} not sent · `;
  if (fg) {
    // BUG-178: build the line from nodes so the elapsed is a live `.q-el` span
    // (refreshed by the 1s strip ticker) instead of a value frozen at queue time.
    const ql = el('div', { class: 'q-l' });
    ql.append(document.createTextNode(`${prefix}Claude is working — “${fg.label}” `));
    if (fg.startedAt) {
      ql.append(document.createTextNode('has been running '));
      ql.append(el('span', { class: 'q-el', text: fmtElapsed(Date.now() - fg.startedAt) }));
      ql.append(document.createTextNode(', '));
    } else {
      ql.append(document.createTextNode('is still running, '));
    }
    ql.append(document.createTextNode(pending.length > 1
      ? 'so your messages go together when that step finishes — or use Interrupt & send (that step’s progress is lost).'
      : 'so your message goes when that step finishes — or use Interrupt & send (that step’s progress is lost).'));
    box.append(ql);
  } else {
    box.append(el('div', { class: 'q-l', text: `${prefix}${why}` }));
  }
  /*
   * BUG-217 — each row shows its words, a plain status, and its actions, all at
   * once. The row used to be a collapsed <details>: the status was a mono chip
   * ("unsent · restored · next") inside the clickable summary, so it read as a
   * set of buttons, while the real actions were hidden until the row was
   * expanded. Now the status is muted prose that nothing about looks pressable,
   * and Send now / Edit / Discard are always visible. The class names the
   * suites read (.qrow .qs .qedit .cacts .force-send) are kept.
   */
  const rowStatus = (item) => (
    // BUG-191: an unconfirmed send may have arrived — say "not confirmed", never "not sent".
    item.dead === UNCONFIRMED_NOTE ? `Not confirmed — ${item.dead}`
      : item.dead ? `Not sent — ${item.dead}`
        : item.sending ? 'Sending…'
          : item.drainWait ? 'Waiting — retries by itself'
            // BUG-217 round 3: the server says another sender has it in flight, or
            // this tab is asking the server what became of it — never sent from here meanwhile.
            : item.remote === 'in-flight' ? 'Being sent from another tab…'
            : item.remote ? 'Checking whether it was already sent…'
            // BUG-129: `restored` is its own state — text that outlived the tab, still
            // unsent. Short: the dock line above says once where it came from.
            : item.restored ? 'Not sent yet'
              : 'Waiting to send');
  state.queue.forEach((item) => {
    const row = el('div', {
      class: `qrow${item.dead ? ' dead' : ''}${!item.dead && item.drainWait ? ' drain-wait' : ''}${item.restored ? ' restored' : ''}${item.sending || item.remote ? ' sending' : ''}${item.remote ? ' held-elsewhere' : ''}`,
      role: 'group',
      'aria-label': 'Queued message',
    });
    const ta = el('textarea', { class: 'qedit', 'aria-label': 'Edit queued message' });
    ta.value = item.text;
    // BUG-129: an edit is a mutation of the only copy — mirror it as it is typed,
    // not at some later repaint that may never come.
    ta.addEventListener('input', () => {
      item.text = ta.value;
      preview.textContent = item.text.replace(/\s+/g, ' ').trim() || '(empty)';
      persistQueue();
    });
    const editBox = el('div', { class: 'qeditbox' });
    editBox.hidden = !item.editing;
    const preview = el('div', { class: 'qp', text: item.text.replace(/\s+/g, ' ').trim() });
    preview.title = item.text;
    const acts = el('div', { class: 'cacts qracts' });
    /*
     * The one primary action, where the user has one to take. BUG-153's rule
     * still holds: nothing is offered that could only answer "I cannot".
     *  - a row that failed → Send again (explicit: the app never resends on its own);
     *  - a row this tab is not sending because another tab / program owns the
     *    session → Send now (the user's say-so);
     *  - Claude mid-reply in THIS tab → Interrupt & send (FEAT-031's force-send,
     *    labelled with its cost; the row goes at the pause without it).
     */
    const primary = (label, title, onClick, extra = '') => {
      const b = el('button', { class: `mini qgo${extra}`, text: label });
      b.title = title;
      b.addEventListener('click', onClick);
      acts.append(b);
    };
    if (item.dead) {
      // BUG-217 round 4: an unconfirmed row may already have arrived — sending it is the user's call, named as such.
      primary(item.dead === UNCONFIRMED_NOTE ? 'Send anyway' : 'Send again', 'Send this message now', () => sendRowNow(item));
    } else if (item.remote) {
      // BUG-217 round 3: the server has not settled it — nothing here may send it yet.
    } else if (!item.sending && !item.drainWait && !state.dropped) {
      if (isDriving()) {
        if (state.busy) {
          const force = el('button', { class: 'mini force-send', text: 'Interrupt & send' });
          // BUG-178: state the cost at the point of action, and name the step that is lost.
          force.title = fg
            ? `Stop the current step (“${fg.label}”) and send this now — that step's progress is lost`
            : 'Stop what Claude is doing and send this now — the in-flight work is lost';
          force.addEventListener('click', () => forceSend(item));
          acts.append(force);
        }
      } else if (!settling && !sendingRow) {
        // Not driving and nothing is delivering it: the dock above says why
        // (another tab, another program, or the session could not be read).
        primary('Send now', 'Send this message to the session now', () => sendRowNow(item));
      }
    }
    const edit = el('button', { class: 'mini', text: item.editing ? 'Done' : 'Edit' });
    edit.setAttribute('aria-expanded', item.editing ? 'true' : 'false');
    edit.addEventListener('click', () => {
      item.editing = !item.editing;
      editBox.hidden = !item.editing;
      edit.textContent = item.editing ? 'Done' : 'Edit';
      edit.setAttribute('aria-expanded', item.editing ? 'true' : 'false');
      if (item.editing) ta.focus();
    });
    if (!item.remote) acts.append(edit);
    /*
     * BUG-217 r2 (UI review #1): Discard is the one action that destroys the
     * user's words, so it is set apart from Edit — its own destructive ink, a
     * gap before it — and it can be undone for a few seconds (paintQueue's
     * undo line).
     */
    const drop = el('button', { class: 'mini x qdrop', text: 'Discard' });
    drop.title = 'Delete this message without sending it (you can undo this for a few seconds)';
    drop.addEventListener('click', () => discardQueueRow(item));
    acts.append(drop);
    // BUG-217: a row already handed to a resume `start` is out of the user's
    // hands until the server answers (a second or so) — editing or discarding it
    // now would change nothing that was sent, so nothing is offered.
    if (item.sending || item.remote) { clear(acts); editBox.hidden = true; }
    /*
     * BUG-149/BUG-153 — "To composer" (now "Move to composer", inside Edit): one
     * click puts the text back where the next Enter sends it. Unconditional — a
     * row is the user's own words, and reclaiming them needs no precondition.
     */
    const back = el('button', { class: 'mini', text: 'Move to composer' });
    back.title = 'Take this text out of the queue and put it in the message box';
    back.addEventListener('click', () => {
      node.prompt.value = node.prompt.value ? `${node.prompt.value}\n\n${item.text}` : item.text;
      state.queue.splice(state.queue.indexOf(item), 1);
      withdrawAtServer(item); // BUG-217 round 3: no tab may send this row now
      // BUG-153: this row may be the drain-wait retry's in-flight attempt — the
      // text is leaving the queue, so the attempt must not keep pointing at it.
      if (state.drainWaitAttempt === item) state.drainWaitAttempt = null;
      if (!drainWaitItem()) disarmDrainWaitRetry();
      paintQueue();
      autosize();
      node.prompt.focus();
      say('moved to the message box — press Enter to send it');
    });
    editBox.append(ta, el('div', { class: 'cacts qedit-acts' }, back));
    row.append(
      el('div', { class: 'qhead' }, el('div', { class: 'qrtext' }, preview, el('div', { class: 'qs', text: rowStatus(item) })), acts),
      editBox,
    );
    box.append(row);
  });
  box.hidden = false;
}


/** Boundary: deliver the WHOLE pending batch as one turn — see the note below. */
let flushBackoff = false; // breaks the send-failed → setBusy(false) → flush loop
/*
 * Deliver ALL pending queued messages as ONE turn, not one-per-turn. Messages
 * queued during a single work period are a batch of context for the next
 * opportunity — fragmenting them into separate turns loses the connection
 * between them and burns turns. They join as blank-line-separated SEGMENTS,
 * each with its own `queueItemNote` header (FEAT-031 Part B — see that
 * comment for why per-item, not per-batch), in their real order — which is
 * also exactly how the transcript persists them, so a live render and a
 * reload agree.
 */
function flushQueue() {
  if (flushBackoff) return;
  // FEAT-065: a delivery-relay socket has no session behind it — flushing into
  // it would bounce every row. Queued rows wait for the drain-wait retry loop
  // (or a real bridge) instead.
  // BUG-153: one predicate — `isDriving()` already excludes the relay socket.
  // BUG-217: NOT driving is no longer a reason to stop here. It used to be the
  // line every stranded message died on: this tab had lost its socket (a reload,
  // a session switch, the bridge closing after the turn), and nothing would ever
  // hand it one back. Now the boundary asks driveQueue to acquire the drive —
  // it resumes the session carrying the next row, or says why it cannot.
  if (!isDriving()) { if (!driveQueue()) paintQueue(); return; }
  if (state.busy || state.dropped) { paintQueue(); return; }
  // BUG-217 r2: read the shared store first — a row another tab discarded or
  // finished leaves here before anything is chosen.
  syncQueue();
  /*
   * BUG-045: a drain-wait row whose self-retry is IN FLIGHT is that retry's to
   * deliver (or put back). BUG-217 round 3: the batch is the leading run of
   * pending rows (sendableRows), and it STAYS in state.queue, marked `sending`,
   * until the server answers — so it is never in no store at all (the BUG-129
   * window the outbox used to cover), and nothing declares it finished early.
   */
  const items = sendableRows();
  // Drop empties (edited to nothing); every other row stays.
  state.queue = state.queue.filter((q) => q.dead || q.sending || q.remote || q.drainWait || q === state.drainWaitAttempt
    || (typeof q.text === 'string' && q.text.trim()));
  if (!items.length) { paintQueue(); return; }
  markRowsSending(items);
  const text = items.map((q, i) => `${queueItemNote(q, i, items.length)}\n${q.text.trim()}`).join('\n\n');
  // One bubble for the combined turn — it IS one turn now, and this matches
  // what the store writes, so reopening the session shows the same thing.
  const flushEl = youBubble(mainThread(), text);
  if (state.viewing === 'main') scrollDown();
  state.turnStartedAt = Date.now();
  state.turnStartUnknown = false; // BUG-033: this tab started this turn — the clock is real
  setBusy(true);
  if (!sendTurn(text, { rows: items, el: flushEl })) {
    // The socket died between the boundary and this send — nothing was handed over.
    for (const q of items) q.sending = false;
    flushEl?.remove?.();
    flushBackoff = true;
    setTimeout(() => { flushBackoff = false; }, 1500);
    setBusy(false);
    paintQueue();
    return;
  }
  say(items.length === 1 ? 'delivered the queued message' : `delivered ${items.length} queued messages together`);
  paintQueue();
}

/*
 * BUG-217 — WHO DELIVERS A QUEUED MESSAGE WHEN THIS TAB IS NOT DRIVING.
 *
 * The invariant: a queued message that is not marked failed always has an owner
 * that will deliver it — this tab's driving socket at the next pause, or a
 * resume `start` in flight — or the dock says why not and offers "Send now".
 * It is never parked on a condition nothing will ever satisfy.
 *
 * What broke it: every delivery path (flushQueue at a busy→idle transition or a
 * turn-end, the BUG-160 reattach ack) needs a DRIVING socket, and a tab gets one
 * only when the user sends or when a still-alive bridge is reattached. So a row
 * that outlived its socket — the user queued a message mid-turn, then reloaded or
 * switched away and back — was restored into a tab that, once the turn had ended
 * and its bridge had closed, had no socket, no bridge to reattach to, and no
 * event that would ever come. It sat there ("not driving the session") until the
 * user worked out to send another message (live: 2026-09-30, about 11 minutes).
 *
 * The fix is ownership, not another trigger: flushQueue — which every boundary
 * already calls — hands a not-driving tab to this function, and this function
 * DOES what the user's own Enter would have done: resume the session with the
 * next row as its prompt, through the same exactly-once machinery the BUG-045
 * drain retry uses (`drainWaitAttempt`: the row leaves the queue only on the
 * server's ack; every refusal keeps it, visibly). A live-but-detached bridge is
 * reattached by that same `start` (busy: the row stays queued for the pause —
 * never injected into a running turn). The rest of the batch follows at that
 * turn's boundary, because by then this tab drives.
 *
 * It deliberately does NOT act where acting would be wrong, and each of those is
 * a state the dock names with a "Send now" the user can press:
 *  - another tab is driving (`liveElsewhere`) — the server refuses anyway;
 *  - another PROGRAM writes the session (`followingExternal`, a terminal) —
 *    resuming would put a second CLI on one transcript;
 *  - the connection dropped, the budget stopped it, or it needs a fork — those
 *    already have their own visible way out.
 * `force` is that button: the user's explicit say-so clears the first two.
 *
 * Returns true when it started (or is already running) a delivery, so the
 * caller does not repaint a stale "waiting" state over it.
 */
function driveQueue({ force = false } = {}) {
  if (isDriving()) return false; // a driving tab's boundary flush owns delivery
  const cur = state.current;
  if (!cur?.sessionId || cur.os === 'windows') return false;
  // openSession has not yet decided how this tab reaches the session (reattach
  // vs follow vs resume) — it calls flushQueue itself once it has.
  // Compared to the CURRENT scope, so an open that was superseded mid-flight
  // (a newer open or a new session bumped txScope) can never hold this shut.
  if (state.queueSettling != null && state.queueSettling === state.txScope) return false;
  if (state.dropped || state.budgetLocked || state.pendingFork || state.forkFrom) return false;
  // Something is already acquiring the drive — a start/resume, a reattach, or a
  // previous attempt awaiting its answer. Its ack/refusal settles the row.
  if (state.live || state.pendingStart != null || state.pendingStartResume != null
    || state.sessReconnecting || state.drainWaitAttempt) return !!state.drainWaitAttempt;
  if (!force && (state.liveElsewhere || state.followingExternal)) return false;
  // BUG-217 r2: the shared store first — a row another tab discarded is gone.
  syncQueue();
  // BUG-217 round 3: the oldest pending row, in order — and not past one the
  // server has not settled, nor a drain-wait row (its own retry loop owns it).
  const item = sendableRows()[0];
  if (!item || item.drainWait) return false;
  // Parked deep in history (a forward gap): a live turn cannot be spliced onto
  // that pane (the BUG-004 shape). Reopen at the real end — openSession then
  // lands back here with a contiguous pane.
  if (mainThread().gap) { reopenAtLatest(); return true; }
  state.liveElsewhere = '';
  state.drainWaitAttempt = item;
  state.drainWaitLastTry = Date.now();
  markRowsSending([item]); // stored as `sending`: a reload mid-attempt asks the server about it, by id
  paintQueue();
  const text = `${queueItemNote(item, 0, 1)}\n${item.text.trim()}`;
  Promise.resolve(startTurn(text, {
    resumeSessionId: cur.sessionId,
    resumeEncodedDir: cur.encodedDir ?? undefined,
    keepComposer: true, // BUG-132: the composer is not this delivery's channel
    queueRows: [item], // BUG-217 round 3: the server claims it by id — one delivery, whichever tab
  })).then(() => {
    // startTurn gave up before it could send (no project, or the socket would not
    // open): nothing was handed over, so nothing will ever answer this attempt.
    if (state.drainWaitAttempt === item && state.pendingStart == null && !state.live) {
      state.drainWaitAttempt = null;
      item.sending = false;
      item.dead = 'could not reach the server — press Send again to retry';
      paintQueue();
    }
  }, () => {
    if (state.drainWaitAttempt !== item) return;
    state.drainWaitAttempt = null;
    item.sending = false;
    item.dead = 'could not reach the server — press Send again to retry';
    paintQueue();
  });
  return true;
}

/** BUG-217 r2: Discard — remove the row (its id goes to `done` for every tab), undoable for a few seconds. */
const QUEUE_UNDO_MS = 8000;
/**
 * BUG-217 round 3: tell the server the user withdrew this row, so a tab that
 * has not heard yet cannot send it. If it had already gone, say so — the dock
 * only ever lost its copy.
 */
function withdrawAtServer(item) {
  if (!item?.id) return;
  void api.queueLedgerDiscard(queueLedgerScope(queueKey), [item.id]).then((r) => {
    const was = r?.states?.[item.id];
    if (was === 'delivered' || was === 'in-flight') say('that message had already been sent — removing it here did not unsend it', true);
  }, () => { /* unreachable: the store's `done` still withdraws it from every tab */ });
}
function discardQueueRow(item) {
  const idx = state.queue.indexOf(item);
  if (idx === -1) return;
  state.queue.splice(idx, 1);
  withdrawAtServer(item);
  if (state.drainWaitAttempt === item) state.drainWaitAttempt = null;
  if (!drainWaitItem()) disarmDrainWaitRetry();
  clearTimeout(state.queueUndo?.timer);
  state.queueUndo = {
    key: queueKey, text: item.text, composedAt: item.composedAt, index: idx,
    until: Date.now() + QUEUE_UNDO_MS,
    timer: setTimeout(() => { state.queueUndo = null; paintQueue(); }, QUEUE_UNDO_MS),
  };
  paintQueue();
}
function undoQueueDiscard() {
  const u = state.queueUndo;
  if (!u) return;
  clearTimeout(u.timer);
  state.queueUndo = null;
  if (u.key !== queueKey) { paintQueue(); return; }
  // A NEW row (new id): the discarded id is finished for every tab, and this is
  // the user putting the words back, not the old row coming back to life.
  state.queue.splice(Math.min(u.index, state.queue.length), 0, { id: newQueueId(), text: u.text, dead: null, composedAt: u.composedAt ?? Date.now() });
  paintQueue();
  say('message restored to the queue');
  // Put back into a tab that is idle: it goes like any other queued row.
  if (!state.busy) flushQueue();
}

/** BUG-217: the user's explicit "Send now" / "Send again" on a row this tab is not already delivering. */
function sendRowNow(item) {
  // BUG-217 round 3: the user's explicit say-so. The row keeps its id; `force`
  // lets the server re-claim it if it holds it as `uncertain` — never if it was
  // delivered (the server then answers so, and the row leaves).
  if (item.dead) { item.dead = null; item.restored = false; item.force = true; }
  if (isDriving()) {
    // Claude is mid-reply: it goes at the next pause like any queued message
    // (interrupting is its own, separately labelled button).
    if (state.busy) { paintQueue(); say('it will send at the next pause'); return; }
    flushQueue();
    return;
  }
  if (!driveQueue({ force: true })) {
    paintQueue();
    say('cannot send from this tab right now — see the note above the message', true);
  }
}

/*
 * FEAT-031 Part A — force-send: interrupt in-flight work and deliver a
 * queued message NOW instead of waiting for the natural turn boundary
 * flushQueue() waits for. Deliberately destructive — the user accepts
 * losing whatever the current turn was mid-producing — and unmistakably
 * distinct from the normal queue row, which only ever waits.
 *
 * Reuses the SAME interrupt path the composer's stop button already drives
 * (`send({ type: 'interrupt' })` -> `AgentSession.interrupt()` in
 * agent-bridge.ts, see the `#go` click handler) rather than inventing a
 * second abort channel. The item is pulled out of state.queue immediately
 * so the eventual flushQueue() for whatever else is still queued does not
 * also redeliver it, and stashed in state.forceSend so the turn-end handler
 * (which is the ONLY place that reliably knows the interrupted turn has
 * actually stopped) can deliver it the moment that happens.
 */
function forceSend(item) {
  const idx = state.queue.indexOf(item);
  if (idx !== -1) state.queue.splice(idx, 1);
  if (!isDriving() || state.dropped) {
    // No socket to interrupt over — same honesty rule as the detached-run
    // guard on the stop button, and BUG-153: the same predicate, so the chip
    // beside the composer cannot claim a turn this refusal denies exists.
    if (idx !== -1) state.queue.splice(idx, 0, item); else state.queue.push(item);
    paintQueue();
    return say('no live session to force-send over — reattach first, then force-send again', true);
  }
  if (!state.busy) {
    // Nothing running to interrupt — this degrades to an immediate send.
    paintQueue();
    return deliverForced(item);
  }
  state.forceSend = item;
  paintQueue();
  send({ type: 'interrupt' });
  say('force-sending — interrupting current work…');
}

/** Deliver one force-sent item as its own turn, right now (not batched). */
function deliverForced(item) {
  const elapsed = fmtElapsed(Date.now() - item.composedAt);
  const text = `[Force-sent ${elapsed} after being queued — in-flight work was interrupted to deliver this immediately.]\n${item.text.trim()}`;
  // BUG-217 round 3: back into the queue as a `sending` row until the server
  // answers (forceSend pulled it out; the row, not an outbox, is its record).
  if (!state.queue.includes(item)) state.queue.unshift(item);
  markRowsSending([item]);
  const forcedEl = youBubble(mainThread(), text);
  if (state.viewing === 'main') scrollDown();
  state.turnStartedAt = Date.now();
  state.turnStartUnknown = false; // BUG-033: this tab started this turn — the clock is real
  setBusy(true);
  if (!sendTurn(text, { rows: [item], el: forcedEl })) {
    // The socket died between the interrupt landing and this send — keep the
    // text recoverable rather than silently dropping it.
    item.sending = false;
    item.dead = 'the socket dropped before the force-send could go out';
    forcedEl?.remove?.();
    setBusy(false);
  } else {
    say('force-sent — delivered immediately');
  }
  paintQueue();
}

/** A pending force-send whose turn will never end cleanly — put it back, marked dead. */
function cancelForceSend(why) {
  const item = state.forceSend;
  if (!item) return;
  state.forceSend = null;
  item.dead = why;
  state.queue.unshift(item);
  paintQueue();
}

/*
 * BUG-079: a session-boundary transition (openSession / startNew / a route that
 * resolves to no session) abandons the OUTGOING session. resetTranscript zeroes
 * state.queue, but two pending-delivery pointers survive it and then act on the
 * WRONG session — this clears them (and their live timers) at every boundary:
 *
 *   - drainWaitAttempt + the drain-wait self-retry interval (Finding A / LOSS):
 *     a stale attempt makes queueRetryableRefusal read `retried` truthy and DROP
 *     the incoming session's next retryable refusal instead of queuing it.
 *   - forceSend + the force-send watchdog (Finding B / WRONG-TARGET): a stale
 *     stash makes the incoming session's next turn-end deliver the OUTGOING
 *     session's text into it.
 *   - pendingStart/pendingStartResume + pendingSend (audited siblings, same
 *     class): the outgoing session's in-flight `start` text / optimistic bubble.
 *     `resumeOnNextSend`, `deliveryRelay`, and `pendingAnswers` are the other
 *     members of this class and are ALREADY cleared by closeSocket().
 *
 * Deliberately NOT called from resetTranscript()/closeSocket(): both are
 * re-entered WITHIN a single session — the BUG-045 drain-retry runs
 * attemptDrainRetry -> startTurn -> resetTranscript with drainWaitAttempt
 * already set, and the FEAT-065 relay close runs closeSocket while the drain-
 * wait loop must keep running — so clearing there would break those same-
 * session behaviors. Only the true boundary entry points call this.
 */
function clearPendingDelivery() {
  state.drainWaitAttempt = null;
  state.drainWaitLastTry = 0;
  disarmDrainWaitRetry();           // the drain-wait ghost-release self-retry interval
  state.forceSend = null;
  clearTimeout(state.busyWatchdog); // the force-send watchdog (armBusyWatchdog -> cancelForceSend)
  state.busyWatchdog = null;
  state.pendingStart = null;
  state.pendingStartResume = null;
  state.pendingStartEl = null;
  state.pendingSend = null;
  state.liveElsewhere = ''; // BUG-149: a banner about the OUTGOING session must not follow the user
}

/** The session is gone — queued rows say so and keep the text recoverable. */
function failQueue(why) {
  let changed = false;
  for (const item of state.queue) if (!item.dead) { item.dead = why; item.sending = false; changed = true; }
  // BUG-217: an attempt pointer at a row that is now failed would read as "a
  // delivery is in flight" forever and swallow the user's Send again.
  if (state.drainWaitAttempt?.dead) state.drainWaitAttempt = null;
  if (changed) paintQueue();
}

async function submit() {
  const p = currentProject();
  if (!p) return say('pick a project first — or add one from the sidebar foot', true);
  const text = node.prompt.value.trim();
  if (!text) return;

  // Bare /model: the CLI's interactive picker is terminal chrome the SDK
  // cannot ship, and burning a turn to print usage text helps no one — the
  // app's own model popover IS that selection UI. With an argument
  // ("/model haiku") it still travels to the CLI, which applies it.
  if (text === '/model') {
    node.prompt.value = '';
    autosize();
    node.modelBtn.click();
    return say('the model picker is this session’s /model — "/model <name>" sends straight to the CLI');
  }

  if (state.dropped) return say('the connection dropped — reconnect and resume before sending', true);
  // BUG-013: refuse at the source, before anything is painted. The composer
  // is already visually locked by paintComposerFor when this is true, so
  // reaching submit() here would only happen via a stale keyboard shortcut —
  // still worth a hard stop rather than an optimistic bubble the server will
  // reject.
  if (state.budgetLocked) return say(state.budgetLockReason || 'this session hit its budget limit and will not send further turns', true);
  const th = viewedThread();
  if (th.kind !== 'main') {
    // Structurally impossible — see paintComposerFor. Never even attempt it.
    // BUG-171: a tool lane is read-only too, so anything but main is blocked.
    return say('a subagent takes no messages — return to main to steer the run', true);
  }

  // A human submit is THE reorder trigger: stamp the target session's
  // user-submit recency now so it climbs to the top immediately (the server's
  // transcript-derived value confirms it on the next list fetch). This is the
  // one path agent frames / drain-wait auto-retries never reach — only a real
  // composer send lands here. No-op for a not-yet-real session.
  stampUserSubmit(state.current.sessionId, state.current.encodedDir);

  /*
   * FEAT-065: the open socket is only the delivered turn's approval relay —
   * it has no session, so a raw 'send' would be refused. Close it (routine,
   * on purpose) and let this message go through the ordinary start gate,
   * which re-judges the survivor (deliver again, or queue-and-wait).
   */
  if (state.deliveryRelay) closeSocket();

  /*
   * BUG-217: the dock is already resuming this session with a queued message
   * (driveQueue) and its socket is not open yet. A second `start` now would race
   * it for the same session; queue this behind it instead — the tab drives once
   * that start is answered, and this goes at that turn's boundary.
   */
  if (!state.live && state.drainWaitAttempt && state.drainWaitAttempt.sending) {
    queueMessage(text);
    node.prompt.value = '';
    autosize();
    return;
  }

  if (state.live && state.ws) {
    /*
     * MID-TURN SENDS QUEUE — they do not pretend. The server refuses a send
     * while a turn runs, and the old code painted the bubble anyway: the
     * message sat in the transcript looking delivered while Claude never saw
     * it (observed in production — the user had to re-paste a lost message).
     * Now it queues like the CLI queues: visibly marked, delivered one per
     * turn boundary, and marked NOT delivered if the session dies first.
     */
    // BUG-159 — while a MAIN turn is genuinely running, hold typed text in the
    // queue (batched, editable, delivered together at the next pause). But when
    // the server is idle behind a live background lane (the strand), holding it
    // waits for a `turn-end` that may be hours away — route it straight to the
    // server, which holds+pushes it into the runtime queue and the idle CLI runs
    // it at the next boundary (Part A). The fall-through send path does exactly
    // that; only the caption below marks it as behind-background.
    const behindBackground = state.busy && idleBehindBackground();
    // BUG-166 — a pending decision means the model is STOPPED, waiting on the
    // user (owned by awaitingUserDecision()). Holding the message in the CLIENT
    // queue waits for a `turn-end` that only the user's OWN answer can produce —
    // which reads as a lockout: the composer will not "let it through". Route it
    // to the server instead, exactly as an idle-behind-background send does: the
    // BUG-159 server path HOLDS it in the runtime InputQueue and marks the turn
    // user-initiated, so it lands as the user's next turn rather than being held
    // as if Claude were working. Same principle BUG-159 set: HELD, never refused.
    const awaitingDecision = state.busy && awaitingUserDecision();
    if (state.busy && !behindBackground && !awaitingDecision) {
      queueMessage(text);
      node.prompt.value = '';
      autosize();
      return;
    }
    const bubbleEl = youBubble(mainThread(), text);
    // Tracked so a rejection (budget stop raced the click — see isBudgetStop
    // in onEvent) can roll this exact bubble back instead of leaving it
    // looking delivered for a turn Claude never received.
    state.pendingSend = { el: bubbleEl, text };
    state.lastTurnPrompt = text; // BUG-031: what the provider-error Retry re-sends
    node.prompt.value = '';
    autosize();
    state.turnStartedAt = Date.now();
    state.turnStartUnknown = false; // BUG-033: this tab started this turn — the clock is real
    setBusy(true);
    sendTurn(text, { texts: [text.trim()], el: bubbleEl });
    if (behindBackground) say('queued behind background work — the idle session delivers it at the next pause');
    else if (awaitingDecision) say('sent — it runs as your next turn once the question above is settled');
    return;
  }

  // A pending fork wins: branch from the Windows-origin history instead of
  // resuming it (which this machine cannot do).
  if (state.forkFrom) {
    const from = state.forkFrom;
    const dir = state.forkEncodedDir; // BUG-090: server-supplied SOURCE dir for a needs-fork branch
    state.forkFrom = null;
    state.forkEncodedDir = null;
    return startTurn(text, { resumeSessionId: from, fork: true, resumeEncodedDir: dir ?? undefined });
  }

  // A re-armed session wins: resume the exact SDK session that dropped.
  if (state.resumeOnNextSend) {
    const resume = state.resumeOnNextSend;
    state.resumeOnNextSend = null;
    return startTurn(text, { resumeSessionId: resume });
  }
  const resume = state.current.sessionId && state.current.os !== 'windows' && !state.sdkSessionId
    ? state.current.sessionId
    : undefined;
  await startTurn(text, { resumeSessionId: resume });
}

/*
 * BUG-160 — re-take the driving socket of a still-running session WITHOUT
 * sending a turn. A sole tab that reloaded (or reopened) a dashboard-driven,
 * detached bridge follows it read-only until the user sends; that leaves
 * `isDriving()` false — the tab claims "not driving the session" though it is
 * the only client, and a queued message restored from before the reload has no
 * path to delivery (flushQueue needs a driving socket). This opens the socket
 * and reattaches with a PROMPTLESS `start`: the server turns a promptless
 * resume into a pure attach (it only delivers a turn `if (cmd.prompt)`, and
 * answers `nothing-to-reattach` when no bridge survives). On the `reattached`
 * ack `followingLive` clears, `isDriving()` becomes true, and the boundary
 * flush finally delivers the restored message (into an idle session at once, a
 * busy one at its next pause — never into a running turn). A bridge driven in
 * ANOTHER tab is not detached and comes back `live-elsewhere`, so a genuine
 * second tab keeps following read-only.
 */
async function reattachDriving(sess) {
  const p = currentProject();
  if (!p || !sess?.sessionId) return;
  // Already driving, a socket is up, or a start is in flight — nothing to do.
  if (isDriving() || state.live || state.pendingStart != null || state.pendingStartResume != null) return;
  const scope = state.txScope; // bail if the user switches sessions mid-connect
  state.sessReconnecting = true;
  paintSessStatus();
  let ws;
  try { ws = await connect(); }
  catch { state.sessReconnecting = false; paintSessStatus(); return; }
  // Switched away (or a real send opened its own socket) while connecting — this
  // one is not ours to keep; close it rather than drive a session off-screen.
  if (scope !== state.txScope || state.ws !== ws) {
    state.closingOnPurpose = true;
    try { ws.close(); } catch { /* already gone */ }
    return;
  }
  state.sessReconnecting = false;
  state.pendingStartResume = sess.sessionId; // a live-elsewhere refusal re-arms the next Enter
  send({
    type: 'start',
    projectId: p.id,
    resumeSessionId: sess.sessionId,
    resumeEncodedDir: sess.encodedDir ?? state.current.encodedDir ?? undefined,
    // No prompt: this is a pure reattach — the server attaches the detached
    // bridge and starts no turn (index.ts: it delivers a turn only `if (cmd.prompt)`).
  });
}

/*
 * BUG-132: `keepComposer` — this start's text did NOT come from the composer, so
 * the composer must not be touched by it. The self-retry of a drain-wait row
 * (attemptDrainRetry, every 7s for as long as the drain is held) re-sends text
 * that lives in the QUEUE; clearing the box here — and, on the refusal that
 * follows, writing the queued row's text back INTO it — destroyed whatever the
 * user was typing, on a 7s cadence, for the whole life of the hold. Observed
 * live: a 46-minute hold made the composer unusable ("it reloads deleting my
 * entered message"). The flag rides on state so the refusal path (which runs
 * later, from the socket) can honour it without re-deriving who started the turn.
 */
async function startTurn(text, { resumeSessionId, fork, resumeEncodedDir, keepComposer, queueRows } = {}) {
  const p = currentProject();
  if (!p) return;
  // BUG-149: a fresh attempt is under way — the previous "another tab has it"
  // banner is about to be re-answered by the server either way, so it must not
  // linger and describe a refusal that may no longer be true.
  state.liveElsewhere = '';
  if (!resumeSessionId) {
    // Guard the one path that can destroy visible history: starting fresh
    // while an SDK session is already represented on screen. That has to be
    // an explicit act (the pencil / + button), never a side effect of Enter.
    if (state.sdkSessionId && mainThread().paneEl.childElementCount > 0) {
      return say('this session is no longer attached — use Reconnect, or start a new session with + in the sidebar', true);
    }
    // BUG-129/BUG-150: this IS the session those rows were typed under, and
    // resetTranscript re-binds ownership + restores them by construction, so
    // nothing queued in this fresh start is left un-persisted. Judge the
    // handed-off outbox it returns.
    judgeAdoptedOutbox(resetTranscript());
    state.current.title = titleFrom(text);
  }
  /*
   * BUG-149: keep the ELEMENT, not just the intention to find it again. The
   * rollback paths locate this bubble as "the last top-level `.you` in main",
   * which is only true while nothing else appends — and the transcript follower
   * does append, asynchronously, whatever the session's real driver writes. In
   * a two-tab run that race showed up twice over: the refused bubble survived
   * (still claiming a delivery that never happened) and the OTHER tab's real,
   * delivered message was the one removed. Both are the transcript lying, which
   * is the failure this whole area exists to prevent.
   */
  const startedBubble = youBubble(mainThread(), text);
  if (!keepComposer) { node.prompt.value = ''; autosize(); }
  node.box.hidden = false;
  node.frozen.hidden = true;
  node.agentDone.hidden = true;
  paintCrown();
  // A resume's connect() is exactly the "reconnecting / reattaching" window
  // FEAT-040 names — transport down, before the live stream resumes. A brand
  // new session's connect() is near-instant and never a resume, so it is not
  // labelled reconnecting (nothing to reattach to).
  if (resumeSessionId) { state.sessReconnecting = true; paintSessStatus(); }
  try {
    await connect();
  } catch (err) {
    state.sessReconnecting = false;
    paintSessStatus();
    return say(err.message, true);
  }
  state.sessReconnecting = false;
  state.turnStartedAt = Date.now();
  state.turnStartUnknown = false; // BUG-033: this tab started this turn — the clock is real
  setBusy(true);
  state.lastTurnPrompt = text; // BUG-031: what the provider-error Retry re-sends
  state.pendingStart = text; // reclaimed into the queue if this re-attaches mid-turn
  // Set in the SAME tick as pendingStart, so a non-null pendingStart always
  // means this element belongs to THAT start (see handleLiveElsewhere).
  state.pendingStartEl = startedBubble ?? null;
  state.pendingStartResume = resumeSessionId ?? null; // so a pre-turn refusal (BUG-029) can re-arm the SAME resume
  state.pendingStartKeepComposer = !!keepComposer; // BUG-132: this text is not the composer's — the rollback must not put it there
  const templateIds = drawer.startTemplateIds();
  // BUG-198 round 2 — a start that BIRTHS a session (new, or a fork) carries this
  // bag: bind it to a pending token + this socket so only ITS session-init adopts it.
  stampPendingStart(state.ws, !resumeSessionId || !!fork);
  send({
    type: 'start',
    projectId: p.id,
    prompt: text,
    resumeSessionId,
    // Without this the server falls back to a scan that refuses to guess
    // between diverged copies of the same session id — which is exactly the
    // case for a Windows-origin session on this dual-boot machine. BUG-090: a
    // needs-fork branch passes the SOURCE dir the server named explicitly (the
    // project's own encodedDir is where the id is missing).
    resumeEncodedDir: resumeSessionId ? (resumeEncodedDir ?? state.current.encodedDir ?? undefined) : undefined,
    fork,
    templateIds,
    overrides: sessionOverrides({ resuming: !!resumeSessionId }), // BUG-196 round 4 — a resume never carries a provider
    ...queueFrameFields(queueRows), // BUG-217 round 3: the queued row this start delivers, claimed by id
  });
  renderTree();
}

/** The session-scope overrides that are legal to send with `start`. */
/*
 * BUG-196 round 6 — the client's copy of the model→engine classifier
 * (modelProviderOfClient, BUG-188 round 2) is DELETED. It was a second judge of a
 * fact the server owns (global-settings.modelProviderOf), and it had already
 * drifted: it did not know the Claude aliases. The server judges every pick against
 * the engine the session really runs on and DECLARES the verdict back
 * (effective-config.ignoredOverrides); the client forgets a pick only on that
 * declaration (see the effective-config handler).
 */
function sessionOverrides({ resuming = false } = {}) {
  const out = {};
  // The provider this start will run under (a session provider override wins,
  // then the project's own setting) — the engine a model override must match.
  // BUG-196 round 3 — a session pinned by its transcript runs on that engine; its
  // start never carries a provider override (the server ignores one — round 4).
  const locked = lockedSessionProvider();
  // BUG-196 round 4 — a start for an EXISTING session id is a resume, whose engine
  // the server alone decides (from the stores the resume reads). It never carries a
  // provider, and until the server has declared the pin the client does not know
  // the engine — so it must not judge (and destroy) a model pick against a guess.
  // BUG-196 round 5 — on a RESUME the client does not judge the model at all, pin
  // landed or not: the server resolves it against the engine the transcript pins
  // (agent-bridge, after P2b) and ANNOUNCES a pick that engine cannot run (status +
  // ignoredOverrides). Dropping it here was a silent second judge of the same fact.
  // BUG-196 round 6 — no model judging here at all, fresh start or resume: the
  // server announces a pick the engine cannot run and the client heals on that.
  for (const field of SESSION_OVERRIDABLE) {
    if (!(field in state.overrides)) continue;
    if (field === 'provider' && (locked || resuming)) continue;
    out[field] = state.overrides[field];
  }
  return Object.keys(out).length ? out : undefined;
}

/** Provisional session title until the store writes a real ai-title. */
function titleFrom(text) {
  const one = text.replace(/\s+/g, ' ').trim();
  if (one.length <= 64) return one;
  const cut = one.slice(0, 64);
  const sp = cut.lastIndexOf(' ');
  return `${(sp > 32 ? cut.slice(0, sp) : cut).replace(/[,.;:—-]$/, '')}…`;
}

function autosize() {
  node.prompt.style.height = 'auto';
  node.prompt.style.height = `${Math.min(node.prompt.scrollHeight, 170)}px`;
}

node.prompt.addEventListener('input', autosize);

/* -------------------------------------------------- "/" command palette */
/*
 * Typing "/" offers the commands the session's CLI listed in its init
 * message (session-init.slashCommands). Between sessions the last-seen list
 * serves as the hint — commands are near-global, and a hint beats nothing.
 * Picking only fills the composer; the command still travels as an ordinary
 * prompt, which the CLI executes itself (verified: "/model" answers with
 * its usage text).
 */

const SLASH_KEY = 'cs-slash';
const slash = { open: false, items: [], sel: 0 };
try { state.slashCommands = JSON.parse(localStorage.getItem(SLASH_KEY) ?? '[]'); } catch { state.slashCommands = []; }

function slashPopEl() { return $('#slashPop'); }

function updateSlashPop() {
  const v = node.prompt.value;
  const m = /^\/([A-Za-z0-9:_-]*)$/.exec(v); // only while typing the command word
  const cmds = state.slashCommands ?? [];
  if (!m || !cmds.length) return hideSlashPop();
  const q = m[1].toLowerCase();
  const items = cmds.filter((c) => c.toLowerCase().startsWith(q)).slice(0, 12);
  if (!items.length) return hideSlashPop();
  slash.open = true;
  slash.items = items;
  slash.sel = Math.min(slash.sel, items.length - 1);
  const pop = slashPopEl();
  clear(pop);
  items.forEach((c, i) => {
    const b = el('button', { class: `sl${i === slash.sel ? ' on' : ''}`, text: `/${c}` });
    b.addEventListener('mousedown', (e) => { e.preventDefault(); pickSlash(c); });
    pop.append(b);
  });
  pop.hidden = false;
}

function hideSlashPop() {
  slash.open = false;
  slashPopEl().hidden = true;
}

function pickSlash(c) {
  node.prompt.value = `/${c} `;
  hideSlashPop();
  node.prompt.focus();
  autosize();
}

node.prompt.addEventListener('input', updateSlashPop);
node.prompt.addEventListener('blur', () => setTimeout(hideSlashPop, 120));

node.prompt.addEventListener('keydown', (e) => {
  if (slash.open) {
    if (e.key === 'ArrowDown') { e.preventDefault(); slash.sel = (slash.sel + 1) % slash.items.length; return updateSlashPop(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); slash.sel = (slash.sel - 1 + slash.items.length) % slash.items.length; return updateSlashPop(); }
    if (e.key === 'Tab' || e.key === 'Enter') { e.preventDefault(); return pickSlash(slash.items[slash.sel]); }
    if (e.key === 'Escape') { e.preventDefault(); return hideSlashPop(); }
  }
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void submit(); }
});
node.go.addEventListener('click', () => {
  /*
   * BUG-153: the refusal belongs to the STOP half of this button only. It used
   * to be the first line, tested on `followingLive && !state.live`, so a
   * detached run that was NOT busy refused to send the message it was in the
   * same breath asking for — the button read "Send", the click answered "send
   * a message to reattach". Now: interrupting needs a socket to interrupt
   * over (the same predicate the chip and force-send read); sending never did,
   * because sending is what creates one.
   */
  if (state.busy) {
    if (!isDriving()) {
      return say('this run is detached — send a message to reattach, then you can steer or interrupt it', true);
    }
    send({ type: 'interrupt' });
    say('interrupting…');
    return;
  }
  void submit();
});
$('#forkBtn').addEventListener('click', () => {
  // BUG-090: a needs-fork signal wins — fork from the SOURCE store dir the
  // server named (the target dir this project resolves to is exactly where the
  // id is missing), not the client-detected Windows path.
  const pf = state.pendingFork;
  const sid = pf ? pf.resumeSessionId : state.current.sessionId;
  if (!sid) return;
  // BUG-198 round 2 — the frozen-bar fork stages a NOT-YET-BORN session, like
  // armFork: its bag must stop being the source's (edits while staged, and every
  // edit after the fork's session-init, wrote under the SOURCE's key). Same
  // project, so the armed values carry over, as armFork's same-project case does.
  const keepArmed = { ...state.overrides };
  resetOverrides(ovrPending());
  Object.assign(state.overrides, keepArmed);
  state.forkFrom = sid;
  if (pf) {
    state.forkEncodedDir = pf.resumeEncodedDir;
    state.pendingFork = null;
  } else {
    state.current.os = 'linux';
  }
  node.box.hidden = false;
  node.frozen.hidden = true;
  node.prompt.focus();
  say(pf && pf.cause === 'isolation-changed'
    ? (pf.toContainer === false
      ? 'Forking to continue here — type the first message and send; it branches this history into a new session running direct on the host. The original stays untouched.'
      : 'Forking into the container — type the first message and send; it branches this history into a new session in the container. The original stays on the host.')
    : pf && pf.cause === 'path-changed'
      ? 'Forking — type the first message and send; it branches this history into a new session under the project’s current directory. The original stays untouched.'
      : 'Forking — type the first message and send; it branches from this history into a new session on this machine. The original stays untouched.');
});

node.planBtn.addEventListener('click', togglePlan);
node.skipBtn.addEventListener('click', toggleSkip);
$('#cogBtn').addEventListener('click', () => void drawer.open('settings'));
// BUG-158 — the seal-strip Settings pill: the deliberate, labelled opener that
// makes the drawer reachable without knowing which status chip is clickable.
node.settingsBtn.addEventListener('click', () => void drawer.open('settings'));

/* ------------------------------------------------------- model picker */
/*
 * `#modelBtn` used to be wired to `drawer.open('settings')` — byte-identical to
 * `#cogBtn` beside it — while its tooltip promised "Choose a model". It now
 * actually chooses one.
 *
 * Everything here is a SESSION override, like the skip/plan toggles: the common
 * case is "just this once, use a bigger model", and that must not rewrite the
 * project default. The project default is one click away in the drawer.
 */
/*
 * The fallback list exists only for a server that has never seen a session:
 * it cannot name VERSIONS truthfully, so it does not try. The real list —
 * the CLI's own display names and descriptions, versions included — replaces
 * it via /api/models (see boot), exactly like the slash-command list.
 */
/*
 * The null row's `d` here is a LAST-RESORT fallback only: paintModelPop
 * overwrites it at render time with the concrete model inheriting actually
 * resolves to (BUG-021 — see resolveInheritedModelLabel). It only ever
 * surfaces when that resolution comes up empty: no project default set AND no
 * session has run yet to report what the CLI picked.
 */
let MODEL_OPTS = [
  { v: null, n: 'Project default', d: 'Not decided yet — resolves once a session runs' },
  { v: 'opus', n: 'Opus', d: 'Deepest reasoning, slowest, priciest' },
  { v: 'sonnet', n: 'Sonnet', d: 'The balanced default for most work' },
  { v: 'haiku', n: 'Haiku', d: 'Fastest and cheapest; fine for small edits' },
];

function adoptModelList(models) {
  if (!Array.isArray(models) || !models.length) return;
  MODEL_OPTS = [
    { v: null, n: 'Project default', d: 'Not decided yet — resolves once a session runs' },
    ...models.map((m) => ({ v: m.value, n: m.displayName || m.value, d: m.description || '', r: m.resolvedModel || null })),
  ];
}

/* ------------------------------------- provider at launch (FEAT-045) */
/*
 * Which ENGINE the picker (and the crown chip) should speak for: the live
 * session's resolved provider wins, then an armed per-launch override, then
 * the project setting. Same resolution paintModelChip used inline pre-045.
 */
/**
 * BUG-196 — the engine an EXISTING session's next turn will resume on, which its
 * transcript PINS (a Codex thread id continues only on Codex, a Claude file only
 * on Claude). The server owns this fact and declares it per SESSION ID
 * (declareLockedProvider ← transcript route / session-init — resumeProviderOf, the
 * SAME resolver agent-bridge P2b applies on resume). Read it here so no UI surface
 * re-derives the engine from the project setting or a per-session override the
 * resume silently ignores (ARCH-010). Null only when the subject session has no
 * declared pin (a pending-new view, or before the server has answered) — never
 * because of what the sidebar happens to show (round 3).
 * A LIVE session is already fixed via dockLive(); dockEffective().provider (the
 * running engine) agrees with this value, so providerView prefers it and this is
 * the non-live-but-resumable case the bug was about.
 */
function lockedSessionProvider() {
  // BUG-196 round 3 — looked up by the id of the session every provider surface
  // ACTS ON: state.current.sessionId is what a send resumes (submit → startTurn),
  // what persistOverrides writes under and what the drawer's session scope edits
  // — foreign dock or not. A pending-new view has no id yet, so it is unlocked by
  // construction (no view predicate needed); session-init names the id and the
  // server declares its engine in the same frame.
  return lockedProviderOf(state.current?.sessionId);
}

/** The short, honest sentence a disabled provider control shows for a locked session. */
function lockedProviderExplain(locked) {
  const runs = locked === 'openai' ? 'OpenAI Codex' : 'Claude';
  const other = locked === 'openai' ? 'Claude' : 'OpenAI Codex';
  return `This conversation runs on ${runs} — its transcript pins the engine, so a resume can only continue on ${runs}. Start a new session to use ${other}.`;
}

/*
 * BUG-196 round 6 — THE engine state of the session every provider surface acts on,
 * computed in ONE place. Round 5 had three readers deriving it separately —
 * providerView (engine shown), providerSwitchRefusal (may it change) and
 * paintProvBtn (locked or not, keyed on the pin alone) — so after a FAILED
 * transcript read the popover and drawer refused while #provBtn showed "Claude
 * (project default)", unlocked: two surfaces, two answers. Every surface now reads
 * this one record, and paintProvSurfaces paints all of them from it.
 *
 *   engine  — 'anthropic' | 'openai', or NULL = not known. An EXISTING session
 *             (it has an id) whose engine the server has not declared yet — the
 *             transcript is still loading, or the read failed — is UNKNOWN. It is
 *             never shown as the project default: that is a guess the resume
 *             ignores, and the round-5 surfaces that showed it offered that
 *             engine's models (a Claude alias then rode a Codex resume).
 *   refusal — why the engine cannot be changed from this view, or null when it
 *             can (only a view with no session id and nothing running in view).
 *   source  — 'running' | 'pinned' | 'unknown' | 'armed' | 'project'.
 */
const ENGINE_UNKNOWN_REFUSAL = 'This conversation already exists, so its engine is set by its transcript, which has not been read yet (still loading, or the read failed). A pick here cannot apply to it. Start a new session to choose an engine.';
function sessionEngine() {
  // BUG-106 — a foreign dock's live provider is not about the selected project;
  // dockEffective() blanks it (the pin below is keyed by id, so it is not).
  const running = dockEffective()?.provider ?? null;
  if (state.current?.sessionId) {
    // BUG-196 — an existing session's engine is pinned by its transcript (declared
    // by the server per id); the resume ignores any project default or override.
    const fixed = running ?? lockedSessionProvider();
    if (fixed) return { engine: fixed, refusal: lockedProviderExplain(fixed), source: running ? 'running' : 'pinned' };
    return { engine: null, refusal: ENGINE_UNKNOWN_REFUSAL, source: 'unknown' };
  }
  const armed = 'provider' in state.overrides ? state.overrides.provider : null;
  const engine = running ?? armed ?? currentProject()?.settings?.provider ?? 'anthropic';
  // BUG-106 — dockLive(): only a live session IN VIEW fixes the engine.
  const refusal = dockLive() ? 'the engine is fixed for a running session — start a new session to switch' : null;
  return { engine, refusal, source: running ? 'running' : armed ? 'armed' : 'project' };
}

/** The engine this view speaks for, or null when an existing session's engine is not known yet (BUG-196 round 6). */
function providerView() {
  return sessionEngine().engine;
}

/*
 * The Codex catalog is a SEPARATE list, never merged into MODEL_OPTS: the
 * engines' catalogs must not poison each other (the pre-045 server kept ONE
 * global list, so a codex session's model/list overwrote the Claude rows).
 * null = never fetched; fetched lazily the first time an OpenAI view needs
 * it, and refreshed on every picker open (the server relearns it from each
 * codex session's own model/list).
 */
let CODEX_MODEL_OPTS = null;

function adoptCodexModelList(models) {
  if (!Array.isArray(models) || !models.length) return;
  CODEX_MODEL_OPTS = [
    { v: null, n: 'Project default', d: 'Not decided yet — resolves once a session runs' },
    ...models.map((m) => ({ v: m.value, n: m.displayName || m.value, d: m.description || '', r: m.resolvedModel || null })),
  ];
}

/** The catalog for the CURRENT provider view. Anthropic = MODEL_OPTS, byte-identical to pre-045. */
function activeModelOpts() {
  const engine = providerView();
  const defaultRow = MODEL_OPTS.find((o) => o.v == null) ?? { v: null, n: 'Project default', d: '' };
  // BUG-196 round 6 — an existing session whose engine is not known yet offers NO
  // engine's catalog: round 5 fell through to the Claude rows here, so after a
  // failed read an OpenAI thread offered Opus/Sonnet/Haiku. The free-text field
  // still works, and the server judges any pick against the real engine.
  if (engine == null) return [defaultRow];
  if (engine !== 'openai') return MODEL_OPTS;
  return CODEX_MODEL_OPTS ?? [defaultRow];
}

let codexModelsInflight = null;
let codexModelsFetchedOnce = false; // ambient repaints probe once; a picker OPEN always re-asks
let codexModelsJson = null; // repaint only on CHANGE — paintModelPop itself refetches, so an unconditional repaint would loop
function refreshCodexModels(opts = {}) {
  if (codexModelsInflight) return codexModelsInflight;
  if (codexModelsFetchedOnce && !opts.force) return Promise.resolve();
  codexModelsInflight = api.models('openai').then((models) => {
    codexModelsInflight = null;
    codexModelsFetchedOnce = true;
    if (!Array.isArray(models) || !models.length) return;
    const j = JSON.stringify(models);
    if (j === codexModelsJson) return;
    codexModelsJson = j;
    adoptCodexModelList(models);
    if (node.modelPop.classList.contains('open')) paintModelPop();
    paintModelBtn();
    paintModelChip();
  }).catch(() => { codexModelsInflight = null; });
  return codexModelsInflight;
}

/*
 * The launch-surface provider control. Everything it sets is the per-launch
 * override the server has validated since FEAT-037 P3 (`overrides.provider`)
 * — never a registry write; the project default is one click away in the
 * drawer. The popover mirrors the drawer's honesty: the OpenAI row carries
 * the LIVE detectCodex() verdict from /api/providers, and picking OpenAI
 * while not connected is allowed but warns with the actionable hint (the
 * launch then fails fast with the same hint — agent-bridge P3).
 */
const PROVIDER_OPTS = [
  { v: 'anthropic', n: 'Claude', d: 'Anthropic — the default engine' },
  { v: 'openai', n: 'OpenAI Codex', d: 'Bills to your ChatGPT subscription' },
];

let provVerdicts; // undefined = unfetched, null = route absent
let provVerdictsInflight = null;
function refreshProvVerdicts() {
  if (provVerdictsInflight) return provVerdictsInflight;
  provVerdictsInflight = api.providers().then((p) => {
    provVerdictsInflight = null;
    provVerdicts = p; // null when the route is absent
    if (node.provPop.classList.contains('open')) paintProvPop();
    paintProvBtn();
    paintProvSel();
  }).catch(() => { provVerdictsInflight = null; });
  return provVerdictsInflight;
}

function paintProvBtn() {
  // Hidden while a session is LIVE: the engine cannot change mid-session
  // (the FEAT-042 crown chip names the running engine); this control is for
  // the launch surface, where overrides are armed pre-start.
  const show = !!currentProject() && !dockLive(); // BUG-106 — A's live session must not hide B's launch control
  node.provBtn.hidden = !show;
  // BUG-196 — a session pinned by its transcript shows its real engine and says so;
  // the popover's options are disabled and the switch is refused. Round 3: written
  // BEFORE the hidden early-return, so the attribute is never left stale.
  // BUG-196 round 6 — keyed on the ONE engine state (sessionEngine), the same record
  // the popover and the drawer read: round 5 keyed this on the pin alone, so after a
  // failed read the button stayed unlocked and said "Claude (project default)" while
  // its own popover refused. An unknown engine is shown as unknown, never guessed.
  const se = sessionEngine();
  node.provBtn.dataset.locked = String(!!se.refusal);
  if (!show) return;
  const cur = se.engine;
  const opt = PROVIDER_OPTS.find((o) => o.v === cur);
  node.provBtn.dataset.provider = cur ?? 'unknown';
  node.provBtn.dataset.set = String(!se.refusal && 'provider' in state.overrides);
  if (se.refusal) {
    node.provBtn.title = `Engine: ${cur == null ? 'not known yet' : (opt?.n ?? cur)} — ${se.refusal}`;
    return;
  }
  const inherited = 'provider' in state.overrides ? ' (this session only)' : ' (project default)';
  node.provBtn.title = `Provider: ${opt?.n ?? cur}${inherited} — applies when the next session starts. Click to change`;
}

/**
 * BUG-196 round 3 — the button, the header twin and the (open) popover repaint
 * TOGETHER from the same source (providerView / lockedSessionProvider), so they
 * can never disagree — round 2 left #provBtn[data-locked] stale while the popover
 * repainted unlocked, because a project switch repainted one and not the other.
 * Called from paintCrown (every selection change) and from declareLockedProvider.
 */
function paintProvSurfaces() {
  paintProvBtn();
  paintProvSel();
  if (node.provPop.classList.contains('open')) paintProvPop();
  // BUG-196 round 6 — the drawer's session-scope Provider control is a lock
  // surface too; it repaints with the others, from the same sessionEngine().
  drawer.repaintLive?.();
}

// this-feat — the header twin of paintProvBtn. Same source of truth
// (providerView / state.overrides), same visibility rule (a project is
// selected and nothing is live), so the labelled selector in the strip and the
// icon in the composer tray never disagree. Short engine names keep the strip
// tight; the popover carries the full description.
const PROV_SHORT = { anthropic: 'Anthropic', openai: 'OpenAI' };
function paintProvSel() {
  // FEAT-139 — the provider (engine) choice is a CONFIG control, so it leaves the
  // strip and lives under the one Settings door (Capabilities ▸ Provider); the
  // composer-tray #provBtn and the settings drawer remain the ways to change it.
  // The element stays in the DOM (handlers/popover untouched) but never shows on
  // the strip. Kept as an early return so nothing below re-reveals it.
  node.provSel.hidden = true;
  if (node.provSel.hidden) return;
  const cur = providerView();
  const opt = PROVIDER_OPTS.find((o) => o.v === cur);
  node.provSelN.textContent = PROV_SHORT[cur] ?? opt?.n ?? cur;
  node.provSel.dataset.provider = cur;
  node.provSel.dataset.set = String('provider' in state.overrides);
  const inherited = 'provider' in state.overrides ? ' (this session only)' : ' (project default)';
  node.provSel.title = `Engine: ${opt?.n ?? cur}${inherited} — Anthropic (Claude) or OpenAI (Codex). Applies when the next session starts; click to change.`;
}
node.provSel.addEventListener('click', (e) => {
  e.stopPropagation();
  if (node.provPop.classList.contains('open')) return closePops();
  closePops();
  void refreshProvVerdicts();
  paintProvPop();
  place(node.provPop, node.provSel, 292);
  node.provPop.classList.add('open');
  node.provSel.setAttribute('aria-expanded', 'true');
});

function openaiVerdict() {
  return provVerdicts?.openai ?? null;
}

function paintProvPop() {
  clear(node.provOpts);
  // BUG-196 — a transcript-pinned session's engine cannot change on resume; the
  // options are disabled and an explanation replaces the availability verdict.
  // BUG-196 round 6 — engine AND refusal from the one sessionEngine() record, so an
  // unknown engine presses no option (round 5 pressed the project default).
  const se = sessionEngine();
  const cur = se.engine;
  const refusal = se.refusal;
  const locked = refusal ? true : null;
  for (const o of PROVIDER_OPTS) {
    const isCur = o.v === cur;
    const b = el('button', { class: 'opt', role: 'menuitem', 'aria-pressed': String(isCur), 'aria-disabled': String(!!locked) });
    if (locked) b.disabled = true;
    b.append(el('span', { class: 'g', text: isCur ? '●' : '○' }));
    const mid = el('span');
    mid.append(el('span', { class: 'n', text: o.n }));
    if (o.d) mid.append(el('span', { class: 'd', text: o.d }));
    if (!locked && isCur && !('provider' in state.overrides)) mid.append(el('span', { class: 'tag', text: 'project default' }));
    b.append(mid);
    if (!locked) b.addEventListener('click', () => pickProvider(o.v));
    node.provOpts.append(b);
  }
  if (locked) {
    const warn = el('div', { class: 'grp-note', text: refusal });
    warn.dataset.warn = 'true';
    node.provOpts.append(warn);
    return;
  }
  // The live detection verdict, in the drawer's own voice (.prov-state).
  const oai = openaiVerdict();
  if (provVerdicts === undefined) {
    node.provOpts.append(el('div', { class: 'prov-state', 'data-status': 'unknown' },
      el('span', { class: 'dot' }), document.createTextNode('OpenAI Codex — checking availability…')));
  } else if (provVerdicts === null) {
    node.provOpts.append(el('div', { class: 'prov-state', 'data-status': 'unknown' },
      el('span', { class: 'dot' }), document.createTextNode('OpenAI Codex — state unknown (no /api/providers route)')));
  } else {
    node.provOpts.append(el('div', { class: 'prov-state', 'data-status': oai?.status ?? 'unknown' },
      el('span', { class: 'dot' }), document.createTextNode(oai?.label ?? 'OpenAI Codex — state unknown')));
    if (oai && oai.status !== 'connected' && oai.hint) {
      node.provOpts.append(el('div', { class: 'grp-note', text: oai.hint }));
    }
    if (cur === 'openai' && oai && oai.status !== 'connected') {
      const warn = el('div', { class: 'grp-note', text: 'Selected, but not connected — launching will fail with the hint above until Codex is usable (docs/PROVIDERS.md).' });
      warn.dataset.warn = 'true';
      node.provOpts.append(warn);
    }
  }
}

/*
 * BUG-196 round 5 — THE guard for a per-session provider write, and the ONE place
 * that decides whether one is allowed at all. Every client surface that can arm,
 * clear or reset a session-scope provider (the composer-tray popover, the Settings
 * drawer's session-scope Provider control, its reset chip, its generic put()) goes
 * through pickProvider below, which asks this first — round 4 guarded pickProvider
 * but the drawer wrote ctx.overrides.provider itself, so a switch for an existing
 * id was accepted in the pre-pin window and after a failed transcript fetch.
 * Returns the refusal text, or null when the view may arm an engine (only a
 * pending-new session with nothing running in view).
 */
function providerSwitchRefusal() {
  // BUG-196 round 6 — a read of the one engine state (sessionEngine), not a second
  // derivation: pinned → the lock explanation; an existing id with no declared
  // engine (loading / read failed) → refused; a live session in view → refused.
  return sessionEngine().refusal;
}

/**
 * The ONE writer of `state.overrides.provider` (BUG-196 round 5). `next` is an
 * engine key, or null = "no override" (the project default).
 */
function pickProvider(next) {
  const refusal = providerSwitchRefusal();
  if (refusal) {
    say(refusal, true);
    paintProvSurfaces();
    drawer.repaintLive?.();
    return false;
  }
  const before = providerView();
  const projectDefault = currentProject()?.settings?.provider ?? 'anthropic';
  if (next == null) next = projectDefault;
  // Picking the project's own default is "no override" — clear rather than
  // storing an override equal to the default (same rule as the drawer).
  if (next === projectDefault) delete state.overrides.provider;
  else state.overrides.provider = next;
  // A model/effort armed for the OTHER engine's catalog would ride the start
  // payload into an engine that cannot honour it — drop them loudly, never
  // silently carry them across.
  let dropped = '';
  if (before !== next && ('model' in state.overrides || 'effort' in state.overrides)) {
    delete state.overrides.model;
    delete state.overrides.effort;
    dropped = ' · the armed model/effort override was cleared (it named the other engine’s catalog — repick from /model)';
  }
  persistOverrides();
  const opt = PROVIDER_OPTS.find((o) => o.v === next);
  const oai = openaiVerdict();
  if (next === 'openai' && provVerdicts && oai && oai.status !== 'connected') {
    say(`provider: ${opt?.n ?? next} — armed, but Codex is ${oai.status === 'not-installed' ? 'not installed' : 'not signed in'}: launching will fail until it is usable. ${oai.hint ?? 'See docs/PROVIDERS.md.'}${dropped}`, true);
  } else {
    say(`provider: ${opt?.n ?? next} — applies when the next session starts${dropped}`);
  }
  paintProvBtn();
  paintProvSel();
  paintProvPop();
  paintModelBtn();
  paintModelChip();
  drawer.repaintLive?.();
  return true;
}

node.provBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  if (node.provPop.classList.contains('open')) return closePops();
  closePops();
  void refreshProvVerdicts(); // live truth on every open, like the drawer
  paintProvPop();
  place(node.provPop, node.provBtn, 292);
  node.provPop.classList.add('open');
  node.provBtn.setAttribute('aria-expanded', 'true');
});
$('#provPopSettings').addEventListener('click', () => { closePops(); void drawer.open('settings'); });

/* --------------------------- Claude account at launch (FEAT-145 step 5) */
/*
 * WHY THIS LIVES ON THE LAUNCH SURFACE and not only in Machine settings: you
 * switch subscription at exactly one moment — the moment the plan you are on has
 * burned its 5-hour window and you are about to start a lane anyway. A control
 * three clicks deep in machine settings is not reachable at that moment, so the
 * second subscription goes on sitting unused, which is the whole symptom
 * FEAT-145 exists to remove.
 *
 * Everything this arms is the per-launch override the server validates
 * (`start.overrides.claudeAccount` — validate.ts SESSION_OVERRIDE_FIELDS), never
 * a registry write: the project and machine defaults stay exactly where they
 * are, and the override dies with the session. Same idiom as the provider
 * control directly above (providerView/state.overrides → pill + popover).
 *
 * CONTAINER PROJECTS: the control is shown but LOCKED, with the reason on
 * screen. Not absent (silence would read as "this feature does not exist here")
 * and not offered-then-rejected (the server refuses it fatally — validate.ts —
 * because a container binds the account's credential file, so a per-session
 * switch would recreate the container under every other session on that project
 * and outlive this one).
 *
 * Built in JS rather than in index.html, like the project overflow menu below:
 * it only exists at all on a machine that has a SECOND Claude account, and it
 * reuses the provider popover's chrome (.pill.sel / .pop / .opt) so it needs no
 * new markup and no new CSS.
 */
let ACCOUNTS;                 // undefined = never fetched, null = no route/unreadable, [] = only the default
let accountsInflight = null;
function refreshAccounts(opts = {}) {
  if (accountsInflight) return accountsInflight;
  if (ACCOUNTS !== undefined && !opts.force) return Promise.resolve();
  accountsInflight = api.getClaudeAccounts().then((list) => {
    accountsInflight = null;
    ACCOUNTS = Array.isArray(list) ? list : null;
    paintAccountSel();
    if (acctPop?.classList.contains('open')) paintAcctPop();
  }).catch(() => { accountsInflight = null; });
  return accountsInflight;
}

/** The rows the server knows about, default first (listAccounts guarantees that order). */
function accountRows() { return Array.isArray(ACCOUNTS) ? ACCOUNTS.filter((a) => a && typeof a.id === 'string') : []; }
function extraAccountRows() { return accountRows().filter((a) => a.id !== 'default'); }

/** Short pill text for an account id — "Default" for the implicit ~/.claude one. */
function acctShortName(id) {
  if (!id || id === 'default') return 'Default';
  const row = accountRows().find((a) => a.id === id);
  return row?.label ?? id;
}

/**
 * An account's plan + login state, in the same words the drawer's machine
 * control uses — so it is obvious WHICH subscription a session will spend.
 */
function acctPlanDesc(a) {
  if (!a) return '';
  const bits = [];
  const sub = a.lastStatus && typeof a.lastStatus.subscriptionType === 'string' ? a.lastStatus.subscriptionType : null;
  if (sub) bits.push(sub);
  bits.push(a.state === 'ready' ? 'logged in' : (a.state === 'pending' ? 'not logged in yet' : String(a.state)));
  return bits.join(', ');
}

/**
 * The account's OWN remaining window, from the per-account usage snapshots
 * (FEAT-145 step 7 made /api/usage report one per account). This is the reason
 * the whole feature exists — "which plan has headroom right now" has to be
 * readable at the point of choosing, not one tooltip away.
 */
function acctUsageDesc(id) {
  const snap = (state.usage ?? []).find((s) => s.provider === 'anthropic' && (s.accountId ?? 'default') === (id ?? 'default'));
  if (!snap) return '';
  if (!snap.available) return `usage unknown${snap.note ? ` (${snap.note})` : ''}`;
  const b = (snap.windows ?? []).find((w) => w.binding) ?? (snap.windows ?? [])[0];
  if (!b) return '';
  const reset = usageResetShort(b.resetsAt);
  return `${b.usedPercent}% of ${b.label}${reset ? ` · resets ${reset}` : ''}`;
}

let acctSel = null; let acctSelN = null; let acctPop = null; let acctOpts = null;
function ensureAccountEls() {
  if (acctSel) return;
  acctSelN = el('span', { id: 'acctSelN', text: 'Default' });
  acctSel = el('button', { class: 'pill sel', id: 'acctSel', 'aria-haspopup': 'true', 'aria-expanded': 'false' },
    el('span', { class: 'g', text: '◑' }), acctSelN);
  acctSel.hidden = true;
  acctSel.addEventListener('click', (e) => {
    e.stopPropagation();
    if (acctPop.classList.contains('open')) return closePops();
    closePops();
    void refreshAccounts({ force: true }); // live truth on every open, like the provider control
    paintAcctPop();
    place(acctPop, acctSel, 300);
    acctPop.classList.add('open');
    acctSel.setAttribute('aria-expanded', 'true');
  });
  // Next to the provider selector in the seal strip: the two answer the same
  // question one after the other — which engine, then which subscription.
  node.provSel.insertAdjacentElement('afterend', acctSel);

  acctOpts = el('div', { id: 'acctOpts' });
  acctPop = el('div', { class: 'pop', id: 'acctPop', role: 'menu', 'aria-label': 'Claude account for the next session' },
    el('h4', { text: 'Claude account' }), acctOpts);
  const foot = el('div', { class: 'pop-foot' });
  const b = el('button', {}, document.createTextNode('Project defaults '), el('span', { class: 'cx', text: '›' }));
  b.addEventListener('click', () => { closePops(); void drawer.open('settings'); });
  foot.append(b);
  acctPop.append(foot);
  node.provPop.insertAdjacentElement('afterend', acctPop);
}

/** Is the account choice locked to project scope for the selected project? */
function accountLockedReason() {
  const p = currentProject();
  if (p?.isolation === 'container') {
    return 'This project runs in a CONTAINER, and the account’s credential file is one of the container’s bind mounts. '
      + 'Switching it for one session would recreate the container under every other session on this project and outlive this one, '
      + 'so the account is pinned at project scope here. Change it in this project’s settings.';
  }
  return '';
}

function paintAccountSel() {
  const p = currentProject();
  // Only ever built/shown when there is a real choice: a second Claude account
  // exists, a project is selected, nothing is live in view (the account is fixed
  // for a running session, like the engine), and this project runs on Claude.
  if (!p || ACCOUNTS === undefined) { void (p ? refreshAccounts() : null); if (acctSel) acctSel.hidden = true; return; }
  const show = !!p && !dockLive() && providerView() === 'anthropic' && extraAccountRows().length > 0;
  if (!show) { if (acctSel) acctSel.hidden = true; return; }
  ensureAccountEls();
  acctSel.hidden = false;
  const cur = claudeAccountView(); // the ONE resolver — override → project → default
  const armed = 'claudeAccount' in state.overrides;
  const locked = accountLockedReason();
  acctSelN.textContent = acctShortName(cur);
  acctSel.dataset.set = String(armed);
  acctSel.dataset.locked = String(!!locked);
  const usage = acctUsageDesc(cur);
  const scope = armed ? ' (this session only)' : ' (project default)';
  acctSel.title = locked
    ? `Claude account: ${acctShortName(cur)} — fixed for this project. ${locked}`
    : `Claude account: ${acctShortName(cur)}${scope} — which subscription the next session bills to`
      + `${usage ? `; ${usage}` : ''}. Applies when the next session starts; click to change.`;
}

function paintAcctPop() {
  ensureAccountEls();
  clear(acctOpts);
  const locked = accountLockedReason();
  const armed = 'claudeAccount' in state.overrides;
  const armedVal = armed ? (state.overrides.claudeAccount ?? 'default') : null;
  const dflt = accountRows().find((a) => a.id === 'default');
  const rows = [
    { v: undefined, n: 'Project default', d: `Inherit — currently ${acctShortName(claudeAccountView())}` },
    { v: null, n: dflt?.label ?? 'Default (~/.claude)', d: acctPlanDesc(dflt), id: 'default' },
    ...extraAccountRows().map((a) => ({ v: a.id, n: a.label, d: acctPlanDesc(a), id: a.id })),
  ];
  for (const o of rows) {
    const isCur = o.v === undefined ? !armed : (armedVal === (o.v ?? 'default'));
    const b = el('button', { class: 'opt', role: 'menuitem', 'aria-pressed': String(isCur), 'aria-disabled': String(!!locked) });
    b.append(el('span', { class: 'g', text: isCur ? '●' : '○' }));
    const mid = el('span');
    mid.append(el('span', { class: 'n', text: o.n }));
    // Plan + login state, then this account's OWN remaining window: the two
    // facts the switch is made on.
    const usage = o.id ? acctUsageDesc(o.id) : '';
    const d = [o.d, usage].filter(Boolean).join(' · ');
    if (d) mid.append(el('span', { class: 'd', text: d }));
    if (isCur && !armed && o.v === undefined) mid.append(el('span', { class: 'tag', text: 'inherited' }));
    b.append(mid);
    b.addEventListener('click', () => pickAccount(o.v));
    acctOpts.append(b);
  }
  if (locked) {
    const warn = el('div', { class: 'grp-note', text: locked });
    warn.dataset.warn = 'true';
    acctOpts.append(warn);
  } else {
    acctOpts.append(el('div', { class: 'grp-note', text: 'Applies to the NEXT session only — the project and machine defaults are untouched. Each account is a thin overlay over ~/.claude, so the transcript history is shared; only the subscription differs.' }));
  }
}

/**
 * `undefined` clears the override (inherit project → machine); `null` pins this
 * session to the implicit default account; a string pins it to that account.
 *
 * Note it never "clears because you picked the current value": the client cannot
 * see the MACHINE default, so "equal to the project's stored value" is not the
 * same question as "equal to what would be inherited". Picking a concrete
 * account therefore always arms an explicit override — the server drops it as a
 * no-op if it equals the resolved default anyway (agent-bridge compares values).
 */
function pickAccount(next) {
  const locked = accountLockedReason();
  if (locked) return say(`the Claude account is project-scope for a container project — ${locked}`, true);
  if (dockLive()) return say('the Claude account is fixed for a running session — start a new session to switch', true);
  if (next === undefined) delete state.overrides.claudeAccount;
  else state.overrides.claudeAccount = next;
  persistOverrides();
  const name = next === undefined ? `${acctShortName(claudeAccountView())} (inherited)` : acctShortName(next ?? 'default');
  const usage = acctUsageDesc(next === undefined ? claudeAccountView() : (next ?? 'default'));
  say(`Claude account: ${name} — applies when the next session starts${usage ? ` · ${usage}` : ''}`);
  paintAccountSel();
  paintAcctPop();
  paintUsageChip(); // the badge follows the account this session will actually run on
  drawer.repaintLive?.();
}

/*
 * Matching the picker's current row against the effective model is not a
 * straight string compare: after `session-init` the server reports the
 * CLI's full wire id (e.g. 'claude-haiku-4-5-20251001'), which never equals
 * an alias row's `v` (e.g. 'haiku'). Each row also carries `r` —
 * `resolvedModel`, the wire id that alias covers — so a row is "current"
 * when the effective value matches EITHER its own value OR its resolved id.
 * Compared case-insensitively and with a trailing '[1m]' stripped, since the
 * 1M-context variants of a model share the same underlying wire id.
 */
function normModelId(s) {
  return String(s ?? '').replace(/\[1m\]$/i, '').toLowerCase();
}

function resolveCurrentModelOpt(opts, current) {
  if (current == null) return opts.find((o) => o.v == null) ?? null;
  const cur = normModelId(current);
  return opts.find((o) => o.v != null && normModelId(o.v) === cur)
    ?? opts.find((o) => o.r && normModelId(o.r) === cur)
    ?? null;
}

/*
 * BUG-021: what model results when THIS session carries no 'model' override —
 * i.e. what "Project default" actually resolves to, named concretely instead
 * of left as the opaque phrase. Never guesses: the project's own configured
 * default (registry `settings.model`) is authoritative when set; failing
 * that, only a session that has ACTUALLY RUN with no override tells the
 * truth, via the live wire id `session-init` reported (folded into
 * state.effective there). Returns null when nothing has told us yet, so
 * callers fall back to honest "not decided yet" copy rather than fabricate a
 * model name.
 */
function resolveInheritedModelLabel() {
  const projectDefault = currentProject()?.settings?.model ?? null;
  if (projectDefault != null) {
    const opt = resolveCurrentModelOpt(activeModelOpts(), projectDefault);
    return opt?.v != null ? opt.n : String(projectDefault);
  }
  // No project default either — only a session that has actually run tells
  // the truth, via the live wire id session-init reported. But NOT if the
  // live session's own effective-config says 'model' was itself overridden
  // (state.effective.overridden) — then the live value is that override's
  // resolution, not the inherited default's, and claiming otherwise would be
  // a lie. A freshly-armed, not-yet-applied client override (state.overrides)
  // does not disqualify it: it only takes effect on the NEXT session (see the
  // popover's own "applies to the NEXT session" messaging), so the CURRENT
  // live session's effective model is still the true default's resolution.
  const eff = dockEffective(); // BUG-106 — a foreign dock's live model is not the selected project's inherited default
  if (eff?.overridden?.includes('model')) return null;
  const raw = eff?.effective?.model ?? null;
  if (raw == null) return null;
  const opt = resolveCurrentModelOpt(activeModelOpts(), raw);
  return opt?.v != null ? opt.n : String(raw);
}
const EFFORT_OPTS = [
  { v: null, n: 'Project default' },
  { v: 'low', n: 'low' }, { v: 'medium', n: 'medium' }, { v: 'high', n: 'high' },
  { v: 'xhigh', n: 'xhigh' }, { v: 'max', n: 'max' },
];

/**
 * What the session is REALLY running with. Once live, the server's
 * effective-config wins over anything the UI believes it requested — same rule
 * the permission chip follows.
 */
function effectiveModel(field) {
  const eff = dockEffective(); // BUG-106 — foreign dock ⟹ the selected project's launch value, not A's live effective
  if (eff?.effective && field in eff.effective) return { value: eff.effective[field], live: true };
  if (field in state.overrides) return { value: state.overrides[field], live: false };
  return { value: currentProject()?.settings?.[field] ?? null, live: false };
}

function paintModelBtn() {
  const has = !!currentProject();
  node.modelBtn.hidden = !has;
  if (!has) return;
  const m = effectiveModel('model');
  const e = effectiveModel('effort');
  const overridden = 'model' in state.overrides;
  // BUG-021: name the concrete model, not the vague "project default" phrase,
  // whenever it can be resolved — see resolveInheritedModelLabel.
  let name;
  if (m.value) {
    const opt = resolveCurrentModelOpt(activeModelOpts(), m.value);
    name = opt?.v != null ? opt.n : String(m.value);
  } else {
    name = resolveInheritedModelLabel() ?? 'project default';
  }
  const inherited = !overridden ? ' (project default)' : '';
  node.modelBtn.dataset.set = String('model' in state.overrides || 'effort' in state.overrides);
  node.modelBtn.title = `Model: ${name}${inherited}${e.value ? ` · effort ${e.value}` : ''}${m.live ? ' (from the running session)' : ' (applies on next launch)'} — click to change for this session`;
  // FEAT-045: the provider control lives beside this button and repaints on
  // exactly the same beats (project switch, launch, override churn).
  paintProvBtn();
  paintProvSel();
}

/* ------------------------------------------- live model chip (FEAT-042) */
/*
 * The provider can switch the model WITHOUT user action (safeguard refusal
 * fallbacks, downgrades) — and until now the only place the model showed at
 * all was inside the /model picker. The chip makes the LIVE resolved model
 * permanently visible in the crown, and flags any change the user did not
 * initiate (pulse + a transcript "model changed: X → Y" line).
 *
 * Detection boundary, stated honestly: the ONE dedicated push signal the SDK
 * has is `model_refusal_fallback` (surfaced as `model-changed`); every other
 * provider-side switch is only observable per-turn, via the wire id stamped on
 * each main-thread assistant message (surfaced as `model-observed`, deduped).
 * So a silent switch becomes visible the moment the new model first SPEAKS —
 * never earlier, and a turn that produces no main-thread assistant message
 * cannot reveal one. Subagent messages are excluded on the server: subagents
 * legitimately run different models.
 */

/** Compact display form: a known picker row's name, else the wire id minus its ceremony. */
function shortModelName(id) {
  if (id == null) return 'default';
  const opt = resolveCurrentModelOpt(activeModelOpts(), id);
  if (opt?.v != null) return opt.n;
  return String(id).replace(/^claude-/i, '').replace(/-\d{8}$/, '');
}

/*
 * "Is this the same model?" across the three spellings in play: a picker alias
 * ('sonnet'), a canonical id ('claude-sonnet-5'), and a dated wire id
 * ('claude-sonnet-5-20250929'). A false "different" here would flag the user's
 * OWN confirmed switch as a silent provider change — the one false alarm this
 * feature must never raise — so alias⊂wire containment is accepted when no
 * picker row joins them.
 */
function sameModel(a, b) {
  if (a == null || b == null) return a == null && b == null;
  const na = normModelId(a);
  const nb = normModelId(b);
  if (na === nb) return true;
  const ra = resolveCurrentModelOpt(activeModelOpts(), a);
  const rb = resolveCurrentModelOpt(activeModelOpts(), b);
  if (ra && rb) return ra === rb;
  return na.includes(nb) || nb.includes(na);
}

function paintModelChip() {
  if (!node.modelChip) return;
  const has = !!currentProject();
  node.modelChip.hidden = !has;
  if (!has) return;
  // The running session's own report wins; the effective config is next; the
  // resolved inherited default covers the pre-launch view. Never fabricates.
  const eff = dockLiveModel() ?? effectiveModel('model').value ?? null; // BUG-106 — foreign dock ⟹ no live model
  /*
   * FEAT-037 P3 — the crown names the ENGINE too, not just the model. Live
   * session: the server's resolved provider (effective-config/ack). Pre-launch:
   * an armed session override, else the project setting. Anthropic — the
   * default — stays UNMARKED, exactly the pre-P3 render; a non-default engine
   * gets a quiet lowercase prefix in the same greyscale chip.
   */
  const provider = providerView(); // FEAT-045: same resolution, now shared with the launch control
  // FEAT-045: name codex models by the engine's own displayName once known
  // (one lazy probe; a picker open re-asks the server regardless).
  if (provider === 'openai' && CODEX_MODEL_OPTS == null) void refreshCodexModels();
  node.modelChip.dataset.provider = provider ?? 'unknown'; // BUG-196 round 6 — null = engine not known yet
  const provMark = provider === 'openai' ? 'codex · ' : '';
  node.modelChipName.textContent = provMark + (eff != null ? shortModelName(eff) : (resolveInheritedModelLabel() ?? '—'));
  node.modelChip.dataset.live = String(!!(dockLive() && eff != null)); // BUG-106
  const src = dockLiveModel()
    ? ' (reported by the running session)'
    : dockLive() ? ' (effective config)' : ' (resolves at launch)';
  node.modelChip.title = `Provider: ${provider == null ? 'not known yet' : provider === 'openai' ? 'OpenAI Codex' : 'Claude (Anthropic)'} · Model: ${eff != null ? String(eff) : 'not resolved yet'}${src} — click to change`;
}

/**
 * A model change the user did NOT initiate: transcript system line + status
 * line + a pulse on the chip. The tinted flag STAYS until the chip is clicked,
 * so the change is catchable even when the pulse itself was missed — that is
 * the entire point of this feature.
 */
/*
 * BUG-081: a provider-side model switch is HIGH signal — the model answering you
 * silently changed, and why — but it used to render as a plain body-coloured line
 * that blended into the conversation. Build it as a distinct centred hairline
 * chip with an amber accent (--st-needs): a fallback/degradation reads as
 * "needs-you" per FEAT-066's restrained palette, and the pill is unmistakably
 * station chrome — not a chat bubble, not prose. `from → to` stays inline; the
 * reason rides alongside when short, collapses to "fallback" when long, and the
 * FULL line is always the chip's `title` so the complete detail is one hover away.
 * This is a LIVE-only marker (there is no persisted transcript block to replay),
 * so the one render site below covers every path that reaches it.
 */
function modelChangeMark(from, to, why) {
  const line = `model changed: ${shortModelName(from)} → ${shortModelName(to)}${why ? ` (${why})` : ''}`;
  const wrap = el('div', { class: 'ran-lbl model-change' });
  const chip = el('span', { class: 'mc-chip', title: line });
  chip.append(el('span', { class: 'mc-ico', 'aria-hidden': 'true', text: '◇' }));
  chip.append(el('span', { class: 'mc-txt', text: `model changed: ${shortModelName(from)} → ${shortModelName(to)}` }));
  if (why) chip.append(el('span', { class: 'mc-why', text: why.length <= 34 ? why : 'fallback' }));
  wrap.append(chip);
  return wrap;
}

function flagModelChange(from, to, why) {
  const line = `model changed: ${shortModelName(from)} → ${shortModelName(to)}${why ? ` (${why})` : ''}`;
  claudeBody(mainThread()).append(modelChangeMark(from, to, why));
  if (state.viewing === 'main') scrollDown();
  say(line, true);
  if (node.modelChip) {
    node.modelChip.dataset.flag = 'true';
    // Restart the pulse when a second change lands while already flagged.
    node.modelChip.style.animation = 'none';
    void node.modelChip.offsetWidth;
    node.modelChip.style.animation = '';
  }
}

function clearModelFlag() {
  if (node.modelChip) delete node.modelChip.dataset.flag;
}

function paintModelPop() {
  /*
   * FEAT-045: the catalog follows the PROVIDER view. An OpenAI session (live
   * or armed) lists the real Codex catalog — the engine's own model/list,
   * remembered per provider by the server — never the static Claude aliases.
   * The Claude path reads MODEL_OPTS through activeModelOpts() unchanged.
   */
  const POPTS = activeModelOpts();
  if (providerView() === 'openai') void refreshCodexModels({ force: true });
  const cur = effectiveModel('model').value ?? null;
  const curE = effectiveModel('effort').value ?? null;
  /*
   * BUG-021 (part 2): a value match is tried first (unchanged — it correctly
   * lights up e.g. the "Opus" row when the project default names 'opus'
   * directly). Only when NOTHING matches AND this session carries no
   * override do we fall back to the null "Project default" row: a live,
   * inherited session reports a real CLI wire id via session-init that this
   * browser's MODEL_OPTS may not carry a matching alias/`r` for (e.g. an
   * unseen version) — without this fallback NO row would light up at all,
   * even though the field is plainly inherited, not overridden.
   */
  const resolvedModelOpt = resolveCurrentModelOpt(POPTS, cur);
  // FEAT-118: a model the CLI accepts but does NOT advertise in its catalog
  // (a versioned id like `claude-opus-4-8`, set via the free-text escape hatch
  // below) resolves to no catalog row. Show it as its own lit row rather than
  // letting the fallback light "Project default", which would misreport what
  // this session is actually running. The sentinel is never an element of
  // POPTS, so no catalog row lights when the current value is custom.
  // Only a genuine OVERRIDE to a custom id gets its own row: an INHERITED
  // custom wire id (no session override) must still light the "Project default"
  // row with its concrete resolved label + "inherited" tag (BUG-021), never a
  // custom row — otherwise the readout would claim the session overrode a model
  // it merely inherited.
  const modelOverridden = ('model' in state.overrides)
    || !!dockEffective()?.overridden?.includes('model');
  const curIsCustom = cur != null && resolvedModelOpt == null && modelOverridden;
  const CUSTOM_CUR = {};
  const curModelOpt = resolvedModelOpt
    ?? (curIsCustom ? CUSTOM_CUR
      : (('model' in state.overrides) ? null : (POPTS.find((o) => o.v == null) ?? null)));
  const fill = (host, opts, current, field, currentOpt) => {
    clear(host);
    for (const o of opts) {
      const isCur = currentOpt !== undefined ? o === currentOpt : o.v === current;
      const b = el('button', { class: 'opt', role: 'menuitem', 'aria-pressed': String(isCur) });
      b.append(el('span', { class: 'g', text: isCur ? '●' : '○' }));
      const mid = el('span');
      mid.append(el('span', { class: 'n', text: o.n }));
      // BUG-021: the "Project default" row's description used to be a static
      // placeholder describing the BEHAVIOUR ("whatever the project is set
      // to"), never the model it actually resolves to. Show the concrete name
      // whenever it can be resolved (see resolveInheritedModelLabel) — for
      // both the currently-inherited row (the readout) and the idle option
      // (so picking it back shows what you'd get). The static `d` on MODEL_OPTS
      // remains only as the honest last-resort fallback (never resolvable yet).
      const resolvedInherited = (field === 'model' && o.v === null) ? resolveInheritedModelLabel() : null;
      const d = resolvedInherited ?? o.d;
      if (d) mid.append(el('span', { class: 'd', text: d }));
      if (resolvedInherited && isCur) mid.append(el('span', { class: 'tag', text: 'inherited' }));
      b.append(mid);
      b.addEventListener('click', () => {
        // BUG-026: the MODEL on a RUNNING session goes through the server's live
        // setModel (like permission mode) — arming a client override does not
        // switch the session and reverts on reopen, because effectiveModel()
        // rightly lets the live value win. effort (no live SDK setter) and any
        // pre-start change stay an arm-for-next-session override.
        if (field === 'model' && dockLive()) return setModelLive(o.v); // BUG-106 — only a live session IN VIEW takes a live model change
        // null = "inherit": drop the override rather than storing a null.
        if (o.v === null) delete state.overrides[field];
        else state.overrides[field] = o.v;
        persistOverrides();
        const live = dockEffective()?.effective;
        say(live
          ? `${field}: ${o.v ?? 'project default'} — applies to the NEXT session; the one running keeps ${live[field] ?? 'its current value'}`
          : `${field}: ${o.v ?? 'project default'} for this session`);
        paintModelBtn();
        paintModelPop();
        paintCrown();
        drawer.repaintLive?.();
      });
      host.append(b);
    }
  };
  fill(node.modelOpts, POPTS, cur, 'model', curModelOpt);
  // FEAT-045: an OpenAI view whose catalog has not been learned yet shows the
  // honest gap — the codex engine reports its own catalog per session.
  if (providerView() === 'openai' && CODEX_MODEL_OPTS == null) {
    node.modelOpts.append(el('div', {
      class: 'grp-note',
      text: 'The Codex catalog is reported by the engine itself — it fills in when a Codex session runs.',
    }));
  }
  // BUG-196 round 6 — the engine-unknown state says why no catalog is offered.
  if (providerView() == null) {
    node.modelOpts.append(el('div', {
      class: 'grp-note',
      'data-engine-unknown': 'true',
      text: 'This conversation\'s engine is not known yet (its transcript has not been read), so no engine\'s model list is shown. A model typed below is checked by the server against the engine the session really runs on.',
    }));
  }

  /*
   * FEAT-118: the free-text escape hatch for THIS session, mirroring what round
   * 3 gave the global-defaults drawer. The CLI accepts model ids it does not
   * advertise in its catalog (a versioned id like `claude-opus-4-8` is not in
   * supportedModels()), so the session picker must not be stricter than the
   * tool it drives: the catalog is a convenience, free-text is the escape. The
   * server validates the shape (dispatch-broker/global-settings MODEL_RE) and
   * the CLI validates the value at launch. A live session in view switches live
   * (setModelLive); anything else arms an override for the next session — the
   * exact same branch the catalog rows above take.
   */
  const applyModel = (v) => {
    if (dockLive()) { setModelLive(v); return; } // BUG-106 — only a live session IN VIEW takes a live change
    if (v === null) delete state.overrides.model; else state.overrides.model = v;
    persistOverrides();
    const live = dockEffective()?.effective;
    say(live
      ? `model: ${v ?? 'project default'} — applies to the NEXT session; the one running keeps ${live.model ?? 'its current value'}`
      : `model: ${v ?? 'project default'} for this session`);
    paintModelBtn();
    paintModelPop();
    paintCrown();
    drawer.repaintLive?.();
  };
  // The currently-set custom value as a real, lit row so it never silently
  // vanishes into a mislabelled "Project default".
  if (curIsCustom) {
    const b = el('button', { class: 'opt', role: 'menuitem', 'aria-pressed': 'true' });
    b.append(el('span', { class: 'g', text: '●' }));
    const mid = el('span');
    mid.append(el('span', { class: 'n', text: cur }));
    mid.append(el('span', { class: 'd', text: 'custom — not in the CLI’s list' }));
    b.append(mid);
    b.addEventListener('click', () => applyModel(cur)); // idempotent re-apply
    node.modelOpts.append(b);
  }
  const free = el('div', { class: 'modelfree' });
  free.append(el('span', { class: 'lbl', text: 'Other model id' }));
  const freeRow = el('div', { class: 'modelfree-row' });
  const freeIn = el('input', {
    type: 'text',
    placeholder: 'e.g. claude-opus-4-8',
    'aria-label': 'Set a model id for this session',
    value: curIsCustom ? cur : '',
  });
  const freeSet = el('button', { type: 'button', class: 'modelfree-set', text: 'Set' });
  const doSet = () => {
    const v = freeIn.value.trim();
    if (!v) return;
    // Mirror the server's MODEL_RE so a bad shape is caught before the round trip.
    if (!/^[A-Za-z0-9][A-Za-z0-9._:[\]-]{0,79}$/.test(v)) {
      say('model id has forbidden characters — letters, digits and . _ : - [ ] only', true);
      return;
    }
    applyModel(v);
  };
  freeSet.addEventListener('click', (e) => { e.stopPropagation(); doSet(); });
  freeIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doSet(); } });
  freeIn.addEventListener('click', (e) => e.stopPropagation());
  freeRow.append(freeIn, freeSet);
  free.append(freeRow);
  node.modelOpts.append(free);

  fill(node.effortOpts, EFFORT_OPTS, curE, 'effort');
}

node.modelBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  if (node.modelPop.classList.contains('open')) return closePops();
  closePops();
  paintModelPop();
  place(node.modelPop, node.modelBtn, 292);
  node.modelPop.classList.add('open');
  node.modelBtn.setAttribute('aria-expanded', 'true');
});
$('#modelPopSettings').addEventListener('click', () => { closePops(); void drawer.open('settings'); });

// FEAT-042: the crown chip opens the SAME picker (no new surface), anchored at
// the chip itself. Clicking also acknowledges a flagged silent change.
node.modelChip.addEventListener('click', (e) => {
  e.stopPropagation();
  clearModelFlag();
  paintModelChip();
  if (node.modelPop.classList.contains('open')) return closePops();
  closePops();
  paintModelPop();
  place(node.modelPop, node.modelChip, 292);
  node.modelPop.classList.add('open');
  node.modelBtn.setAttribute('aria-expanded', 'true');
});

async function reloadProject(id) {
  const fresh = await api.getProject(id);
  const i = state.projects.findIndex((x) => x.id === id);
  if (i >= 0) state.projects[i] = fresh;
  drawer.repaint();
  paintCrown();
}

/* ------------------------------------------------------------- popovers */

function place(popEl, anchor, width) {
  const r = anchor.getBoundingClientRect();
  popEl.style.left = `${Math.max(8, Math.min(r.left, window.innerWidth - width - 12))}px`;
  const top = r.bottom + 6;
  popEl.style.top = `${Math.min(top, window.innerHeight - 80)}px`;
  if (r.top > window.innerHeight / 2) {
    popEl.style.top = '';
    popEl.style.bottom = `${window.innerHeight - r.top + 6}px`;
  } else popEl.style.bottom = '';
}

/* ---- per-project overflow (FEAT-038: onboard to Orchard) ---- */
/*
 * Built in JS (not index.html) so it stays entirely within app.js. Reuses the
 * shared `.pop.rowmenu`/`.mi` chrome so it looks native and is positioned by the
 * same `placeAt` the session row menu uses.
 */
const projMenu = el('div', { class: 'pop rowmenu', id: 'projMenu', role: 'menu', 'aria-label': 'Project actions' });
document.body.append(projMenu);

function openProjectMenu(p, x, y) {
  closePops();
  clear(projMenu);
  const onboard = el('button', { class: 'mi', role: 'menuitem', 'aria-label': `Onboard ${p.name} to Orchard` },
    el('span', { class: 'l', text: 'Onboard to Orchard' }));
  onboard.addEventListener('click', (e) => { e.stopPropagation(); closePops(); void onboardProject(p); });
  projMenu.append(onboard);
  projMenu.classList.add('open');
  placeAt(projMenu, x, y);
  onboard.focus();
}

/*
 * One click = the same idempotent onboarding the CLI runs (POST .../onboard →
 * scripts/onboard.mjs's core). Feedback is honest: a first run reports how many
 * artifacts were created; a re-run reports "already onboarded" rather than
 * pretending it did work; a bad target (hostPath gone) surfaces the server's
 * 400 message instead of a silent success. After onboarding, the project has a
 * board, so refresh the Needs-You rail for it.
 */
async function onboardProject(p) {
  say(`onboarding ${p.name} to Orchard…`);
  try {
    const r = await api.api(`/api/projects/${encodeURIComponent(p.id)}/onboard`, { method: 'POST', body: '{}' });
    // If this is the open project, its (now-scaffolded) board should light up
    // the Needs-You rail. refreshRail repaints WITHOUT touching the status line,
    // so the success message below stays the last word (selectProject's own
    // isolation blurb would otherwise clobber it).
    if (state.current.projectId === p.id) await refreshRail(true);
    if (r.alreadyOnboarded) {
      say(`${p.name} is already onboarded to Orchard — nothing to do`);
    } else {
      say(`onboarded ${p.name} to Orchard · ${r.createdCount} artifact${r.createdCount === 1 ? '' : 's'} created`);
    }
  } catch (err) {
    say(`could not onboard ${p.name}: ${err.message}`, true);
  }
}

function closePops() {
  closeRowMenu();
  node.picker.classList.remove('open');
  node.modelPop.classList.remove('open');
  node.provPop.classList.remove('open');
  acctPop?.classList.remove('open'); // FEAT-145 — built on demand, so it may not exist yet
  acctSel?.setAttribute('aria-expanded', 'false');
  node.procPop.classList.remove('open');
  projMenu.classList.remove('open');
  $('#treeMenu').classList.remove('open');
  node.modelBtn.setAttribute('aria-expanded', 'false');
  node.provBtn.setAttribute('aria-expanded', 'false');
  node.provSel.setAttribute('aria-expanded', 'false');
  node.procBtn.setAttribute('aria-expanded', 'false');
}

node.insBtn.addEventListener('click', () => void drawer.open('instructions', 'settings'));
// FEAT-139 — the sidebar-foot Settings door opens the one panel at Machine scope
// ("global settings"): Appearance, Templates and the machine-wide project
// defaults all live there. The navbar cog opens the same panel at project scope.
$('#settingsFootBtn').addEventListener('click', () => void drawer.open('settings', { scope: 'machine' }));

/* ------------------------------------------------------------ add project */

/*
 * The picker has two modes. `scan` lists likely project dirs (the fast path);
 * `browse` is a real directory walker for everything the scan roots miss —
 * typing a path from memory stays available but stops being the only escape.
 */
const pick = { mode: 'scan', path: null, hi: -1 };

function openPicker() {
  closePops();
  pick.mode = 'scan';
  node.pickFilter.value = '';
  place(node.picker, $('#addProjBtn'), 360);
  node.picker.classList.add('open');
  // FEAT-069: the filter is the primary way in — land the caret there on open
  // so the user can type-to-narrow immediately (Esc still closes via the ladder).
  node.pickFilter.focus();
  void paintPicker();
}

/* ---- FEAT-069: live filter + keyboard nav over the picker rows ----
 * Every actionable candidate row carries a data-filter string (name + path,
 * lowercased). The nav/here/".." rows deliberately have none, so they always
 * stay visible. Filtering hides non-matches; highlight walks the visible set. */
function pickFilterableRows() {
  return [...node.pickList.querySelectorAll('.prow[data-filter]')];
}
function pickVisibleRows() {
  return pickFilterableRows().filter((r) => !r.hidden && !r.disabled);
}
function setPickHi(i) {
  const rows = pickVisibleRows();
  for (const r of pickFilterableRows()) r.classList.remove('hi');
  if (!rows.length) { pick.hi = -1; return; }
  pick.hi = ((i % rows.length) + rows.length) % rows.length;
  const r = rows[pick.hi];
  r.classList.add('hi');
  r.scrollIntoView({ block: 'nearest' });
}
function applyPickFilter() {
  const q = node.pickFilter.value.trim().toLowerCase();
  const rows = pickFilterableRows();
  let shown = 0;
  for (const r of rows) {
    const match = !q || r.dataset.filter.includes(q);
    r.hidden = !match;
    if (match) shown++;
  }
  const oldHint = node.pickList.querySelector('.pick-nomatch');
  if (oldHint) oldHint.remove();
  if (q && shown === 0 && rows.length) {
    node.pickList.append(el('div', { class: 'hint-row pick-nomatch', text: 'no match — clear the filter or type a path below.' }));
  }
  // A single match is pre-highlighted so Enter adds it without an arrow press.
  setPickHi(0);
}
node.pickFilter.addEventListener('input', applyPickFilter);
node.pickFilter.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown') { e.preventDefault(); return setPickHi(pick.hi + 1); }
  if (e.key === 'ArrowUp') { e.preventDefault(); return setPickHi(pick.hi - 1); }
  if (e.key === 'Enter') {
    const rows = pickVisibleRows();
    const target = (pick.hi >= 0 && rows[pick.hi]) || (rows.length === 1 ? rows[0] : null);
    if (target) { e.preventDefault(); target.click(); }
    return;
  }
  // Esc falls through to the document-level Esc ladder, which closes the picker.
});

$('#addProjBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  if (node.picker.classList.contains('open')) return closePops();
  openPicker();
});

$('#pickMode').addEventListener('click', (e) => {
  e.stopPropagation();
  pick.mode = pick.mode === 'scan' ? 'browse' : 'scan';
  node.pickFilter.value = ''; // FEAT-069: flipping surfaces starts from the full list
  node.pickFilter.focus();
  void paintPicker();
});

async function paintPicker() {
  $('#pickMode').textContent = pick.mode === 'scan' ? 'browse folders ›' : '‹ suggestions';
  if (pick.mode === 'scan') return paintPickerScan();
  return paintPickerBrowse(pick.path);
}

async function paintPickerScan() {
  clear(node.pickList).append(el('div', { class: 'hint-row', text: 'looking for directories…' }));
  try {
    const found = await api.scanProjects();
    if (pick.mode !== 'scan') return; // the user flipped modes mid-fetch
    clear(node.pickList);
    if (!found.length) node.pickList.append(el('div', { class: 'hint-row', text: 'nothing found under ~/projects or ~/random_projects — browse or type a path below.' }));
    for (const s of found) {
      const b = el('button', { class: 'prow', title: s.hostPath });
      b.dataset.filter = `${s.name} ${s.hostPath}`.toLowerCase();
      b.append(el('span', { class: 'mid' },
        el('span', { class: 'nm', text: s.name }),
        el('span', { class: 'ph', text: shortPath(s.hostPath) })));
      if (s.alreadyRegistered) {
        b.disabled = true;
        b.append(el('span', { class: 'tag', text: 'added' }));
      } else if (s.hasGit) {
        b.append(el('span', { class: 'tag', text: 'git' }));
      }
      b.addEventListener('click', () => void addProject(s.hostPath, s.name));
      node.pickList.append(b);
    }
    applyPickFilter(); // FEAT-069: honour a filter typed before the scan resolved
  } catch (err) {
    clear(node.pickList).append(el('div', { class: 'hint-row', text: `scan failed: ${err.message}` }));
  }
}

async function paintPickerBrowse(startPath) {
  clear(node.pickList).append(el('div', { class: 'hint-row', text: 'reading…' }));
  let r;
  try {
    r = await api.listDirs(startPath ?? undefined);
  } catch (err) {
    clear(node.pickList).append(el('div', { class: 'hint-row', text: err.message }));
    return;
  }
  if (pick.mode !== 'browse') return;
  pick.path = r.path;
  node.pickPath.value = r.path; // Enter still means "add what the field says"
  clear(node.pickList);

  const here = el('button', { class: 'prow here', title: r.path });
  here.append(el('span', { class: 'mid' },
    el('span', { class: 'nm', text: r.alreadyRegistered ? 'This directory is already a project' : '+ Add this directory' }),
    el('span', { class: 'ph', text: shortPath(r.path) })));
  if (r.alreadyRegistered) here.disabled = true;
  else here.addEventListener('click', () => void addProject(r.path));
  node.pickList.append(here);

  if (r.parent) {
    const up = el('button', { class: 'prow dir', title: r.parent });
    up.append(el('span', { class: 'mid' }, el('span', { class: 'nm', text: '‹ ..' })));
    up.addEventListener('click', (e) => { e.stopPropagation(); node.pickFilter.value = ''; void paintPickerBrowse(r.parent); });
    node.pickList.append(up);
  }
  if (!r.dirs.length) node.pickList.append(el('div', { class: 'hint-row', text: 'no subdirectories here' }));
  for (const d of r.dirs) {
    const b = el('button', { class: 'prow dir', title: `${d.path} — click to open` });
    b.dataset.filter = `${d.name} ${d.path}`.toLowerCase();
    b.append(el('span', { class: 'mid' }, el('span', { class: 'nm', text: `${d.name} ›` })));
    if (d.alreadyRegistered) b.append(el('span', { class: 'tag', text: 'added' }));
    else if (d.hasGit) b.append(el('span', { class: 'tag', text: 'git' }));
    b.addEventListener('click', (e) => { e.stopPropagation(); node.pickFilter.value = ''; void paintPickerBrowse(d.path); });
    node.pickList.append(b);
  }
  applyPickFilter(); // FEAT-069: keep the filter applied across mode/dir changes
}

/* ---- context menu on the project list's empty space ---- */

function openTreeMenu(x, y) {
  closePops();
  const tm = $('#treeMenu');
  tm.classList.add('open');
  placeAt(tm, x, y);
}
node.tree.addEventListener('contextmenu', (e) => {
  // Rows and headers own their own menus — only true whitespace answers here.
  if (e.target.closest('button')) return;
  e.preventDefault();
  openTreeMenu(e.clientX, e.clientY);
});
/* Deliberately NO left-click trigger: the menu is an extra way in, and a
   stray click on empty space must keep doing what it always did — nothing. */
$('#tmAdd').addEventListener('click', (e) => {
  e.stopPropagation();
  openPicker();
});
$('#tmCollapse').addEventListener('click', (e) => {
  e.stopPropagation();
  state.expanded.clear();
  saveExpanded();
  renderTree();
  closePops();
});

node.pickPath.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const v = node.pickPath.value.trim();
  if (v) void addProject(v);
});

async function addProject(hostPath, name) {
  closePops();
  try {
    // FEAT-089: the picker's "Apply the Orchard method" checkbox (default on)
    // is a reachable opt-out AT ADD TIME — unchecking adds the project without
    // writing anything into the target repo.
    const applyMethod = node.pickApplyMethod ? node.pickApplyMethod.checked : true;
    const { project: p, method } = await api.createProject(hostPath, name, { applyMethod });
    node.pickPath.value = '';
    await loadProjects(); // resets state.projects + resortProjects (an explicit sort point)
    // FEAT-074 (B) — SURFACE the just-added project. A brand-new project has no
    // recorded activity, so the recency sort would sink it to the bottom (and the
    // alpha sort scatters it) — the user then has to hunt for what they just added.
    // Float it to the TOP of the stable captured order as temporarily-most-recent;
    // it relaxes to its natural sort on the next explicit resort (loadProjects /
    // sort toggle), per the ticket — no lie stamped onto lastActivityAt.
    state.projOrder = [p.id, ...state.projOrder.filter((id) => id !== p.id)];
    // FEAT-074 (A) — open a fresh NEW session (the FEAT-073 pending-new active row),
    // NOT an auto-opened detected old session. The detected sessions stay listed in
    // the sidebar to open explicitly; landing on one was the BUG-087 stale-content
    // confusion this design avoids. startNew handles the whole boundary — draft
    // save, socket/watch drop, resetTranscript (header/content agree), pendingNew,
    // composer focus — and renders the pending row aria-current at the project top.
    startNew(p.id);
    // Bring the opened (pending) session into view so the user sees where they
    // landed even in a long sidebar. The pending row is derived + rendered
    // synchronously by startNew's renderTree, so it is present now.
    (node.tree?.querySelector('button.row.pending')
      ?? node.tree?.querySelector('[aria-current="true"]'))?.scrollIntoView?.({ block: 'nearest' });
    const n = listedCount(state.sessions.get(p.id));
    // FEAT-089: SURFACE the method side effect — never let the user discover it.
    let methodNote = '';
    if (method?.declined) {
      methodNote = ' · method not applied (repo untouched)';
    } else if (method?.error) {
      methodNote = ` · method apply failed: ${method.error}`;
    } else if (method?.applied) {
      const createdCount = (method.reports ?? []).filter(
        (r) => /^(created|added|merged)/.test(r.status),
      ).length;
      methodNote = createdCount
        ? ` · method applied (${createdCount} file${createdCount === 1 ? '' : 's'} scaffolded, Working Agreement attached)`
        : ' · method already present (nothing scaffolded)';
    }
    say(`added ${p.name} · new session · ${n} session${n === 1 ? '' : 's'} of history listed${methodNote}`);
  } catch (err) {
    say(`could not add ${hostPath}: ${err.message}`, true);
  }
}

/* -------------------------------------------------------------- chrome bits */

/*
 * The sidebar toggle. It always reopens what it closed, but before this the
 * button kept its "Hide sidebar" label and icon while collapsed — so a person
 * who hid the sidebar had no signal that the same button brings it back, and a
 * pane you cannot tell how to reopen reads as gone. paintFold() reflects the
 * live state into the title, aria-label, aria-expanded and a mirror class, so
 * the way back is always legible.
 */
function paintFold() {
  const collapsed = node.win.classList.contains('collapsed');
  node.fold.title = collapsed ? 'Show sidebar' : 'Hide sidebar';
  node.fold.setAttribute('aria-label', collapsed ? 'Show sidebar' : 'Hide sidebar');
  node.fold.setAttribute('aria-expanded', String(!collapsed));
  node.fold.classList.toggle('is-collapsed', collapsed);
}
node.fold.addEventListener('click', () => { node.win.classList.toggle('collapsed'); paintFold(); });
paintFold();
// FEAT-070 — restore the saved sort and wire the toggle.
state.projSort = loadProjSort();
paintProjSort();
node.projSort?.addEventListener('click', toggleProjSort);
$('#findBtn').addEventListener('click', () => {
  node.finder.classList.toggle('on');
  if (node.finder.classList.contains('on')) { node.findInput.focus(); void loadAllSessions(); }
  else { node.findInput.value = ''; renderTree(); }
});
/*
 * FEAT-059 — the global New button is NOT "new session in whatever project
 * is currently selected" (that used to silently pollute the selected
 * project's session list with a throwaway question). It always opens a
 * session in the Orchard-owned scratch project instead; the per-project "+"
 * next to each project name (renderProjectGroup, above) is the affordance
 * for "a session in THIS project" and is unchanged.
 */
$('#newBtn').addEventListener('click', () => { void startScratch(); });

async function startScratch() {
  let p;
  try {
    p = await api.ensureScratchProject();
  } catch (err) {
    return say(`could not start a scratch session: ${err.message}`, true);
  }
  const idx = state.projects.findIndex((x) => x.id === p.id);
  if (idx < 0) state.projects.push(p);
  else state.projects[idx] = p;
  state.expanded.add(p.id);
  startNew(p.id);
}
node.findInput.addEventListener('focus', () => void loadAllSessions());
node.findInput.addEventListener('input', () => { scheduleContentSearch(); renderTree(); });
node.findInput.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  e.preventDefault();
  // "#partial" + Enter completes the project scope; a completed query searches.
  if (completeProjectScope()) return;
  void runContentSearch();
});

document.addEventListener('click', (e) => {
  if (e.target.closest('#picker') || e.target.closest('#rowMenu')
    || e.target.closest('#projMenu')
    || e.target.closest('#addProjBtn') || e.target.closest('#treeMenu')) return;
  closePops();
});
/* A right-click anywhere else dismisses the row menu too — otherwise the
   browser's own menu would open on top of ours and both would be on screen. */
document.addEventListener('contextmenu', (e) => {
  if (e.target.closest('#rowMenu') || e.target.closest('#projMenu') || e.target.closest('.row') || e.target.closest('.proj')) return;
  closeRowMenu();
  projMenu.classList.remove('open');
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  // FEAT-090: the reply sheet is the topmost layer of all — Esc closes it first.
  if (tvSheetOpen()) {
    e.preventDefault();
    closeTvSheet();
    return;
  }
  // FEAT-146: settings is a real modal now, with `inert` on the app behind it
  // and armed ceremonies inside it. It sits here — above the ticket modal,
  // below the reply sheet — and it owns what Esc means inside itself:
  // drawer.close() disarms the innermost armed ceremony FIRST and keeps the
  // modal open, refuses entirely during a live sign-in or with an uncommitted
  // free-text edit, and only closes when nothing is at stake. The second Esc
  // is what closes it.
  if (drawer.isOpen()) {
    e.preventDefault();
    drawer.close();
    return;
  }
  // FEAT-053: the rail's ticket modal is the topmost layer — Esc closes it
  // FIRST and stops; the drawer/popovers/subagent walk stays untouched below.
  if (ticketModalOpen()) {
    e.preventDefault();
    closeTicketModal();
    return;
  }
  // FEAT-099: Git is a sibling route too; Esc follows its sessions link so the
  // URL and browser history stay in step with the visible surface.
  if (gitView?.isOpen()) {
    e.preventDefault();
    gitView.home.click();
    return;
  }
  // FEAT-075: Esc leaves the guide reader, returning to the session view (via
  // the home link's href so the URL stops saying #/guide).
  if (gv.open) {
    e.preventDefault();
    gv.home.click();
    return;
  }
  // FEAT-058: inside the ticket dashboard, Esc walks OUT of a ticket to the
  // list first — it must not fall through to the session Esc ladder (which
  // would leave a detail view open while acting on the hidden session pane).
  if (tv.open) {
    e.preventDefault();
    if (tv.ticketId) navTickets(tv.projectId, null);
    return;
  }
  const hadPop = document.querySelector('.pop.open');
  closePops();
  if (hadPop) return;
  backToMain(); // last: Esc walks out of a subagent thread
});

// BUG-158 — Ctrl/⌘ , is the conventional "settings" shortcut and is otherwise
// unbound here; it toggles the project-settings drawer so the panel has a
// keyboard path alongside the seal-strip Settings pill. Only acts when a
// project is selected (nothing to configure otherwise). Works while typing —
// the modifier chord never lands as a literal comma in a field.
document.addEventListener('keydown', (e) => {
  if (e.key !== ',' || !(e.metaKey || e.ctrlKey) || e.shiftKey || e.altKey) return;
  if (!currentProject()) return;
  e.preventDefault();
  if (drawer.isOpen()) drawer.close();
  else void drawer.open('settings');
});
$('#backToMain').addEventListener('click', backToMain);
$('#reconnectBtn').addEventListener('click', () => void reconnectDropped());

node.scroll.addEventListener('scroll', onScroll, { passive: true });
node.jump.addEventListener('click', () => {
  const th = viewedThread();
  if (th.key === 'main' && th.gap) return void reopenAtLatest();
  scrollToBottom();
});

/* FEAT-118 — the two within-session-mark affordances, built in JS (not the
   contended index.html) and mounted beside the "Latest" pill in the dock:
     • #leftoff — the one-action return to the auto read boundary. Sits opposite
       the Latest pill; appears only while the "you were here" line is above.
     • #bookmark — the manual bookmark toggle (set → jump → clear from one
       control), reusing the pin ribbon glyph the user's "a bookmark like book"
       maps to. */
(() => {
  const dock = node.jump.parentNode;
  if (!dock) return;
  const leftoff = el('button', { class: 'leftoff', id: 'leftoff', type: 'button', hidden: '', title: 'Jump to where you left off' },
    el('span', { class: 'a', text: '↑' }),
    el('span', { class: 'lbl', text: 'You left off here' }),
    el('span', { class: 'g', text: '' }));
  leftoff.addEventListener('click', jumpToReadLine);
  dock.append(leftoff);
  node.leftoff = leftoff;

  const bookmark = el('button', { class: 'bkmk', id: 'bookmark', type: 'button', hidden: '', 'aria-pressed': 'false', 'aria-label': 'Set bookmark', title: 'Bookmark this spot — drop a marker here you can jump back to (sets → jumps → clears)' },
    svg(MENU_ICON.pin, 12));
  bookmark.addEventListener('click', toggleBookmark);
  dock.append(bookmark);
  node.bookmark = bookmark;
})();
node.historyLatestBtn.addEventListener('click', () => reopenAtLatest());
// The viewport height is part of "am I at the bottom" — a resize that shortens
// the scroller must not silently strand a stuck thread above the end.
window.addEventListener('resize', () => {
  const th = viewedThread();
  if (th.stick !== false) scrollToBottom(th);
  else paintJump();
});
// FEAT-118 — returning to the tab must NOT advance the read boundary (that is
// Discord's over-eager clear): it only REPAINTS, so the "you left off here" line
// the frozen boundary produced becomes visible where the user last read.
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) paintMarks(viewedThread());
});
// A reload within the save debounce must not drop a just-advanced read mark.
window.addEventListener('pagehide', () => {
  try {
    localStorage.setItem(READMARK_KEY, JSON.stringify(Object.fromEntries(state.readMarks)));
    localStorage.setItem(BOOKMARK_KEY, JSON.stringify(Object.fromEntries(state.bookmarks)));
  } catch { /* full/private */ }
});

/* ═══════════════════════════════════ in-app guide reader (FEAT-075) ═══════
 *
 * `#/guide` (index → README) and `#/guide/<page>` (a specific page) — a ROUTE,
 * a sibling of the ticket dashboard, so the session view underneath stays live.
 *
 * Content is the app's OWN docs/guide/*.md, served read-only by /api/guide. The
 * markdown is rendered by the SAME prose() the transcript and ticket views use;
 * the only special case is a ```mermaid fenced block, which prose() would flatten
 * to a code box (it drops the language) — so mermaid blocks are split OUT here,
 * rendered offline by the vendored mermaid bundle, and everything between them
 * goes through prose() untouched. No network: the bundle is a local static file.
 */
const gv = {
  root: $('#guideView'),
  home: $('#gvHome'),
  sub: $('#gvSub'),
  nav: $('#gvNav'),
  doc: $('#gvDoc'),
  open: false,
  page: null,
  pages: null,     // cached page list (null = not yet loaded)
  seq: 0,          // guards a late fetch from painting over a newer one
  // BUG-094: the hash to send "← sessions" back to — the session that was open
  // when the reader was entered, captured before its pane is hidden. A bare
  // `#/project/<id>` (the old behaviour) is read by the session router as "no
  // session → start a new one", which dropped the user onto a blank session.
  returnHash: '#/',
};
const guideSlide = createSlidePanel(gv.root, { settledClass: 'guide-open' });

/** Keep synchronous panel content work out of a newly displayed slide transition. */
async function waitForEnteringSlide(entering, panel) {
  if (!entering || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  await new Promise((resolve) => {
    let timer;
    const done = (event) => {
      if (event && (event.target !== panel || event.propertyName !== 'transform')) return;
      panel.removeEventListener('transitionend', done);
      clearTimeout(timer);
      resolve();
    };
    panel.addEventListener('transitionend', done);
    timer = setTimeout(done, 300);
  });
}

let mermaidPromise = null;
/** Lazy-load the vendored mermaid bundle (offline; only when a diagram appears). */
function loadMermaid() {
  if (window.mermaid) return Promise.resolve(window.mermaid);
  if (mermaidPromise) return mermaidPromise;
  mermaidPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = '/vendor/mermaid.min.js';
    s.onload = () => (window.mermaid ? resolve(window.mermaid) : reject(new Error('mermaid missing after load')));
    s.onerror = () => reject(new Error('mermaid vendor failed to load'));
    document.head.append(s);
  });
  return mermaidPromise;
}

const GUIDE_MERMAID = /```mermaid[^\n]*\n([\s\S]*?)```/g;

/**
 * Render a guide page's markdown: prose() for everything, mermaid fences pulled
 * out into their own holders. Returns the article node plus the pending mermaid
 * blocks to render once the (lazy) engine is up. The holder pre-fills with a
 * labelled source listing, which stays visible as the fallback if the engine is
 * unavailable — the diagram content is never dropped.
 */
async function renderGuideDoc(markdown, seq = gv.seq) {
  const wrap = el('article', { class: 'gv-doc-body prose' });
  const pending = [];
  const md = String(markdown ?? '');
  let last = 0;
  let idx = 0;
  GUIDE_MERMAID.lastIndex = 0;
  let m;
  while ((m = GUIDE_MERMAID.exec(md))) {
    const before = md.slice(last, m.index);
    if (before.trim()) await appendGuideMarkdown(wrap, before, seq);
    if (seq !== gv.seq || !gv.open) return null;
    const holder = el('div', { class: 'gv-mermaid' },
      el('div', { class: 'gv-cap', text: 'diagram · mermaid' }),
      el('pre', { class: 'gv-mermaid-src', text: m[1].replace(/\n+$/, '') }));
    wrap.append(holder);
    pending.push({ holder, src: m[1], id: `gvm-${gv.seq}-${idx += 1}` });
    last = m.index + m[0].length;
  }
  const rest = md.slice(last);
  if (rest.trim()) await appendGuideMarkdown(wrap, rest, seq);
  if (seq !== gv.seq || !gv.open) return null;
  // prose() is tuned for headings INSIDE a message, so it renders `#` as h3 to
  // sit under the page chrome. A guide page IS the page, so promote two levels
  // (h3→h1 …) — the parser is still prose(), only the document altitude shifts.
  for (const h of [...wrap.querySelectorAll('h3, h4, h5, h6')]) {
    const lvl = Math.max(1, Number(h.tagName[1]) - 2);
    const n = el(`h${lvl}`, { class: h.className || null });
    while (h.firstChild) n.append(h.firstChild);
    h.replaceWith(n);
  }
  return { wrap, pending };
}

/**
 * Keep guide markdown out of any single long task. Top-level sections retain
 * their markdown context (tables/lists stay whole), while yielding a painted
 * frame between prose() calls. Closing or navigating invalidates the work.
 */
async function appendGuideMarkdown(wrap, markdown, seq) {
  const chunks = String(markdown).split(/(?=^#{1,2}\s)/m).filter((part) => part.trim());
  for (const chunk of chunks) {
    if (seq !== gv.seq || !gv.open) return;
    wrap.append(...prose(chunk).childNodes);
    await new Promise((resolve) => requestAnimationFrame(resolve));
  }
}

/** Render any queued mermaid blocks offline; leave the labelled fallback on failure. */
async function renderGuideMermaids(pending, seq) {
  if (!pending.length) return;
  let mermaid;
  try { mermaid = await loadMermaid(); } catch { return; } // fallback listings stand
  if (seq !== gv.seq) return; // navigated away while the bundle loaded
  const dark = document.documentElement.dataset.theme === 'dark'
    || (!document.documentElement.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
  try {
    mermaid.initialize({ startOnLoad: false, theme: dark ? 'dark' : 'neutral', securityLevel: 'strict', fontFamily: 'inherit' });
  } catch { /* re-init across pages is fine; ignore a duplicate-config throw */ }
  for (const p of pending) {
    if (seq !== gv.seq) return;
    try {
      const { svg } = await mermaid.render(p.id, p.src);
      if (seq !== gv.seq) return;
      clear(p.holder);
      // Trusted content: the app's own committed guide docs, rendered under
      // mermaid securityLevel 'strict'. Same trust tier as ticket/transcript md.
      p.holder.innerHTML = svg;
      p.holder.classList.add('rendered');
    } catch {
      p.holder.classList.add('gv-failed'); // the labelled source stays visible
    }
  }
}

/** Mermaid is deliberately below the slide's critical path, including cached bundles. */
async function renderGuideMermaidsAfterSlide(pending, seq) {
  if (!pending.length) return;
  if (!document.documentElement.classList.contains('guide-open')) {
    await new Promise((resolve) => {
      let timer;
      const done = (event) => {
        if (event && (event.target !== gv.root || event.propertyName !== 'transform')) return;
        gv.root.removeEventListener('transitionend', done);
        clearTimeout(timer);
        resolve();
      };
      gv.root.addEventListener('transitionend', done);
      timer = setTimeout(done, 300);
    });
  }
  if (seq !== gv.seq || !gv.open) return;
  // Loading/parsing the large vendored bundle and Mermaid's own layout are
  // synchronous. Give the settled reader a quiet interval first, so a prompt
  // close wins and cancels this enhancement before either task begins.
  await new Promise((resolve) => setTimeout(resolve, 500));
  if (seq !== gv.seq || !gv.open) return;
  await renderGuideMermaids(pending, seq);
}

/** Paint the left-hand page list, marking the current page. */
function renderGuideNav() {
  clear(gv.nav);
  const pages = gv.pages ?? [];
  if (!pages.length) {
    gv.nav.append(el('div', { class: 'gv-empty', text: 'No guide pages are available.' }));
    return;
  }
  for (const p of pages) {
    const a = el('a', {
      href: formatGuideHash({ page: p.page }),
      class: p.page === gv.page ? 'on' : null,
      text: p.title || p.page,
    });
    a.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.button !== 0) return;
      e.preventDefault();
      navGuide(p.page);
    });
    gv.nav.append(a);
  }
}

/** Show the reader for a route, loading the page list and the named page. */
async function showGuide(route) {
  const seq = (gv.seq += 1);
  const entering = !gv.open;
  const pagesRequest = !gv.pages ? api.guidePages().catch(() => []) : null;
  if (entering) {
    // Capture where "← sessions" returns to BEFORE the session pane is hidden —
    // the FULL open-session route (id, dir, scroll), not a bare project hash
    // (BUG-094). currentRoute() is null only when no project is open at all.
    const back = currentRoute();
    gv.returnHash = back ? formatHash(back) : '#/';
    gv.open = true;
    guideSlide.open();
  }
  const slideReady = waitForEnteringSlide(entering, gv.root);
  gv.home.setAttribute('href', gv.returnHash);
  // Page list: fetched once, then cached for the session.
  if (pagesRequest) {
    gv.pages = await pagesRequest;
    if (seq !== gv.seq) return;
  }
  // No explicit page → the index (README if present, else the first page).
  let page = route.page;
  if (!page) page = gv.pages.some((p) => p.page === 'README') ? 'README' : (gv.pages[0]?.page ?? null);
  const pageRequest = page ? api.guidePage(page).catch(() => null) : null;
  await slideReady;
  if (seq !== gv.seq || !gv.open) return;
  gv.page = page;
  renderGuideNav();
  document.title = page ? `${page} — Guide` : 'Guide — Orchard';
  gv.sub.textContent = gv.pages.find((p) => p.page === page)?.title ?? '';

  if (!page) {
    clear(gv.doc).append(el('div', { class: 'gv-msg', text: 'This build has no guide pages (docs/guide is absent).' }));
    return;
  }
  clear(gv.doc).append(el('div', { class: 'gv-loading', text: 'Loading…' }));
  const data = await pageRequest;
  if (seq !== gv.seq) return;
  if (!data) {
    clear(gv.doc).append(el('div', { class: 'gv-msg' },
      el('b', { text: 'That guide page was not found.' }),
      document.createTextNode(` (${page})`)));
    return;
  }
  const rendered = await renderGuideDoc(data.markdown, seq);
  if (!rendered || seq !== gv.seq || !gv.open) return;
  const { wrap, pending } = rendered;
  clear(gv.doc).append(wrap);
  gv.doc.scrollTop = 0;
  gv.sub.textContent = data.title || gv.sub.textContent;
  void renderGuideMermaidsAfterSlide(pending, seq);
}

function hideGuide() {
  if (!gv.open) return;
  gv.open = false;
  guideSlide.close();
  paintTitle();
}

/** Navigate WITHIN the reader (pushes history, so Back works as expected). */
function navGuide(page, { replace = false } = {}) {
  const href = formatGuideHash({ page });
  if (replace) window.history.replaceState(null, '', href);
  else window.history.pushState(null, '', href);
  void showGuide({ page });
}

gv.home.addEventListener('click', () => { hideGuide(); });

/* ═══════════════════════════════════ ticket dashboard (FEAT-058) ══════════
 *
 * `#/tickets` (list) and `#/tickets/<ID>` (detail) — a ROUTE, deliberately not a
 * modal, so it can live in a SECOND browser tab while the session tab stays live
 * and the user can ask the orchestrator about a ticket while reading it.
 *
 * The rail (FEAT-018) stays the "what needs you NOW" surface; this is the full
 * archive: every ticket, its real file markdown, full-text search over the
 * BODIES (the Activity logs are where the content is), and the writes that let a
 * human keep the board honest — append a note, reopen a Done ticket, flag 👤,
 * file a new ticket.
 *
 * Everything here is files on disk, so a change made in this tab is visible to
 * the NEXT session with no extra plumbing: the board snapshot injected into a
 * launched session's prompt (src/server/board.ts `boardStateSection`) and the
 * rail both read the same INDEX.md + ticket files this writes.
 */
const tv = {
  root: $('#ticketsView'),
  home: $('#tvHome'),
  project: $('#tvProject'),
  search: $('#tvSearch'),
  filters: $('#tvFilters'),
  status: $('#tvStatus'),
  owner: $('#tvOwner'),
  sev: $('#tvSev'),
  count: $('#tvCount'),
  newBtn: $('#tvNew'),
  allBtn: $('#tvAll'),      // FEAT-082 — the persistent "All tickets" control
  digest: $('#tvDigest'),   // FEAT-082 — the landing digest container
  list: $('#tvList'),
  detail: $('#tvDetail'),
  /* state */
  open: false,
  projectId: null,
  ticketId: null,
  // FEAT-082 — which of the three shapes is showing: 'digest' (the landing),
  // 'all' (the full table), 'detail' (one ticket). Drives showTickets + which
  // pane is visible; kept in sync with the URL by parseTicketsHash.
  view: 'digest',
  board: null,       // the last board payload for the digest (lanes + counts)
  q: '',
  rows: [],
  // FEAT-082 — which project `rows` were loaded for. The digest updates
  // `projectId` but leaves the full-list `rows` untouched, so a digest→all
  // hop could otherwise render another project's stale rows. The 'all'/'detail'
  // paths reload whenever this no longer matches `projectId`.
  rowsProjectId: null,
  hasBoard: true,
  current: null,     // the loaded detail
  searchTimer: null,
  seq: 0,            // guards a late fetch from overwriting a newer one
  /* FEAT-063 — tracker bones: sorting lives on the column headers, and the
     list is keyboard-first (↑/↓ move a cursor row, Enter opens it). */
  sortBy: 'activity',
  sortAsc: false,
  cursor: -1,
  // BUG-094: where "← sessions" returns to — the open session captured when the
  // dashboard was entered, not a bare `#/project/<id>` the router reads as "new
  // session". The board can view a DIFFERENT project than the open session; the
  // back link is about the user's session, so it follows state.current, not tv.
  returnHash: '#/',
};
const ticketsSlide = createSlidePanel(tv.root, { settledClass: 'tickets-open' });

const SEV_RANK = { high: 0, med: 1, medium: 1, low: 2 };

function ticketsHref(projectId, ticketId = null, view = null) {
  return formatTicketsHash({ projectId, ticketId, view });
}
/** The full-list ('all') hash for a project. */
function allTicketsHref(projectId) {
  return formatTicketsHash({ projectId, view: 'all' });
}

/**
 * Show the dashboard for a route, loading whatever it names. FEAT-082 — three
 * shapes, resolved once here into `tv.view`:
 *   digest  — bare `#/tickets`: the landing (what awaits you). Fetches board +
 *             tickets in parallel and renders the digest.
 *   all     — `#/tickets/all`: the full sortable/searchable/keyboard table (the
 *             former landing state, moved wholesale, behaviour unchanged).
 *   detail  — `#/tickets/<ID>`: one ticket, unchanged.
 */
async function showTickets(route) {
  const pid = route.projectId || tv.projectId || state.current.projectId
    || (state.projects[0]?.id ?? null);
  const changedProject = pid !== tv.projectId;
  tv.projectId = pid;
  const view = route.view === 'all' ? 'all' : (route.ticketId ? 'detail' : 'digest');
  tv.view = view;
  tv.ticketId = view === 'detail' ? (route.ticketId ?? null) : null;
  if (!tv.open) {
    // BUG-094: capture the open-session route BEFORE hiding its pane — "←
    // sessions" returns HERE, not to a bare project hash that starts a new one.
    const back = currentRoute();
    tv.returnHash = back ? formatHash(back) : '#/';
    tv.open = true;
    ticketsSlide.open();
    void loadBoardProjects();
  } else if (changedProject) {
    // Refresh the project switcher so its selected option (and counts) tracks the
    // project actually on screen — otherwise a URL hop to another project's board
    // leaves the dropdown labelling the wrong one.
    void loadBoardProjects();
  }
  document.title = tv.ticketId
    ? `${tv.ticketId} — Board`
    : (view === 'all' ? 'All tickets — Board' : 'Board — Orchard');
  tv.home.setAttribute('href', tv.returnHash);
  // The "All tickets" control points at /all and hides itself while that IS the
  // view (nothing to escape to).
  tv.allBtn.setAttribute('href', allTicketsHref(pid));
  tv.allBtn.classList.toggle('on', view === 'all');

  if (view === 'digest') {
    await showDigest(changedProject);
    return;
  }
  // 'all' and 'detail' both need the ticket rows (the table, and the back-to-list
  // continuity behind a detail). Reload if the project changed, we have none, or
  // the cached rows belong to a different project (a digest hop can leave them so).
  if (changedProject || !tv.rows.length || tv.rowsProjectId !== pid) await loadTicketRows();
  else renderTicketRows();
  if (view === 'detail') await loadTicketDetail(tv.ticketId);
  else showTicketList();
}

function hideTickets() {
  if (!tv.open) return;
  tv.open = false;
  ticketsSlide.close();
  paintTitle();
}

/* ═══════════════════════════════════ the digest (FEAT-082) ════════════════
 *
 * The landing state for `#/tickets`. The premise (user's words): opening the
 * board should show WHAT AWAITS YOUR INPUT, not the corpus. So this is not a
 * table — it is, top to bottom: a thin counts strip, the Awaiting-you block
 * (Decide / Look at), Answered-awaiting, In flight, Recently-updated (7d, ≤10),
 * and Observations (collapsed). The full table still exists, one click away at
 * `#/tickets/all`. Built from BOTH /board (lanes, counts, observations) and
 * /tickets (recently-updated), fetched in parallel; on partial failure it
 * renders what loaded and says plainly what did not.
 */

/** The ticket TYPE from its id prefix (FEAT / BUG / ARCH / DEPLOY / …). */
function ticketType(id) {
  const m = /^([A-Z]+)-\d+$/.exec(String(id || ''));
  return m ? m[1] : '';
}

/**
 * A small type badge. ARCH gets a deliberately DISTINCT treatment (an outlined
 * ◆ chip) rather than a fourth colour in the same family — there are only four
 * ARCH tickets and half of them are open decisions, so they should read apart.
 */
function typeBadge(id) {
  const t = ticketType(id);
  const cls = `dg-tb tt-${t.toLowerCase() || 'na'}`;
  if (t === 'ARCH') {
    return el('span', { class: `${cls} arch`, title: 'Architecture' },
      el('span', { class: 'dg-tb-glyph', text: '◆' }),
      el('span', { text: 'ARCH' }));
  }
  return el('span', { class: cls, title: t || 'ticket', text: t || '—' });
}

/** Whole days between a `YYYY-MM-DD` and today (UTC), or null if unparseable. */
function daysAgo(dateStr) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dateStr || ''));
  if (!m) return null;
  const then = Date.UTC(+m[1], +m[2] - 1, +m[3]);
  const now = new Date();
  const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  return Math.round((today - then) / 86_400_000);
}

/** A compact relative-day label for a `YYYY-MM-DD` (falls back to the raw string). */
function relDay(dateStr) {
  const d = daysAgo(dateStr);
  if (d === null) return String(dateStr || '');
  if (d <= 0) return 'today';
  if (d === 1) return 'yesterday';
  if (d < 7) return `${d}d ago`;
  if (d < 14) return '1w ago';
  if (d < 60) return `${Math.floor(d / 7)}w ago`;
  return String(dateStr);
}

/** One-line clamp helper for a title/question shown inline. */
function clampText(s, n) {
  const t = String(s || '').replace(/\s+/g, ' ').trim();
  return t.length > n ? `${t.slice(0, n - 1).trimEnd()}…` : t;
}

/**
 * Enter the digest: hide the other panes, fetch board + tickets in parallel, and
 * render. `api.board` degrades a no-board project to {hasBoard:false} rather than
 * throwing, so a genuine transport failure is the only rejection — allSettled
 * lets each lane fail independently (partial-failure honesty).
 */
async function showDigest() {
  tv.detail.hidden = true;
  tv.list.hidden = true;
  tv.filters.hidden = true;
  tv.digest.hidden = false;
  tv.current = null;
  const pid = tv.projectId;
  const seq = ++tv.seq;
  clear(tv.digest).append(el('div', { class: 'dg-loading', text: 'reading the board…' }));
  if (!pid) { renderDigest({ status: 'rejected' }, { status: 'rejected' }); return; }
  const [boardRes, listRes] = await Promise.allSettled([api.board(pid), api.ticketList(pid, '')]);
  if (seq !== tv.seq || pid !== tv.projectId || tv.view !== 'digest') return; // superseded
  // The digest already fetched this project's UNFILTERED ticket list — keep it as
  // the full-list cache so a digest→all hop needs no second round-trip and can
  // never render another project's stale rows (tv.rowsProjectId is the guard).
  if (listRes.status === 'fulfilled' && Array.isArray(listRes.value?.tickets)) {
    tv.rows = listRes.value.tickets;
    tv.hasBoard = listRes.value.hasBoard !== false;
    tv.rowsProjectId = pid;
    tv.q = '';
  }
  tv.board = boardRes.status === 'fulfilled' ? boardRes.value : null;
  renderDigest(boardRes, listRes);
}

/** Set the full-list filters + query, then navigate to `/all` pre-filtered. The
 *  full-text body search is server-side, so clear the cached rows to force a
 *  re-fetch under the new query (filters alone are client-side and need none,
 *  but clearing unconditionally keeps the landing state honest). */
function openAllFiltered({ status = 'all', owner = 'all', sev = 'all', q = '' } = {}) {
  tv.q = q;
  tv.search.value = q;
  tv.status.value = status;
  tv.owner.value = owner;
  tv.sev.value = sev;
  tv.rows = [];
  navTickets(tv.projectId, null, { view: 'all' });
}

/**
 * FEAT-082 (visual review) — the digest search placeholder, SHORTENED at narrow
 * widths instead of being clipped. The full phrase ends "…↵ opens the full list";
 * at 480px the field cut it mid-phrase ("↵ opens the full"), which loses the word
 * that made the sentence mean anything. A placeholder cannot be picked in CSS, so
 * the width test lives here — one module-level media query, one listener, so a
 * re-render never stacks another.
 */
const dgNarrow = window.matchMedia('(max-width: 560px)');
const digestSearchPlaceholder = () =>
  (dgNarrow.matches ? 'Search every ticket…' : 'Search every ticket body… ↵ opens the full list');
dgNarrow.addEventListener('change', () => {
  const s = document.querySelector('.dg-search');
  if (s) s.placeholder = digestSearchPlaceholder();
});

/** A counts chip: scrolls to a digest section when present, else navigates. */
function digestChip({ label, n, onClick }) {
  const chip = el('button', {
    type: 'button', class: `dg-chip st-${label.replace(/\s+/g, '')}${n ? '' : ' zero'}`,
    title: n ? `${n} ${label}` : `no ${label}`,
  }, el('span', { class: 'dg-cn', text: String(n) }), el('span', { class: 'dg-cl', text: label }));
  if (n && onClick) chip.addEventListener('click', onClick);
  else chip.disabled = true;
  return chip;
}

/** One Awaiting-you row (kind 'decide' | 'look'). */
function digestAwaitRow(it, kind, actMap) {
  const when = relDay(actMap.get(it.id)?.lastActivity);
  const a = el('a', {
    class: `dg-item dg-${kind}`, 'data-id': it.id, href: ticketsHref(tv.projectId, it.id),
  });
  a.addEventListener('click', (e) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    navTickets(tv.projectId, it.id);
  });
  const head = el('div', { class: 'dg-item-head' },
    typeBadge(it.id),
    el('span', { class: 'dg-id', text: it.id }),
    el('span', { class: 'dg-title', text: it.title, title: it.title }),
    it.sev ? el('span', { class: `dg-sev sev-${it.sev.toLowerCase().slice(0, 3)}`, text: it.sev }) : null,
    when ? el('span', { class: 'dg-when', text: when }) : null);
  a.append(head);
  if (kind === 'decide') {
    const nOpts = it.options?.length ?? 0;
    const meta = el('div', { class: 'dg-decide-meta' },
      el('span', { class: 'dg-optc', text: nOpts ? `${nOpts} options` : 'decision' }));
    if (it.recommended) meta.append(el('span', { class: 'dg-rec', text: `recommends ${it.recommended}` }));
    const body = el('div', { class: 'dg-item-body' });
    // FEAT-082 (visual review): when the ticket's decision heading carried no
    // content of its own, the server falls back to the ticket TITLE as the
    // question (board.ts questionFromTitle) — and the title is already the head
    // of this row. Printing it again, or printing the scaffolding heading ("The
    // decision"), would put a contentless line where the thing to decide goes;
    // the option count + the title carry the row instead.
    if (it.question && !it.questionFromTitle) body.append(el('span', { class: 'dg-q', text: clampText(it.question, 120) }));
    body.append(meta);
    a.append(body);
  } else {
    // The INDEX status blurb, VERBATIM (clamped to two lines by CSS). This
    // sentence is the triage recommendation — what makes "look at" possible
    // without opening the ticket.
    const blurb = String(it.status || '').trim();
    a.append(el('div', { class: 'dg-item-body' },
      el('span', { class: 'dg-blurb', text: blurb || 'no status recorded on the board row' })));
  }
  return a;
}

/**
 * Build the whole digest from the (settled) board + tickets fetches. Renders
 * what loaded; a failed lane becomes an honest inline notice, not a blank.
 */
function renderDigest(boardRes, listRes) {
  const board = boardRes.status === 'fulfilled' ? boardRes.value : null;
  const boardOk = !!board;
  const rows = listRes.status === 'fulfilled' ? (listRes.value?.tickets ?? []) : null;
  const listOk = Array.isArray(rows);
  // Join lastActivity/mtime onto the board items (the board payload carries
  // neither — the tickets list does).
  const actMap = new Map((rows ?? []).map((r) => [r.id, r]));

  const needs = board?.needsYou ?? [];
  const answered = board?.answeredAwaiting ?? [];
  const inflight = board?.inflight ?? [];
  const observations = board?.observations ?? [];
  const counts = board?.summary?.counts ?? null;

  const wrap = el('div', { class: 'dg-wrap' });

  if (!boardOk && !listOk) {
    clear(tv.digest).append(el('div', { class: 'dg-wrap' },
      el('div', { class: 'dg-fail' },
        el('b', { text: 'The board could not be read.' }),
        document.createTextNode(' Neither the board nor the ticket list answered. '),
        el('a', { class: 'dg-inline-link', href: allTicketsHref(tv.projectId), text: 'Try the full list →' }))));
    return;
  }
  if (boardOk && !board.hasBoard) {
    clear(tv.digest).append(el('div', { class: 'dg-wrap' },
      el('div', { class: 'dg-empty-board' },
        el('b', { text: 'This project has no board.' }),
        document.createTextNode(' There is no docs/bugs/ directory here — onboard the project to start one.'))));
    return;
  }

  /* ── counts strip ── */
  if (counts) {
    const openTotal = (counts.needs ?? 0) + (counts.answered ?? 0) + (counts.inflight ?? 0) + (counts.queued ?? 0);
    const scrollTo = (sel) => () => {
      const t = tv.digest.querySelector(sel);
      if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    const strip = el('div', { class: 'dg-counts' },
      digestChip({ label: 'needs', n: counts.needs ?? 0, onClick: scrollTo('#dg-awaiting') }),
      digestChip({ label: 'answered', n: counts.answered ?? 0, onClick: scrollTo('#dg-answered') }),
      digestChip({ label: 'in flight', n: counts.inflight ?? 0, onClick: scrollTo('#dg-inflight') }),
      digestChip({ label: 'queued', n: counts.queued ?? 0, onClick: () => openAllFiltered({ status: 'open', owner: 'none' }) }),
      digestChip({ label: 'observations', n: counts.observations ?? 0, onClick: scrollTo('#dg-observations') }),
      digestChip({ label: 'open', n: openTotal, onClick: () => openAllFiltered({ status: 'open' }) }),
      digestChip({ label: 'done', n: counts.doneToday ?? 0, onClick: () => openAllFiltered({ status: 'done' }) }));
    wrap.append(strip);
  } else if (!boardOk) {
    wrap.append(el('div', { class: 'dg-note', text: 'The board lanes and counts could not be loaded — showing recent activity only.' }));
  }

  /* ── a digest search: Enter launches the full body-search list ── */
  const search = el('input', {
    class: 'dg-search', type: 'search', autocomplete: 'off', spellcheck: 'false',
    placeholder: digestSearchPlaceholder(), 'aria-label': 'Search tickets',
  });
  search.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    openAllFiltered({ q: search.value.trim() });
  });
  wrap.append(el('div', { class: 'dg-searchrow' }, search,
    el('a', { class: 'dg-inline-link', href: allTicketsHref(tv.projectId), text: 'All tickets →' })));

  /* ── Awaiting you — the largest block ── */
  const awaiting = el('section', { class: 'dg-sec dg-awaiting', id: 'dg-awaiting' });
  awaiting.append(el('h2', { class: 'dg-h', text: 'Awaiting you' }));
  if (!boardOk) {
    awaiting.append(el('div', { class: 'dg-fail-inline', text: 'The board lanes could not be loaded — the full list is still available above.' }));
  } else if (!needs.length) {
    // Inbox zero: collapse to a plain line, and let Recently-updated be the body.
    awaiting.append(el('div', { class: 'dg-zero' },
      el('span', { class: 'dg-zero-tick', text: '✓' }),
      el('span', { text: 'Nothing needs you.' })));
  } else {
    const decide = needs.filter((it) => it.question);
    const look = needs.filter((it) => !it.question);
    if (decide.length) {
      awaiting.append(el('div', { class: 'dg-subh dg-subh-decide' },
        el('span', { text: 'Decide' }), el('span', { class: 'dg-subn', text: String(decide.length) })));
      const g = el('div', { class: 'dg-group' });
      for (const it of decide) g.append(digestAwaitRow(it, 'decide', actMap));
      awaiting.append(g);
    }
    if (decide.length && look.length) awaiting.append(el('div', { class: 'dg-divider' }));
    if (look.length) {
      awaiting.append(el('div', { class: 'dg-subh dg-subh-look' },
        el('span', { text: 'Look at' }), el('span', { class: 'dg-subn', text: String(look.length) })));
      const g = el('div', { class: 'dg-group' });
      for (const it of look) g.append(digestAwaitRow(it, 'look', actMap));
      awaiting.append(g);
    }
  }
  wrap.append(awaiting);

  /* ── Answered — awaiting action (hidden when empty) ── */
  if (answered.length) {
    const sec = el('section', { class: 'dg-sec dg-answered', id: 'dg-answered' });
    sec.append(el('h2', { class: 'dg-h', text: 'Answered — awaiting action' }));
    const g = el('div', { class: 'dg-group' });
    for (const it of answered) {
      const a = el('a', { class: 'dg-item dg-answered-item', 'data-id': it.id, href: ticketsHref(tv.projectId, it.id) });
      a.addEventListener('click', (e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        navTickets(tv.projectId, it.id);
      });
      a.append(el('div', { class: 'dg-item-head' },
        typeBadge(it.id),
        el('span', { class: 'dg-id', text: it.id }),
        el('span', { class: 'dg-title', text: it.title, title: it.title })));
      a.append(el('div', { class: 'dg-item-body' },
        el('span', { class: 'dg-answer', text: `you chose “${clampText(it.answer, 80)}”${it.answeredOn ? ` on ${it.answeredOn}` : ''}` }),
        el('span', { class: 'dg-nodispatch', text: 'nothing dispatched yet' })));
      g.append(a);
    }
    sec.append(g);
    wrap.append(sec);
  }

  /* ── In flight (hidden when empty) — one read-only line each ── */
  if (inflight.length) {
    const sec = el('section', { class: 'dg-sec dg-inflight', id: 'dg-inflight' });
    sec.append(el('h2', { class: 'dg-h', text: 'In flight' }));
    const g = el('div', { class: 'dg-group' });
    for (const it of inflight) {
      const a = el('a', { class: 'dg-item dg-flight-item', 'data-id': it.id, href: ticketsHref(tv.projectId, it.id) });
      a.addEventListener('click', (e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        navTickets(tv.projectId, it.id);
      });
      a.append(el('div', { class: 'dg-item-head' },
        typeBadge(it.id),
        el('span', { class: 'dg-id', text: it.id }),
        el('span', { class: 'dg-title', text: it.title, title: it.title }),
        el('span', { class: 'dg-flight-glyph', text: '🤖', title: 'an agent is on it' }),
        relDay(actMap.get(it.id)?.lastActivity) ? el('span', { class: 'dg-when', text: relDay(actMap.get(it.id)?.lastActivity) }) : null));
      g.append(a);
    }
    sec.append(g);
    wrap.append(sec);
  }

  /* ── Recently updated — 7-day window, capped 10, grouped by day ── */
  const rec = el('section', { class: 'dg-sec dg-recent', id: 'dg-recent' });
  const recCount = el('span', { class: 'dg-count-note' });
  rec.append(el('div', { class: 'dg-h-row' },
    el('h2', { class: 'dg-h', text: 'Recently updated' }),
    recCount,
    el('a', { class: 'dg-inline-link', href: allTicketsHref(tv.projectId),
      title: 'The full list, newest activity first', text: 'see all →' })));
  if (!listOk) {
    rec.append(el('div', { class: 'dg-fail-inline', text: 'The ticket list could not be loaded, so recent activity is unavailable.' }));
  } else {
    // Last 7 days by the ticket's newest Activity date; capped at 10 (87 of the
    // real board's 166 files were touched in the last 7 days — unbounded here
    // just recreates the corpus the digest exists to avoid). No change summary:
    // the data model only knows lastActivity, and inventing "what changed" would
    // be a lie.
    //
    // FEAT-082 (visual review): a ticket already shown ABOVE (Awaiting you,
    // Answered, In flight) is not repeated down here — on a screen whose whole
    // premise is compression, the same three tickets appearing twice reads as a
    // dump, not a digest. The lanes above always carry more context than a
    // recent-activity line, so the row above wins.
    const shownAbove = new Set([...needs, ...answered, ...inflight].map((it) => it.id));
    const inWindow = rows
      .filter((r) => { const d = daysAgo(r.lastActivity); return d !== null && d >= 0 && d <= 6; })
      .sort((a, b) => (a.lastActivity === b.lastActivity ? b.mtimeMs - a.mtimeMs : (a.lastActivity < b.lastActivity ? 1 : -1)))
      .filter((r) => !shownAbove.has(r.id));
    const recent = inWindow.slice(0, 10);
    // Name the window: "10 of 63" reads as curation; a bare 10 reads as a
    // truncation the screen is hiding from you.
    if (inWindow.length) recCount.textContent = `${recent.length} of ${inWindow.length}`;
    if (!recent.length) {
      rec.append(el('div', { class: 'dg-quiet', text: 'No tickets were touched in the last 7 days.' }));
    } else {
      let day = null;
      let group = null;
      for (const r of recent) {
        if (r.lastActivity !== day) {
          day = r.lastActivity;
          rec.append(el('div', { class: 'dg-dayh', text: relDay(day) }));
          group = el('div', { class: 'dg-group' });
          rec.append(group);
        }
        const a = el('a', { class: 'dg-item dg-recent-item', 'data-id': r.id, href: ticketsHref(tv.projectId, r.id) });
        a.addEventListener('click', (e) => {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
          e.preventDefault();
          navTickets(tv.projectId, r.id);
        });
        const kind = ticketStatusKind(r);
        a.append(el('div', { class: 'dg-item-head' },
          typeBadge(r.id),
          el('span', { class: 'dg-id', text: r.id }),
          el('span', { class: 'dg-title', text: r.title, title: r.title }),
          // No date on the row: every row here sits under a day heading that
          // already states it, and ten rows repeating one date is ten rows of
          // nothing. The state pill carries what differs.
          // ARCH-004: the digest is the LANDING screen, so an unreadable state
          // must not draw a confident "Open" here either. Only the ERROR level
          // reaches the digest — a half-edited-but-unambiguous file is not
          // worth a mark on a screen whose whole premise is compression, and
          // its warning is waiting one click away in the detail pane.
          digestStatePill(r, kind)));
        group.append(a);
      }
    }
  }
  wrap.append(rec);

  /* ── Observations — bottom, collapsed to a count, expandable ── */
  if (observations.length) {
    const sec = el('section', { class: 'dg-sec dg-observations', id: 'dg-observations' });
    const body = el('div', { class: 'dg-obs-body', hidden: true });
    for (const it of observations) body.append(observationRow(it));
    const toggle = el('button', { type: 'button', class: 'dg-obs-toggle', 'aria-expanded': 'false' },
      el('span', { class: 'dg-obs-caret', text: '▸' }),
      el('span', { text: `Observations` }),
      el('span', { class: 'dg-obs-n', text: String(observations.length) }));
    toggle.addEventListener('click', () => {
      const open = body.hidden;
      body.hidden = !open;
      toggle.setAttribute('aria-expanded', String(open));
      toggle.querySelector('.dg-obs-caret').textContent = open ? '▾' : '▸';
    });
    sec.append(toggle, body);
    wrap.append(sec);
  }

  clear(tv.digest).append(wrap);
}

/** Navigate WITHIN the dashboard (pushes history, so Back works as expected).
 *  FEAT-082 — `view` selects the digest / full-list / detail shape; when it is
 *  'all' the ticketId is ignored (the full list names no single ticket). */
function navTickets(projectId, ticketId, { replace = false, view = null } = {}) {
  const resolved = view === 'all' ? 'all' : (ticketId ? 'detail' : 'digest');
  const href = formatTicketsHash({ projectId, ticketId: resolved === 'detail' ? ticketId : null, view: resolved });
  if (replace) window.history.replaceState(null, '', href);
  else window.history.pushState(null, '', href);
  void showTickets({ projectId, ticketId: resolved === 'detail' ? ticketId : null, view: resolved });
}

/** The project switcher: every registered project that HAS a board. */
async function loadBoardProjects() {
  let boards = [];
  try { boards = await api.boards(); } catch { /* the switcher is a nicety */ }
  clear(tv.project);
  const known = new Set();
  for (const b of boards) {
    known.add(b.id);
    tv.project.append(el('option', {
      value: b.id,
      text: `${b.name} — ${b.open} open${b.needsYou ? ` · ${b.needsYou}👤` : ''}`,
    }));
  }
  // The selected project may have no board at all — say so rather than
  // silently switching the user to somebody else's board.
  if (tv.projectId && !known.has(tv.projectId)) {
    const p = state.projects.find((x) => x.id === tv.projectId);
    tv.project.append(el('option', { value: tv.projectId, text: `${p?.name ?? tv.projectId} — no board` }));
  }
  tv.project.value = tv.projectId ?? '';
}

async function loadTicketRows() {
  const pid = tv.projectId;
  const seq = ++tv.seq;
  if (!pid) { tv.rows = []; tv.rowsProjectId = null; renderTicketRows(); return; }
  tv.list.setAttribute('aria-busy', 'true');
  try {
    const r = await api.ticketList(pid, tv.q);
    if (seq !== tv.seq || pid !== tv.projectId) return; // a newer request won
    tv.rows = r.tickets ?? [];
    tv.hasBoard = r.hasBoard !== false;
    tv.rowsProjectId = pid;
  } catch (err) {
    if (seq !== tv.seq) return;
    tv.rows = [];
    tv.rowsProjectId = null;
    tv.hasBoard = false;
    say(`could not read the board: ${err.message}`, true);
  } finally {
    tv.list.removeAttribute('aria-busy');
  }
  renderTicketRows();
}

function filteredRows() {
  const st = tv.status.value;
  const ow = tv.owner.value;
  const sv = tv.sev.value;
  let rows = tv.rows.filter((t) => {
    if (st !== 'all' && t.section !== st) return false;
    if (ow === 'you' && !t.needsYou) return false;
    if (ow === 'agent' && !String(t.owner).includes('🤖')) return false;
    if (ow === 'none' && (t.needsYou || String(t.owner).includes('🤖'))) return false;
    if (sv !== 'all' && (t.sev || '').toLowerCase().slice(0, 3) !== sv.slice(0, 3)) return false;
    return true;
  });
  // FEAT-063: header-driven sorting. `cmp` is always ASCENDING; `sortAsc`
  // is the direction sign. (Clicking "Activity" defaults to descending —
  // newest first — every other column to ascending; see sortByColumn.)
  const by = tv.sortBy;
  const cmp = (a, b) => {
    if (by === 'id') return a.id.localeCompare(b.id, undefined, { numeric: true });
    if (by === 'title') return a.title.localeCompare(b.title);
    if (by === 'owner') return ownerGlyph(a).localeCompare(ownerGlyph(b));
    if (by === 'status') {
      const s = (t) => (t.section === 'done' ? 'Done' : (t.boardStatus || t.status || 'open'));
      return s(a).localeCompare(s(b));
    }
    if (by === 'sev') {
      const r = (SEV_RANK[(b.sev || '').toLowerCase()] ?? 3) - (SEV_RANK[(a.sev || '').toLowerCase()] ?? 3);
      if (r) return r; // ascending severity = low → high
      return a.id.localeCompare(b.id, undefined, { numeric: true });
    }
    // activity, ascending = oldest first; ties break on mtime
    return a.lastActivity === b.lastActivity ? a.mtimeMs - b.mtimeMs : (a.lastActivity < b.lastActivity ? -1 : 1);
  };
  const sign = tv.sortAsc ? 1 : -1;
  return rows.slice().sort((a, b) => sign * cmp(a, b));
}

/** A header click: same column toggles direction, a new column gets its
 *  intuitive default (activity newest-first, everything else ascending). */
function sortByColumn(col) {
  if (tv.sortBy === col) tv.sortAsc = !tv.sortAsc;
  else { tv.sortBy = col; tv.sortAsc = col !== 'activity'; }
  renderTicketRows();
}

function ownerGlyph(t) {
  if (t.needsYou) return '👤';
  if (String(t.owner).includes('🤖')) return '🤖';
  return '—';
}

/**
 * FEAT-066: the small STATUS color language. Derives a stable kind from the
 * ticket's own facts — the tags/badges get tinted, never the page. Kinds map to
 * the palette-derived tint tokens in styles.css (open=neutral, in-progress=blue,
 * needs-you=amber, done/verified=green; dark-theme aware, one source of truth):
 *   done  — closed/verified (section === done)
 *   needs — 👤 waiting on the user
 *   prog  — 🤖 in flight, or a "building/in-progress" status
 *   open  — everything else (the neutral default; no tint added)
 */
function ticketStatusKind(t) {
  if (t.section === 'done') return 'done';
  if (t.needsYou) return 'needs';
  const status = String(t.boardStatus || t.status || '').toLowerCase();
  if (String(t.owner || '').includes('🤖') || /progress|building|in.?flight|wip|review/.test(status)) return 'prog';
  return 'open';
}

/**
 * ARCH-004 — THE TICKET'S OWN REPORT ABOUT ITS STATE, ON SCREEN.
 *
 * The schema (scripts/lib/ticket-schema.mjs) enumerates every way a ticket can
 * fail to declare exactly one interpretable state — absent, empty,
 * unrecognised, duplicated-and-disagreeing, duplicated-and-agreeing, declared
 * below the header, or written with near-miss punctuation — and the server
 * carries the verdict on every summary as `statusError` / `statusWarning`.
 * Three rounds of work made the parser loud; until this renderer read those two
 * fields, the loudness stopped at the API and a ticket whose state is
 * contradictory drew an ordinary row showing its raw prose. The whole point of
 * a loud parser is that a PERSON sees it, so both fields are rendered here.
 *
 * The two levels are deliberately NOT one appearance:
 *   · ERROR   — no tool can answer done-or-open for this ticket. The row's
 *               status tag stops claiming a state at all: it is REPLACED by the
 *               server's own headline, tinted brick, and the row takes a brick
 *               edge so it is findable while scanning.
 *   · WARNING — the answer is not in doubt, the file is just half-edited. The
 *               status stays exactly as it was and picks up one small amber
 *               mark; nothing is recoloured, because nothing is wrong with the
 *               answer.
 * Both carry the SERVER'S sentence verbatim — as the tag's `title`, as
 * screen-reader text inside the row (a colour-only or hover-only signal is the
 * same invisibility this fixes), and in full in the detail pane.
 */
function statusFlaw(t) {
  const err = String(t?.statusError ?? '').trim();
  const warn = String(t?.statusWarning ?? '').trim();
  if (err) return { level: 'error', message: err, headline: flawHeadline(err) };
  if (warn) return { level: 'warn', message: warn, headline: flawHeadline(warn) };
  return null;
}

/**
 * The first clause of the server's message — `MISSING STATUS FIELD`,
 * `DUPLICATE STATUS FIELD`, `UNMAPPABLE STATUS`… — which is already written as
 * a short headline before the `: <file> — <detail>` that follows. Taking the
 * server's own words keeps the table honest with the detail pane and with
 * `board:check`; the UI never invents a second vocabulary for the same defect.
 */
function flawHeadline(msg) {
  const i = msg.indexOf(':');
  const head = (i > 0 && i <= 34 ? msg.slice(0, i) : msg).trim();
  return head.length <= 34 ? head : `${head.slice(0, 33)}…`;
}

/** The Status cell for one row — the flawed shapes included (see statusFlaw). */
function ticketStatusCell(t, flaw) {
  const text = t.section === 'done' ? 'Done' : (t.boardStatus || t.status || 'open');
  if (!flaw) return el('span', { class: `c-status st-${ticketStatusKind(t)}`, text });
  if (flaw.level === 'error') {
    // The state is NOT rendered: there is no state to render, and printing the
    // raw prose next to the error would re-assert the very claim that failed.
    return el('span', { class: 'c-status st-flaw-err', title: flaw.message },
      document.createTextNode(flaw.headline),
      el('span', { class: 'sr-only', text: ` — status error: ${flaw.message}` }));
  }
  return el('span', { class: `c-status st-${ticketStatusKind(t)} has-flaw-warn`, title: flaw.message },
    document.createTextNode(text),
    el('span', { class: 'c-flawmark', 'aria-hidden': 'true', text: WARN_MARK }),
    el('span', { class: 'sr-only', text: ` — status warning: ${flaw.message}` }));
}

/** U+FE0E pins the text presentation: a colour-emoji triangle would shout. */
const WARN_MARK = '⚠︎';

/**
 * The detail pane's notes — zero, one or two hairline blocks carrying the
 * server's sentences verbatim. `statusWarning` is the joined form of a LIST
 * (' | ' between entries, built by the schema), so it is split back into one
 * line per defect: two independent complaints run together read as one
 * confusing sentence.
 */
/** The digest recent-lane state pill — brick + the server's headline when the state cannot be read. */
function digestStatePill(r, kind) {
  const err = String(r?.statusError ?? '').trim();
  if (!err) return el('span', { class: `dg-state st-${kind}`, text: r.section === 'done' ? 'Done' : 'Open' });
  return el('span', { class: 'dg-state st-flaw-err', title: err },
    document.createTextNode(flawHeadline(err)),
    el('span', { class: 'sr-only', text: ` — status error: ${err}` }));
}

function statusFlawNotes(t) {
  const out = [];
  const err = String(t?.statusError ?? '').trim();
  const warn = String(t?.statusWarning ?? '').trim();
  if (err) out.push(flawNote('error', 'status error', [err]));
  if (warn) out.push(flawNote('warn', 'status warning', warn.split(' | ').map((s) => s.trim()).filter(Boolean)));
  return out;
}

function flawNote(level, label, lines) {
  const box = el('div', {
    class: `tv-flaw ${level === 'error' ? 'err' : 'warn'}`,
    role: 'note', 'aria-label': label,
  }, el('span', { class: 'tvf-k', text: label }));
  const body = el('div', { class: 'tvf-body' });
  for (const line of lines) body.append(el('p', { class: 'tvf-m', text: line }));
  box.append(body);
  return box;
}

function renderTicketRows() {
  const rows = filteredRows();
  clear(tv.list);
  tv.count.textContent = tv.q
    ? `${rows.length} matching · ${tv.rows.length} scanned`
    : `${rows.length} of ${tv.rows.length}`;

  if (!tv.hasBoard) {
    tv.list.append(el('div', { class: 'tv-empty' },
      el('b', { text: 'This project has no board.' }),
      document.createTextNode(' There is no docs/bugs/ directory here — onboard the project to start one.')));
    return;
  }
  if (!rows.length) {
    tv.list.append(el('div', { class: 'tv-empty' },
      el('b', { text: tv.q ? 'No ticket matches that.' : 'No tickets match these filters.' }),
      document.createTextNode(tv.q ? ' The search covers ids, titles and every line of every ticket body.' : '')));
    return;
  }
  // FEAT-063: sortable headers — the table is the sort control now.
  const hcell = (cls, col, label) => {
    const active = tv.sortBy === col;
    const c = el('span', {
      class: `${cls} hsort${active ? (tv.sortAsc ? ' asc' : ' desc') : ''}`,
      role: 'button', tabindex: '0',
      'aria-sort': active ? (tv.sortAsc ? 'ascending' : 'descending') : 'none',
      title: `Sort by ${label.toLowerCase()}`,
      text: label,
    });
    c.addEventListener('click', () => sortByColumn(col));
    c.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); sortByColumn(col); } });
    return c;
  };
  const head = el('div', { class: 'tv-row tv-head' },
    hcell('c-id', 'id', 'ID'),
    hcell('c-title', 'title', 'Title'),
    hcell('c-own', 'owner', 'Owner'),
    hcell('c-status', 'status', 'Status'),
    hcell('c-sev', 'sev', 'Sev'),
    hcell('c-when', 'activity', 'Activity'));
  tv.list.append(head);
  tv.cursor = Math.min(tv.cursor, rows.length - 1);
  for (const [i, t] of rows.entries()) {
    const flaw = statusFlaw(t);
    const row = el('a', {
      class: `tv-row${t.section === 'done' ? ' done' : ''}${i === tv.cursor ? ' kb' : ''}`
        + (flaw ? ` tv-flawed flaw-${flaw.level === 'error' ? 'err' : 'warn'}` : ''),
      'data-id': t.id,
      href: ticketsHref(tv.projectId, t.id),
    },
      el('span', { class: 'c-id', text: t.id }),
      el('span', { class: 'c-title', text: t.title, title: t.title }),
      el('span', { class: 'c-own', text: ownerGlyph(t) }),
      ticketStatusCell(t, flaw),
      // BUG-126 — the cell is clamped to one line in CSS, so the full recorded
      // severity is carried on the title attribute the way .c-title does it.
      el('span', {
        class: `c-sev sev-${(t.sev || '').toLowerCase().slice(0, 3)}`,
        text: t.sev || '',
        title: t.sev || '',
      }),
      el('span', { class: 'c-when', text: t.lastActivity }));
    // Plain-left-click navigates in place; ctrl/cmd-click keeps the browser's
    // own "open in a new tab", which is the whole point of a real href.
    row.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault();
      navTickets(tv.projectId, t.id);
    });
    if (t.matches?.length) {
      const hits = el('div', { class: 'tv-hits' });
      for (const mt of t.matches) {
        hits.append(el('div', { class: `tv-hit${mt.inActivityLog ? ' log' : ''}` },
          el('span', { class: 'ln', text: `:${mt.line}` }),
          el('span', { class: 'tx', text: mt.text })));
      }
      if (t.matchCount > t.matches.length) {
        hits.append(el('div', { class: 'tv-hit more', text: `+${t.matchCount - t.matches.length} more line(s) in this ticket` }));
      }
      tv.list.append(el('div', { class: 'tv-rowwrap' }, row, hits));
    } else {
      tv.list.append(row);
    }
  }
}

function showTicketList() {
  tv.digest.hidden = true;
  tv.detail.hidden = true;
  tv.list.hidden = false;
  tv.filters.hidden = false;
  // Keep the search box honest with the query the rows were actually loaded under
  // (a digest hop resets tv.q to ''), so it never shows text it is not applying.
  if (tv.search.value !== tv.q) tv.search.value = tv.q;
  clear(tv.detail);
  tv.current = null;
  const active = tv.list.querySelector('.tv-row.active');
  if (active) active.classList.remove('active');
}

/* FEAT-063 — tracker keyboard: ↑/↓ move a cursor row, Enter opens it. Only on
 * the LIST (never over the detail document, the modal, or any form control). */
function moveTicketCursor(delta) {
  const rows = [...tv.list.querySelectorAll('a.tv-row')];
  if (!rows.length) return;
  tv.cursor = tv.cursor < 0
    ? (delta > 0 ? 0 : rows.length - 1)
    : Math.max(0, Math.min(rows.length - 1, tv.cursor + delta));
  for (const [i, r] of rows.entries()) r.classList.toggle('kb', i === tv.cursor);
  rows[tv.cursor].scrollIntoView({ block: 'nearest' });
}
document.addEventListener('keydown', (e) => {
  if (!tv.open || tv.list.hidden || ticketModalOpen()) return;
  const t = e.target;
  const tag = t?.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || t?.isContentEditable) return;
  if (t?.classList?.contains('hsort')) return; // header cells sort on their own Enter
  if (e.key === 'ArrowDown') { e.preventDefault(); moveTicketCursor(1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); moveTicketCursor(-1); }
  else if (e.key === 'Enter' && tv.cursor >= 0) {
    const row = tv.list.querySelectorAll('a.tv-row')[tv.cursor];
    if (row?.dataset.id) { e.preventDefault(); navTickets(tv.projectId, row.dataset.id); }
  }
});

async function loadTicketDetail(id) {
  tv.digest.hidden = true;
  tv.list.hidden = true;
  tv.filters.hidden = true;
  tv.detail.hidden = false;
  clear(tv.detail).append(el('div', { class: 'tv-empty', text: `loading ${id}…` }));
  const seq = ++tv.seq;
  try {
    const t = await api.ticket(tv.projectId, id);
    if (seq !== tv.seq) return;
    tv.current = t;
    clear(tv.detail).append(ticketDetailNode(t));
  } catch (err) {
    if (seq !== tv.seq) return;
    clear(tv.detail).append(el('div', { class: 'tv-empty' },
      el('b', { text: `Cannot open ${id}.` }), document.createTextNode(` ${err.message}`)));
  }
}

/**
 * THE REUSABLE DETAIL RENDERER. Returns a detached node for one ticket: header
 * facts, the write actions, and the ticket's REAL markdown rendered with the
 * same `prose()` renderer the transcript uses.
 *
 * Deliberately a standalone function taking a ticket payload — FEAT-053's rail
 * ticket modal is meant to call THIS rather than grow a second renderer that
 * drifts from it. `opts.compact` drops the actions for a read-only embed.
 */
function ticketDetailNode(t, opts = {}) {
  // ONE view model for both ticket formats (public/lib/ticket-record.js): a
  // migrated ticket's human layer comes off its record verbatim; a legacy one
  // carries what genuinely exists and says "Not recorded" for the rest.
  const v = ticketView(t);
  const wrap = el('div', {
    class: `tv-doc tv-banded${v.migrated ? ' is-migrated' : ' is-legacy'}`,
    'data-id': t.id, 'data-rev': t.rev,
    'data-format': v.migrated ? 'record' : 'legacy',
  });
  // Header fields that live only in the FILE (the list payload doesn't carry
  // them) — read straight out of the markdown, never invented.
  const mdField = (name) => (new RegExp(`^- \\*\\*${name}:\\*\\*\\s*(.*)$`, 'mi')
    .exec(t.markdown || '')?.[1] ?? '').trim();

  // ── top line: back link + (non-compact) the action toolbar, right-aligned ──
  const acts = opts.compact ? null : ticketActions(t, wrap);
  const top = el('div', { class: 'tv-dtop' });
  if (!opts.compact) {
    // FEAT-082 — the list moved to /all, so "all tickets" lands there (the
    // browser Back button still returns to wherever you came from — digest or list).
    const back = el('a', { class: 'tv-back', href: allTicketsHref(tv.projectId), text: '← all tickets' });
    back.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.button !== 0) return;
      e.preventDefault();
      navTickets(tv.projectId, null, { view: 'all' });
    });
    top.append(back, acts.tools);
  }
  wrap.append(top);

  // ── BAND 1: the hero — type · id, the title, and the state PILLS ─────────
  // The pills are the orthogonal state fields (work state, what it needs from a
  // human, whether it is proved) as separate values, never one prose sentence.
  // The status COLOUR language. A legacy ticket's kind is derived from the board
  // row as it always was; a migrated ticket's comes from its own enums, because
  // the server still reads the legacy prose header and a migrated ticket does not
  // have one — deriving "open" from a missing field would be inventing a state.
  const kind = v.migrated ? recordStatusKind(v) : ticketStatusKind(t);
  const flawed = !v.migrated && !!String(t.statusError ?? '').trim();
  const hero = el('div', { class: 'tv-hero' });
  hero.append(el('h1', { class: 'tv-dtitle' },
    el('span', { class: 'd-id', text: `${v.typeLabel} · ${t.id}` }),
    document.createTextNode(' '),
    // A legacy title routinely carries backticked paths; rendering the raw
    // markers in the one line a reader always reads is noise, not fidelity.
    // `v.title` only: falling through to the raw payload title is what printed a
    // fence marker as a headline. The view model has already decided what the
    // title is, including when the honest answer is that there isn't one.
    inlineInto(el('span', { class: 'd-t' }), v.title || (v.recordUnreadable ? '' : (t.title || '')))));
  hero.append(heroPills(t, v, kind));
  wrap.append(hero);

  // ── ARCH-004's notes (see below) sit here, between the hero and the human
  // band: under the facts they contradict, above everything derived from them.
  //
  // They are LEGACY-ONLY, and deliberately so. `statusError` is the verdict of
  // the server's prose-header parser, and a migrated ticket has no prose header
  // to parse — every migrated ticket would otherwise draw a permanent "MISSING
  // STATUS FIELD" error about a field the format deleted on purpose. A migrated
  // ticket's state is its `work_state` enum, which cannot be unreadable; the
  // board tools keep their own opinion about the file either way.
  //
  // …and a BROKEN RECORD is treated like a migrated ticket here, not a legacy
  // one. `statusError` is the prose-header parser's verdict, and a migrated file
  // HAS no prose header — so a corrupt-record ticket was drawing a permanent
  // "MISSING STATUS FIELD: …" error about a field its own format deleted on
  // purpose, on top of the real record error, naming the wrong defect first. The
  // record error is the true and complete explanation; this one is an artifact of
  // parsing a file the parser was never meant to read.
  const notes = (v.migrated || v.recordUnreadable) ? [] : statusFlawNotes(t);
  if (notes.length) wrap.append(el('div', { class: 'tv-flaws' }, ...notes));
  // A BROKEN record — and the note must describe what actually happened, not the
  // reassuring version. The earlier wording ("the original markdown is shown in
  // full") was false: readTicketRecord stripped the fenced block before handing
  // the body over, so the ONE text a reader needs in order to repair the file was
  // the one text the page could not show. The block's bytes now travel in
  // `v.body` verbatim and render as the first code block of the deep band, so the
  // note says where they went and how to reach them.
  if (v.parseError) {
    wrap.classList.add('is-record-error');
    wrap.append(el('div', { class: 'tv-flaws' },
      flawNote('error', 'ticket record error', [
        `${v.parseError}`,
        // A CLAIM ABOUT THE FILE, NOT ABOUT ITS HISTORY. The earlier wording said
        // "This ticket HAS been migrated", which the view cannot know: all it can
        // see is that the file BEGINS with an orchard-ticket block. A hand-written
        // ticket that opens with an example block — a ticket about the format
        // itself would — is indistinguishable, and would have been told a fact
        // about its own past that is false. So the sentence states what was
        // observed and names the one reading it cannot rule out.
        'This file BEGINS with an orchard-ticket record block, so it is read as a migrated ticket whose record is broken — not as one that was never migrated. None of the human layer below could be filled in from it. (The view can only see the file, not its history: a hand-written file that opens with an example block looks the same.)',
        'Nothing has been dropped: the file is rendered below exactly as it is on disk. The unreadable orchard-ticket block is the first code block below, under the caption that names it — verbatim, fences included.',
        // …and the one thing "verbatim" still cannot promise — stated PER CLASS.
        // The text node holds the file's bytes; what a reader cannot do is read
        // some of them correctly off the screen. An earlier round said the whole
        // flagged set "can make the order you SEE differ", which is true of a bidi
        // control and false of a NUL, a zero-width space and a line separator — it
        // pointed a reader at display order and away from the real hazard, a byte
        // they cannot see at all. So each class present gets the sentence that is
        // true of IT, and a class that is absent contributes no sentence.
        ...invisibleClaims(v.rawRecordInvisibles),
      ])));
  }

  // ── BAND 2: the human layer — what is happening, what it needs, what waiting
  // costs, and the plain facts. Always visible; never behind an expander. ─────
  //
  // NEVER RENDER A FIELD WHOSE ONLY CONTENT IS ITS OWN ABSENCE. This band used to
  // render unconditionally, so an un-migrated ticket — 182 of the 190 on the real
  // board — opened with a full-width card reading "What's happening / Not
  // recorded / What this ticket needs / Not recorded", an empty impact card
  // beside it, and a paragraph apologising for all three. That is ~45 words of
  // scaffolding occupying the most valuable space on the screen, pushing the
  // ticket's actual first sentence below the fold to say nothing. An empty band
  // is worse than no band: "Not recorded" earns its place in the dense facts
  // grid below, where a label and an empty value share one line and the reader is
  // scanning, and nowhere that costs a heading and a full-width row.
  //
  // So both cards are built conditionally and the ticket's own prose takes the
  // space. The grid's `human` and `impact` areas collapse to zero height when
  // nothing is placed in them, so the layout needs no legacy special case.
  const human = humanNarrative(v);
  if (human) wrap.append(human);
  const impact = impactCard(v);
  if (impact) wrap.append(impact);

  // The facts card. `state` + `status` stay here for a LEGACY ticket because the
  // raw board sentence is real information the pills cannot carry (and ARCH-004's
  // unreadable-state treatment lands on it). A MIGRATED ticket's state is already
  // three enum pills in the hero, so repeating it here would be exactly the
  // duplicate metadata dump this redesign exists to remove.
  const meta = el('div', { class: 'tv-dmeta' });
  const kv = (k, val, { always = false } = {}) => {
    if (!val && !always) return;
    meta.append(el('span', { class: 'kv' }, el('span', { class: 'k', text: k }),
      typeof val === 'string' || val === null || val === undefined
        ? el('span', { class: `v${val ? '' : ' v-none'}`, text: val || NOT_RECORDED })
        : val));
  };
  meta.append(el('div', { class: 'tv-facts-h', text: 'Facts' }));
  // …and NOT for a broken record: `state` here is the board index's guess and
  // `status` is the prose-header parse of a file that has no prose header. The
  // hero already stopped claiming a state for exactly that reason; repeating the
  // claim in the facts grid would put it back, in smaller type.
  if (!v.migrated && !v.recordUnreadable) {
    kv('state', el('span', { class: `v d-badge ${t.section} st-${kind}`, text: t.section === 'done' ? 'Done' : 'Open' }));
    kv('status', el('span', { class: `v d-status st-${kind}${flawed ? ' st-flaw-err' : ''}`, text: t.status || '—' }));
  }
  kv('area', v.area, { always: true });
  kv('reported', v.reported ? `${v.reported}${v.reportedBy ? ` · ${v.reportedBy}` : ''}` : null, { always: true });
  kv('owner', el('span', { class: 'v d-own' },
    el('span', { class: 'd-own-g', text: ownerGlyph(t) }),
    el('span', { class: 'd-own-t', text: v.owner ? ` ${v.owner}` : ' unassigned' })));
  kv('severity', v.severity && v.severity !== 'not_recorded'
    ? el('span', { class: `v d-sev sev-${v.severity.slice(0, 3)}`, text: v.severity })
    : null, { always: true });
  kv('updated', v.updated, { always: true });
  if (!v.migrated) kv('verified-by', mdField('Verified-by') || mdField('Verified by'));
  kv('file', el('span', { class: 'v mono', text: t.relPath || t.file }));
  wrap.append(meta);

  // ── BAND 3: the deep layer — diagnosis, evidence, proof, related code and the
  // activity log, each its own expander (never one collapsed markdown blob), and
  // ALWAYS in the DOM: the API returns the whole record regardless, so an agent
  // reading this ticket is never given the collapsed version.
  //
  // The prose is the ticket's real markdown MINUS its record block (`v.body`):
  // rendering the JSON header as a code block would put the machine layer back at
  // the top of the human's screen, which is the defect, inverted.
  //
  // THE UNPARSEABLE BLOCK IS PRINTED, NOT PARSED. An earlier round fed the WHOLE
  // file to prose() and let it draw the block as a code block. It got the bytes
  // into the model but not onto the page: prose() splits on every ``` run
  // anywhere in the text (`public/lib/dom.js`, BUG-111's char-run fence model),
  // so a record whose own human-layer text quotes an inline ``` — which a ticket
  // ABOUT fenced code legitimately does, and at least six real ones do —
  // terminated the <pre> mid-value and the info-string strip ate the next line.
  // A clean-room round measured 16 of 49 record lines still unreachable, with
  // `work_state` among them, under a note promising "verbatim, fences included".
  //
  // So the block never meets the markdown parser at all. `v.rawRecordFence` is
  // the matched region byte-for-byte, fences included, inserted as a TEXT node
  // into a real <pre>: nothing can split it, strip it or reinterpret it, and the
  // promise the note makes is one the renderer can actually keep. Only
  // `v.proseBody` — the markdown AFTER the block — goes to prose().
  const doc = prose(v.recordUnreadable ? v.proseBody : v.body, 'prose');
  if (v.recordUnreadable && v.rawRecordFence) {
    doc.prepend(el('div', { class: 'out tv-rawrec' }, el('pre', { text: v.rawRecordFence })));
    // Named in the DOM, not by a CSS ::before — a caption a screen reader cannot
    // reach is not a caption.
    doc.prepend(el('p', { class: 'tv-rawrec-cap',
      text: 'The ticket’s orchard-ticket record block, verbatim and whole — this is the text that could not be parsed.' }));
  }
  // The file's own H1 repeats the header above verbatim — mark it so the
  // stylesheet can fold it away (the bytes are still in the DOM, untouched).
  // Matched on the ID PREFIX, not on the whole line: a title carrying inline
  // markdown (BUG-104's `docs/prompts`) renders WITHOUT its backticks, so an
  // equality test against the payload's raw title silently stopped folding
  // exactly the titles most likely to be long.
  //
  // AND FOLDING IS NOW EARNED, NOT ASSUMED. `.tv-dup-title` is `display: none` —
  // the strongest elision on this page, invisible AND out of the accessibility
  // tree — and it used to fire on the ID PREFIX alone, i.e. on the strength of
  // `BUG-104 — ` matching. Everything after that dash was DISCARDED UNREAD on the
  // assumption it repeated the header. When it does not (a file whose H1 was
  // edited without the board index following, a migrated record whose `title`
  // differs from the prose H1 it was authored from) the page silently deleted a
  // line of the file while claiming to show the body whole. So the remainder is
  // now compared against the title actually printed in the hero, and only an
  // exact match is folded: a heading that says something different stays on
  // screen, because that difference is information.
  const first = doc.firstElementChild;
  const heroTitle = (wrap.querySelector('.tv-hero .d-t')?.textContent ?? '').replace(/\s+/g, ' ').trim();
  const headText = (first && /^H\d$/.test(first.tagName))
    ? first.textContent.replace(/\s+/g, ' ').trim() : null;
  const idRe = String(t.id ?? '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const headRest = headText && idRe
    ? (new RegExp(`^${idRe}\\s*[—–-]\\s*(.*)$`).exec(headText)?.[1] ?? null) : null;
  if (headRest !== null) {
    // Compared on rendered TEXT both sides: the hero title and this heading are
    // both built through `inlineInto`, so backticks and `**` are already gone
    // from each — the comparison BUG-104 got wrong when it tested raw markdown.
    if (headRest === heroTitle) first.classList.add('tv-dup-title');
    // …and the header-fields bullet list right under it renders compact either
    // way: compacting is styling, not hiding, so it needs no such proof.
    if (first.nextElementSibling?.tagName === 'UL') first.nextElementSibling.classList.add('tv-filemeta');
  }
  sectionActivityLog(doc);
  // Each `##` section becomes its own expander, in place. A MIGRATED ticket's
  // deep prose starts collapsed (the human layer above already answered the
  // question a reader came with); a LEGACY ticket's does not, because for a
  // legacy ticket this prose IS the ticket and collapsing it would hide the only
  // content there is. The activity log is collapsed either way — it is the
  // archaeology, it is most of the bytes, and its summary states how much.
  const slots = sectionDeepSlots(doc, { openByDefault: !v.migrated });
  const md = el('div', { class: 'tv-md' });
  // The eyebrow is a DIVIDER between the human layer and the archaeology under
  // it, and it only means something when there is a human layer above it to
  // divide from. On an un-migrated ticket this prose IS the ticket, and labelling
  // it "Context for deeper review & agents" both mislabels it and re-adds the
  // scaffolding the empty band just lost — one more row between the reader and
  // the first real sentence. So it is drawn only when something precedes it.
  if (v.migrated) {
    md.append(el('div', { class: 'tv-deep-h' },
      el('span', { class: 'tv-deep-eyebrow', text: 'Context for deeper review & agents' }),
      el('span', { class: 'tv-deep-note', text: slots ? `${slots} sections` : 'no sections' })));
  }
  for (const card of deepRecordCards(v)) md.append(card);
  md.append(doc);
  wrap.append(md);

  // ── the write half, a plain FORM under the document — not a composer ──
  if (!opts.compact) wrap.append(acts.form);

  // ── FEAT-090: reply where you read it. Only on the full route detail (never
  // the compact/read-only modal — opening is not answering, BUG-025), and only
  // when the ticket actually carries a decision. "Add a note" (above) and
  // "Decide" (here) are different acts and stay separate controls. ──
  // A MIGRATED ticket carries its decision in the record, where the server's
  // prose parse cannot see it — so the live decision is "either source", and the
  // card is fed both (the record wins where they overlap).
  if (!opts.compact && (t.decision || v.decision)) {
    wrap.classList.add('has-decide');
    mountDecide(wrap, t, v);
  }
  // Historical decisions must not read as active: they are a collapsed, visibly
  // inactive record at the foot of the deep band, never beside the live one.
  if (v.decisionHistory.length) wrap.querySelector('.tv-md')?.append(decisionHistoryCard(v));
  return wrap;
}

/* ══════════════════════════ the redesigned ticket bands ═══════════════════
 *
 * docs/analysis/ticket-board-redesign-plan.md §2.7. The measured complaint the
 * redesign answers: a reader currently walks 348–1,039 words of invariant
 * statement, design archaeology and failed-patch history before being told what
 * they are being asked. The bands put that in a fixed order —
 *
 *   hero (type · id, title, state pills)
 *   human layer (what's happening / what it needs / impact of waiting / facts)
 *   the decision
 *   the deep layer, collapsed, per-section
 *
 * — so the reader can stop at the first band and an agent still receives all of
 * it. Nothing here summarises: every field is authored, quoted-with-its-source,
 * or the literal words "Not recorded".
 */

/** FEAT-066's colour language, derived from a migrated ticket's OWN enums. */
function recordStatusKind(v) {
  if (v.workState === 'done' || v.workState === 'verified') return 'done';
  if (v.humanAction && v.humanAction !== 'none') return 'needs';
  if (v.workState === 'in_progress' || v.workState === 'in_verification') return 'prog';
  return 'open';
}

/** The hero's pill row: the orthogonal state fields, one pill each. */
function heroPills(t, v, kind) {
  const pills = el('div', { class: 'tv-pills' });
  const pill = (cls, text, title) => pills.append(el('span', { class: `tv-pill ${cls}`, title: title || text, text }));

  const action = HUMAN_ACTION_LABEL[v.humanAction] ?? null;
  if (action) pill('tp-action', action, `this ticket is waiting on you: ${action.toLowerCase()}`);

  if (v.migrated) {
    const ws = WORK_STATE_LABEL[v.workState] ?? v.workState ?? NOT_RECORDED;
    pill(`tp-state st-${kind}${v.workState === 'blocked' ? ' tp-blocked' : ''}`, ws);
    // PROOF IS NEVER IMPLIED, AND NOW IT IS NEVER DERIVED EITHER (ARCH-009).
    //
    // Four pills used to be drawn here, one per value of a computed
    // `verification_state`: "Verified — holds", "Verification pending", "Proof
    // not recorded", "Verification BROKEN". Three of the four restated what the
    // work-state pill beside them already says, and the fourth — the one that
    // matters — was wrong on real tickets, because the state was folded off the
    // LAST of a set of regex-scraped verdicts. `FEAT-061` and `FEAT-062` are
    // both closed VERIFIED over an unresolved BROKEN and both painted the green
    // "Verified — holds" pill.
    //
    // So the hero draws ONE proof pill and only the loud one, from the record's
    // own attributed `verification[]` via the single rule that owns this
    // question. Everything else about proof is in the "Proof" card below, which
    // prints every verdict with its provider, run id and date — nothing is
    // hidden by dropping the badges, and nothing is claimed that a scraper
    // decided. Silence here means "no unresolved defect is recorded", which is
    // a fact about the array, not an opinion about the ticket.
    if (outstandingBroken(v.verification)) {
      pill('tp-proof tp-proof-broken', 'Verification BROKEN',
        'a recorded verification came back BROKEN and no later verdict resolved it');
    }
  } else {
    // ARCH-004's rule, carried into the hero: when the schema could not read this
    // ticket's state, the pill STOPS CLAIMING ONE. It is replaced by the server's
    // own headline, tinted brick — printing "Open" beside an error note that says
    // the state is unreadable would re-assert the very claim that failed.
    // A broken record's state genuinely cannot be read, and `t.section` is the
    // board index's opinion, not the file's — so no state pill is drawn at all
    // rather than one that says "Open" about a ticket nothing could parse. That
    // is ARCH-004's own rule: when the state is unreadable, stop claiming one.
    //
    // THIS IS LOAD-BEARING ON THE BLOCK BEING BYTE-EXACT. Declining to state a
    // work state is only honest while the reader can still READ one — and the
    // sole surviving copy of `work_state` is inside the raw record block. When
    // that block was routed through prose() it truncated at a quoted ``` run
    // before reaching `work_state`, and the page then neither stated the state
    // nor showed it: silence about a fact it had also hidden. The <pre> above is
    // a text node for this reason, and verify-ticket-view-redesign asserts
    // `work_state` is reachable on all 32 corruption variants.
    const flaw = v.recordUnreadable ? null : statusFlaw(t);
    if (v.recordUnreadable) {
      /* the "Record unreadable" pill below carries this */
    } else if (flaw?.level === 'error') {
      pills.append(el('span', { class: 'tv-pill tp-state tp-flaw-err', title: flaw.message },
        document.createTextNode(flaw.headline),
        el('span', { class: 'sr-only', text: ` — status error: ${flaw.message}` })));
    } else {
      pill(`tp-state st-${kind}${flaw ? ' has-flaw-warn' : ''}`, t.section === 'done' ? 'Done' : 'Open',
        flaw ? flaw.message : undefined);
    }
    // Same distinction as the narrative note: "Not migrated" is a claim about the
    // FILE, and it is false for a migrated ticket whose record is corrupt.
    if (v.recordUnreadable) {
      pill('tp-legacy tp-record-err', 'Record unreadable',
        'this ticket carries a structured record, but it could not be parsed — the file is shown whole below, block included');
    } else {
      pill('tp-legacy', 'Not migrated', 'this ticket predates the structured format — its human layer is derived from its prose sections');
    }
  }
  if (v.severity && v.severity !== 'not_recorded') pill(`tp-sev sev-${v.severity.slice(0, 3)}`, `${v.severity} severity`);
  else pill('tp-sev tp-none', 'Severity not recorded');
  return pills;
}

/**
 * One sentence per hazard class actually present in the raw record block, plus a
 * single closing line. Never a sentence over the union of classes: that is how a
 * NUL came to be described as something that reorders text.
 */
function invisibleClaims(runs) {
  if (!runs.length) return [];
  const byKind = new Map();
  for (const r of runs) byKind.set(r.kind, [...(byKind.get(r.kind) ?? []), r]);
  const name = {
    bidi: 'bidirectional format control', separator: 'line or paragraph separator',
    zeroWidth: 'zero-width character', control: 'non-printing control character',
  };
  const out = [];
  for (const [kind, list] of byKind) {
    const n = list.reduce((a, r) => a + r.n, 0);
    out.push(`That block contains ${n} ${name[kind]}${n === 1 ? '' : 's'} — `
      + `${list.map((r) => `${r.cp}${r.n > 1 ? ` \u00d7${r.n}` : ''}`).join(', ')}. `
      + `Characters like these ${INVISIBLE_CLAIM[kind]}.`);
  }
  out.push('The text shown is byte-for-byte what is in the file; check against the file itself '
    + 'before concluding what it says.');
  return out;
}

/**
 * BAND 2 left: what's happening + what this ticket needs — or NOTHING.
 *
 * Returns null when neither field is authored, and omits either heading whose
 * own field is missing. A heading over "Not recorded" is not information; it is
 * a receipt for a field that does not exist, and it costs the reader the top of
 * their screen. The absence stays checkable elsewhere, where it is cheap: the
 * hero carries a "Not migrated" / "Record unreadable" pill, and the facts grid
 * states its own gaps one line at a time.
 *
 * The un-migrated ticket's explanatory paragraph is gone with the empty band it
 * explained. It existed to tell the reader where the content actually was; with
 * no band in the way, the content is the next thing on the page.
 */
function humanNarrative(v) {
  const hasSummary = !!(typeof v.summary === 'string' ? v.summary : v.summary?.text);
  const hasNeed = !!v.need;
  if (!hasSummary && !hasNeed) return null;
  const card = el('div', { class: 'tv-human' });
  if (hasSummary) {
    card.append(el('h2', { class: 'th-h', text: 'What\u2019s happening' }));
    card.append(fieldPara(v.summary, 'th-summary'));
  }
  if (hasNeed) {
    card.append(el('h3', { class: `th-sub${hasSummary ? '' : ' th-sub-first'}`, text: 'What this ticket needs' }));
    card.append(fieldPara(v.need, 'th-need'));
  }
  return card;
}

/**
 * One human-layer paragraph. TWO honest outcomes and no third: an authored field,
 * printed verbatim and whole, or the literal words "Not recorded". There is no
 * eliding branch here on purpose — a field that looks authored but is a machine
 * cut is the same failure this redesign exists to remove, because it teaches the
 * reader to distrust the layout.
 */
function fieldPara(field, cls) {
  const value = typeof field === 'string' ? { text: field, from: null } : field;
  if (!value?.text) return el('p', { class: `${cls} th-none`, text: NOT_RECORDED });
  // Authored prose, so it may carry inline markdown — a quoted legacy section
  // routinely does (`independent-verify.mjs`, **only**). Rendered through the
  // shared safe inline renderer, which builds DOM nodes and inserts text AS
  // TEXT, so the reader never meets a raw `*marker*` and no file content can
  // inject markup.
  return inlineInto(el('p', { class: cls }), value.text);
}

/** BAND 2 right, top: the cost of doing nothing — including its BOUND. */
function impactCard(v) {
  // …or null. A tinted, bordered card whose whole body is the words "Not
  // recorded" is a box drawn around nothing; same rule as the narrative band.
  if (!v.impact) return null;
  const card = el('div', { class: 'tv-impact' });
  card.append(el('div', { class: 'ti-h', text: 'Impact if we wait' }));
  card.append(fieldPara(v.impact, 'ti-body'));
  return card;
}

/**
 * FEAT-090 — attach the Decide affordances to a rendered ticket detail:
 *   - WIDE (≥900px): a sticky "Decide" card in the right column (grid-area decide).
 *   - NARROW (≤900px): a pinned bottom action bar; tapping opens a bottom sheet.
 * Both drive the SAME reply submit. Once answered, the card flips in place to a
 * server-confirmed read-only reading (createDecideCard's renderChosen discipline).
 */
function mountDecide(wrap, t, v = null) {
  const pid = tv.projectId;
  // The card is driven by the RECORD when the ticket has one (option cards, mode,
  // recommendation reason, prerequisite, stages) and by the server's prose parse
  // otherwise. A migrated ticket may have no prose `## Question` at all, so the
  // legacy shape is synthesised from the record rather than left null — the
  // answered-state reading and the reply pipeline both read it.
  const rich = v?.decision ?? null;
  const decision = t.decision ?? (rich && {
    question: rich.question ?? '',
    options: rich.options.map((o) => ({ key: o.key, label: o.label, description: o.what_changes ?? '' })),
    recommended: rich.recommendation ?? null,
  }) ?? null;
  // Any server-confirmed reply flips the card to its read-only reading (question.js
  // renderChosen discipline — a chosen state is shown ONLY from the server).
  const answered = t.answer || null;

  // The reply submit — rev-gated, reloads the detail on success, preserves the
  // draft on a 409 (a concurrent agent wrote the ticket while you were deciding).
  const submit = async (reply, ui) => {
    ui.sending();
    try {
      await api.ticketAnswer(pid, t.id, reply, wrap.dataset.rev);
      closeTvSheet();
      await loadTicketRows();
      const fresh = await api.ticket(pid, t.id);
      tv.current = fresh;
      clear(tv.detail).append(ticketDetailNode(fresh));
      say(reply.followup
        ? `added a follow-up to ${t.id} — still awaiting handover (no agent started)`
        : reply.kind === 'decision'
          ? `recorded to ${t.id} — awaiting handover (no agent started)`
          : `sent to ${t.id} — ownership passed to the agent`);
    } catch (err) {
      if (err.status === 409) {
        // Re-read, re-render, and restore what the user was typing/choosing.
        const fresh = await api.ticket(pid, t.id);
        tv.current = fresh;
        const node = ticketDetailNode(fresh);
        clear(tv.detail).append(node);
        const noteEl = node.querySelector('.tv-decide .dc-note');
        if (noteEl) noteEl.value = reply.note || '';
        if (reply.chose) {
          const radio = node.querySelector(`.tv-decide .dc-opt input[value="${reply.chose.key}"]`);
          if (radio) { radio.checked = true; radio.dispatchEvent(new Event('change')); }
        }
        say(`${t.id} changed on disk while you were deciding (an agent may be writing to it) — nothing was written; your draft is kept, re-read and retry.`, true);
      } else {
        ui.failed(err.message);
        say(`could not record your reply to ${t.id}: ${err.message}`, true);
      }
    }
  };

  // The card lives in the right column on wide screens (grid-area decide).
  const wideWrap = el('div', { class: 'tv-decide-wrap' });
  wideWrap.append(createDecideCard({ decision, rich, answered, onSubmit: submit }).node);
  // READING ORDER, not just grid position. The wide layout puts this card in the
  // right column either way, but the DOM order is what a narrow screen, a screen
  // reader and Tab all follow — and it is the thing the redesign is measured on:
  // "how many words does a reader pass before they are told what they are being
  // asked". Behind the deep band that number is the whole ticket. So the card is
  // INSERTED directly after the narrative and the impact card, ahead of both the
  // facts card and the deep band — the facts are reference material a reader
  // consults, never a queue they have to clear to reach the question.
  const anchor = wrap.querySelector(':scope > .tv-dmeta') ?? wrap.querySelector(':scope > .tv-md');
  if (anchor) anchor.before(wideWrap); else wrap.append(wideWrap);

  // The narrow pinned bar — only while the decision is UNANSWERED (an answered
  // ticket has nothing to reply to at every scroll position). Tapping opens a
  // bottom sheet holding a fresh Decide card over the SAME submit.
  if (!answered) {
    const rec = (rich?.recommendation ?? decision?.recommended)
      ? `Recommends ${rich?.recommendation ?? decision.recommended}`
      : 'Decision needed';
    const bar = el('div', { class: 'tv-decide-bar' },
      el('span', { class: 'tdb-rec', text: rec }),
      el('button', { class: 'tdb-open solid', type: 'button', text: 'Answer' }));
    bar.querySelector('.tdb-open').addEventListener('click', () => openTvSheet({ ...t, decision }, submit, rich));
    wrap.append(bar);
  }
}

/* ── FEAT-090 — the narrow-screen reply sheet (a .tmodal variant: same Esc
   ladder, same backdrop, rounded top, body scrolls). ── */
let tvSheetEl = null;
function tvSheetOpen() { return !!tvSheetEl; }
function closeTvSheet() {
  if (!tvSheetEl) return;
  tvSheetEl.remove();
  tvSheetEl = null;
}
function openTvSheet(t, submit, rich = null) {
  closeTvSheet();
  const card = createDecideCard({ decision: t.decision, rich, answered: null, onSubmit: submit }).node;
  const box = el('div', { class: 'tv-sheet-box' },
    el('button', { class: 'ic tv-sheet-x', type: 'button', 'aria-label': 'Close', text: '✕' }),
    el('div', { class: 'tv-sheet-body' }, card));
  const back = el('div', { class: 'tv-sheet-back' });
  tvSheetEl = el('div', { class: 'tv-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Answer decision' }, back, box);
  back.addEventListener('click', closeTvSheet);
  box.querySelector('.tv-sheet-x').addEventListener('click', closeTvSheet);
  document.body.append(tvSheetEl);
}

/**
 * FEAT-063: the Activity log renders SECTIONED — each dated entry becomes a
 * bordered block whose date-heading is the block header. Pure DOM re-parenting
 * of prose() output: every node survives verbatim, nothing is rewritten.
 */
function sectionActivityLog(doc) {
  const heads = [...doc.querySelectorAll('h3, h4, h5, h6')];
  const logHead = heads.find((h) => /^activity log/i.test(h.textContent.trim()));
  if (!logHead) return;
  logHead.classList.add('tv-log-h');
  const logLevel = Number(logHead.tagName[1]);
  const entryLevel = logLevel + 1; // "### date — author" renders one level below
  const section = el('div', { class: 'tv-log' });
  logHead.after(section);
  let entry = null;
  while (section.nextSibling) {
    const n = section.nextSibling;
    const lvl = /^H\d$/.test(n.tagName ?? '') ? Number(n.tagName[1]) : 99;
    if (lvl <= logLevel) break; // a new top-level section ends the log
    if (lvl === entryLevel) {
      entry = el('div', { class: 'tv-logent' });
      section.append(entry);
      n.classList.add('tv-logent-h');
    }
    (entry ?? section).append(n); // append() MOVES the live node
  }
}

/**
 * Turn every `##` section of the rendered ticket body into its own expander, IN
 * PLACE. Pure DOM re-parenting of prose() output, exactly like sectionActivityLog:
 * every node survives verbatim, nothing is rewritten, and the section's own
 * heading element is MOVED INTO the <summary> rather than replaced — so it stays
 * a real heading in the accessibility tree and in every `.tv-md .prose h4` query.
 *
 * (prose() renders `#`→h3, `##`→h4, `###`→h5, so a ticket's top-level sections
 * are h4 here. sectionActivityLog must run first: it has already folded the log's
 * dated entries into .tv-log, which then travels into the log's own expander.)
 */
function sectionDeepSlots(doc, { openByDefault = false } = {}) {
  const groups = [];
  let cur = null;
  for (const n of [...doc.children]) {
    if (n.tagName === 'H4') { cur = { head: n, nodes: [] }; groups.push(cur); }
    else if (cur) cur.nodes.push(n);
  }
  for (const g of groups) {
    const title = g.head.textContent.trim();
    const isLog = /^activity log/i.test(title);
    const box = el('details', { class: `tv-slot${isLog ? ' tv-slot-log' : ''}` });
    if (openByDefault && !isLog) box.open = true;
    const entries = isLog
      ? g.nodes.reduce((n, x) => n + (x.classList?.contains('tv-log') ? x.querySelectorAll('.tv-logent').length : 0), 0)
      : 0;
    const sum = el('summary', { class: 'tv-slot-h' });
    g.head.replaceWith(box);          // the details takes the heading's place…
    g.head.classList.add('tv-slot-t');
    sum.append(g.head);               // …and the heading moves inside its summary
    if (isLog) sum.append(el('span', { class: 'tv-slot-n', text: entries ? `${entries} entries` : 'appended' }));
    box.append(sum);
    const body = el('div', { class: 'tv-slot-b' });
    for (const n of g.nodes) body.append(n);   // append() MOVES the live node
    box.append(body);
  }
  return groups.length;
}

/**
 * The MIGRATED record's structured deep fields, as their own expanders. These do
 * not exist in the markdown body at all — an agent reads them off the API, and
 * this is where a human can too. Every one of them prints "Not recorded" rather
 * than rendering nothing, because a claim of absence is checkable and silence is
 * not (the plan's §2.7 rule, and the reason `verification[]` exists).
 *
 * An EMPTY slot is that claim and nothing else, so it is drawn as one flat row —
 * the label and the words "Not recorded" on a single line, the dense-grid form
 * the rule allows — and NOT as a disclosure. A triangle that opens onto a
 * paragraph restating the summary line is the empty-band defect in miniature: it
 * advertises content to the reader, to Tab and to a screen reader, and delivers
 * a second copy of the absence.
 */
function deepRecordCards(v) {
  if (!v.migrated) return [];
  const out = [];
  const slot = (title, n, build, { empty = false } = {}) => {
    const head = [el('h4', { class: 'tv-slot-t ph', text: title }),
      el('span', { class: 'tv-slot-n', text: n })];
    if (empty) {
      out.push(el('div', { class: 'tv-slot tv-slot-rec tv-slot-flat' },
        el('div', { class: 'tv-slot-h' }, ...head)));
      return;
    }
    const box = el('details', { class: 'tv-slot tv-slot-rec' });
    box.append(el('summary', { class: 'tv-slot-h' }, ...head),
      el('div', { class: 'tv-slot-b' }, build()));
    out.push(box);
  };

  slot('Proof', v.verification.length ? `${v.verification.length} recorded` : NOT_RECORDED, () => {
    const b = el('div', { class: 'tvr-proof' });
    for (const e of v.verification) {
      b.append(el('div', { class: `tvr-run verdict-${String(e?.verdict || '').toLowerCase()}` },
        el('span', { class: 'tvr-verdict', text: String(e?.verdict || NOT_RECORDED).toUpperCase() }),
        el('span', { class: 'tvr-prov', text: `${e?.provider ?? NOT_RECORDED}${e?.model ? ` · ${e.model}` : ''}` }),
        el('span', { class: 'tvr-run-id mono', text: e?.run_id ?? NOT_RECORDED }),
        e?.verdict_on ? el('span', { class: 'tvr-on', text: e.verdict_on }) : null,
        e?.commit ? el('span', { class: 'tvr-commit mono', text: e.commit }) : null));
    }
    return b;
  }, { empty: !v.verification.length });

  // The schema's DEFAULT for success_criteria is the one-item list `["Not
  // recorded"]`, so an unfilled field arrives wearing a count of 1 and rendered
  // as a bullet reading "Not recorded". That is the same absence, disguised as
  // content — it is filtered here rather than counted.
  const criteria = v.successCriteria.filter((c) => String(c ?? '').trim()
    && String(c).trim().toLowerCase() !== NOT_RECORDED.toLowerCase());
  slot('Success criteria', criteria.length ? `${criteria.length}` : NOT_RECORDED, () => {
    const ul = el('ul', { class: 'tvr-list' });
    for (const c of criteria) ul.append(el('li', { text: String(c) }));
    return ul;
  }, { empty: !criteria.length });

  slot('Related code', v.codeRefs.length ? `${v.codeRefs.length} paths` : NOT_RECORDED, () => {
    const ul = el('ul', { class: 'tvr-list tvr-refs' });
    for (const c of v.codeRefs) {
      ul.append(el('li', {},
        el('span', { class: 'mono', text: String(c?.path ?? '') }),
        c?.symbol ? el('span', { class: 'tvr-sym mono', text: ` ${c.symbol}` }) : null,
        c?.note ? el('span', { class: 'tvr-note', text: ` — ${c.note}` }) : null));
    }
    return ul;
  }, { empty: !v.codeRefs.length });

  const relCount = v.related.length + v.recurrence.length;
  slot('Related tickets', relCount ? `${relCount}` : NOT_RECORDED, () => {
    const ul = el('ul', { class: 'tvr-list' });
    for (const r of v.related) {
      ul.append(el('li', {},
        el('span', { class: 'tvr-rel', text: String(r?.relation ?? '') }),
        el('a', { class: 'tvr-id', href: ticketsHref(tv.projectId, r?.id), text: String(r?.id ?? '') })));
    }
    for (const id of v.recurrence) {
      ul.append(el('li', {},
        el('span', { class: 'tvr-rel', text: 'recurrence evidence' }),
        el('a', { class: 'tvr-id', href: ticketsHref(tv.projectId, id), text: String(id) })));
    }
    return ul;
  }, { empty: !relCount });

  if (v.source && (v.source.confirmation || v.source.archived_path || (v.source.dropped ?? []).length)) {
    slot('Provenance', v.source.archived_path ? 'archived original' : 'migration record', () => {
      const b = el('div', { class: 'tvr-src' });
      if (v.source.original_title) b.append(el('p', {}, el('b', { text: 'Original title: ' }), document.createTextNode(v.source.original_title)));
      if (v.source.archived_path) b.append(el('p', {}, el('b', { text: 'Archived at: ' }), el('span', { class: 'mono', text: v.source.archived_path })));
      if (v.source.sha256) b.append(el('p', {}, el('b', { text: 'sha256: ' }), el('span', { class: 'mono', text: String(v.source.sha256) })));
      b.append(el('p', {}, el('b', { text: 'The migration’s own statement: ' }),
        document.createTextNode(v.source.confirmation || NOT_RECORDED)));
      const dropped = Array.isArray(v.source.dropped) ? v.source.dropped : [];
      b.append(el('p', {}, el('b', { text: 'Deliberately left behind: ' }),
        document.createTextNode(dropped.length ? dropped.join('; ') : 'nothing')));
      return b;
    });
  }
  return out;
}

/**
 * Past decisions, collapsed and visibly INACTIVE. This is the direct fix for the
 * failure mode where an answered older design question still reads as open next
 * to a log full of implementation: a ticket has at most one live decision, and
 * everything else is history, drawn like history.
 */
function decisionHistoryCard(v) {
  const box = el('details', { class: 'tv-slot tv-slot-hist' });
  box.append(el('summary', { class: 'tv-slot-h' },
    el('h4', { class: 'tv-slot-t ph', text: 'Decisions already made' }),
    el('span', { class: 'tv-slot-n', text: `${v.decisionHistory.length} · settled` })));
  const body = el('div', { class: 'tv-slot-b' });
  for (const h of v.decisionHistory) {
    const item = el('div', { class: 'tvh-item' });
    item.append(el('div', { class: 'tvh-q', text: String(h?.question ?? NOT_RECORDED) }));
    item.append(el('div', { class: 'tvh-a' },
      el('span', { class: 'tvh-chosen', text: h?.chosen ? `chose ${h.chosen}` : 'no option recorded' }),
      el('span', { class: 'tvh-when', text: h?.chosen_on ? `on ${h.chosen_on}` : (h?.asked_on ? `asked ${h.asked_on}` : NOT_RECORDED) }),
      h?.chosen_by ? el('span', { class: 'tvh-by', text: `by ${h.chosen_by}` }) : null));
    if (h?.note) item.append(el('div', { class: 'tvh-note', text: String(h.note) }));
    body.append(item);
  }
  box.append(body);
  return box;
}

/**
 * The write half: note, reopen, 👤 flag. Every one of them is append-only or
 * logged. FEAT-063 split the PRESENTATION in two — `tools` (reopen + 👤 flag)
 * is a small right-aligned toolbar in the document header, `form` (the note
 * field + Append) is a plain form under the Activity log, deliberately NOT
 * shaped like the session composer. Both carry .tv-acts so the compact/modal
 * embed excludes every write control at once.
 */
function ticketActions(t, wrap) {
  const pid = tv.projectId;
  const msg = el('div', { class: 'tv-msg', hidden: true });

  const noteInput = el('textarea', {
    class: 'tv-note', rows: '3', 'aria-label': `Add a note to ${t.id}`,
    placeholder: `Add a note — appended to the Activity log, dated and attributed to you. Agents read this.`,
  });
  const noteBtn = el('button', { class: 'tv-btn solid', id: 'tvNoteBtn', type: 'button', text: 'Append note' });
  const reopenBtn = el('button', { class: 'tv-btn', id: 'tvReopenBtn', type: 'button', text: 'Reopen' });
  const flagBtn = el('button', {
    class: 'tv-btn', id: 'tvFlagBtn', type: 'button',
    text: t.needsYou ? 'Clear 👤' : 'Mark 👤',
    title: t.needsYou ? 'Clear needs-you (drops it off the rail)' : 'Mark needs-you (surfaces it on the rail)',
  });

  const show = (text, kind) => {
    msg.hidden = false;
    msg.className = `tv-msg ${kind}`;
    msg.textContent = text;
  };
  /* A write that lands, or a conflict that is stated rather than swallowed. */
  const afterWrite = async (r, what) => {
    if (r.board && r.board.fails?.length) {
      show(`${what}, but the board is now in drift: ${r.board.fails.join(' | ')}`, 'err');
    } else if (r.board && r.board.error) {
      show(`${what}, but INDEX.md could not be reconciled: ${r.board.error}`, 'err');
    } else {
      show(`${what} — board reconciled, board:check green.`, 'ok');
    }
    await loadTicketRows();
    const fresh = await api.ticket(pid, t.id);
    tv.current = fresh;
    const node = ticketDetailNode(fresh);
    node.querySelector('.tv-msg')?.replaceWith(msg);
    clear(tv.detail).append(node);
  };
  const onConflict = async (err, draft) => {
    if (err.status !== 409) { show(err.message, 'err'); return; }
    show('This ticket changed on disk while you were typing (an agent may be writing to it) — '
      + 'nothing was written. It has been reloaded below; your text is kept, re-read and retry.', 'err');
    const fresh = await api.ticket(pid, t.id);
    tv.current = fresh;
    const node = ticketDetailNode(fresh);
    node.querySelector('.tv-note').value = draft;
    clear(tv.detail).append(node);
    node.querySelector('.tv-msg')?.replaceWith(msg);
    node.querySelector('.tv-note').focus();
  };

  noteBtn.addEventListener('click', async () => {
    const text = noteInput.value.trim();
    if (!text) { noteInput.focus(); return; }
    noteBtn.disabled = true;
    try {
      const r = await api.ticketNote(pid, t.id, text, wrap.dataset.rev);
      await afterWrite(r, `note appended to ${t.id}`);
    } catch (err) {
      await onConflict(err, text);
    } finally { noteBtn.disabled = false; }
  });

  reopenBtn.disabled = t.section !== 'done';
  reopenBtn.title = t.section === 'done'
    ? 'Flip the Status header back to OPEN, log why, and let the board tool move the row'
    : 'This ticket is already open';
  reopenBtn.addEventListener('click', async () => {
    const reason = noteInput.value.trim();
    if (!reason) {
      show('Reopening records WHY in the ticket — write the reason in the note field first.', 'err');
      noteInput.focus();
      return;
    }
    reopenBtn.disabled = true;
    try {
      const r = await api.ticketReopen(pid, t.id, reason, wrap.dataset.rev);
      await afterWrite(r, `${t.id} reopened`);
    } catch (err) {
      await onConflict(err, reason);
    } finally { reopenBtn.disabled = false; }
  });

  flagBtn.addEventListener('click', async () => {
    flagBtn.disabled = true;
    try {
      const r = await api.ticketOwner(pid, t.id, !t.needsYou);
      await afterWrite(r, r.owner === '👤' ? `${t.id} marked 👤 — it is on the rail now` : `${t.id} unflagged`);
    } catch (err) {
      show(err.message, 'err');
    } finally { flagBtn.disabled = false; }
  });

  const tools = el('div', { class: 'tv-acts tv-tools' }, reopenBtn, flagBtn);
  const form = el('div', { class: 'tv-acts tv-noteform' },
    el('div', { class: 'tv-form-h', text: 'Add to the Activity log' }),
    noteInput,
    el('div', { class: 'tv-actrow' }, msg, noteBtn));
  return { tools, form };
}

/* ------------------------------------------------------------ file a ticket */

function openNewTicketForm() {
  tv.digest.hidden = true;
  tv.list.hidden = true;
  tv.filters.hidden = true;
  tv.detail.hidden = false;
  const prefix = el('select', { class: 'tv-sel' },
    ...['BUG', 'FEAT', 'ARCH', 'DEPLOY'].map((p) => el('option', { value: p, text: p })));
  const title = el('input', { class: 'tv-in', type: 'text', placeholder: 'Short title', 'aria-label': 'Ticket title' });
  const sev = el('select', { class: 'tv-sel' },
    ...['med', 'high', 'low'].map((s) => el('option', { value: s, text: s })));
  const area = el('input', { class: 'tv-in', type: 'text', placeholder: 'Area (server / UI / …)', 'aria-label': 'Area' });
  const summary = el('textarea', { class: 'tv-note', rows: '4', placeholder: 'What you saw / what you want. Verbatim is best.', 'aria-label': 'Summary' });
  const flag = el('input', { type: 'checkbox', id: 'tvNewFlag' });
  const msg = el('div', { class: 'tv-msg', hidden: true });
  const file = el('button', { class: 'tv-btn solid', id: 'tvFileBtn', type: 'button', text: 'File it' });
  const cancel = el('button', { class: 'tv-btn', type: 'button', text: 'Cancel' });
  cancel.addEventListener('click', () => navTickets(tv.projectId, null));
  file.addEventListener('click', async () => {
    if (!title.value.trim()) { title.focus(); return; }
    file.disabled = true;
    try {
      const r = await api.ticketCreate(tv.projectId, {
        prefix: prefix.value, title: title.value.trim(), severity: sev.value,
        area: area.value.trim(), summary: summary.value.trim(), needsYou: flag.checked,
      });
      await loadTicketRows();
      navTickets(tv.projectId, r.id);
      say(`filed ${r.id}`);
    } catch (err) {
      msg.hidden = false;
      msg.className = 'tv-msg err';
      msg.textContent = err.message;
      file.disabled = false;
    }
  });
  clear(tv.detail).append(el('div', { class: 'tv-doc tv-new' },
    el('h1', { class: 'tv-dtitle', text: 'File a ticket' }),
    el('p', { class: 'tv-dsub', text: 'Written from this project’s TEMPLATE.md (TEMPLATE-ARCH.md for ARCH). The id is allocated by the board tool’s rule — max existing + 1, never reused.' }),
    el('div', { class: 'tv-newrow' }, prefix, title),
    el('div', { class: 'tv-newrow' }, sev, area),
    summary,
    el('label', { class: 'tv-check' }, flag, el('span', { text: ' mark 👤 needs-you (surfaces it on the rail)' })),
    el('div', { class: 'tv-actrow' }, file, cancel),
    msg));
}

/* --------------------------------------------------------------- wiring */

// A project switch stays in the current view (the full list stays the full list,
// the digest stays the digest) rather than always dumping the user on the digest.
tv.project.addEventListener('change', () => navTickets(tv.project.value, null, { view: tv.view === 'all' ? 'all' : 'digest' }));
// FEAT-082 — the persistent "All tickets" control: in-place nav to the full list.
tv.allBtn.addEventListener('click', (e) => {
  if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
  e.preventDefault();
  navTickets(tv.projectId, null, { view: 'all' });
});
tv.search.addEventListener('input', () => {
  clearTimeout(tv.searchTimer);
  tv.searchTimer = setTimeout(() => {
    tv.q = tv.search.value.trim();
    void loadTicketRows().then(() => { if (!tv.ticketId) showTicketList(); });
  }, 180);
});
tv.search.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  e.preventDefault();
  clearTimeout(tv.searchTimer);
  tv.q = tv.search.value.trim();
  if (tv.ticketId) navTickets(tv.projectId, null);
  else void loadTicketRows();
});
for (const sel of [tv.status, tv.owner, tv.sev]) sel.addEventListener('change', renderTicketRows);
tv.newBtn.addEventListener('click', openNewTicketForm);
tv.home.addEventListener('click', () => { hideTickets(); });

let gitReturnHash = '#/';

async function showGit(route) {
  const entering = !gitView.isOpen();
  if (entering) {
    const back = currentRoute();
    gitReturnHash = back ? formatHash(back) : '#/';
  }
  const projectId = route.projectId || state.current.projectId || state.projects[0]?.id || null;
  document.title = 'Git — Orchard';
  await gitView.open({ projectId, view: route.view || 'changes' }, gitReturnHash);
}

function hideGit() {
  if (!gitView.isOpen()) return;
  gitView.close();
  paintTitle();
}

function navGit(projectId, { replace = false, view = 'changes' } = {}) {
  if (!projectId) return;
  const href = formatGitHash({ projectId, view });
  if (replace) window.history.replaceState(null, '', href);
  else window.history.pushState(null, '', href);
  void showGit({ projectId, view });
}

/**
 * A hash typed by hand, a link opened in a second tab, or Back/Forward — all
 * three land here. `popstate` alone would miss the first two.
 */
function onHashRoute() {
  // Guide, tickets and Git are mutually exclusive sibling overlays. Resolve
  // each before the session parser and always drop the other two.
  const g = parseGuideHash(location.hash);
  if (g) { hideTickets(); hideGit(); void showGuide(g); return true; }
  hideGuide();
  const t = parseTicketsHash(location.hash);
  if (t) { hideGit(); void showTickets(t); return true; }
  hideTickets();
  const git = parseGitHash(location.hash);
  if (git) { void showGit(git); return true; }
  hideGit();
  return false;
}
window.addEventListener('hashchange', onHashRoute);

/* ------------------------------------------------------------------- boot */

/* -------------------------------------------------------------- url state */
/*
 * The URL is a mirror of {project, session, dir, top-visible message, agent
 * thread}, and the ONLY navigation state that survives a reload. Discipline:
 * push when opening a different session or project (a place Back should
 * return to), replace for scroll drift and thread switches (which must not
 * spam history). See lib/route.js for why hash and what the fields mean.
 */

const nav = { applying: false, scrollTimer: null };

function currentRoute() {
  const { projectId, sessionId, encodedDir } = state.current;
  if (!projectId) return null;
  if (!sessionId) return { projectId };
  const th = mainThread();
  const agent = state.viewing !== 'main' ? state.viewing : null;
  // At the bottom, the URL says nothing about position: a reload should land
  // where a fresh open lands — the newest page. Parked anywhere else (scrolled
  // up, or a restore still owing newer messages), remember the top message.
  // While an agent pane covers the main pane its geometry is unreadable, so
  // the last written `i` is carried forward instead of recomputed.
  let i = null;
  if (state.viewing === 'main') {
    if (th.stick === false || th.gap) i = topVisibleIndex(th);
  } else {
    const prev = parseHash(location.hash);
    if (prev?.sessionId === sessionId) i = prev.i;
  }
  return { projectId, sessionId, dir: encodedDir ?? null, i, agent };
}

function syncUrl(mode = 'replace') {
  if (nav.applying) return; // navigation is being driven BY the URL right now
  const r = currentRoute();
  if (!r) return;
  const prev = parseHash(location.hash);
  if (sameRoute(prev, r)) return;
  const hash = formatHash(r);
  const newPlace = !prev || prev.projectId !== r.projectId || prev.sessionId !== (r.sessionId ?? null);
  if (mode === 'push' && newPlace) window.history.pushState(null, '', hash);
  else window.history.replaceState(null, '', hash);
  paintTitle();
}

/**
 * The tab title is the multi-tab dashboard's cheapest signal: which session
 * this is, and — via the leading dot — whether Claude is working in it right
 * now, readable from a squeezed tab strip without switching.
 */
function paintTitle() {
  const name = state.current.title;
  document.title = `${state.busy ? '● ' : ''}${name ? `${name} — Claude Station` : 'Claude Station'}`;
}

/** Trailing-debounced replace — scroll fires far too often to write through. */
function syncUrlSoon() {
  clearTimeout(nav.scrollTimer);
  nav.scrollTimer = setTimeout(() => syncUrl('replace'), 400);
}

/**
 * Drive the view to what a route names. Returns false ONLY when the project
 * id is unknown (caller falls back to the default view); every other outcome
 * — including a session that is not there — leaves a deliberate, honest view
 * behind and returns true. A missing session must NOT silently become a new
 * session: that silence was the original bug.
 */
async function applyRoute(route) {
  if (!route) return false;
  const p = state.projects.find((x) => x.id === route.projectId);
  if (!p) return false;
  nav.applying = true;
  try {
    state.expanded.add(p.id);
    saveExpanded();
    if (!route.sessionId) {
      startNew(p.id);
      return true;
    }
    const s = await loadSessions(p.id);
    const matches = (s.list ?? []).filter((x) => x.sessionId === route.sessionId);
    const sess = route.dir
      ? matches.find((x) => x.encodedDir === route.dir)
      : (matches.length === 1 ? matches[0] : null);
    if (!sess) {
      selectProject(p.id, { quiet: true });
      resetOverrides(OVR_NONE); // BUG-198 round 2 — no session here: owns nothing, never adopted (selectProject no longer clears)
      state.current = { projectId: p.id, encodedDir: null, sessionId: null, title: null, os: null };
      followCurrent(false);
      clearPendingDelivery(); // BUG-079: a link that resolves to no session is still a boundary
      closeSocket();
      resetTranscript();
      renderTree();
      const why = matches.length > 1
        ? ` The id ${route.sessionId.slice(0, 8)}… exists in ${matches.length} history folders and the link does not say which (no dir=) — open it from the sidebar instead.`
        : ` No session ${route.sessionId.slice(0, 8)}… under “${p.name}”. It may have been deleted, or the link may be wrong.`;
      mainThread().paneEl.append(el('div', { class: 'hint-row' },
        el('b', { text: 'This link points to a session that is not here.' }),
        document.createTextNode(why)));
      say('session in the URL not found', true);
      window.history.replaceState(null, '', formatHash({ projectId: p.id }));
      return true;
    }
    await openSession(p, sess, { at: route.i, agent: route.agent });
    return true;
  } finally {
    nav.applying = false;
  }
}

window.addEventListener('popstate', () => {
  // FEAT-058: the ticket dashboard is a sibling route — Back/Forward across it
  // must be handled BEFORE the session route parser, which would read a
  // `#/tickets…` hash as "no route" and leave the overlay stranded.
  // FEAT-075: the guide overlay is a sibling route — handle Back/Forward across
  // it before the session parser, which would read `#/guide…` as "no route".
  if (location.hash.startsWith('#/guide')) {
    hideTickets();
    hideGit();
    void showGuide(parseGuideHash(location.hash) ?? {});
    return;
  }
  hideGuide();
  if (location.hash.startsWith('#/tickets')) {
    hideGit();
    void showTickets(parseTicketsHash(location.hash) ?? {});
    return;
  }
  hideTickets();
  if (location.hash.startsWith('#/git')) {
    void showGit(parseGitHash(location.hash) ?? {});
    return;
  }
  hideGit();
  const r = parseHash(location.hash);
  if (!r) return;
  const cur = currentRoute();
  // Within the same session only position/thread changed — move in place
  // rather than re-opening (a re-open would reset scroll AND cost a fetch).
  if (cur && r.projectId === cur.projectId && r.sessionId && r.sessionId === cur.sessionId) {
    nav.applying = true;
    try {
      const th = mainThread();
      if ((r.agent ?? null) !== (cur.agent ?? null)) {
        if (r.agent && state.threads.has(r.agent)) void viewAgent(r.agent);
        else if (!r.agent) backToMain();
      } else if (Number.isInteger(r.i)) {
        scrollToIndex(th, r.i);
      } else if (!th.gap) {
        scrollToBottom(th);
      }
    } finally { nav.applying = false; }
    return;
  }
  void applyRoute(r);
});

async function boot() {
  // BUG-158: the shell (HTML/CSS) is painted by the browser well before this
  // runs, but the sidebar tree stays empty until the project list arrives. Show
  // a quiet loading row FIRST so a reload never looks frozen while that request
  // is in flight; loadProjects() → renderTree() replaces it with the real tree.
  node.tree.append(el('div', { class: 'hint-row', text: 'loading projects…' }));
  try {
    await loadProjects();
  } catch (err) {
    node.tree.textContent = ''; // drop the "loading projects…" row
    node.tree.append(el('div', { class: 'hint-row', text: `the server is not answering: ${err.message}` }));
    return say(err.message, true);
  }
  renderRail(); // paint the quiet empty rail immediately; refreshRail fills it per project
  await drawer.ensureTemplates(); // FEAT-139: prewarm the template list (its count now shows inside Settings → Machine, not the removed sidebar door)
  loadExpanded(); // the user's working set of open projects survives reloads
  loadSeen();
  loadMarks(); // FEAT-118 — read-marks and bookmarks survive a reload
  // A project restored as expanded must get its list NOW — without this its
  // kids sit empty until the background sweep happens to reach it.
  for (const id of state.expanded) if (state.projects.some((p) => p.id === id)) void loadSessions(id);
  if (state.projects.length) {
    // The URL is the first authority on what to show: a reload or a shared
    // link lands back on ITS session, not on a fresh default view.
    const route = parseHash(location.hash);
    const restored = route ? await applyRoute(route) : false;
    if (!restored) {
      const first = state.projects[0];
      state.expanded.add(first.id);
      selectProject(first.id, { quiet: true });
      state.current.title = null;
      paintCrown();
      renderTree();
      await loadSessions(first.id);
      if (route) {
        // A route existed but named a project this registry does not have —
        // say so instead of quietly showing something else.
        mainThread().paneEl.append(el('div', { class: 'hint-row' },
          el('b', { text: 'This link points to a project that is not registered here' }),
          document.createTextNode(` (${route.projectId}). Showing your projects instead.`)));
        say('project in the URL not found', true);
        window.history.replaceState(null, '', location.pathname);
      }
    }
  } else {
    renderTree();
    say('No projects registered yet.');
  }
  // Follow sessions other processes are writing, and mark them in the sidebar.
  // Both degrade to nothing if the server half is not there: the watch socket
  // simply never receives `session-appended`, and the live route 404s once and
  // is never asked again.
  watch();
  startLivePolling();
  startProcPolling();
  startUsagePolling(); // FEAT-116 — provider rate-limit window readout
  // BUG-034: the strip's correcting poll, and FEAT-057's death ledger — both
  // are server-authored and both must be right on a FRESH LOAD with no socket
  // and no orchestrator turn, so they are fetched at boot, not on first event.
  startRunningPolling();
  void pollRunning();
  void refreshOutcomes();
  // The server remembers the last slash-command list any session reported —
  // so "/" works in a fresh browser profile, before this browser's first
  // session-init. localStorage stays as the offline fallback.
  void api.slashCommands().then((cmds) => {
    if (Array.isArray(cmds) && cmds.length) {
      state.slashCommands = cmds;
      try { localStorage.setItem('cs-slash', JSON.stringify(cmds)); } catch { /* volatile */ }
    }
  }).catch(() => { /* route absent or transient — cache already loaded */ });
  // Same for models: the CLI's names carry the versions the picker must show.
  void api.models().then(adoptModelList).catch(() => { /* fallback list stands */ });
  // Background-load every project's session list: the unseen badges and
  // per-project live dots need the lists to say anything about COLLAPSED
  // projects, and the search index warms for free. Fire-and-forget — the
  // first paint above never waits on it.
  void loadAllSessions();
  paintSessStatus();
  // FEAT-058: a tab opened straight on `#/tickets…` (a second tab, a bookmark,
  // a link the orchestrator handed over) shows the dashboard over the normal
  // boot — the session view underneath stays fully alive, which is what makes
  // the "read a ticket in one tab, talk to the orchestrator in the other"
  // workflow work.
  if (location.hash.startsWith('#/tickets') || location.hash.startsWith('#/guide') || location.hash.startsWith('#/git')) onHashRoute();
  window.__station = {
    state, drawer, api, loadSessions, renderTree, onEvent, startTurn, viewAgent, showThread,
    // BUG-100: footer (#fine) internals, so a verify script can drive the real
    // status/turn-end paths and assert the isolation label is never displaced by
    // raw command text and that every item stays within the hard length cap.
    isoLabel, restLabel, runningAgentCount, truncFine, MAX_FINE, currentProject,
    backToMain, applyAppend, refreshLive, menu, visibleSessions, rowTitle,
    // FEAT-154: the session-row builder + its ground-truth lifecycle resolver,
    // exposed so a verify script can drive the REAL state→indicator mapping and
    // the waiting > running > error > finished > idle precedence directly.
    sessionRow, sessionLifecycle,
    // FEAT-070: project ordering + session recency-window internals, so a verify
    // script can drive the sort/toggle and the window without re-deriving them.
    orderedProjects, resortProjects, toggleProjSort, paintProjSort,
    withinRecentWindow, isAlwaysVisible, isAttentionSession, hasLiveWork,
    isBriefSession, hoursSince, SUBSTANTIAL_MSGS, MIN_SEATS, MAX_SEATS, RECENT_SEAT_H,
    // session-list-recency: order by last USER submit, not mtime. `recencyKey`
    // is the sort key; `stampUserSubmit`/`orderedSessions` let a verify assert
    // agent activity does NOT reorder while a human submit does.
    orderedSessions, recencyKey, stampUserSubmit,
    // BUG-067: the transcript renderer + its main-thread accessor, exposed so a
    // verify script can render a fixture transcript and assert on which entries
    // become user bubbles vs collapsed system notices.
    renderMessages, mainThread, harnessNotice, stampTime,
    // BUG-177: the failed-quality-gate banner + per-turn badge pass, exposed so a
    // verify script can drive the REAL server's hookErrors roll-up through the
    // real render and assert the banner is present, classified, and readable.
    mountHookErrorBanner, applyHookBadges,
    // BUG-168: the briefing-prefix peel — the terminator literal + the legacy
    // heuristic split, exposed so a verify script can assert the new/legacy/
    // board-snapshot/empty-body splits directly and the mid-prose "[station]" case.
    BRIEFING_TERMINATOR, legacyBriefingSplit,
    // FEAT-083: the structured response-digest renderer + its enable check, so a
    // verify script can render the four fixtures (well-formed / none / malformed
    // / disabled) through the real render path and assert on the resulting DOM.
    assistantProse, digestEnabled,
    // FEAT-072: the queued-metadata detector, exposed so a verify script can
    // assert the prefix/body split (and non-matching brackets) directly.
    queuedCaption,
    // BUG-081: the model-change/refusal-fallback notice render site + its live
    // SSE entry point, exposed so a verify script can drive the authentic
    // dispatch and assert the notice renders as a distinct accented chip.
    flagModelChange, modelChangeMark,
    // Override-lifecycle internals, exposed read-only-in-spirit for verify scripts
    // (e.g. scripts/verify-new-session-overrides.mjs) to arm/inspect session
    // overrides the same way the model popover and skip-perms toggle do.
    persistOverrides, paintModelBtn, paintModelPop, sessionOverrides,
    refreshRail, renderRail,
    // FEAT-153: the board grid + answer mount, so a verify script can drive the
    // real grid render, the current-session partition, and the click→answer flow.
    renderBoardGrid, boardGridModel, currentSessionTicketIds, openAnswer, closeAnswer,
    // BUG-139: the crown git chip's painter, so a verify script can assert the
    // EXACT rendered text for status payloads the live server cannot easily be
    // made to produce — chiefly a STALE server whose response predates the
    // added/removed fields entirely, which is what rendered "+undefined".
    paintGitChip,
    // FEAT-058: the ticket dashboard's internals, so a verify script can drive
    // the route and assert on what it rendered without re-deriving the rules.
    // `ticketDetailNode` is the REUSABLE renderer FEAT-053's modal should call.
    tv, showTickets, navTickets, loadTicketRows, ticketDetailNode,
    // The redesign (docs/analysis/ticket-board-redesign-plan.md): the view model
    // that normalises a migrated record and a legacy prose ticket into one shape,
    // exposed so a verify script can assert what the BANDS were built from
    // without re-deriving the format rules from the markdown itself.
    ticketView,
    // FEAT-082: the digest landing internals, so a verify script can assert on
    // what awaits the user without racing the parallel board+tickets fetch.
    showDigest, renderDigest, ticketType,
    // FEAT-075: the in-app guide reader's internals, so a verify script can
    // drive the route and assert on the rendered page + mermaid without racing.
    gv, showGuide, navGuide, hideGuide, renderGuideDoc,
    // FEAT-053: the rail ticket modal, FEAT-051: the integrations strip —
    // exposed so verify scripts drive them without re-deriving the rules.
    openTicketModal, closeTicketModal, ticketModalOpen,
    paintIntegrations, plannedServers, liveAttachedServers,
    // BUG-016: expose the poll loop internals so verify scripts can force an
    // immediate cycle instead of sleeping out the full RAIL_POLL_MS.
    pollRail, RAIL_POLL_MS,
    /*
     * ARCH-001 phase 2 / BUG-034 + FEAT-057: the renderer's whole surface, so a
     * verify script can force a reconciliation cycle (instead of sleeping out
     * SNAP_POLL_MS) and can compare what the STRIP shows against what the
     * SERVER said — which is the only assertion that actually proves this fix.
     */
    pollRunning, applySnapshot, stripModel, renderStrip, SNAP_POLL_MS,
    // BUG-106 — the selectProject boundary + the dock's session-bound surfaces and
    // the foreign-view predicate, so a verify script can drive a real sidebar
    // project switch and assert the strip / hairline / live-count re-scope (and
    // that switching back restores them) without re-deriving the rules.
    selectProject, dockIsForeign, paintPerm, renderRailSummary,
    refreshOutcomes, renderOutcomes, outcomesHeadline,
    refreshPending, renderPending, pendingHeadline, processPending, dismissPending, showPendingBundle, // ARCH-017
    // FEAT-118 — session-list lifecycle markers + within-session read-mark and
    // manual bookmark, exposed so a verify script can drive the real fold/row
    // render and the real transcript marks (seed/advance/paint/jump/toggle)
    // instead of re-deriving the rules.
    sessionLifecycle, endedUnanswered, recentlyVisited, sessionRow,
    seedReadMark, advanceReadMark, paintReadLine, paintMarks, paintBookmark,
    jumpToReadLine, toggleBookmark, maxRenderedIndex, FINISHED_WINDOW_MS,
    // BUG-017: openSession() runs synchronously up to its first `await`
    // (closeSocket() included) before returning its promise — exposing it lets
    // a verify script set `state.live = true` right after calling it, landing
    // deterministically DURING the pending fetches, the same window a real
    // concurrent connect() would race into. Without this hook there is no way
    // to construct the exact "state.live true while liveRecordFor runs" case
    // from outside the module.
    openSession,
    // BUG-083: the new-session boundary + the per-project/session draft
    // machinery, so a verify script can drive a real switch and assert that a
    // draft is saved under its own key and restored on return (never carried).
    startNew, draftKey, saveDraft, restoreDraft,
    // BUG-087 / FEAT-074: the add-project open path, so a verify script can drive
    // a real add-project switch and assert the transcript pane + sidebar surface.
    addProject,
    // FEAT-040: session-status ground truth, for verify scripts to assert
    // against without re-deriving the priority rules themselves.
    // BUG-153: `isDriving` alongside them, so a script can assert the CHIP and
    // the GUARDS agree — the property whose absence was the bug — rather than
    // testing each half against its own idea of liveness.
    computeSessState, paintSessStatus, isDriving,
    // BUG-075: the crown/seal renderer, so a verify script can drive it against
    // a container vs direct project and assert the "+ Add mount" chip is gated
    // on isolation (same ground truth as the Direct/Container chip beside it).
    paintCrown,
    // BUG-082: the proc chip's capped-preview + full-port popover internals,
    // so a verify script can inject N>cap ports and assert the inline cap/+N,
    // the :4317-first stable order, and the popover's full list.
    paintProcChip, paintProcPop, orderedPorts, closePops,
    // FEAT-048: survival ground truth on the hover — exposed so a verify
    // script can await the lazy fetch deterministically instead of racing a
    // real mouseenter.
    refreshSessSurvival, survivalHintLine,
    // FEAT-022: autonomous-mode controls + mirror, for verify scripts.
    startAutonomous, stopAutonomous, refreshAuto, paintAuto,
    // FEAT-042: model-chip internals, so the spec can assert the live report /
    // expectation without re-deriving them from the DOM.
    paintModelChip,
    modelChipInfo: () => ({
      wire: liveWireModel,
      expected: expectedLiveModel,
      flagged: node.modelChip?.dataset.flag === 'true',
    }),
    // BUG-106 clean-room — the full set of surfaces that read the open session's
    // LIVE state, exposed so scripts/verify-bug-106-crossproject-strip.mjs can
    // enumerate every one of them and prove none leaks A's live work under a
    // foreign selection B. dockSnap/dockLive/dockEffective/dockLiveTools/
    // dockLiveModel are the SINGLE gate the paint surfaces route through.
    providerView, paintProvBtn, projectDot, effectivePerm,
    // BUG-196 — the transcript-owned resume engine + the selector's refusal path,
    // exposed so a browser suite can drive the real openSession→lockedProvider flow
    // and assert the per-session indicator shows the real engine and the selector
    // refuses a switch (vs a fresh session, which is switchable).
    lockedSessionProvider, pickProvider, paintProvPop,
    // BUG-196 round 3 — the id-keyed pin store (read by id; written only from
    // server declarations), exposed so the suite can synthesize the pre-fix state.
    lockedProviderOf, declareLockedProvider, lockedProviders,
    // BUG-196 round 5 — the ONE guard every provider write asks (drawer included).
    providerSwitchRefusal,
    // BUG-196 round 6 — the ONE engine state every provider surface paints from.
    sessionEngine, paintProvSurfaces,
    // BUG-196 round 2 — the REAL live-event dispatcher, so a browser suite can
    // drive the session-init frame (the new-session-first-turn / reattach entry
    // path that never goes through openSession's transcript fetch) and assert the
    // provider surfaces lock without re-deriving the handler.
    onEvent,
    // FEAT-145 — the launch-surface Claude-account control, so a browser suite
    // can drive the real pick/paint path (container lock, per-account window)
    // instead of re-deriving it. `setAccountsForTest` injects the account list
    // the server would have returned.
    paintAccountSel, paintAcctPop, pickAccount, accountLockedReason, acctUsageDesc, claudeAccountView,
    setAccountsForTest: (list) => { ACCOUNTS = list; },
    dockSnap, dockLive, dockEffective, dockLiveTools, dockLiveModel,
    // BUG-129: the queue's durability surface — so a verify script can drive
    // the REAL accept/persist/restore path (rather than re-deriving the storage
    // shape from the outside) and read back the exact key it writes under.
    queueMessage, paintQueue, adoptQueue, persistQueue, flushQueue, QUEUE_KEY,
    // BUG-217: the not-driving delivery owner, so a verify can drive it directly.
    driveQueue,
    // BUG-150: resetTranscript is the single owner of the queue↔session binding
    // (it re-adopts on every exit path), exposed so a verify script can assert
    // ownership is never left null and can detect a synthesized pre-fix client.
    resetTranscript,
    queueOwnerKey: () => queueKey, // which session's rows state.queue currently mirrors (null = none)
    // BUG-166: the composer-send entry point + the pending-decision owner + the
    // question renderer, so a verify script can render a REAL AskUserQuestion
    // card and drive the REAL submit()/computeSessState paths against it — the
    // lockout + mislabel — rather than re-deriving the busy-vs-awaiting rule.
    submit, awaitingUserDecision, renderQuestion, settleDecisionFromResult,
  };
}

await boot();
