/**
 * BUG-217 — THE DELIVERED-ROW LEDGER.
 *
 * The one fact every tab kept working out for itself — "has this queued row
 * already reached the session?" — is declared here, by the only party that
 * knows it: the server, at the moment it hands a prompt to the CLI. A tab asks;
 * it never infers the answer from transcript text or from another tab's
 * localStorage entry (ARCH-010: whoever owns a fact writes it down).
 *
 * A queued row carries an id minted when the row is created. A `start` or
 * `send` frame that delivers queued rows carries their ids, and the socket
 * handler CLAIMS them synchronously, before any await, so two frames carrying
 * one id cannot both get through. A claim is then settled exactly once:
 *   - delivered — the prompt was handed over. Permanent.
 *   - released  — it was not handed over (refused, re-attached behind a running
 *     turn, the socket had no session). The id is free again.
 *   - uncertain — handed over with no confirmation. Never re-sent automatically;
 *     only the user's explicit "Send anyway" (`force`) may claim it again.
 * `discarded` is the user withdrawing a row: a later automatic send of that id —
 * from a tab that has not heard yet — is refused.
 *
 * ── Round 4: ABSENCE IS NOT EVIDENCE ─────────────────────────────────────────
 * Round 3 read "no record of this id" as "never delivered". But the ledger can
 * forget (it is capped, a file can be lost), so a forgotten delivered row read
 * `none` and went to the CLI a second time. Now the ledger says what it still
 * reliably remembers, and absence counts only inside that span:
 *   - every row id carries its birth time (`qt-<ms base36>-<random>`, minted by
 *     the tab; `queueNow` on the frame/request lets the server put that time on
 *     its own clock);
 *   - each scope keeps a HORIZON: nothing born after it has been forgotten.
 *     Evicting an entry raises the horizon to that entry's time (compared with a
 *     margin for clock error). Below that sits a FLOOR: the ledger EPOCH (when
 *     this data dir's ledger began), or the moment an unreadable file was set
 *     aside;
 *   - an absent id born after both is `none`. Otherwise — born before it, or birth unknown (an id without a
 *     time, a request without `queueNow`) — it is `uncertain`: shown to the user
 *     with Send anyway / Discard, never sent on its own.
 * So eviction can never turn a delivered row into `none`: it can only make an
 * old row ask the user.
 *
 * Scope: one ledger per SESSION (`s:<session id>`), or per PROJECT for a
 * session that has no id yet (`p:<project id>`, a fresh start). A session's
 * lookups also read its project's scope, where its first rows may have been
 * claimed. A flood aimed at one scope can only age out that scope's own rows.
 *
 * Expiry: a claim nobody settles within IN_FLIGHT_TTL_MS READS as `uncertain`
 * (never as free — a slow container start may still hand it over).
 *
 * Durability: the claim is written to disk BEFORE the handover, and a claim
 * still in-flight when the server starts again (it died mid-handover) loads as
 * `uncertain`. If that write fails, the claim is refused (`uncertain`): nothing
 * is handed over that the ledger could forget.
 */
import * as path from 'node:path';
import * as fs from 'node:fs';
import { dataDir, writeAtomic } from '../lib/paths.ts';

export type LedgerState = 'in-flight' | 'delivered' | 'uncertain' | 'discarded';
export type LedgerAnswer = LedgerState | 'none';

export const IN_FLIGHT_TTL_MS = 5 * 60_000;
/** Entries kept per scope. Past this the oldest settled entries go, and the horizon rises to cover them. */
export const SCOPE_CAP = 2_000;
/** Slack on the birth-vs-horizon comparison: the tab's clock is only known to within one request's latency. */
export const BIRTH_MARGIN_MS = 5_000;
const ID_RE = /^[A-Za-z0-9_.:-]{4,80}$/;
const SCOPE_RE = /^[sp]:[A-Za-z0-9._-]{1,128}$/;

interface Entry { s: LedgerState; at: number; tok?: symbol }
/*
 * `horizon`: the latest entry this scope evicted (checked with the clock margin).
 * `floor`: when this scope began remembering at all — the epoch, or the moment an
 * unreadable file was set aside. Nothing can have been delivered into a scope
 * before it began, short of a clock-estimate error, so no margin applies there.
 */
interface Scope { key: string; horizon: number; floor: number; entries: Map<string, Entry> }
/** Which scope a claim is written to, and which other scope a lookup also reads. */
export interface LedgerScope { write: string; also?: string | null }

let store: { dir: string; epoch: number; scopes: Map<string, Scope> } | null = null;

function root(): string { return path.join(dataDir(), 'queue-ledger'); }

/** The ledger's in-memory state for the current data dir; the epoch is fixed the first time the dir is used. */
function ledger() {
  const dir = root();
  if (store?.dir === dir) return store;
  const f = path.join(dir, 'epoch.json');
  let epoch = NaN;
  try { epoch = Number(JSON.parse(fs.readFileSync(f, 'utf8'))?.epoch); } catch { /* absent or unreadable */ }
  if (!Number.isFinite(epoch) || epoch <= 0) {
    // No epoch (a new data dir, an upgrade, or a lost ledger): nothing before now is remembered.
    epoch = Date.now();
    try { writeAtomic(f, JSON.stringify({ epoch })); } catch (err) {
      console.warn(`[orchard] BUG-217: could not write the queue-ledger epoch (${(err as Error).message})`);
    }
  }
  store = { dir, epoch, scopes: new Map() };
  return store;
}

/** Start the ledger's memory now (server boot), so its epoch predates every row a tab composes after it. */
export function initQueueLedger(): void { ledger(); }

export function validScope(key: unknown): key is string {
  return typeof key === 'string' && SCOPE_RE.test(key) && !key.includes('..');
}

function scopeFile(key: string): string { return path.join(root(), `${key.replace(':', '_')}.json`); }

function scope(key: string): Scope {
  const l = ledger();
  const hit = l.scopes.get(key);
  if (hit) return hit;
  const sc: Scope = { key, horizon: 0, floor: l.epoch, entries: new Map() };
  const f = scopeFile(key);
  let text: string | null = null;
  try { text = fs.readFileSync(f, 'utf8'); } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') sc.floor = Date.now(); // cannot read what it remembers: remember nothing before now
  }
  if (text !== null) {
    try {
      const raw = JSON.parse(text) as { horizon?: unknown; floor?: unknown; entries?: Record<string, { s?: unknown; at?: unknown }> };
      if (typeof raw?.horizon === 'number' && raw.horizon > sc.horizon) sc.horizon = raw.horizon;
      if (typeof raw?.floor === 'number' && raw.floor > sc.floor) sc.floor = raw.floor;
      for (const [id, e] of Object.entries(raw?.entries ?? {})) {
        if (!ID_RE.test(id) || !e || typeof e.at !== 'number') continue;
        // A claim left in-flight by a previous process died mid-handover: it may have arrived.
        if (e.s === 'in-flight') sc.entries.set(id, { s: 'uncertain', at: e.at });
        else if (e.s === 'delivered' || e.s === 'uncertain' || e.s === 'discarded') sc.entries.set(id, { s: e.s, at: e.at });
      }
    } catch {
      sc.floor = Date.now();
      try { fs.renameSync(f, `${f}.corrupt-${Date.now()}`); } catch { /* leave it; the horizon already covers it */ }
      console.warn(`[orchard] BUG-217: queue ledger ${key} was unreadable — rows older than now will ask before sending`);
    }
  }
  l.scopes.set(key, sc);
  return sc;
}

/** Write a scope; false when the disk refused. Over the cap, the oldest settled entries go and the horizon rises past them. */
function persist(sc: Scope): boolean {
  if (sc.entries.size > SCOPE_CAP) {
    const settled = [...sc.entries].filter(([, e]) => e.s !== 'in-flight').sort((a, b) => a[1].at - b[1].at);
    for (const [id, e] of settled) {
      if (sc.entries.size <= SCOPE_CAP) break;
      sc.entries.delete(id);
      if (e.at > sc.horizon) sc.horizon = e.at;
    }
  }
  const f = scopeFile(sc.key);
  try {
    if (!sc.entries.size && !sc.horizon && sc.floor <= ledger().epoch) {
      // Nothing to remember: no file and no memory (claims under a made-up session leave no litter).
      // Safe to drop — an open lease always holds an in-flight entry, so no lease still points here.
      ledger().scopes.delete(sc.key);
      fs.rmSync(f, { force: true });
      return true;
    }
    const entries: Record<string, { s: LedgerState; at: number }> = {};
    for (const [id, e] of sc.entries) entries[id] = { s: e.s, at: e.at };
    writeAtomic(f, JSON.stringify({ horizon: sc.horizon, floor: sc.floor, entries }));
    return true;
  } catch (err) {
    console.warn(`[orchard] BUG-217: could not persist queue ledger ${sc.key} (${(err as Error).message})`);
    return false;
  }
}

/** A row id's birth time on the TAB's clock, or null when the id carries none. */
export function queueRowBirth(id: string): number | null {
  const m = /^qt-([0-9a-z]{6,10})-/.exec(id);
  if (!m) return null;
  const t = parseInt(m[1], 36);
  return Number.isFinite(t) ? t : null;
}

interface Ctx { sc: Scope; also: Scope | null; now: number; skew: number | null }
function ctxOf(where: LedgerScope, clientNow: unknown): Ctx {
  const now = Date.now();
  return {
    sc: scope(where.write),
    also: where.also && where.also !== where.write && validScope(where.also) ? scope(where.also) : null,
    now,
    // No usable tab clock (absent, 0 from an empty query param, garbage): no birth can be placed.
    skew: typeof clientNow === 'number' && Number.isFinite(clientNow) && clientNow > 0 ? now - clientNow : null,
  };
}

function current(id: string, c: Ctx): LedgerAnswer {
  const e = c.sc.entries.get(id) ?? c.also?.entries.get(id);
  if (e) return e.s === 'in-flight' && c.now - e.at > IN_FLIGHT_TTL_MS ? 'uncertain' : e.s;
  // Absent. That is evidence only for a row born after everything this scope has forgotten.
  const born = queueRowBirth(id);
  if (born === null || c.skew === null) return 'uncertain';
  const b = born + c.skew;
  return b > Math.max(c.sc.floor, ledger().epoch) && b > c.sc.horizon + BIRTH_MARGIN_MS ? 'none' : 'uncertain';
}

/** Well-formed ids from an untrusted frame field, or null when the frame carries none. */
export function queueIdsOf(v: unknown): string[] | null {
  if (!Array.isArray(v)) return null;
  const ids = [...new Set(v.filter((x): x is string => typeof x === 'string' && ID_RE.test(x)))];
  return ids.length ? ids.slice(0, 200) : null;
}

export interface Lease {
  readonly ids: string[];
  /** True until settled. */
  readonly open: boolean;
  delivered(): void;
  release(): void;
  uncertain(): void;
}

/**
 * Claim every id or none. Synchronous — call it before any await in the
 * handler, which is what makes the claim atomic across sockets. `force` (the
 * user's explicit "Send anyway") may re-claim an `uncertain` id; nothing may
 * re-claim a delivered, discarded or live in-flight one.
 */
export function claimQueueIds(where: LedgerScope, ids: string[], { force = false, clientNow }: { force?: boolean; clientNow?: unknown } = {}):
  | { ok: true; lease: Lease }
  | { ok: false; states: Record<string, LedgerAnswer>; unwritable?: boolean } {
  if (!validScope(where.write)) return { ok: false, states: Object.fromEntries(ids.map((id) => [id, 'uncertain' as const])) };
  const c = ctxOf(where, clientNow);
  const free = (a: LedgerAnswer) => a === 'none' || (force && a === 'uncertain');
  if (!ids.every((id) => free(current(id, c)))) {
    return { ok: false, states: Object.fromEntries(ids.map((id) => [id, current(id, c)])) };
  }
  const sc = c.sc;
  const tok = Symbol('claim');
  for (const id of ids) sc.entries.set(id, { s: 'in-flight', at: c.now, tok });
  if (!persist(sc)) {
    // Not on disk, so a crash after the handover would forget it: hand nothing over.
    for (const id of ids) if (sc.entries.get(id)?.tok === tok) sc.entries.delete(id);
    return { ok: false, unwritable: true, states: Object.fromEntries(ids.map((id) => [id, 'uncertain' as const])) };
  }
  let open = true;
  const settle = (s: 'delivered' | 'uncertain' | null) => {
    if (!open) return;
    open = false;
    for (const id of ids) {
      const e = sc.entries.get(id);
      if (!e || e.tok !== tok) continue; // re-claimed by a forced send since — not ours to settle
      if (s) sc.entries.set(id, { s, at: Date.now() }); else sc.entries.delete(id);
    }
    persist(sc); // a failed write leaves the on-disk in-flight claim, which reloads as uncertain
  };
  return {
    ok: true,
    lease: {
      ids,
      get open() { return open; },
      delivered: () => settle('delivered'),
      release: () => settle(null),
      uncertain: () => settle('uncertain'),
    },
  };
}

/** What the server knows about each id. `none` only for a row born after everything this scope has forgotten. */
export function queueLedgerStatus(where: LedgerScope, ids: string[], clientNow?: unknown): Record<string, LedgerAnswer> {
  if (!validScope(where.write)) return Object.fromEntries(ids.map((id) => [id, 'uncertain' as const]));
  const c = ctxOf(where, clientNow);
  return Object.fromEntries(ids.map((id) => [id, current(id, c)]));
}

/**
 * The user withdrew these rows. An id nobody has taken becomes `discarded`, so
 * a tab that has not heard yet cannot send it; the answer is each id's state
 * BEFORE the discard, so the caller can say "that one had already been sent".
 */
export function discardQueueIds(where: LedgerScope, ids: string[], clientNow?: unknown): Record<string, LedgerAnswer> {
  if (!validScope(where.write)) return Object.fromEntries(ids.map((id) => [id, 'uncertain' as const]));
  const c = ctxOf(where, clientNow);
  const before = Object.fromEntries(ids.map((id) => [id, current(id, c)]));
  let changed = false;
  for (const id of ids) if (before[id] === 'none') { c.sc.entries.set(id, { s: 'discarded', at: c.now }); changed = true; }
  if (changed) persist(c.sc);
  return before;
}
