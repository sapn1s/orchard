/**
 * BUG-217 round 5 — THE SERVER-OWNED OUTBOX.
 *
 * A message the user queues is a ROW this module minted and wrote to disk
 * before it answered the POST. Only this module moves a row, and every move is
 * on disk before it takes effect:
 *
 *   queued ──► sending ──► delivered
 *     ▲  │          └────► uncertain   (handed over, arrival not confirmed)
 *     │  ├────────────────► failed      (not handed over; the server's own reason)
 *     │  └────────────────► discarded   (the user withdrew it)
 *     └──── uncertain | failed          (the user's Send anyway / Send again — once)
 *
 * Nothing a client says is read as delivery evidence: not an absence, a
 * timestamp, a scope, or text. The one piece of evidence from outside this file
 * is the RECEIVER's own record: every prompt the outbox hands over carries the
 * row's id (`ref q-…`) in its header, so the session's transcript — written by
 * the CLI when it takes the message — can confirm an arrival. That check can
 * only move a row TOWARD delivered; it never authorises a send.
 *
 * Why (four rounds, one shape): each earlier round had a reader INFER delivery
 * from something that can lie or forget — a tab's memory, localStorage locks,
 * transcript text, an evicting ledger, client clocks. Here the owner of the row
 * declares its state (ARCH-010), and nothing is evicted.
 *
 * STORAGE. One append-only journal per session, `outbox/<session>.jsonl`, one
 * JSON line per transition (a batch's transition is ONE line), each fsync'd
 * before the caller proceeds, plus `<session>.head` recording the last line
 * number, so a file truncated at a line boundary is detected too. On load, a
 * row caught `sending` becomes `uncertain` (a crash between handover and its
 * record) unless the transcript shows it arrived. ANY damage — an unparsable
 * line, a missing or disagreeing head, a gap — fails LOUDLY: every row that
 * had not finished becomes `uncertain`, the file is copied aside, and the
 * session carries a `damaged` notice until the user dismisses it; while it is
 * set, a nonce the outbox does not know arrives `uncertain` (its record may be
 * the line that was lost). No row is ever evicted.
 *
 * DELIVERY. `pumpOutbox` runs on every change and on a short tick for sessions
 * holding a queued row — whether or not any tab is open. It asks the wiring
 * (index.ts, which owns bridges/survivors/spawning) whether the session can
 * take a turn NOW (`probe`, synchronous), writes the batch `sending`, then
 * hands it over (`handOver`) and writes the outcome. The wiring holds the
 * session's delivery reservation (BUG-191's `deliveryInFlight`) across all of
 * it, so no socket path can race a second prompt in.
 */
import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { dataDir, writeAtomic } from '../lib/paths.ts';

export type OutboxState = 'queued' | 'sending' | 'delivered' | 'uncertain' | 'failed' | 'discarded';

/** How the server would resume this session if no bridge holds it — the tab's settings when the row was made. */
export interface ResumeSettings {
  projectId: string;
  encodedDir: string | null;
  overrides: Record<string, unknown> | null;
  templateIds: string[] | null;
}

export interface OutboxRow {
  id: string;
  nonce: string;
  /** Delivery order — assigned by the server when the row is made. */
  seq: number;
  text: string;
  /** `queued`: typed while Claude was working. `direct`: a typed send the session could not take at once. */
  origin: 'queued' | 'direct';
  state: OutboxState;
  /** Plain words for the dock: why it failed / is uncertain. */
  reason: string | null;
  createdAt: number;
  updatedAt: number;
  /** Interrupt & send: goes alone, first, at the boundary. */
  forced: boolean;
  /** The user's Send now over "another program is writing this session". */
  overrideExternal: boolean;
  /** Which route handed it over. */
  via: string | null;
  /** The transcript shows it arrived. */
  confirmed: boolean;
  sentAt: number | null;
  /** Transcript size just before the handover — where to look for its ref. */
  sizeAtSend: number | null;
  resume: ResumeSettings;
  /** Hash of the create request — a replayed nonce must carry the same request. */
  payload: string;
}

export interface OutboxHold { kind: string; text: string; drain?: unknown }

export interface ProbeWait { kind: 'wait'; hold: OutboxHold; retryMs?: number }
export interface ProbeGo { kind: 'go'; route: string; ctx?: unknown }
export type Probe = ProbeWait | ProbeGo;
export type HandOutcome =
  | { kind: 'delivered'; via: string }
  | { kind: 'refused'; hold: OutboxHold; retryMs?: number }
  | { kind: 'uncertain'; reason: string }
  | { kind: 'failed'; reason: string };

export interface OutboxWiring {
  /** Can the session take a turn right now? Synchronous: nothing may change between this and the handover. */
  probe(sessionId: string, resume: ResumeSettings, opts: { overrideExternal: boolean; forced: boolean }): Probe;
  /** Take / release the session's delivery reservation (shared with the socket paths). */
  reserve(sessionId: string): () => void;
  /** Hand the prompt over. Must not throw synchronously before it has either handed over or refused. */
  handOver(sessionId: string, go: ProbeGo, prompt: string, resume: ResumeSettings): Promise<HandOutcome>;
  /** The receiver's record: does the session transcript contain `needle` after `from` bytes? null = unreadable. */
  transcriptHas(sessionId: string, resume: ResumeSettings, needle: string, from: number): boolean | null;
  transcriptSize(sessionId: string, resume: ResumeSettings): number | null;
  /** Interrupt a busy bridge (FEAT-031); resolves once the interrupt has been sent. */
  interrupt(sessionId: string): Promise<void> | null;
  /** Something changed that a driving tab should see at once (the outbox-turn event etc.). */
  announce(sessionId: string, e: { t: 'outbox-turn'; sessionId: string; text: string; ids: string[] }): void;
}

interface Box {
  sid: string;
  rows: Map<string, OutboxRow>;
  byNonce: Map<string, string>;
  seq: number;
  lsn: number;
  lines: number;
  damaged: { at: number; detail: string } | null;
  hold: OutboxHold | null;
  nextTryAt: number;
  reserved: boolean;
  /** Consecutive refusals of a resume, for backoff. */
  refusals: number;
  interrupting: Promise<void> | null;
}

const SID_RE = /^[A-Za-z0-9._-]{1,128}$/;
const NONCE_RE = /^[A-Za-z0-9._:-]{8,128}$/;
export const MAX_TEXT = 200_000;
/** A row delivered this recently and not yet seen in the transcript is checked again after a restart. */
const RECOVER_WINDOW_MS = 10 * 60_000;
/** How long an `uncertain` row keeps looking for its ref in the transcript. */
const UNCERTAIN_RECHECK_MS = 10 * 60_000;
const TICK_MS = 500;

const boxes = new Map<string, Box>();
let wiring: OutboxWiring | null = null;
let timer: NodeJS.Timeout | null = null;
/** The server is going down: hand nothing more over (a turn started now would be orphaned mid-handover). */
let stopped = false;

export class OutboxError extends Error {
  readonly status: number;
  readonly extra: Record<string, unknown>;
  constructor(message: string, status: number, extra: Record<string, unknown> = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

function root(): string { return path.join(dataDir(), 'outbox'); }
function journalOf(sid: string): string { return path.join(root(), `${sid}.jsonl`); }
function headOf(sid: string): string { return path.join(root(), `${sid}.head`); }

export function validSessionId(sid: unknown): sid is string {
  return typeof sid === 'string' && SID_RE.test(sid) && !sid.includes('..');
}

function fsyncDir(dir: string): void {
  let fd: number | null = null;
  try { fd = fs.openSync(dir, 'r'); fs.fsyncSync(fd); } catch { /* best effort: not every fs allows a dir fsync */ } finally { if (fd != null) fs.closeSync(fd); }
}

/* ------------------------------------------------------------------ loading */

function blankBox(sid: string): Box {
  return { sid, rows: new Map(), byNonce: new Map(), seq: 0, lsn: 0, lines: 0, damaged: null, hold: null, nextTryAt: 0, reserved: false, refusals: 0, interrupting: null };
}

function isRow(v: unknown): v is OutboxRow {
  const r = v as OutboxRow;
  return !!r && typeof r.id === 'string' && typeof r.nonce === 'string' && typeof r.text === 'string'
    && typeof r.seq === 'number' && typeof r.state === 'string' && !!r.resume && typeof r.resume.projectId === 'string';
}

function load(sid: string): Box {
  const box = blankBox(sid);
  const file = journalOf(sid);
  let text: string | null = null;
  try { text = fs.readFileSync(file, 'utf8'); } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') {
      // Cannot read what it holds: refuse everything for this session rather than pretend it is empty.
      throw new OutboxError(`the saved queue for this session cannot be read (${(err as Error).message})`, 500);
    }
  }
  if (text === null) return box;
  const problems: string[] = [];
  let head: number | null = null;
  try { head = Number(JSON.parse(fs.readFileSync(headOf(sid), 'utf8'))?.lsn); } catch (err) {
    // An empty journal with no head is a create that never finished (nothing was acknowledged from it).
    if (text.trim()) problems.push((err as NodeJS.ErrnoException).code === 'ENOENT' ? 'its head record is missing' : 'its head record is unreadable');
  }
  const segs = text.split('\n');
  let expect = 1;
  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    if (!s.trim()) continue;
    let o: { lsn?: unknown; rows?: unknown; damaged?: unknown } | null = null;
    try { o = JSON.parse(s); } catch { /* below */ }
    if (!o || typeof o !== 'object' || typeof o.lsn !== 'number') {
      problems.push(i === segs.length - 1 ? 'its last line is cut off' : `line ${i + 1} is unreadable`);
      continue;
    }
    if (o.lsn !== expect) problems.push(`line ${i + 1} is out of sequence (${o.lsn}, expected ${expect})`);
    expect = o.lsn + 1;
    box.lsn = Math.max(box.lsn, o.lsn);
    box.lines++;
    if (Array.isArray(o.rows)) {
      for (const r of o.rows) {
        if (!isRow(r)) { problems.push(`line ${i + 1} holds a malformed row`); continue; }
        box.rows.set(r.id, { ...r });
        box.byNonce.set(r.nonce, r.id);
        box.seq = Math.max(box.seq, r.seq);
      }
    }
    if ('damaged' in o) box.damaged = (o.damaged as Box['damaged']) ?? null;
  }
  if (head != null && Number.isFinite(head) && head > box.lsn) problems.push(`it ends at line ${box.lsn} but was written up to line ${head} — it was truncated`);
  const now = Date.now();
  const fixes: OutboxRow[] = [];
  if (problems.length) {
    const detail = problems.join('; ');
    console.error(`[orchard] BUG-217: the outbox of session ${sid} is DAMAGED (${detail}) — every message it had not finished is now marked "not confirmed"; nothing is sent from it until the user decides`);
    try { fs.copyFileSync(file, `${file}.corrupt-${now}`); } catch { /* the rewrite below still leaves it readable */ }
    box.damaged = { at: now, detail };
    for (const r of box.rows.values()) {
      if (r.state === 'queued' || r.state === 'sending') {
        fixes.push({ ...r, state: 'uncertain', updatedAt: now, reason: 'Orchard’s saved queue for this session was damaged, so it cannot tell whether this was already sent — check the conversation, then Send anyway or Discard' });
      }
    }
  }
  for (const r of box.rows.values()) {
    if (fixes.some((f) => f.id === r.id)) continue;
    if (r.state === 'sending') {
      fixes.push({ ...r, state: 'uncertain', updatedAt: now, reason: 'Orchard stopped while sending this, so it may or may not have arrived — check the conversation, then Send anyway or Discard' });
    }
  }
  for (const f of fixes) box.rows.set(f.id, f);
  if (problems.length) {
    // Rewrite a clean journal from what survived (the damaged copy is kept beside it).
    compact(box, { damaged: box.damaged });
  } else if (fixes.length) {
    append(box, fixes);
  }
  return box;
}

/** Recovery for rows a crash may have left mid-flight: the transcript is the receiver's record. */
function recover(box: Box): void {
  if (!wiring) return;
  const now = Date.now();
  const out: OutboxRow[] = [];
  for (const r of box.rows.values()) {
    const recent = r.sentAt != null && now - r.sentAt < RECOVER_WINDOW_MS;
    if (!recent || r.confirmed) continue;
    if (r.state !== 'delivered' && r.state !== 'uncertain') continue;
    const has = wiring.transcriptHas(box.sid, r.resume, r.id, 0);
    if (has === true) out.push({ ...r, state: 'delivered', confirmed: true, reason: null, updatedAt: now });
    else if (r.state === 'delivered') {
      out.push({ ...r, state: 'uncertain', updatedAt: now, reason: 'Orchard restarted right after handing this over, and it is not in the conversation yet — it may not have arrived. Check, then Send anyway or Discard' });
    }
  }
  if (out.length) append(box, out);
}

function boxOf(sid: string): Box {
  const hit = boxes.get(sid);
  if (hit) return hit;
  const b = load(sid);
  boxes.set(sid, b);
  recover(b);
  return b;
}

/* ------------------------------------------------------------------ writing */

/** Test-only crash point: SIGKILL this process right after the named transition is on disk. */
function crashPoint(name: string): void {
  if (process.env.ORCHARD_TEST_OUTBOX_CRASH_AT === name && process.env.CLAUDE_STATION_DATA) {
    console.error(`[orchard] BUG-217 test crash point: ${name}`);
    process.kill(process.pid, 'SIGKILL');
  }
}

function writeLine(box: Box, obj: Record<string, unknown>): void {
  const dir = root();
  const file = journalOf(box.sid);
  const fresh = !fs.existsSync(file);
  if (fresh) fs.mkdirSync(dir, { recursive: true });
  const lsn = box.lsn + 1;
  const line = `${JSON.stringify({ lsn, ...obj })}\n`;
  const fd = fs.openSync(file, 'a', 0o600);
  try { fs.writeSync(fd, line); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  if (fresh) fsyncDir(dir);
  box.lsn = lsn;
  box.lines++;
  writeAtomic(headOf(box.sid), JSON.stringify({ lsn }));
}

/** Put rows on disk, then in memory. Throws (and changes nothing in memory) when the disk refuses. */
function append(box: Box, rows: OutboxRow[]): void {
  writeLine(box, { rows });
  for (const r of rows) { box.rows.set(r.id, r); box.byNonce.set(r.nonce, r.id); box.seq = Math.max(box.seq, r.seq); }
  if (box.lines > 64 + 4 * box.rows.size) compact(box, { damaged: box.damaged });
}

function compact(box: Box, { damaged }: { damaged: Box['damaged'] }): void {
  const dir = root();
  fs.mkdirSync(dir, { recursive: true });
  const rows = [...box.rows.values()].sort((a, b) => a.seq - b.seq);
  const lines = [JSON.stringify({ lsn: 1, rows }), JSON.stringify({ lsn: 2, damaged })];
  writeAtomic(journalOf(box.sid), `${lines.join('\n')}\n`);
  fsyncDir(dir);
  box.lsn = 2;
  box.lines = 2;
  writeAtomic(headOf(box.sid), JSON.stringify({ lsn: 2 }));
}

/* ------------------------------------------------------------------ reading */

export interface OutboxView {
  sessionId: string;
  rows: Array<Pick<OutboxRow, 'id' | 'nonce' | 'seq' | 'text' | 'origin' | 'state' | 'reason' | 'createdAt' | 'updatedAt' | 'forced' | 'via'>>;
  /** Rows that finished in the last two minutes — so a tab can say "sent", and follow a turn it did not start. */
  recent: Array<Pick<OutboxRow, 'id' | 'nonce' | 'state' | 'via' | 'updatedAt'>>;
  hold: OutboxHold | null;
  damaged: Box['damaged'];
}

const RECENT_MS = 120_000;
function view(box: Box): OutboxView {
  const all = [...box.rows.values()].sort((a, b) => a.seq - b.seq);
  const rows = all
    .filter((r) => r.state !== 'delivered' && r.state !== 'discarded')
    .map(({ id, nonce, seq, text, origin, state, reason, createdAt, updatedAt, forced, via }) => ({ id, nonce, seq, text, origin, state, reason, createdAt, updatedAt, forced, via }));
  const now = Date.now();
  const recent = all
    .filter((r) => (r.state === 'delivered' || r.state === 'discarded') && now - r.updatedAt < RECENT_MS)
    .map(({ id, nonce, state, via, updatedAt }) => ({ id, nonce, state, via, updatedAt }));
  return { sessionId: box.sid, rows, recent, hold: rows.some((r) => r.state === 'queued') ? box.hold : null, damaged: box.damaged };
}

export function outboxView(sid: string): OutboxView {
  if (!validSessionId(sid)) throw new OutboxError('bad session id', 400);
  return view(boxOf(sid));
}

/** Has this session ever had an outbox (in memory or on disk)? A read of an unknown id creates nothing. */
export function outboxExists(sid: string): boolean {
  return validSessionId(sid) && (boxes.has(sid) || fs.existsSync(journalOf(sid)));
}

/** Does this session hold a row still waiting to go (so a typed prompt must queue behind it)? */
export function outboxHasPending(sid: string | null | undefined): boolean {
  if (!sid || !validSessionId(sid)) return false;
  const b = boxes.get(sid);
  if (!b) {
    if (!fs.existsSync(journalOf(sid))) return false;
    try { return [...boxOf(sid).rows.values()].some((r) => r.state === 'queued' || r.state === 'sending'); } catch { return false; }
  }
  return [...b.rows.values()].some((r) => r.state === 'queued' || r.state === 'sending');
}

/** The state of one row (tests, and the delivered/discarded answer to a late edit). */
export function outboxRow(sid: string, id: string): OutboxRow | null {
  if (!validSessionId(sid)) return null;
  return boxOf(sid).rows.get(id) ?? null;
}

/* ---------------------------------------------------------------- mutations */

export interface CreateRequest {
  nonce: string;
  text: string;
  origin?: 'queued' | 'direct';
  /** A client may only make a row MORE cautious: `uncertain` or `failed` rows are never sent by themselves. */
  initial?: 'queued' | 'uncertain' | 'failed';
  reason?: string | null;
  /**
   * The user discarded this row before the server acknowledged it. If the
   * nonce is known the row is discarded (when it still can be); otherwise it
   * is recorded already discarded, so it can never be delivered.
   */
  discard?: boolean;
  resume: ResumeSettings;
}

function payloadOf(req: CreateRequest): string {
  return crypto.createHash('sha256').update(JSON.stringify([req.text, req.origin ?? 'queued', req.initial ?? 'queued', req.reason ?? null])).digest('hex').slice(0, 24);
}

export function createOutboxRow(sid: string, req: CreateRequest): { row: OutboxRow; created: boolean; view: OutboxView } {
  if (!validSessionId(sid)) throw new OutboxError('bad session id', 400);
  if (typeof req.nonce !== 'string' || !NONCE_RE.test(req.nonce)) throw new OutboxError('a nonce (8–128 chars of [A-Za-z0-9._:-]) is required', 400);
  if (typeof req.text !== 'string' || !req.text.trim()) throw new OutboxError('text is required', 400);
  if (req.text.length > MAX_TEXT) throw new OutboxError(`text is longer than ${MAX_TEXT} characters`, 413);
  const box = boxOf(sid);
  const payload = payloadOf(req);
  const known = box.byNonce.get(req.nonce);
  if (known) {
    const row = box.rows.get(known)!;
    // Idempotent: the same request again is the same row. A different request under the same nonce is a bug, never a merge.
    if (row.payload !== payload) throw new OutboxError('this nonce was already used for a different message', 409, { row: { id: row.id, state: row.state } });
    if (req.discard && (row.state === 'queued' || row.state === 'uncertain' || row.state === 'failed')) {
      const gone: OutboxRow = { ...row, state: 'discarded', updatedAt: Date.now() };
      append(box, [gone]);
      return { row: gone, created: false, view: view(box) };
    }
    return { row, created: false, view: view(box) };
  }
  const now = Date.now();
  let state: OutboxState = req.discard ? 'discarded' : req.initial === 'uncertain' || req.initial === 'failed' ? req.initial : 'queued';
  let reason = state === 'queued' ? null : (typeof req.reason === 'string' && req.reason.trim() ? req.reason.trim().slice(0, 400) : null);
  if (state === 'queued' && box.damaged) {
    // A lost line could have held this nonce (already delivered): ask rather than send.
    state = 'uncertain';
    reason = 'Orchard’s saved queue for this session was damaged, so it cannot tell whether this was already sent — check the conversation, then Send anyway or Discard';
  }
  if (state === 'uncertain' && !reason) reason = 'it may already have been sent — check the conversation, then Send anyway or Discard';
  if (state === 'failed' && !reason) reason = 'it was not sent';
  const row: OutboxRow = {
    id: `q${crypto.randomBytes(8).toString('hex')}`,
    nonce: req.nonce,
    seq: box.seq + 1,
    text: req.text,
    origin: req.origin === 'direct' ? 'direct' : 'queued',
    state,
    reason,
    createdAt: now,
    updatedAt: now,
    forced: false,
    overrideExternal: false,
    via: null,
    confirmed: false,
    sentAt: null,
    sizeAtSend: null,
    resume: req.resume,
    payload,
  };
  append(box, [row]);
  crashPoint('created');
  holdNow(box);
  kick(sid);
  return { row, created: true, view: view(box) };
}

function mutable(box: Box, id: string, verb: string, allowed: OutboxState[]): OutboxRow {
  const row = box.rows.get(id);
  if (!row) throw new OutboxError(`no queued message ${id} in this session`, 404);
  if (!allowed.includes(row.state)) {
    const why = row.state === 'sending' ? 'it is being sent right now'
      : row.state === 'delivered' ? 'it has already been sent'
        : row.state === 'discarded' ? 'it was discarded'
          : `it is ${row.state}`;
    throw new OutboxError(`cannot ${verb} this message: ${why}`, 409, { row: { id: row.id, state: row.state } });
  }
  return row;
}

export function editOutboxRow(sid: string, id: string, text: unknown): OutboxView {
  if (typeof text !== 'string' || !text.trim()) throw new OutboxError('text is required (Discard removes a message)', 400);
  if (text.length > MAX_TEXT) throw new OutboxError(`text is longer than ${MAX_TEXT} characters`, 413);
  const box = boxOf(sid);
  const row = mutable(box, id, 'edit', ['queued', 'uncertain', 'failed']);
  append(box, [{ ...row, text, updatedAt: Date.now() }]);
  crashPoint('edited');
  return view(box);
}

export function discardOutboxRow(sid: string, id: string): OutboxView {
  const box = boxOf(sid);
  const row = mutable(box, id, 'discard', ['queued', 'uncertain', 'failed']);
  append(box, [{ ...row, state: 'discarded', updatedAt: Date.now() }]);
  crashPoint('discarded');
  kick(sid);
  return view(box);
}

/**
 * The user's Send anyway / Send again / Send now / Interrupt & send.
 *  - `anyway` (Send anyway, Send again): uncertain | failed → queued, ONCE — a
 *    second press finds it queued, sending or delivered and is refused (409);
 *  - `now` (Send now) on a queued row: it may go past "another program is
 *    writing this session" — the user's say-so over that heuristic;
 *  - `interrupt` on a queued row → FEAT-031: it goes alone, first, and a
 *    running turn is interrupted for it.
 */
export function sendOutboxRow(sid: string, id: string, { interrupt = false, now = false }: { interrupt?: boolean; now?: boolean } = {}): OutboxView {
  const box = boxOf(sid);
  const row = box.rows.get(id);
  if (row && row.state === 'queued') {
    if (!interrupt && !now) throw new OutboxError('this message is already waiting to be sent', 409, { row: { id: row.id, state: row.state } });
    // A second Interrupt & send for a row already forced asks nothing more: a late second
    // interrupt could land on the forced turn itself (plan review B5).
    if (interrupt && row.forced) return view(box);
    append(box, [{ ...row, forced: row.forced || interrupt, overrideExternal: true, updatedAt: Date.now() }]);
  } else {
    const r = mutable(box, id, 'send', ['uncertain', 'failed']);
    append(box, [{ ...r, state: 'queued', reason: null, forced: interrupt, overrideExternal: true, updatedAt: Date.now() }]);
    crashPoint('requeued');
  }
  if (interrupt && wiring) {
    const p = wiring.interrupt(sid);
    if (p) {
      // The forced row waits until the interrupt has been sent (a later boundary must not swallow it).
      const inter: Promise<void> = p.then(() => undefined, () => undefined);
      box.interrupting = inter;
      void inter.then(() => { if (box.interrupting === inter) box.interrupting = null; kick(sid); });
    }
  }
  box.nextTryAt = 0;
  holdNow(box);
  kick(sid);
  return view(box);
}

export function dismissOutboxDamage(sid: string): OutboxView {
  const box = boxOf(sid);
  if (box.damaged) { writeLine(box, { damaged: null }); box.damaged = null; }
  return view(box);
}

/* ------------------------------------------------------------------ delivery */

function fmtElapsed(ms: number): string {
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  return `${m}m${String(s % 60).padStart(2, '0')}s`;
}

/** The prompt for a batch: each row keeps its own header (FEAT-031 Part B), and every header carries the row's ref. */
export function composeOutboxPrompt(rows: OutboxRow[], now = Date.now()): string {
  if (rows.length === 1) {
    const r = rows[0];
    const ago = fmtElapsed(now - r.createdAt);
    const head = r.forced
      ? `[Force-sent ${ago} after being queued — in-flight work was interrupted to deliver this immediately. ref ${r.id}]`
      : r.origin === 'direct'
        ? `[Held ${ago} until the session could take it. ref ${r.id}]`
        : `[Queued ${ago} ago, composed while the previous response was still being written — it predates that response. ref ${r.id}]`;
    return `${head}\n${r.text.trim()}`;
  }
  return rows.map((r, i) => {
    const ago = fmtElapsed(now - r.createdAt);
    const what = r.origin === 'direct' ? `held ${ago} until the session could take it` : `queued ${ago} ago, composed while the previous response was still being written`;
    return `[msg ${i + 1}/${rows.length} · ${what} · ref ${r.id}]\n${r.text.trim()}`;
  }).join('\n\n');
}

const settingsKey = (r: OutboxRow) => JSON.stringify([r.resume.projectId, r.resume.encodedDir, r.resume.overrides ?? null, r.resume.templateIds ?? null]);

/** What goes next: a forced row alone; else every queued row in order, cut where the resume settings change. */
function nextBatch(box: Box): OutboxRow[] {
  const queued = [...box.rows.values()].filter((r) => r.state === 'queued').sort((a, b) => a.seq - b.seq);
  if (!queued.length) return [];
  const forced = queued.find((r) => r.forced);
  if (forced) return [forced];
  const key = settingsKey(queued[0]);
  const out: OutboxRow[] = [];
  for (const r of queued) { if (settingsKey(r) !== key) break; out.push(r); }
  return out;
}

/** Say at once why the next row waits (the answer to a create should not claim "sending" while Claude works). */
function holdNow(box: Box): void {
  if (!wiring || box.reserved) return;
  const head = nextBatch(box)[0];
  if (!head) return;
  try {
    const p = wiring.probe(box.sid, head.resume, { overrideExternal: head.overrideExternal, forced: head.forced });
    box.hold = p.kind === 'wait' ? p.hold : { kind: 'sending', text: 'sending now' };
  } catch { /* the pump decides */ }
}

function kick(sid: string): void {
  setImmediate(() => { void pump(sid); });
}

async function pump(sid: string): Promise<void> {
  if (!wiring || stopped) return;
  let box: Box;
  try { box = boxOf(sid); } catch { return; }
  if (box.reserved || box.interrupting) return;
  if (Date.now() < box.nextTryAt) return;
  const batch = nextBatch(box);
  if (!batch.length) { box.hold = null; return; }
  const head = batch[0];
  const p = wiring.probe(sid, head.resume, { overrideExternal: batch.every((r) => r.overrideExternal), forced: head.forced });
  if (p.kind === 'wait') {
    if (box.hold?.kind !== p.hold.kind) console.log(`[orchard] BUG-217: outbox ${sid} waits (${p.hold.kind}): ${p.hold.text}`);
    box.hold = p.hold;
    box.nextTryAt = Date.now() + (p.retryMs ?? 0);
    return;
  }
  // The reservation is taken in the same tick as the probe: no socket path can slip a prompt in between.
  box.reserved = true;
  const release = wiring.reserve(sid);
  try {
    const now = Date.now();
    const prompt = composeOutboxPrompt(batch, now);
    const size = wiring.transcriptSize(sid, head.resume);
    try {
      append(box, batch.map((r) => ({ ...r, state: 'sending' as const, sentAt: now, sizeAtSend: size, updatedAt: now })));
    } catch (err) {
      box.hold = { kind: 'disk', text: `Orchard cannot write its queue to disk (${(err as Error).message}), so it is not sending anything — nothing was lost` };
      box.nextTryAt = Date.now() + 5000;
      console.error(`[orchard] BUG-217: outbox ${sid}: the sending record could not be written — nothing handed over (${(err as Error).message})`);
      return;
    }
    crashPoint('sending');
    box.hold = { kind: 'sending', text: 'sending…' };
    let out: HandOutcome;
    try { out = await wiring.handOver(sid, p, prompt, head.resume); }
    catch (err) { out = { kind: 'uncertain', reason: `the handover failed part-way (${(err as Error).message}) — it may or may not have arrived. Check the conversation, then Send anyway or Discard` }; }
    crashPoint('handed-over');
    const t = Date.now();
    const cur = batch.map((r) => box.rows.get(r.id)!).filter(Boolean);
    let next: OutboxRow[];
    if (out.kind === 'delivered') {
      next = cur.map((r) => ({ ...r, state: 'delivered' as const, via: out.via, reason: null, updatedAt: t }));
      box.refusals = 0;
      box.hold = null;
    } else if (out.kind === 'refused') {
      next = cur.map((r) => ({ ...r, state: 'queued' as const, sentAt: null, sizeAtSend: null, updatedAt: t }));
      box.refusals++;
      box.hold = out.hold;
      box.nextTryAt = t + (out.retryMs ?? Math.min(60_000, 2000 * 2 ** Math.min(5, box.refusals - 1)));
    } else if (out.kind === 'uncertain') {
      next = cur.map((r) => ({ ...r, state: 'uncertain' as const, reason: out.reason, updatedAt: t }));
      box.hold = null;
    } else {
      next = cur.map((r) => ({ ...r, state: 'failed' as const, sentAt: null, sizeAtSend: null, reason: out.reason, updatedAt: t }));
      box.hold = null;
    }
    try { append(box, next); } catch (err) {
      // The outcome could not be recorded; the on-disk `sending` reloads as uncertain. Keep memory honest meanwhile.
      console.error(`[orchard] BUG-217: outbox ${sid}: the outcome (${out.kind}) could not be written (${(err as Error).message}) — a restart will show these as not confirmed`);
      for (const r of next) box.rows.set(r.id, out.kind === 'refused' ? { ...r, state: 'uncertain', reason: 'Orchard could not record what happened to this — check the conversation, then Send anyway or Discard' } : r);
    }
    if (out.kind === 'delivered') {
      crashPoint('delivered');
      try { wiring.announce(sid, { t: 'outbox-turn', sessionId: sid, text: prompt, ids: batch.map((r) => r.id) }); } catch { /* a tab that misses it reads the transcript */ }
    }
  } finally {
    box.reserved = false;
    release();
  }
  kick(sid);
}

/** Confirm recent deliveries and settle uncertain rows from the receiver's record. Only ever moves toward delivered. */
function confirmFromTranscript(box: Box): void {
  if (!wiring) return;
  const now = Date.now();
  const out: OutboxRow[] = [];
  for (const r of box.rows.values()) {
    if (r.confirmed || r.sentAt == null) continue;
    if (r.state === 'delivered' && now - r.sentAt < RECOVER_WINDOW_MS) {
      if (wiring.transcriptHas(box.sid, r.resume, r.id, r.sizeAtSend ?? 0) === true) out.push({ ...r, confirmed: true, updatedAt: now });
    } else if (r.state === 'uncertain' && now - r.updatedAt < UNCERTAIN_RECHECK_MS) {
      if (wiring.transcriptHas(box.sid, r.resume, r.id, 0) === true) {
        out.push({ ...r, state: 'delivered', confirmed: true, reason: null, updatedAt: now });
      }
    }
  }
  if (out.length) { try { append(box, out); } catch { /* retried next tick */ } }
}

let tickN = 0;
function tick(): void {
  tickN++;
  for (const box of boxes.values()) {
    const rows = [...box.rows.values()];
    if (rows.some((r) => r.state === 'queued')) void pump(box.sid);
    // Transcript reads are cheaper than they look but not free: every 2 s is plenty for a confirmation.
    if (tickN % 4 === 0 && rows.some((r) => !r.confirmed && r.sentAt != null && (r.state === 'delivered' || r.state === 'uncertain'))) confirmFromTranscript(box);
  }
}

/**
 * Boot: wire the engine, load EVERY journal on disk and schedule delivery — a
 * row queued before a restart goes by itself, whether or not any tab ever opens.
 */
export function startOutbox(w: OutboxWiring): void {
  wiring = w;
  let names: string[] = [];
  try { names = fs.readdirSync(root()); } catch { /* no outbox yet */ }
  for (const n of names) {
    const m = /^(.+)\.jsonl$/.exec(n);
    if (!m || !validSessionId(m[1])) continue;
    try { boxOf(m[1]); } catch (err) { console.error(`[orchard] BUG-217: outbox ${m[1]} could not be loaded: ${(err as Error).message}`); }
  }
  if (!timer) { timer = setInterval(tick, TICK_MS); timer.unref?.(); }
  for (const sid of boxes.keys()) kick(sid);
}

/** Shutdown: stop delivering. Rows stay queued on disk and the next boot delivers them. */
export function stopOutbox(): void {
  stopped = true;
  if (timer) { clearInterval(timer); timer = null; }
}

/** A bridge became idle (or anything else a queued row may have been waiting for) — look now, not at the next tick. */
export function nudgeOutbox(sid: string | null | undefined): void {
  if (!sid || !boxes.has(sid)) return;
  const b = boxes.get(sid)!;
  b.nextTryAt = 0;
  kick(sid);
}
